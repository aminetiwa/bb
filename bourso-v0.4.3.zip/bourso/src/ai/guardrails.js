// ============================================================================
//  BOURSO :: guardrails.js — « l'IA propose, le code dispose ».
//  Règles déterministes appliquées APRÈS le modèle : un LLM ne peut jamais émettre
//  un STRONG_* quand actualités et marché se contredisent, sur des données périmées, un carnet disloqué,
//  ni un stop du mauvais côté. Chaque intervention est tracée dans `notes`.
// ============================================================================

export const DEFAULT_RISK = Object.freeze({
  minConfidence: 0.55,          // en dessous : HOLD
  strongConfidence: 0.75,       // seuil des STRONG_*
  conflictOverride: 0.8,        // confiance requise pour trader malgré un conflit (jamais STRONG)
  maxStaleMs: 5_000,            // fraîcheur maximale des features
  maxSpreadTicks: 4,
  maxSizeFraction: 0.5,         // fraction max du budget de risque par signal
  maxEntryDeviationPct: 1.5,    // entrée à ±1,5 % du prix courant au plus
  maxStopPct: 3,                // invalidation à 3 % de l'entrée au plus… (ou maxStopAtr × ATR si plus large)
  maxStopAtr: 2.5,              // …une valeur agitée a droit à un stop proportionné à sa volatilité
  minStopTicks: 4,              // …et à 4 ticks au moins (plus près = bruit du carnet)
  minStopAtr: 0.5,              // …et à 0,5 ATR au moins : plus près, le bruit quotidien suffit à le toucher
  minRewardRisk: 1.2,           // rendement (1re cible) / risque (invalidation) minimal
  directionThreshold: 0.15,     // |score| minimal pour qu'un agent « ait un avis »
  directionMinConfidence: 0.4,
  newsDirectionThreshold: 0.35, // actualités : une tonalité plus faible ne contredit pas le marché…
  newsMinConfidence: 0.5,       // …ni une lecture peu sûre (sinon presque tout finissait en HOLD)
});

export const DIRECTION = Object.freeze({ STRONG_BUY: 1, BUY: 1, HOLD: 0, SELL: -1, STRONG_SELL: -1 });
const isStrong = (d) => d === 'STRONG_BUY' || d === 'STRONG_SELL';
const weaken = (d) => (d === 'STRONG_BUY' ? 'BUY' : d === 'STRONG_SELL' ? 'SELL' : d);

export function agentDirection(score, confidence, risk = DEFAULT_RISK) {
  if (!Number.isFinite(score) || !Number.isFinite(confidence)) return 0;
  if (Math.abs(score) < risk.directionThreshold || confidence < risk.directionMinConfidence) return 0;
  return Math.sign(score);
}

/** Accord calculé (et non déclaré par le LLM) entre la lecture des actualités et celle du marché. */
export function computeAgreement(sentiment, quant, risk = DEFAULT_RISK) {
  const newsRisk = { ...risk, directionThreshold: risk.newsDirectionThreshold ?? risk.directionThreshold, directionMinConfidence: risk.newsMinConfidence ?? risk.directionMinConfidence };
  const s = sentiment ? agentDirection(sentiment.aggregate?.score, sentiment.aggregate?.confidence, newsRisk) : 0;
  const q = quant ? agentDirection(quant.bias, quant.confidence, risk) : 0;
  return { s, q, agreement: s && q ? (s === q ? 'ALIGNED' : 'CONFLICT') : 'PARTIAL' };
}

function decimalsOf(tick) {
  for (let d = 0; d <= 10; d++) {
    const s = tick * 10 ** d;
    if (Math.abs(s - Math.round(s)) < 1e-9 * Math.max(1, s)) return d;
  }
  return 10;
}
export const roundToTick = (x, tick) => Number((Math.round(x / tick) * tick).toFixed(decimalsOf(tick)));

/** Niveaux structurels du profil de volume (le « mur » du carnet est exclu : annulable, spoofable). */
function levelsOf(f) {
  const vp = f?.volume_profile ?? {};
  // v0.3 : supports, résistances et pivots du dossier complet s'ajoutent aux niveaux du profil
  return [vp.poc, vp.vah, vp.val, ...(vp.hvn ?? []), ...(vp.lvn ?? []), ...(f?.levels ?? [])].filter(Number.isFinite);
}

/** Recale le plan de trade sur des niveaux réels. @returns {string|null} raison d'abandon éventuelle */
function fixPlan(d, f, risk, notes) {
  const dir = DIRECTION[d.decision];
  const p = f.price, tick = f.tick_size ?? 0.01;
  const far = (x) => (Math.abs(x - p) / p) * 100 > risk.maxEntryDeviationPct;
  let low = d.entry?.low, high = d.entry?.high;
  if (!(low > 0 && high > 0) || low > high || far(low) || far(high)) {
    [low, high] = dir > 0 ? [roundToTick(p - tick, tick), roundToTick(p, tick)] : [roundToTick(p, tick), roundToTick(p + tick, tick)];
    notes.push(`Entrée recalée sur le prix courant [${low} ; ${high}]`);
  }
  d.entry = { low, high };
  const ref = dir > 0 ? low : high;
  const stopPct = (x) => (Math.abs(ref - x) / ref) * 100;

  // Invalidation : du bon côté de l'entrée, ni trop près (bruit : ticks et 0,5 ATR) ni trop loin
  // (3 % ou 2,5 ATR) ; sinon le niveau structurel valide le plus proche ; à défaut, 1 ATR.
  const atr = Number.isFinite(f.atr) && f.atr > 0 ? f.atr : 0;
  const maxPct = Math.max(risk.maxStopPct, atr ? (risk.maxStopAtr * atr * 100) / ref : 0);
  const minDist = Math.max(risk.minStopTicks * tick, atr * risk.minStopAtr) - 1e-9;
  const inv = d.invalidation;
  const valid = (x) => Number.isFinite(x) && x > 0 && (dir > 0 ? x < low : x > high) && stopPct(x) <= maxPct + 1e-9 && Math.abs(ref - x) >= minDist;
  if (!valid(inv)) {
    const lv = levelsOf(f).map((x) => roundToTick(x - dir * tick, tick)).filter(valid);
    let cand = dir > 0 ? Math.max(...lv) : Math.min(...lv), why = 'niveau structurel valide le plus proche';
    if (!Number.isFinite(cand) && atr) { cand = roundToTick(ref - dir * atr, tick); why = '1 ATR'; }
    if (!Number.isFinite(cand) || !valid(cand)) return `aucun niveau d'invalidation entre ${(minDist / ref * 100).toFixed(2)} % et ${maxPct.toFixed(2)} % de l'entrée`;
    notes.push(`Invalidation ${Number.isFinite(inv) ? inv : '∅'} → ${cand} (${why}, ${stopPct(cand).toFixed(2)} %)`);
    d.invalidation = cand;
  }

  const raw = (d.targets ?? []).filter(Number.isFinite);
  const ok = raw.filter((x) => (dir > 0 ? x > high : x < low)).sort((a, b) => dir * (a - b));
  if (ok.length !== raw.length) notes.push('Cible(s) du mauvais côté retirée(s)');
  d.targets = ok.slice(0, 3);
  d.reward_risk = null;
  if (d.targets.length) {
    const mid = (low + high) / 2;
    d.reward_risk = Number((Math.abs(d.targets[0] - mid) / Math.abs(mid - d.invalidation)).toFixed(2));
    if (d.reward_risk < risk.minRewardRisk) return `rendement/risque ${d.reward_risk} < ${risk.minRewardRisk}`;
  }
  return null;
}

/**
 * @param {object|null} raw décision validée du modèle
 * @param {{ sentiment?:object, quant?:object, features?:object, risk?:object, failures?:string[] }} ctx
 * @returns {{ decision:object, agreement:string, notes:string[], executable:boolean }}
 */
export function applyGuardrails(raw, { sentiment = null, quant = null, features = null, risk: r = {}, failures = [] } = {}) {
  const risk = { ...DEFAULT_RISK, ...r };
  const notes = [];
  let d = raw && DIRECTION[raw.decision] !== undefined ? { ...raw } : null;
  const hold = (why) => {
    notes.push(why);
    d = { ...(d ?? { confidence: 0, rationale: [], dissent: '', memory_refs: [] }), decision: 'HOLD', entry: { low: 0, high: 0 }, invalidation: 0, targets: [], size_fraction: 0 };
  };
  if (!d) hold('Décision du modèle absente ou invalide → HOLD');

  const { s, q, agreement } = computeAgreement(sentiment, quant, risk);

  if (failures.length >= 2) hold('Les deux agents spécialistes ont échoué → HOLD');
  else if (failures.length === 1 && isStrong(d.decision)) {
    d.decision = weaken(d.decision);
    d.confidence = Math.min(d.confidence, 0.6);
    notes.push(`${failures[0]} indisponible → pas de STRONG, confiance ≤ 0.6`);
  }
  if (Number(features?.age_ms) > risk.maxStaleMs) hold(`Données périmées (${features.age_ms} ms) → HOLD`);
  if (quant && (quant.liquidity === 'DISLOCATED' || quant.regime === 'ILLIQUID')) hold(`Marché ${quant.liquidity}/${quant.regime} → HOLD`);

  if (DIRECTION[d.decision] !== 0 && agreement === 'CONFLICT' && (isStrong(d.decision) || d.confidence < risk.conflictOverride)) {
    hold('Actualités et marché se contredisent (signes opposés) → HOLD');
  }
  const dir = DIRECTION[d.decision];
  if (dir !== 0 && s === -dir && q === -dir) hold('Décision contraire aux actualités ET au marché → HOLD');

  if (isStrong(d.decision)) {
    const why = [];
    if (agreement !== 'ALIGNED' || s !== DIRECTION[d.decision]) why.push(`accord ${agreement}`);
    if (d.confidence < risk.strongConfidence) why.push(`confiance ${d.confidence.toFixed(2)} < ${risk.strongConfidence}`);
    if (quant && !['DEEP', 'NORMAL'].includes(quant.liquidity)) why.push(`liquidité ${quant.liquidity}`);
    if (Number(features?.spread_ticks) > risk.maxSpreadTicks) why.push(`spread ${features.spread_ticks} ticks`);
    if (why.length) {
      notes.push(`${d.decision} rétrogradé en ${weaken(d.decision)} (${why.join(', ')})`);
      d.decision = weaken(d.decision);
    }
  }
  if (DIRECTION[d.decision] !== 0 && d.confidence < risk.minConfidence) {
    hold(`Confiance ${d.confidence.toFixed(2)} < ${risk.minConfidence} → HOLD`);
  }

  if (DIRECTION[d.decision] !== 0 && Number.isFinite(features?.price)) {
    const abort = fixPlan(d, features, risk, notes);
    if (abort) hold(`Plan de trade non viable : ${abort} → HOLD`);
  }

  if (DIRECTION[d.decision] === 0) d.size_fraction = 0;
  else {
    let sz = Math.min(d.size_fraction ?? 0, risk.maxSizeFraction);
    if (quant?.liquidity === 'THIN') {
      sz *= 0.5;
      notes.push('Liquidité THIN → taille ÷ 2');
    }
    d.size_fraction = Number(sz.toFixed(3));
  }

  const active = DIRECTION[d.decision] !== 0;
  const executable = active && features?.session === 'CONTINUOUS';
  if (active && features?.session && features.session !== 'CONTINUOUS') notes.push(`Séance ${features.session} : signal non exécutable automatiquement`);
  if (sentiment?.injection_detected) notes.push('⚠ Tentative d\'injection de prompt détectée dans un document (neutralisée)');
  return { decision: d, agreement, notes, executable };
}

// ============================================================================
//  BOURSO :: server/http.js — API REST + fichiers de l'interface.
//
//  Tout est servi en local (127.0.0.1) : marché, historiques binaires, screener, IA d'analyse,
//  agent Bourso Pro, laboratoire quant (Monte Carlo GPU/CPU vérifié, balayages massifs,
//  walk-forward, Markov, cycles, statistiques, corrélations), ordres simulés, état machine.
//  Protection : en-tête Host et Origin contrôlés (pas de requête venant d'un autre site, pas de
//  « DNS rebinding »), écritures uniquement en JSON, chemins statiques confinés.
// ============================================================================
import { TTF_SOURCE } from '../data/ttf.js';
import { checkSources } from '../data/check.js';
import { DEFAULT_FEEDS } from '../data/news-real.js';
import { readFile, stat } from 'node:fs/promises';
import { join, extname, resolve, sep } from 'node:path';
import { MarketService, TIMEFRAMES } from './market-service.js';
import { systemSnapshot } from './system.js';
import { LEVELS, SWEEP_CODES, fineGrid } from '../compute/service.js';
import { STRATEGIES } from '../core/quant/backtest.js';
import { garch11, logReturns } from '../core/quant/volatility.js';
import { garchSpec } from '../core/quant/montecarlo.js';
import { roundTick, decimalsOf } from '../core/quant/numeric.js';
import { ANALYSE_SCHEMA } from '../ai/schemas.js';
import { ANALYSTE_V3, AGENT_PRO } from '../ai/prompts.js';
import { resolveSymbol } from '../ai/tools.js';
import { EXCHANGES, REGIONS, STATE_LABEL, localTimeOf } from '../market/exchanges.js';
import { SECTORS } from '../market/universe.js';


// ---------------------------------------------------------------- réglages : clés d'API masquées
const KEY_MASK = '••••';
/** Réglages tels que l'interface les voit : les clés d'API ne sortent jamais en clair. */
export function publicSettings(st) {
  if (!st?.data?.keys) return st;
  const keys = Object.fromEntries(Object.entries(st.data.keys).map(([k, v]) => [k, v ? `${KEY_MASK}${String(v).slice(-4)}` : '']));
  return { ...st, data: { ...st.data, keys } };
}
/** Contrôle des réglages « Données » reçus : mode, intensité, clés (le masque = inchangée), flux RSS. */
function cleanDataSettings(d) {
  const out = { ...d };
  if (out.mode !== undefined && !['real', 'demo'].includes(out.mode)) throw new HttpError(400, 'mode de données inconnu (real, demo)');
  if (out.intensity !== undefined && !['econome', 'normale', 'soutenue'].includes(out.intensity)) throw new HttpError(400, 'intensité inconnue (econome, normale, soutenue)');
  if (out.keys && typeof out.keys === 'object') {
    const keys = {};
    for (const [k, v0] of Object.entries(out.keys)) {
      if (!['finnhub', 'fmp', 'twelvedata', 'stooq'].includes(k)) continue;
      const v = String(v0 ?? '').trim();
      if (v.startsWith(KEY_MASK)) continue; // valeur masquée renvoyée telle quelle : on garde la clé enregistrée
      if (v && !/^[\w.-]{4,200}$/.test(v)) throw new HttpError(400, `clé ${k} : caractères inattendus`);
      keys[k] = v;
    }
    out.keys = keys;
  }
  if (out.feeds !== undefined) {
    if (!Array.isArray(out.feeds)) throw new HttpError(400, 'flux : liste attendue');
    out.feeds = out.feeds.slice(0, 40).map((f) => {
      let u;
      try { u = new URL(String(f?.url ?? '')); } catch { throw new HttpError(400, `flux : adresse invalide (${String(f?.url ?? '').slice(0, 80)})`); }
      if (!['http:', 'https:'].includes(u.protocol)) throw new HttpError(400, 'flux : seules les adresses http(s) sont acceptées');
      return { name: String(f.name || u.host).slice(0, 60), url: u.href, lang: ['fr', 'en'].includes(f.lang) ? f.lang : 'fr', enabled: f.enabled !== false };
    });
  }
  return out;
}

export const VERSION = '0.4.3';

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.glsl': 'text/plain; charset=utf-8',
  '.wasm': 'application/wasm', '.md': 'text/markdown; charset=utf-8', '.txt': 'text/plain; charset=utf-8',
};
const SECURITY_HEADERS = {
  'cross-origin-opener-policy': 'same-origin', 'cross-origin-embedder-policy': 'require-corp', 'cross-origin-resource-policy': 'same-origin',
  'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer',
};

export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const num = (v, d) => (v === undefined || v === null || v === '' || !Number.isFinite(Number(v)) ? d : Number(v));
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));

/** Hôtes acceptés : la machine locale (et l'hôte configuré). */
export function hostAllowed(hostHeader, extra = []) {
  if (!hostHeader) return false;
  const h = hostHeader.replace(/:\d+$/, '').replace(/^\[|\]$/g, '').toLowerCase();
  const list = typeof extra === 'function' ? extra() : extra; // liste fixe, ou relue (écoute sur 0.0.0.0)
  return ['127.0.0.1', 'localhost', '::1', ...list.map((x) => String(x).toLowerCase())].includes(h);
}

export function createApp({ root, store, compute, market, portfolio, analysis, agent, alerts, hub, log = () => {}, allowHosts = [], dataRewrite = null }) {
  const dataCheck = { running: null, last: null };
  const startedAt = Date.now();
  const routes = [];
  const add = (method, path, handler) => {
    const keys = [];
    const re = new RegExp(`^${path.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; })}$`);
    routes.push({ method, re, keys, handler });
  };
  const sym = (s) => {
    const r = resolveSymbol(market, s);
    if (!r) throw new HttpError(404, `valeur inconnue : ${s}`);
    return r;
  };
  const dailyOf = (s) => {
    const d = market.sim.daily(s);
    return { open: Float64Array.from(d.open), high: Float64Array.from(d.high), low: Float64Array.from(d.low), close: Float64Array.from(d.close), volume: Float64Array.from(d.volume), dates: d.dates };
  };
  /** Valeur prête pour un calcul : historique chargé (données réelles) et assez long. */
  const readySym = async (raw, minDays = 60) => {
    const s = sym(raw);
    await market.prepare(s).catch((e) => {
      // pas d'historique du tout et source injoignable : on dit pourquoi (503 si le site est en pause)
      if (!market.sim.daily(s).close.length) throw new HttpError(e.blocked ? 503 : 502, e.blocked ? `${e.message} : réessaie après la pause` : e.message);
    });
    const n = market.sim.daily(s).close.length;
    if (n < minDays) throw new HttpError(422, `historique insuffisant pour ${market.get(s).meta.name} : ${n} séance(s)${market.real ? ' (chargement en cours ou source indisponible, voir Système → Sources de données)' : ''}`);
    return s;
  };

  // ======================================================================= application
  add('GET', '/api/health', () => ({ ok: true, version: VERSION, uptime: process.uptime() }));
  add('GET', '/api/meta', () => ({
    app: 'Bourso', version: VERSION, demo: !market.real, data: market.dataInfo(), startedAt, regions: REGIONS,
    sectors: Object.fromEntries(Object.entries(SECTORS).map(([k, v]) => [k, v[0]])),
    exchanges: Object.values(EXCHANGES).sort((a, b) => a.order - b.order).map((e) => ({ mic: e.mic, name: e.name, short: e.short, country: e.country, countryName: e.countryName, region: e.region, tz: e.tz, ccy: e.ccy, open: e.open, close: e.close, breaks: e.breaks, index: e.index, n: market.sim.instruments.filter((x) => x.meta.mic === e.mic).length })),
    timeframes: TIMEFRAMES, stateLabels: STATE_LABEL,
    strategies: Object.entries(STRATEGIES).map(([id, s]) => ({ id, name: s.name, short: s.short ?? s.name, explain: s.explain, params: Object.keys(s.grid ?? {}), sweep: SWEEP_CODES[id] !== undefined })),
    levels: Object.fromEntries(Object.entries(LEVELS).map(([k, v]) => [k, { ...v }])), settings: publicSettings(store.settings), favorites: store.favorites,
    count: market.sim.instruments.length,
  }));

  // ======================================================================= marché
  add('GET', '/api/universe', () => market.universe());
  add('GET', '/api/quotes', () => market.allQuotes());
  add('GET', '/api/quote/:sym', (p) => {
    const s = sym(p.sym);
    if (market.real) market.sim.touch(s);
    const m = market.meta(s), q = market.quote(s), row = market.screener().find((r) => r.sym === s) ?? null;
    return { sym: s, meta: m, quote: q, screen: row, clock: market.sim.clockInfo().find((c) => c.mic === m.mic) ?? null };
  });
  add('GET', '/api/history', async (p, q) => {
    const s = sym(q.get('sym')), tf = q.get('tf') ?? '1D';
    if (!TIMEFRAMES[tf]) throw new HttpError(400, `unité de temps inconnue : ${tf}`);
    // données réelles : historique / bougies intraday chargés à la demande (sources gratuites, mis en cache)
    // source en pause (refus du site) : attendu, déjà signalé une fois — on sert ce qui est en cache
    await market.prepare(s, tf).catch((e) => { if (!e.blocked) log(`historique ${s} ${tf} : ${e.message}`); });
    const h = market.history(s, tf, q.get('days') ? clamp(num(q.get('days'), 5), 1, 60) : undefined);
    if (q.get('format') === 'json') return { header: h.header, open: Array.from(h.arrays[0]), high: Array.from(h.arrays[1]), low: Array.from(h.arrays[2]), close: Array.from(h.arrays[3]), volume: Array.from(h.arrays[4]) };
    return { binary: MarketService.encode(h) };
  });
  add('GET', '/api/live', (p, q) => market.live(sym(q.get('sym')), num(q.get('since'), 0)));
  add('GET', '/api/book', (p, q) => {
    const s = sym(q.get('sym'));
    const b = market.sim.book(s, clamp(num(q.get('depth'), 15), 5, 50));
    if (!b) return { sym: s, unavailable: true, reason: 'Carnet d\'ordres non disponible avec les sources gratuites (il faudrait un flux de niveau 2 payant).', bids: [], asks: [], quote: market.quote(s) };
    return { sym: s, ...b, quote: market.quote(s) };
  });
  add('GET', '/api/tape', (p, q) => market.sim.tape(sym(q.get('sym')), clamp(num(q.get('limit'), 100), 1, 512), num(q.get('since'), 0)));
  add('GET', '/api/fundamentals/:sym', async (p) => {
    const s = sym(p.sym);
    if (market.real) await market.sim.fundamentals(s).catch((e) => log(`fondamentaux ${s} : ${e.message}`));
    return { sym: s, real: market.real, fundamentals: market.meta(s).fundamentals, dividends: market.real ? market.get(s).dividends.slice(-12) : [] };
  });
  add('GET', '/api/screener', () => ({ at: market.screenAt, ms: market.screenMs ?? null, rows: market.screener() }));
  add('GET', '/api/overview', () => market.overview());
  add('GET', '/api/sectors', () => market.sectors());
  add('GET', '/api/index/:key', (p) => market.indexSeries(decodeURIComponent(p.key)));
  add('GET', '/api/clocks', () => market.sim.clockInfo());
  add('GET', '/api/fx', () => market.sim.fx.list());
  add('GET', '/api/news', async (p, q) => {
    const limit = clamp(num(q.get('limit'), 50), 1, 500), s = q.get('sym');
    if (s && market.real) await market.prepare(sym(s), null, { news: true }).catch(() => {});
    const items = s ? market.sim.news.forSym(sym(s), limit) : market.sim.news.items.slice(-limit);
    return items.slice().reverse().map((n) => ({ ...n, name: n.sym ? market.get(n.sym)?.meta.name : null, sector: n.sectorKey ? SECTORS[n.sectorKey]?.[0] : null }));
  });
  add('GET', '/api/search', async (p, q) => {
    const t = String(q.get('q') ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
    if (!t) return [];
    const f = (s) => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    const score = (x) => {
      const m = x.meta, code = f(m.code), name = f(m.name);
      let sc = code === t ? 100 : code.startsWith(t) ? 70 : name.startsWith(t) ? 60 : name.includes(t) ? 40 : m.isin && f(m.isin) === t ? 90 : 0;
      if (sc && m.region === 'Europe') sc += 5;
      return sc;
    };
    const limit = clamp(num(q.get('limit'), 12), 1, 50);
    const local = market.sim.instruments.map((x) => [score(x), x]).filter(([s]) => s > 0).sort((a, b) => b[0] - a[0] || market.sizeOf(b[1]) - market.sizeOf(a[1])).slice(0, limit)
      .map(([, x]) => ({ sym: x.meta.sym, code: x.meta.code, name: x.meta.name, ex: x.ex.short, country: x.meta.country, region: x.meta.region, ccy: x.meta.currency, last: x.last, chgPct: (x.last / x.prev - 1) * 100 }));
    // données réelles : toutes les actions du monde (recherche Yahoo), ajoutables d'un clic
    if (!market.real || q.get('external') === '0' || t.length < 2 || local.length >= limit) return local;
    const ext = await market.sim.searchExternal(String(q.get('q'))).catch(() => []);
    const known = new Set(local.map((x) => x.sym));
    return [...local, ...ext.filter((e) => e.supported && !(e.sym && known.has(e.sym))).slice(0, Math.max(3, limit - local.length)).map((e) => (e.sym
      ? { sym: e.sym, code: market.get(e.sym)?.meta.code, name: e.name, ex: market.get(e.sym)?.ex.short, last: market.get(e.sym)?.last ?? null }
      : { external: true, yahoo: e.yahoo, code: e.yahoo, name: e.name, ex: e.exchange, mic: e.mic, sector: e.sector, type: e.type }))];
  });
  // ======================================================================= données réelles : sources, ajout de valeurs, mode
  add('GET', '/api/data/status', () => ({ ...market.dataInfo(), ...market.status(), defaultFeeds: DEFAULT_FEEDS }));
  add('POST', '/api/data/add', async (p, q, body) => {
    if (!market.real) throw new HttpError(400, 'ajout de valeurs : uniquement avec les données réelles');
    try {
      const s = await market.sim.addSymbol({ yahoo: body?.yahoo, name: body?.name, exchange: body?.exchange, sector: body?.sector });
      return { sym: s, meta: market.meta(s) };
    } catch (e) { throw new HttpError(422, e.message); }
  });
  add('POST', '/api/data/refresh', async (p, q, body) => {
    const s = sym(body?.sym);
    if (!market.real) return { ok: true };
    const x = market.get(s);
    x.hist.at = 0;
    x.dead = false;
    await market.sim.loadHistory(x, { priority: 3 }).catch((e) => { throw new HttpError(e.blocked ? 503 : 502, e.message); });
    await market.prepare(s, '1m', { news: true }).catch(() => {});
    return { ok: true, days: x.daily.n, source: x.hist.source };
  });
  add('POST', '/api/data/check', async () => {
    // une vérification à la fois (elle sollicite chaque source une fois)
    if (dataCheck.running) return dataCheck.running;
    const keys = store.settings.data?.keys ?? {}, feeds = store.settings.data?.feeds?.length ? store.settings.data.feeds : DEFAULT_FEEDS;
    dataCheck.running = checkSources({ net: market.real ? market.sim.net : null, rewrite: dataRewrite, keys, feeds })
      .then((r) => { dataCheck.last = r; return r; })
      .finally(() => { dataCheck.running = null; });
    return dataCheck.running;
  });
  add('GET', '/api/data/check', () => dataCheck.last ?? { at: null, results: [], summary: null });
  add('POST', '/api/data/mode', async (p, q, body) => {
    const mode = body?.mode === 'demo' ? 'demo' : 'real';
    store.setSettings({ data: { mode } });
    await market.setMode(mode);
    return market.dataInfo();
  });

  // ======================================================================= exports CSV
  add('GET', '/api/export/history.csv', (p, q) => {
    const s = sym(q.get('sym')), tf = q.get('tf') ?? '1D', h = market.history(s, tf);
    if (!h) throw new HttpError(400, 'unité de temps inconnue');
    const [o, hi, lo, c, v] = h.arrays, H = h.header, ex = EXCHANGES[market.get(s).meta.mic], dec = decimalsOf(H.tick);
    const lines = ['date;heure;ouverture;plus_haut;plus_bas;cloture;volume'];
    for (let i = 0; i < H.count; i++) {
      let date, time = '';
      if (H.intraday) {
        const day = Math.floor(i / H.perSession), k = i % H.perSession;
        date = H.dates[day] ?? '';
        time = localTimeOf(ex, k * H.barSeconds, H.barSeconds < 60);
      } else date = H.dates[i];
      lines.push([date, time, o[i].toFixed(dec), hi[i].toFixed(dec), lo[i].toFixed(dec), c[i].toFixed(dec), Math.round(v[i])].join(';'));
    }
    return { csv: lines.join('\n'), filename: `${s.replace(':', '_')}_${tf}.csv` };
  });
  add('GET', '/api/export/screener.csv', () => {
    const rows = market.screener(), cols = ['sym', 'name', 'ex', 'region', 'sector', 'ccy', 'last', 'chgPct', 'volume', 'perf1s', 'perf1m', 'perf3m', 'perf1a', 'ytd', 'rsi14', 'adx', 'atrPct', 'vol20', 'relVol', 'rating', 'ratingLabel', 'per', 'dy', 'capEur'];
    const esc = (x) => (x === null || x === undefined ? '' : /[;"\n]/.test(String(x)) ? `"${String(x).replace(/"/g, '""')}"` : String(x));
    return { csv: [cols.join(';'), ...rows.map((r) => cols.map((k) => esc(r[k])).join(';'))].join('\n'), filename: 'bourso_screener.csv' };
  });

  // ======================================================================= réglages, favoris
  add('GET', '/api/settings', () => publicSettings(store.settings));
  add('PUT', '/api/settings', async (p, q, body) => {
    const before = store.settings.data?.mode;
    if (body?.data) body = { ...body, data: cleanDataSettings(body.data) };
    const s = store.setSettings(body ?? {});
    analysis.applySettings();
    if (body?.data) {
      // changement de mode seulement si l'utilisateur a changé le réglage (pas pour un renvoi de tous les réglages)
      if (body.data.mode && body.data.mode !== before) await market.setMode(body.data.mode);
      else if (market.real) market.sim.configure({ intensity: s.data.intensity, keys: s.data.keys, feeds: s.data.feeds?.length ? s.data.feeds : DEFAULT_FEEDS });
    }
    if (body?.compute?.level && LEVELS[body.compute.level]) compute.level = body.compute.level;
    if (body?.compute?.mode && ['auto', 'gpu', 'cpu'].includes(body.compute.mode)) compute.mode = body.compute.mode;
    hub?.broadcast({ t: 'settings', settings: publicSettings(s) });
    return publicSettings(s);
  });
  add('GET', '/api/favorites', () => store.favorites.map((s) => ({ sym: s, name: market.get(s)?.meta.name ?? s })));
  add('PUT', '/api/favorites', (p, q, body) => {
    const list = (Array.isArray(body) ? body : body?.favorites ?? []).map((s) => resolveSymbol(market, s)).filter(Boolean);
    const out = store.setFavorites(list);
    analysis.wake?.();
    hub?.broadcast({ t: 'favorites', favorites: out });
    return out;
  });

  // ======================================================================= portefeuille simulé
  add('GET', '/api/portfolio', () => portfolio.summary());
  add('POST', '/api/orders', (p, q, body) => portfolio.place({ ...body, sym: sym(body?.sym), source: 'manuel' }));
  add('DELETE', '/api/orders/:id', (p) => portfolio.cancel(p.id) ?? (() => { throw new HttpError(404, 'ordre introuvable'); })());
  add('POST', '/api/portfolio/reset', (p, q, body) => {
    portfolio.reset(num(body?.cash, store.settings.trading.initialCash));
    return portfolio.summary();
  });
  add('GET', '/api/fees', (p, q) => {
    const s = sym(q.get('sym')), side = q.get('side') === 'SELL' ? 'SELL' : 'BUY', qty = Math.max(1, Math.floor(num(q.get('qty'), 1)));
    const px = num(q.get('px'), market.sim.quote(s).last), x = market.get(s);
    return { sym: s, side, qty, px, ...portfolio.fees(s, side, qty, px), ttfSource: TTF_SOURCE, capEur: x.capEur, isin: x.meta.isin };
  });

  add('GET', '/api/portfolio/risk', () => portfolio.risk());

  // ======================================================================= tracés, alertes
  add('GET', '/api/drawings/:sym', (p) => store.getDrawings(sym(p.sym)));
  add('PUT', '/api/drawings/:sym', (p, q, body) => {
    if (!Array.isArray(body)) throw new HttpError(400, 'liste de tracés attendue');
    if (body.length > 500 || JSON.stringify(body).length > 512 * 1024) throw new HttpError(413, 'trop de tracés');
    return store.setDrawings(sym(p.sym), body);
  });
  add('GET', '/api/alerts', () => alerts.list);
  add('POST', '/api/alerts', (p, q, body) => alerts.add({ ...body, sym: sym(body?.sym) }));
  add('DELETE', '/api/alerts/:id', (p) => ({ ok: alerts.remove(p.id) }));
  add('POST', '/api/alerts/:id/rearm', (p) => alerts.rearm(p.id));

  // ======================================================================= IA d'analyse (Ollama)
  add('GET', '/api/ai/status', () => ({ ollama: analysis.ollama, model: analysis.model(), modelStatus: { analysis: analysis.modelStatus('ai'), agent: analysis.modelStatus('agent') }, queue: analysis.queue(), settings: store.settings.ai, reliability: analysis.reliability() }));

  // ======================================================================= modèles Ollama (choix, test, téléchargement)
  const ollamaDown = (e) => new HttpError(503, `Ollama injoignable (${e.message})`);
  add('GET', '/api/ollama/models', async () => { try { return await analysis.models(); } catch (e) { throw ollamaDown(e); } });
  add('POST', '/api/ollama/host', async (p, q, body) => analysis.setHost(body?.host));
  add('POST', '/api/ollama/test', async (p, q, body) => {
    if (!body?.model) throw new HttpError(400, 'modèle requis');
    try { return await analysis.testModel(body.model); } catch (e) { return { model: body.model, ok: false, error: e.message }; }
  });
  add('POST', '/api/ollama/pull', (p, q, body) => analysis.pullModel(body?.model));
  add('POST', '/api/ollama/create', (p, q, body) => analysis.createTuned(body?.from, body?.name || 'bourso'));
  add('POST', '/api/ollama/cancel', (p, q, body) => ({ ok: analysis.cancelModelOp(body?.model) }));
  add('DELETE', '/api/ollama/models/:name', async (p) => analysis.deleteModel(p.name));
  add('POST', '/api/ai/check', () => analysis.checkOllama());
  add('POST', '/api/ai/analyze', (p, q, body) => analysis.request(sym(body?.sym), { think: body?.think, reason: body?.reason ?? 'demande manuelle' }));
  add('POST', '/api/ai/resume', () => analysis.resume());
  add('GET', '/api/ai/signals', (p, q) => {
    const s = q.get('sym') ? sym(q.get('sym')) : null, lim = clamp(num(q.get('limit'), 50), 1, 1000);
    return store.signals.filter((x) => !s || x.sym === s).slice(-lim).reverse().map(({ raw, ...rest }) => rest);
  });
  add('GET', '/api/ai/signal/:id', (p) => store.signals.find((x) => x.id === p.id) ?? (() => { throw new HttpError(404, 'signal introuvable'); })());
  add('GET', '/api/ai/reliability', () => analysis.reliability());
  add('GET', '/api/ai/dossier', async (p, q) => {
    const s = sym(q.get('sym')), t0 = Date.now(), r = await analysis.dossier(s);
    return { ...r, ms: Date.now() - t0, tokens: Math.round(r.text.length / 3.6) };
  });
  add('GET', '/api/ai/prompts', () => ({ analyste: ANALYSTE_V3, agent: AGENT_PRO, schema: ANALYSE_SCHEMA }));

  // ======================================================================= agent Bourso Pro
  add('GET', '/api/agent/tools', () => agent.toolList());
  add('GET', '/api/agent/conversations', () => store.listConversations());
  add('POST', '/api/agent/conversations', (p, q, body) => agent.create({ sym: body?.sym ? sym(body.sym) : null }));
  add('GET', '/api/agent/conversations/:id', async (p) => {
    const c = await store.getConversation(p.id);
    if (!c) throw new HttpError(404, 'discussion introuvable');
    return { ...c, busy: agent.busy(c.id) };
  });
  add('DELETE', '/api/agent/conversations/:id', async (p) => {
    agent.abort(p.id);
    await store.deleteConversation(p.id);
    return { ok: true };
  });
  add('POST', '/api/agent/conversations/:id/messages', async (p, q, body) => {
    const c = await store.getConversation(p.id);
    if (!c) throw new HttpError(404, 'discussion introuvable');
    if (agent.busy(c.id)) throw new HttpError(409, 'une réponse est déjà en cours');
    const s = body?.sym === undefined ? undefined : body.sym === null ? null : resolveSymbol(market, body.sym);
    agent.send(c.id, body?.text, { sym: s }).catch((e) => log(`agent : ${e.message}`));
    return { ok: true, conv: c.id };
  });
  add('POST', '/api/agent/conversations/:id/abort', (p) => ({ ok: agent.abort(p.id) }));
  add('POST', '/api/agent/tool/:name', async (p, q, body) => agent.runTool(p.name, body ?? {}));

  // ======================================================================= laboratoire quant
  add('POST', '/api/lab/montecarlo', async (p, q, body) => {
    const s = await readySym(body?.sym, 120), d = market.sim.daily(s), qt = market.sim.quote(s), m = market.get(s).meta;
    const steps = clamp(Math.round(num(body?.steps, 20)), 1, 750), win = clamp(Math.round(num(body?.window, 756)), 60, d.close.length);
    const ret = logReturns(d.close.subarray(d.close.length - win)).subarray(1);
    let model;
    const kind = body?.model ?? 'garch';
    if (kind === 'bootstrap') model = { model: 'bootstrap', returns: Float64Array.from(ret), block: clamp(Math.round(num(body?.block, 5)), 1, 60) };
    else {
      const fit = garch11(ret);
      if (!fit) throw new HttpError(422, 'ajustement GARCH impossible sur cette série');
      model = garchSpec(fit, kind === 'garch_t' ? { nu: clamp(num(body?.nu, 5), 2.5, 60) } : {});
    }
    const upPct = num(body?.upPct, null), downPct = num(body?.downPct, null);
    const up = upPct ? roundTick(qt.last * (1 + upPct / 100), m.tick) : 0, down = downPct ? roundTick(qt.last * (1 - downPct / 100), m.tick) : 0;
    const paths = body?.paths ? clamp(Math.round(num(body.paths, 1e6)), 1000, 200_000_000) : undefined;
    const o = { s0: qt.last, steps, up, down, paths, seed: body?.seed ? Math.round(num(body.seed, 1)) >>> 0 : undefined, mode: body?.mode };
    const res = await compute.monteCarlo(model, o);
    const verify = body?.verify ? await compute.verifyMC(model, { ...o, seed: res.seed }, clamp(num(body?.verifyPaths, 50_000), 1000, 2_000_000)) : null;
    const { returns, ...modelInfo } = model;
    void returns;
    return { sym: s, name: m.name, ccy: m.currency, s0: qt.last, up, down, model: { kind, ...modelInfo, window: win }, ...res, verify };
  });
  add('POST', '/api/lab/sweep', async (p, q, body) => {
    const s = await readySym(body?.sym, 300), strategy = body?.strategy ?? 'ema_cross';
    if (SWEEP_CODES[strategy] === undefined) throw new HttpError(400, `stratégie non balayable : ${strategy}`);
    const d = dailyOf(s), years = clamp(num(body?.years, 5), 1, 5), from = Math.max(0, d.close.length - Math.round(years * 252));
    const data = { open: d.open.subarray(from), high: d.high.subarray(from), low: d.low.subarray(from), close: d.close.subarray(from) };
    const r = await compute.sweep(data, strategy, { scale: body?.scale ? clamp(num(body.scale, 1), 0.5, 8) : undefined, costBps: clamp(num(body?.costBps, 5), 0, 200), short: Boolean(body?.short), mode: body?.mode });
    return { sym: s, name: market.get(s).meta.name, years, ...r, top: r.top.slice(0, 100) };
  });
  add('GET', '/api/lab/grid', (p, q) => {
    const id = q.get('strategy') ?? 'ema_cross';
    if (SWEEP_CODES[id] === undefined) throw new HttpError(400, 'stratégie non balayable');
    const g = fineGrid(id, clamp(num(q.get('scale'), LEVELS[compute.level].sweepScale), 0.5, 8));
    return { strategy: id, keys: g.keys, combos: g.combos.length };
  });
  add('POST', '/api/lab/walkforward', async (p, q, body) => {
    const s = await readySym(body?.sym, 300), d = dailyOf(s), t0 = Date.now();
    const strategies = (body?.strategies ?? Object.keys(STRATEGIES).filter((k) => k !== 'buy_hold')).filter((k) => STRATEGIES[k]);
    const r = await compute.task('walkforward', { data: d, strategies, folds: clamp(num(body?.folds, 4), 2, 10), costBps: clamp(num(body?.costBps, 5), 0, 200), short: Boolean(body?.short) }, { priority: 3 });
    return { sym: s, name: market.get(s).meta.name, dates: d.dates, ms: Date.now() - t0, ...r };
  });
  add('POST', '/api/lab/backtest', async (p, q, body) => {
    const s = await readySym(body?.sym, 300), id = body?.strategy ?? 'ema_cross';
    if (!STRATEGIES[id]) throw new HttpError(400, 'stratégie inconnue');
    const d = dailyOf(s), t0 = Date.now();
    const r = await compute.task('walkforward', { data: d, strategies: [id], folds: clamp(num(body?.folds, 4), 2, 10), costBps: clamp(num(body?.costBps, 5), 0, 200), short: Boolean(body?.short) }, { priority: 3 });
    return { sym: s, ms: Date.now() - t0, ...r };
  });
  add('POST', '/api/lab/hmm', async (p, q, body) => {
    const s = await readySym(body?.sym, 250), d = market.sim.daily(s), win = clamp(Math.round(num(body?.window, 1000)), 200, d.close.length), t0 = Date.now();
    const r = await compute.task('hmm', { returns: logReturns(d.close.subarray(d.close.length - win)).subarray(1), K: Math.round(num(body?.K, 0)) === 0 ? 0 : clamp(Math.round(num(body?.K, 3)), 2, 5), restarts: clamp(num(body?.restarts, 8), 1, 40) }, { priority: 3 });
    if (!r) throw new HttpError(422, 'historique trop court pour ce nombre d\'états');
    return { sym: s, dates: d.dates.slice(-win + 1), close: Array.from(d.close.subarray(d.close.length - win + 1)), ms: Date.now() - t0, ...r };
  });
  add('POST', '/api/lab/cycles', async (p, q, body) => {
    const s = await readySym(body?.sym, 160), d = market.sim.daily(s), win = clamp(Math.round(num(body?.window, 512)), 128, d.close.length);
    const minPeriod = clamp(num(body?.minPeriod, 5), 2, win / 4), maxPeriod = clamp(num(body?.maxPeriod, Math.floor(win / 3)), minPeriod + 2, win / 2);
    return { sym: s, window: win, ...(await compute.task('cycles', { close: Float64Array.from(d.close.subarray(d.close.length - win)), opts: { minPeriod, maxPeriod, top: 6 } }, { priority: 3 })) };
  });
  add('POST', '/api/lab/analogs', async (p, q, body) => {
    const s = await readySym(body?.sym, 400), d = dailyOf(s), t0 = Date.now();
    const r = await compute.task('analogs', { data: d, k: clamp(Math.round(num(body?.k, 30)), 10, 60), spacing: clamp(Math.round(num(body?.spacing, 5)), 1, 30), horizons: [5, clamp(Math.round(num(body?.horizon, 20)), 10, 60)] }, { priority: 3 });
    if (!r) throw new HttpError(422, 'historique insuffisant pour chercher des analogues');
    return { sym: s, ms: Date.now() - t0, ...r };
  });
  add('POST', '/api/lab/stats', async (p, q, body) => {
    const s = await readySym(body?.sym, 120), d = market.sim.daily(s), win = clamp(Math.round(num(body?.window, 1260)), 100, d.close.length);
    return { sym: s, window: win, ...(await compute.task('stats', { close: Float64Array.from(d.close.subarray(d.close.length - win)) }, { priority: 3 })) };
  });
  add('POST', '/api/lab/technical', async (p, q, body) => {
    const s = sym(body?.sym), tf = body?.tf ?? '1D';
    let why = '';
    await market.prepare(s, tf).catch((e) => { why = e.blocked ? ` (${e.message})` : ''; });
    const h = market.history(s, tf);
    if (!h) throw new HttpError(400, 'unité de temps inconnue');
    if (h.header.count < 60) throw new HttpError(422, `pas assez de bougies pour le résumé technique${why || (market.real ? ' (historique en cours de chargement)' : '')}`);
    const [open, high, low, close, volume] = h.arrays;
    return { sym: s, tf, ...(await compute.task('technical', { data: { open, high, low, close, volume } }, { priority: 3 })) };
  });
  add('POST', '/api/lab/correlation', async (p, q, body) => {
    let syms = (body?.syms ?? []).map((x) => resolveSymbol(market, x)).filter(Boolean);
    if (!syms.length) {
      const rows = market.screener().filter((r) => !body?.region || r.region === body.region).sort((a, b) => (b.size ?? 0) - (a.size ?? 0));
      syms = rows.slice(0, clamp(num(body?.n, 30), 2, 80)).map((r) => r.sym);
    }
    syms = syms.slice(0, 80);
    for (const x of syms) await market.prepare(x).catch(() => {});
    syms = syms.filter((x) => market.sim.daily(x).close.length >= 60);
    if (syms.length < 2) throw new HttpError(422, 'pas assez de valeurs avec un historique chargé');
    const win = clamp(Math.round(num(body?.window, 252)), 30, 1259);
    const al = market.alignedReturns(syms, win);
    const r = await compute.task('correlation', { series: al.returns }, { priority: 3 });
    return { syms, names: syms.map((s) => market.get(s).meta.name), window: win, days: al.dates.length, from: al.dates[0] ?? null, to: al.dates.at(-1) ?? null, ...r };
  });
  add('POST', '/api/lab/stress', async (p, q, body) => compute.stress({ seconds: clamp(num(body?.seconds, 15), 3, 120), onProgress: (x) => hub?.broadcast({ t: 'stress', progress: x }) }));

  // ======================================================================= système
  add('GET', '/api/system', async () => ({
    snapshot: await systemSnapshot(), compute: compute.info(), version: VERSION, startedAt,
    market: { mode: market.mode, real: market.real, instruments: market.sim.instruments.length, exchanges: Object.keys(market.sim.clocks).length, stepMs: market.stepMs, screenMs: market.screenMs ?? null, screenAt: market.screenAt, news: market.sim.news.items.length,
      ...(market.real ? (({ quotesLive, quotesFresh15min, histories, historyQueue, intensityLabel, yahooPausedUntil }) => ({ quotesLive, quotesFresh15min, histories, historyQueue, intensityLabel, yahooPausedUntil }))(market.status()) : {}) },
    ollama: analysis.ollama, model: analysis.model(), modelStatus: { analysis: analysis.modelStatus('ai'), agent: analysis.modelStatus('agent') }, ai: analysis.stats, agent: agent.stats, ws: hub?.info() ?? null,
  }));
  add('POST', '/api/system/calibrate', async () => compute.calibrate());
  add('POST', '/api/system/level', (p, q, body) => {
    if (!LEVELS[body?.level]) throw new HttpError(400, 'niveau inconnu');
    compute.level = body.level;
    store.setSettings({ compute: { level: body.level } });
    return compute.info();
  });
  add('POST', '/api/system/mode', (p, q, body) => {
    if (!['auto', 'gpu', 'cpu'].includes(body?.mode)) throw new HttpError(400, 'mode inconnu (auto, gpu, cpu)');
    compute.mode = body.mode;
    store.setSettings({ compute: { mode: body.mode } });
    return compute.info();
  });

  // ======================================================================= fichiers statiques
  const roots = [
    { prefix: '/src/core/', dir: join(root, 'src/core') },
    { prefix: '/src/market/', dir: join(root, 'src/market') },
    { prefix: '/', dir: join(root, 'web') },
  ];
  async function serveStatic(pathname, req, res) {
    const r = roots.find((x) => pathname.startsWith(x.prefix));
    if (!r) return false;
    let rel = decodeURIComponent(pathname.slice(r.prefix.length));
    if (!rel || rel.endsWith('/')) rel += 'index.html';
    if (rel.split('/').some((seg) => seg.startsWith('.'))) return false;
    const file = resolve(r.dir, rel);
    if (!file.startsWith(resolve(r.dir) + sep)) return false;
    let st;
    try { st = await stat(file); } catch { return false; }
    if (!st.isFile()) return false;
    const etag = `"${st.size.toString(36)}-${Math.floor(st.mtimeMs).toString(36)}"`;
    if (req.headers['if-none-match'] === etag) {
      res.writeHead(304, { etag, ...SECURITY_HEADERS });
      res.end();
      return true;
    }
    res.writeHead(200, { 'content-type': MIME[extname(file)] ?? 'application/octet-stream', 'content-length': st.size, etag, 'cache-control': 'no-cache', ...SECURITY_HEADERS });
    res.end(req.method === 'HEAD' ? undefined : await readFile(file));
    return true;
  }

  // ======================================================================= traitement d'une requête
  const send = (res, status, body, extra = {}) => {
    const data = Buffer.from(JSON.stringify(body));
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': data.length, 'cache-control': 'no-store', ...SECURITY_HEADERS, ...extra });
    res.end(data);
  };
  const readBody = (req) => new Promise((ok, ko) => {
    let n = 0;
    const parts = [];
    req.on('data', (c) => {
      n += c.length;
      if (n > 2 * 2 ** 20) { ko(new HttpError(413, 'requête trop volumineuse')); req.destroy(); } else parts.push(c);
    });
    req.on('end', () => {
      if (!n) return ok(undefined);
      try { ok(JSON.parse(Buffer.concat(parts).toString('utf8'))); } catch { ko(new HttpError(400, 'JSON invalide')); }
    });
    req.on('error', ko);
  });

  const handler = async (req, res) => {
    const t0 = performance.now();
    try {
      if (!hostAllowed(req.headers.host, allowHosts)) throw new HttpError(421, 'hôte non autorisé');
      const url = new URL(req.url, 'http://localhost');
      const write = req.method !== 'GET' && req.method !== 'HEAD';
      if (write) {
        const origin = req.headers.origin;
        if (origin && !hostAllowed(new URL(origin).host, allowHosts)) throw new HttpError(403, 'origine refusée');
        if (req.headers['content-length'] !== '0' && req.headers['content-length'] !== undefined && !/^application\/json/i.test(req.headers['content-type'] ?? '')) throw new HttpError(415, 'JSON attendu');
      }
      if (url.pathname.startsWith('/api/')) {
        for (const r of routes) {
          if (r.method !== req.method && !(r.method === 'GET' && req.method === 'HEAD')) continue;
          const m = r.re.exec(url.pathname);
          if (!m) continue;
          const params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
          const body = write ? await readBody(req) : undefined;
          const out = await r.handler(params, url.searchParams, body, req);
          if (out?.binary) {
            res.writeHead(200, { 'content-type': 'application/octet-stream', 'content-length': out.binary.length, 'cache-control': 'no-store', ...SECURITY_HEADERS });
            res.end(out.binary);
          } else if (out?.csv !== undefined) {
            const data = Buffer.from(`﻿${out.csv}`, 'utf8');
            res.writeHead(200, { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': `attachment; filename="${out.filename}"`, 'content-length': data.length, ...SECURITY_HEADERS });
            res.end(data);
          } else send(res, 200, out ?? null);
          const ms = performance.now() - t0;
          if (ms > 1500) log(`lent : ${req.method} ${url.pathname} ${Math.round(ms)} ms`);
          return;
        }
        throw new HttpError(404, `route inconnue : ${req.method} ${url.pathname}`);
      }
      if ((req.method === 'GET' || req.method === 'HEAD') && (await serveStatic(url.pathname, req, res))) return;
      throw new HttpError(404, 'introuvable');
    } catch (e) {
      // seule une HttpError fixe le code HTTP ; l'erreur d'une source (NetError : 0, 429…) devient 503 / 502
      const status = e instanceof HttpError && e.status >= 400 && e.status <= 599 ? e.status : e?.blocked ? 503 : e?.name === 'NetError' ? 502 : 500;
      if (status >= 500 && !e?.blocked) log(`erreur ${req.method} ${req.url} : ${e?.stack ?? e?.message}`);
      try {
        if (!res.headersSent) send(res, status, { error: String(e?.message ?? e) });
        else res.end();
      } catch { res.destroy(); } // jamais d'erreur qui sorte d'ici : elle arrêterait le serveur
    }
  };
  handler.routes = routes;
  return handler;
}

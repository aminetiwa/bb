#!/usr/bin/env node
// ============================================================================
//  BOURSO :: server/main.js — démarrage du serveur Bourso (tout en local).
//
//   npm start                     → http://localhost:3000 (via le superviseur scripts/run.js)
//   npm run server                → ce fichier directement, sans superviseur
//   OLLAMA_HOST=127.0.0.1:11434   → serveur Ollama (défaut)
//   BOURSO_PORT / BOURSO_HOST     → port / adresse d'écoute (défaut 3000 / 127.0.0.1 ;
//                                   0.0.0.0 = tout le réseau : les adresses de la machine sont acceptées)
//   BOURSO_ALLOW_HOSTS=a,b        → noms d'hôte acceptés en plus (ex. nom MagicDNS Tailscale)
//   BOURSO_GPU=off                → désactive le GPU (Dawn/Vulkan)
//   BOURSO_DATA=data              → dossier des données (réglages, signaux, discussions, cache des cours)
//   BOURSO_MARKET=real|demo       → données réelles (défaut) ou démonstration (simulateur)
// ============================================================================
import http from 'node:http';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { StateStore } from './state.js';
import { MarketService } from './market-service.js';
import { Portfolio } from './portfolio.js';
import { AlertService } from './alerts.js';
import { createApp, VERSION } from './http.js';
import { createHub } from './ws.js';
import { ComputeService } from '../compute/service.js';
import { OllamaClient } from '../ai/ollama-client.js';
import { AnalysisService } from '../ai/analysis.js';
import { AgentService } from '../ai/agent.js';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const log = (...a) => console.log(`[${new Date().toLocaleTimeString('fr-FR')}]`, ...a);

export const DEFAULT_PORT = 3000;

/** Adresses de cette machine, toutes interfaces (Wi-Fi, Ethernet, Tailscale…). */
export function machineAddresses() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const a of list ?? []) out.push({ name, address: String(a.address).replace(/%.*$/, ''), v4: a.family === 'IPv4' || a.family === 4, internal: a.internal });
  }
  return out;
}

/** Adresse Tailscale (plage 100.64.0.0/10) ? */
const isTailscale = (ip) => /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(ip);

/**
 * Hôtes acceptés dans les en-têtes Host / Origin, en plus de localhost (protection contre le
 * « DNS rebinding » : un site piégé arrive avec SON nom de domaine, jamais avec l'adresse de ta
 * machine). Écoute sur 0.0.0.0 : toutes les adresses de la machine (relues toutes les 10 s, une
 * interface peut changer) et son nom ; plus les noms de BOURSO_ALLOW_HOSTS.
 */
export function hostAllowList(host, extraEnv = process.env.BOURSO_ALLOW_HOSTS) {
  const extra = String(extraEnv ?? '').split(',').map((x) => x.trim()).filter(Boolean);
  if (host !== '0.0.0.0' && host !== '::') return [...(host !== '127.0.0.1' && host !== 'localhost' ? [host] : []), ...extra];
  let cache = null, at = 0;
  return () => {
    if (!cache || Date.now() - at > 10_000) {
      cache = [...machineAddresses().map((a) => a.address), os.hostname(), `${os.hostname()}.local`, ...extra];
      at = Date.now();
    }
    return cache;
  };
}

export async function startServer({ port = Number(process.env.BOURSO_PORT ?? DEFAULT_PORT), host = process.env.BOURSO_HOST ?? '127.0.0.1', dataDir = process.env.BOURSO_DATA ?? resolve(ROOT, 'data'), ollamaHost = process.env.OLLAMA_HOST, gpu = process.env.BOURSO_GPU ?? 'auto', autoAnalysis = true, quiet = false, market: marketMode = process.env.BOURSO_MARKET ?? null, dataRewrite = null } = {}) {
  const say = quiet ? () => {} : log;
  const t0 = Date.now();
  say(`Bourso ${VERSION} — démarrage…`);
  const store = await new StateStore(dataDir).load();

  const compute = await ComputeService.create({ gpu, level: store.settings.compute.level, log: say });
  compute.mode = store.settings.compute.mode ?? 'auto';
  const ci = compute.info();
  say(`calcul : CPU ${ci.cpu.model} (${ci.cpu.cores} cœurs), ${ci.native.ok ? `addon C++ ${ci.native.version}` : 'workers JS (mêmes résultats, plus lent)'}, ${ci.pool.size} workers`);
  if (!ci.native.ok) say(`  ↳ ${(ci.native.error ?? 'module C++ indisponible').split('\n')[0].slice(0, 200)}`);
  say(ci.gpu.ok ? `GPU : ${ci.gpu.vendor} ${ci.gpu.architecture} ${ci.gpu.description}${ci.gpu.software ? ' (logiciel)' : ''}` : `GPU : non utilisé — ${ci.gpu.reason}`);
  await compute.calibrate().catch((e) => say(`étalonnage : ${e.message}`));

  const mode = marketMode ?? store.settings.data?.mode ?? 'real';
  const market = await new MarketService({ mode, store, compute, log: say, dataDir, rewrite: dataRewrite }).init();
  const portfolio = new Portfolio({ market, store });
  const alerts = new AlertService({ market, store });
  // valeurs « chaudes » (rafraîchies plus souvent) : positions et alertes actives, en plus des favoris et des valeurs affichées
  market.extraHot = () => [...Object.keys(portfolio.s.positions ?? {}), ...alerts.list.filter((a) => a.active).map((a) => a.sym)];
  if (market.real) say('données RÉELLES : Yahoo Finance (cours différés), BCE (change), Google Actualités / GDELT / presse — premiers cours dans une à deux minutes, historiques complets en un quart d\'heure environ');
  const client = new OllamaClient({ host: ollamaHost });
  const analysis = new AnalysisService({ client, market, compute, store, portfolio, log: say });
  const agent = new AgentService({ client, analysis, market, compute, portfolio, store, log: say });
  analysis.applySettings();
  market.start();

  const o = await analysis.checkOllama();
  say(o.up ? `Ollama ${o.version} sur ${client.base} — modèles : ${o.models.map((m) => m.name).join(', ') || 'aucun'} → modèle utilisé : ${analysis.model()}` : `Ollama injoignable sur ${client.base} (${o.error}) → réponses SIMULÉES tant qu'il n'est pas lancé`);

  const timers = [
    setInterval(() => portfolio.tick(), 250),
    setInterval(() => alerts.check(), 500),
    setInterval(() => portfolio.sample(), 60_000),
    setInterval(() => analysis.checkOllama(), 30_000),
    setInterval(() => analysis.trackOutcomes(), 5000),
  ];
  // la boucle tourne toujours (demandes manuelles) ; autoAnalysis = false coupe seulement l'analyse automatique des favoris
  analysis.loop({ favorites: autoAnalysis }).catch((e) => say(`boucle IA arrêtée : ${e.message}`));

  const allowHosts = hostAllowList(host);
  const hubRef = { current: null };
  const hub = { broadcast: (...a) => hubRef.current?.broadcast(...a), info: () => hubRef.current?.info() ?? null };
  const app = createApp({ root: ROOT, store, compute, market, portfolio, analysis, agent, alerts, hub, log: say, allowHosts, dataRewrite });
  const server = http.createServer(app);
  server.keepAliveTimeout = 65_000;
  hubRef.current = createHub({ server, market, portfolio, analysis, agent, alerts, compute, log: say, allowHosts });
  market.on('mode', (m) => {
    portfolio.load();
    say(`données : ${m === 'real' ? 'RÉELLES' : 'démonstration (simulées)'}`);
    hubRef.current?.broadcast({ t: 'reload', reason: 'mode' });
  });
  await new Promise((ok, ko) => {
    server.once('error', ko);
    server.listen(port, host, ok);
  });
  const addr = server.address();
  const everywhere = host === '0.0.0.0' || host === '::';
  say(`prêt en ${((Date.now() - t0) / 1000).toFixed(1)} s → http://${everywhere || host === '127.0.0.1' ? 'localhost' : host}:${addr.port}`);
  if (everywhere) {
    const urls = machineAddresses().filter((a) => a.v4 && !a.internal).map((a) => `http://${a.address}:${addr.port}${isTailscale(a.address) ? ' (Tailscale)' : ''}`);
    if (urls.length) say(`réseau : ${urls.join(' · ')}`);
    say('⚠ Bourso écoute sur tout le réseau, sans mot de passe : à réserver à un réseau de confiance (Tailscale, maison). Pour un nom (MagicDNS…) : BOURSO_ALLOW_HOSTS=nom');
  }

  let closing = false;
  const close = async () => {
    if (closing) return;
    closing = true;
    timers.forEach(clearInterval);
    analysis.stop();
    market.stop();
    hubRef.current.close();
    await new Promise((r) => server.close(r));
    server.closeAllConnections?.();
    await store.flush().catch(() => {});
    await compute.close();
  };
  return { server, port: addr.port, store, compute, market, portfolio, analysis, agent, alerts, hub: hubRef.current, close };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  // une erreur JavaScript imprévue ne doit pas arrêter le serveur : on la journalise en entier
  process.on('uncaughtException', (e) => log(`ERREUR imprévue (le serveur continue) : ${e?.stack ?? e}`));
  process.on('unhandledRejection', (e) => log(`ERREUR asynchrone imprévue (le serveur continue) : ${e?.stack ?? e}`));
  const s = await startServer().catch((e) => {
    console.error(`Bourso n'a pas pu démarrer : ${e.message}`);
    if (e.code === 'EADDRINUSE') console.error(`Le port ${process.env.BOURSO_PORT ?? DEFAULT_PORT} est déjà utilisé (une autre application ?) : choisis-en un autre, par ex. BOURSO_PORT=3001 npm start`);
    process.exit(2);
  });
  let stopping = false;
  const stop = async (why) => {
    if (stopping) return;
    stopping = true;
    log(`arrêt (${why})…`);
    setTimeout(() => process.exit(0), 4000); // arrêt forcé si la fermeture traîne
    await s.close().catch(() => {});
    process.exit(0);
  };
  process.on('SIGINT', () => stop('SIGINT'));
  process.on('SIGTERM', () => stop('SIGTERM'));
  // lancé par le superviseur : s'il disparaît, on s'arrête proprement
  if (process.env.BOURSO_SUPERVISED === '1') process.on('disconnect', () => stop('superviseur parti'));
}

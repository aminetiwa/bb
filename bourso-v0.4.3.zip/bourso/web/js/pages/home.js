// ============================================================================
//  BOURSO :: pages/home.js — ACCUEIL : la séance en un coup d'œil.
//  Indices, places et devises · favoris avec la dernière décision de l'IA · palmarès européens ·
//  volumes inhabituels · secteurs · largeur de marché · décisions IA · actualités · portefeuille.
// ============================================================================
import { S } from '../core/store.js';
import { get, history } from '../core/api.js';
import { live } from '../core/live.js';
import { $, setHtml, sparkSvg, meter } from '../core/dom.js';
import { esc, pct, num, cls, eur, int, big, ago, fullDate, decisionChip, ratingChip, price, dateTime } from '../core/fmt.js';
import { nameCell, star, chg, px, bindStars, newsItem, clockRow, symHref } from '../core/ui.js';

export default {
  title: 'Accueil',
  async mount(root) {
    root.innerHTML = `
      <div class="page-title"><h1>La séance</h1><span class="sub" id="h-sub"></span></div>
      <div class="layout">
        <aside>
          <section class="box"><h2 class="box-title"><span class="ico">▤</span>Indices <span class="title-note">${S.real ? 'niveaux réels, différés' : 'paniers simulés'}</span></h2><table class="tbl" id="h-idx"></table></section>
          <section class="box"><h2 class="box-title"><span class="ico">◷</span>Places boursières <span class="title-note"><a href="#/marches/places">toutes</a></span></h2><div class="scroll"><table class="tbl compact" id="h-clocks"></table></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">€</span>Devises <span class="title-note">pour 1 €</span></h2><table class="tbl compact" id="h-fx"></table></section>
        </aside>
        <div>
          <section class="box"><h2 class="box-title"><span class="ico">★</span>Mes favoris <span class="title-note">l'IA les analyse dans cet ordre · <a href="#/favoris">gérer</a></span></h2><table class="tbl" id="h-favs"></table></section>
          <div class="cols cols-2">
            <section class="box"><h2 class="box-title"><span class="ico up">▲</span>Plus fortes hausses — Europe</h2><table class="tbl compact" id="h-gain"></table></section>
            <section class="box"><h2 class="box-title"><span class="ico down">▼</span>Plus fortes baisses — Europe</h2><table class="tbl compact" id="h-lose"></table></section>
            <section class="box"><h2 class="box-title"><span class="ico">⚡</span>Volumes inhabituels <span class="title-note">volume ÷ moyenne 20 j au même moment</span></h2><table class="tbl compact" id="h-relvol"></table></section>
            <section class="box"><h2 class="box-title"><span class="ico">⇄</span>Les plus échangées <span class="title-note">capitaux en € · <label class="chk"><input type="checkbox" id="h-world"> monde</label></span></h2><table class="tbl compact" id="h-active"></table></section>
          </div>
          <section class="box"><h2 class="box-title"><span class="ico">▦</span>Secteurs du jour <span class="title-note">variation moyenne · <a href="#/marches/secteurs">détail</a></span></h2><div class="box-body" id="h-sectors"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">≋</span>Largeur de marché par région</h2><table class="tbl" id="h-breadth"></table></section>
        </div>
        <aside class="col-right">
          <section class="box"><h2 class="box-title"><span class="ico">◆</span>Dernières décisions de l'IA <span class="title-note"><a href="#/ia">console</a></span></h2><table class="tbl compact" id="h-sigs"></table></section>
          <section class="box"><h2 class="box-title"><span class="ico">✉</span>Actualités <span class="title-note"><a href="#/actualites">toutes</a></span></h2><ul class="news scroll tall" id="h-news"></ul></section>
          <section class="box"><h2 class="box-title"><span class="ico">₪</span>Mon portefeuille <span class="title-note">${S.real ? 'fictif' : 'simulé'} · <a href="#/portefeuille">détail</a></span></h2><div id="h-pf"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">⏰</span>Alertes <span class="title-note"><a href="#/portefeuille/alertes">gérer</a></span></h2><div id="h-alerts"></div></section>
        </aside>
      </div>`;
    const offStars = bindStars(root);
    const sparks = new Map();
    const loadSparks = async () => {
      await Promise.all(S.favorites.filter((s) => !sparks.has(s)).map(async (s) => {
        try { const h = await history(s, '1D'); sparks.set(s, Array.from(h.close.subarray(Math.max(0, h.close.length - 64)))); } catch { /* ignoré */ }
      }));
    };

    const renderFavs = () => {
      const rows = S.favorites.map((s, i) => {
        const q = S.quote(s), r = S.row(s), a = S.ai.queue?.favorites?.find((f) => f.sym === s);
        const series = sparks.get(s);
        const spark = series ? sparkSvg([...series.slice(0, -1), Number.isFinite(q?.last) ? q.last : series.at(-1)], { w: 90, h: 24, base: series.at(-2) }) : '';
        const st = a?.state === 'running' ? '<span class="chip run">analyse…</span>' : a?.decision ? decisionChip(a.decision, ` ${Math.round((a.confidence ?? 0) * 100)} %`) : '<span class="chip none">en attente</span>';
        return `<tr><td class="muted">${i + 1}</td><td>${star(s)}</td><td>${nameCell(s)}</td><td class="r num"><b>${q ? px(s, q.last) : '—'}</b></td><td class="r num">${q ? chg(q.chgPct) : '—'}</td>
          <td>${spark}</td><td class="r num">${r?.rsi14 ?? '—'}</td><td>${ratingChip(r?.rating, r?.ratingLabel)}</td><td>${st}${a?.simulated ? ' <span class="chip sim">simulé</span>' : ''}</td></tr>`;
      });
      setHtml($('#h-favs'), `<thead><tr><th>#</th><th></th><th>Valeur</th><th class="r">Cours</th><th class="r">Var.</th><th>3 mois</th><th class="r">RSI</th><th>Technique</th><th>Décision IA</th></tr></thead><tbody>${rows.join('') || '<tr class="empty"><td colspan="9">Aucun favori : ajoute des valeurs avec ☆</td></tr>'}</tbody>`);
    };

    const pickRows = (list) => `<tbody>${list.map((x) => `<tr><td>${star(x.sym)}</td><td>${nameCell(x.sym)}</td><td class="r num">${px(x.sym, x.last)}</td><td class="r num">${chg(x.chgPct)}</td></tr>`).join('')}</tbody>`;
    const renderOverview = (o) => {
      if (!o) return;
      const reg = (k) => o.indices.find((i) => i.key === k);
      const idxKeys = ['EUROPE', 'XPAR', 'XETR', 'XAMS', 'XLON', 'XMIL', 'XMAD', 'XSWX', 'XBRU', 'XSTO', 'MONDE', 'XNYS', 'XNAS', 'XTKS', 'XHKG'];
      setHtml($('#h-idx'), `<thead><tr><th>Indice</th><th class="r">Niveau</th><th class="r">Var.</th><th class="r" title="hausses / baisses${S.real ? ' parmi les valeurs suivies par Bourso' : ''}">▲/▼</th></tr></thead><tbody>${idxKeys.map(reg).filter(Boolean).map((i) => `<tr${S.real && i.at ? ` title="niveau du ${dateTime(i.at)}${i.proxy ? ' — indice approché par un fonds indiciel coté' : ''}"` : ''}><td>${esc(i.name.replace(' (panier sim.)', ''))}</td><td class="r num">${num(i.level, 2)}</td><td class="r num">${chg(i.chgPct)}</td><td class="r small"><span class="up">${i.up}</span>/<span class="down">${i.down}</span></td></tr>`).join('')}</tbody>`);
      setHtml($('#h-gain'), pickRows(o.gainersEu.slice(0, 8)));
      setHtml($('#h-lose'), pickRows(o.losersEu.slice(0, 8)));
      const world = $('#h-world')?.checked;
      setHtml($('#h-relvol'), `<tbody>${(world ? o.relVol : o.relVolEu).slice(0, 8).map((x) => `<tr><td>${nameCell(x.sym)}</td><td class="r num"><b>× ${num(x.relVol, 1)}</b></td><td class="r num">${chg(x.chgPct)}</td></tr>`).join('') || `<tr class="empty"><td>${S.real ? 'Pas encore d\'échanges aujourd\'hui sur ces places (ou indicateurs en cours de calcul)' : 'Aucun volume inhabituel'}</td></tr>`}</tbody>`);
      setHtml($('#h-active'), `<tbody>${(world ? o.active : o.activeEu).slice(0, 8).map((x) => `<tr><td>${nameCell(x.sym)}</td><td class="r num">${big(x.turnoverEur)} €</td><td class="r num">${chg(x.chgPct)}</td></tr>`).join('')}</tbody>`);
      const maxAbs = Math.max(0.5, ...o.sectors.map((s) => Math.abs(s.chg)));
      const secRow = (s) => `<tr title="meilleure : ${esc(s.best?.name ?? '')} ${pct(s.best?.chgPct)} · moins bonne : ${esc(s.worst?.name ?? '')} ${pct(s.worst?.chgPct)}"><td>${esc(s.name)}</td><td style="width:34%"><div class="meter center"><i style="left:${s.chg >= 0 ? 50 : 50 + (s.chg / maxAbs) * 50}%;width:${(Math.abs(s.chg) / maxAbs) * 50}%;background:${s.chg >= 0 ? 'var(--up)' : 'var(--down)'}"></i></div></td><td class="r num">${chg(s.chg)}</td><td class="r small"><span class="up">${s.up}</span>/<span class="down">${s.down}</span></td></tr>`;
      const half = Math.ceil(o.sectors.length / 2);
      setHtml($('#h-sectors'), `<div class="cols cols-2"><table class="tbl compact"><tbody>${o.sectors.slice(0, half).map(secRow).join('')}</tbody></table><table class="tbl compact"><tbody>${o.sectors.slice(half).map(secRow).join('')}</tbody></table></div>`);
      setHtml($('#h-breadth'), `<thead><tr><th>Région</th><th class="r">Valeurs</th><th>Hausses / baisses</th><th class="r">&gt; MM200</th><th class="r">&gt; VWAP</th><th class="r">Var. moy.</th></tr></thead><tbody>${Object.entries(o.breadth).map(([k, b]) => `<tr><td><b>${esc(k)}</b></td><td class="r">${b.n}</td><td style="width:30%"><div class="meter" style="background:var(--down-bg)"><i style="width:${((b.up / b.n) * 100).toFixed(1)}%;background:var(--up)"></i></div><small><span class="up">${b.up}</span> / <span class="down">${b.down}</span></small></td><td class="r">${Math.round((b.aboveSma200 / b.n) * 100)} %</td><td class="r">${Math.round((b.aboveVwap / b.n) * 100)} %</td><td class="r">${chg(b.avgChg)}</td></tr>`).join('')}</tbody>`);
      setHtml($('#h-clocks'), `<tbody>${o.clocks.map(clockRow).join('')}</tbody>`);
      setHtml($('#h-fx'), `<tbody>${o.fx.slice(0, 14).map((f) => `<tr><td>${esc(f.pair)}</td><td class="r num">${num(f.rate, f.rate > 50 ? 2 : 4)}</td><td class="r num">${chg(f.chgPct)}</td></tr>`).join('')}</tbody>`);
      $('#h-sub').textContent = `${fullDate(Date.now())} · ${S.universe.length} actions sur ${o.clocks.length} places · ${o.clocks.filter((c) => c.live).length} places ouvertes`;
    };

    const renderNews = (fresh) => setHtml($('#h-news'), S.news.slice(0, 14).map((n, i) => newsItem(n, { fresh: fresh && i === 0 })).join(''));
    const renderSigs = async () => {
      const sigs = await get('/api/ai/signals?limit=9').catch(() => []);
      setHtml($('#h-sigs'), sigs.length ? `<tbody>${sigs.map((g) => `<tr><td class="small muted">${ago(g.at)}</td><td>${nameCell(g.sym, { sub: false, name: g.name })}</td><td>${decisionChip(g.decision)}</td><td class="r num">${Math.round(g.confidence * 100)} %</td><td>${g.simulated ? '<span class="chip sim">simulé</span>' : ''}${g.outcome ? ` <span class="chip ${g.outcome === 'objectif' ? 'ok' : g.outcome === 'stop' ? 'ko' : ''}">${esc(g.outcome)}</span>` : ''}</td></tr>`).join('')}</tbody>` : '<tbody><tr class="empty"><td>L\'IA n\'a encore rien analysé</td></tr></tbody>');
    };
    const renderPf = async () => {
      const p = await get('/api/portfolio').catch(() => null);
      if (!p) return;
      const top = [...p.positions].sort((a, b) => Math.abs(b.valueEur) - Math.abs(a.valueEur)).slice(0, 4);
      setHtml($('#h-pf'), `<table class="kv"><tr><th>Valeur totale</th><td>${eur(p.totalEur, 2)}</td></tr><tr><th>Performance</th><td class="${cls(p.perfPct)}">${pct(p.perfPct)}</td></tr>
        <tr><th>Liquidités</th><td>${eur(p.cashEur, 2)}</td></tr><tr><th>Plus-value latente</th><td class="${cls(p.unrealizedEur)}">${eur(p.unrealizedEur, 2)}</td></tr><tr><th>Frais payés (dont TTF)</th><td>${eur(p.feesEur, 2)}</td></tr></table>
        ${top.length ? `<table class="tbl compact"><tbody>${top.map((x) => `<tr><td>${nameCell(x.sym, { sub: false })}</td><td class="r num">${int(x.qty)}</td><td class="r num">${eur(x.valueEur)}</td><td class="r num">${chg(x.upnlPct)}</td></tr>`).join('')}</tbody></table>` : '<div class="empty">Aucune position — F1 pour acheter</div>'}`);
    };
    const renderAlerts = async () => {
      const al = await get('/api/alerts').catch(() => []);
      const act = al.filter((a) => a.active), trig = al.filter((a) => !a.active).slice(0, 3);
      setHtml($('#h-alerts'), `<div class="box-body small">${act.length} alerte(s) active(s)${trig.length ? ' · dernières déclenchées :' : ''}</div>${trig.length ? `<table class="tbl compact"><tbody>${trig.map((a) => `<tr><td>${nameCell(a.sym, { sub: false })}</td><td class="num">${px(a.sym, a.triggerPrice)}</td><td class="small muted">${ago(a.triggeredAt)}</td></tr>`).join('')}</tbody></table>` : ''}`);
    };

    renderOverview(S.overview);
    renderFavs();
    renderNews(false);
    await Promise.all([renderSigs(), renderPf(), renderAlerts(), loadSparks()]);
    renderFavs();
    if (!S.overview) renderOverview(await get('/api/overview'));

    $('#h-world').addEventListener('change', () => renderOverview(S.overview));
    let favT = 0;
    const offs = [
      S.on('overview', renderOverview),
      S.on('quotes', () => { const t = performance.now(); if (t - favT > 500) { favT = t; renderFavs(); } }),
      S.on('screener', renderFavs),
      S.on('favorites', () => loadSparks().then(renderFavs)),
      S.on('news', () => renderNews(true)),
      S.on('ai', (m) => { if (m.ev === 'queue') renderFavs(); if (m.ev === 'result') renderSigs(); }),
      live.on('pf', renderPf),
      live.on('alerts', renderAlerts),
    ];
    return { unmount() { offs.forEach((f) => f()); offStars(); } };
  },
};
void price;

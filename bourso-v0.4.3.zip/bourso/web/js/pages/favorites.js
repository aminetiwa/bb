// ============================================================================
//  BOURSO :: pages/favorites.js — FAVORIS : la liste que l'IA analyse, dans l'ordre.
//  Glisser-déposer pour réordonner, ajout par recherche, état de l'IA par valeur (en attente,
//  en cours, analysée, ignorée faute de nouveauté), dernière décision, règle de réanalyse.
// ============================================================================
import { S } from '../core/store.js';
import { get, post, history } from '../core/api.js';
import { live } from '../core/live.js';
import { $, el, on, setHtml, sparkSvg, toast, meter } from '../core/dom.js';
import { esc, num, pct, int, ago, decisionChip, ratingChip, dur } from '../core/fmt.js';
import { nameCell, chg, px, symHref } from '../core/ui.js';

const STATE = { waiting: ['en attente', ''], running: ['analyse en cours', 'run'], done: ['analysée', 'ok'], skipped: ['rien de nouveau', 'hold'], error: ['erreur', 'ko'] };

export default {
  title: 'Favoris',
  async mount(root) {
    root.innerHTML = `<div class="page-title"><h1>Mes favoris</h1><span class="sub">l'IA n'analyse que ces valeurs, une par une, dans cet ordre</span></div>
      <div class="layout l2">
        <div>
          <section class="box ov"><h2 class="box-title"><span class="ico">★</span>Liste ordonnée <span class="title-note">glisser-déposer ou ▲▼ pour changer l'ordre</span></h2>
            <div class="form" style="position:relative"><input type="search" id="f-add" placeholder="Ajouter une valeur : nom, code ou ISIN…" style="width:420px" autocomplete="off"><div class="suggest hidden" id="f-sug" style="top:36px;left:10px;width:520px"></div><span class="help-text">Toutes les places ; l'Europe apparaît en premier.</span></div>
            <table class="tbl" id="f-tbl"></table></section>
        </div>
        <aside>
          <section class="box"><h2 class="box-title"><span class="ico">◆</span>Comment l'IA travaille</h2><div class="box-body small stack">
            <p>Un <b>seul modèle</b> (~30 milliards de paramètres, via Ollama) passe sur tes favoris <b>dans l'ordre</b>, puis recommence. Les analyses demandées à la main passent devant.</p>
            <p>Pour ne pas gaspiller de calcul, une valeur n'est <b>réanalysée que s'il y a du nouveau</b> : mouvement de cours, actualité importante, ou dernière analyse trop ancienne.</p>
            <p>Avant chaque appel au modèle, la machine calcule tout : ~60 indicateurs, Monte Carlo GPU/CPU, backtests, régimes de Markov, cycles, niveaux, actualités, position. Le modèle ne fait que raisonner sur ces chiffres.</p></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">⚙</span>Règle de réanalyse</h2><div class="form col" id="f-policy"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">Σ</span>Compteurs</h2><div id="f-stats"></div></section>
        </aside>
      </div>`;
    const sparks = new Map();
    let dragSym = null;
    const loadSparks = async () => Promise.all(S.favorites.filter((s) => !sparks.has(s)).map(async (s) => {
      try { const h = await history(s, '1D'); sparks.set(s, Array.from(h.close.subarray(h.close.length - 64))); } catch { /* ignoré */ }
    }));
    const render = () => {
      if (dragSym) return;
      const q = S.ai.queue, rows = S.favorites.map((s, i) => {
        const qq = S.quote(s), r = S.row(s), a = q?.favorites?.find((f) => f.sym === s) ?? {}, st = STATE[a.state] ?? STATE.waiting, sp = sparks.get(s);
        return `<tr draggable="true" data-sym="${esc(s)}" class="${a.state === 'running' ? 'sel' : ''}">
          <td class="muted" style="cursor:grab">⋮⋮ ${i + 1}</td><td>${nameCell(s)}</td><td class="r"><b>${qq ? px(s, qq.last) : '—'}</b></td><td class="r">${qq ? chg(qq.chgPct) : '—'}</td>
          <td>${sp ? sparkSvg([...sp.slice(0, -1), Number.isFinite(qq?.last) ? qq.last : sp.at(-1)], { w: 100, h: 26, base: sp.at(-2), fill: true }) : ''}</td>
          <td class="r">${r ? num(r.rsi14, 1) : '—'}</td><td>${ratingChip(r?.rating, r?.ratingLabel)}</td><td class="r">${r ? chg(r.perf1m, 1) : '—'}</td>
          <td><span class="chip ${st[1]}">${st[0]}</span><small>${esc(a.reason ?? '')}</small></td>
          <td>${a.decision ? `${decisionChip(a.decision)} <b>${Math.round((a.confidence ?? 0) * 100)} %</b>${a.simulated ? ' <span class="chip sim">simulé</span>' : ''}<small>${ago(a.at)}</small>` : '<span class="muted small">—</span>'}</td>
          <td class="r nowrap"><button class="mini" data-up ${i ? '' : 'disabled'}>▲</button><button class="mini" data-down ${i < S.favorites.length - 1 ? '' : 'disabled'}>▼</button>
            <button class="mini" data-run title="Analyser maintenant (prioritaire)">◆ analyser</button><a class="mini" href="${symHref(s)}">graphique</a><button class="mini" data-rm title="Retirer">✕</button></td></tr>`;
      });
      setHtml($('#f-tbl', root), `<thead><tr><th>#</th><th>Valeur</th><th class="r">Cours</th><th class="r">Var.</th><th>3 mois</th><th class="r">RSI</th><th>Technique</th><th class="r">1 mois</th><th>État de l'IA</th><th>Dernière décision</th><th></th></tr></thead><tbody>${rows.join('') || '<tr class="empty"><td colspan="11">Aucun favori : ajoute une valeur ci-dessus.</td></tr>'}</tbody>`);
      const stt = q?.stats ?? {};
      setHtml($('#f-stats', root), `<table class="kv"><tr><th>Analyses faites</th><td>${int(stt.analyzed)}</td></tr><tr><th>Évitées (rien de nouveau)</th><td>${int(stt.skipped)} <small class="muted">· ${pct((q?.saved ?? 0) * 100, 0, false)} de calcul économisé</small></td></tr>
        <tr><th>Réponses simulées</th><td>${int(stt.simulated)}</td></tr><tr><th>Erreurs</th><td>${int(stt.errors)}</td></tr><tr><th>En cours</th><td>${q?.running ? `${esc(q.running.name)} — ${esc(q.running.stage ?? '')}` : '—'}</td></tr>
        <tr><th>Demandes manuelles en file</th><td>${q?.manual?.length ?? 0}</td></tr></table>`);
    };
    const renderPolicy = () => {
      const a = S.settings.ai, p = a.policy;
      $('#f-policy', root).innerHTML = `<label class="chk"><input type="checkbox" data-k="auto" ${a.auto ? 'checked' : ''}> analyse automatique des favoris</label>
        <label class="f">Réanalyser si le cours a bougé de plus de (%)<input type="number" data-p="movePct" value="${p.movePct}" step="0.1" min="0.05"></label>
        <label class="f">Réanalyser au plus tard après (minutes)<input type="number" data-p="maxAgeMin" value="${Math.round(p.maxAgeMs / 60000)}" min="1"></label>
        <label class="f">Jamais deux fois en moins de (minutes)<input type="number" data-p="minGapMin" value="${Math.round(p.minGapMs / 60000)}" min="0"></label>
        <label class="chk"><input type="checkbox" data-p="onlyDuringSession" ${p.onlyDuringSession ? 'checked' : ''}> seulement pendant la séance</label>
        <button class="btn btn-small primary" id="f-save">Enregistrer</button>`;
      $('#f-save', root).onclick = async () => {
        const g = (k) => root.querySelector(`[data-p="${k}"]`);
        await S.saveSettings({ ai: { auto: root.querySelector('[data-k="auto"]').checked, policy: { movePct: Number(g('movePct').value), maxAgeMs: Number(g('maxAgeMin').value) * 60000, minGapMs: Number(g('minGapMin').value) * 60000, onlyDuringSession: g('onlyDuringSession').checked } } });
        toast('Règle enregistrée', '', 'ok', 1500);
      };
    };
    // ajout par recherche
    const input = $('#f-add', root), sug = $('#f-sug', root);
    let tm = null;
    input.addEventListener('input', () => {
      clearTimeout(tm);
      tm = setTimeout(async () => {
        const v = input.value.trim();
        if (!v) { sug.classList.add('hidden'); return; }
        const r = await get(`/api/search?q=${encodeURIComponent(v)}&limit=10`);
        sug.innerHTML = r.map((x) => `<a href="#" data-add="${esc(x.sym)}"><span class="code">${esc(x.code)}</span><span>${esc(x.name)} <span class="where">${esc(x.ex)}</span></span><span>${S.isFav(x.sym) ? '★ déjà' : '+ ajouter'}</span><span></span></a>`).join('') || '<div class="empty">Aucune valeur</div>';
        sug.classList.remove('hidden');
      }, 120);
    });
    on(sug, 'click', '[data-add]', async (e, a) => {
      e.preventDefault();
      if (!S.isFav(a.dataset.add)) await S.setFavorites([...S.favorites, a.dataset.add]);
      input.value = '';
      sug.classList.add('hidden');
      toast('Ajouté aux favoris', esc(S.name(a.dataset.add)), 'ok', 2000);
    });
    // réordonner, retirer, analyser
    const tbl = $('#f-tbl', root);
    const move = (sym, d) => {
      const l = [...S.favorites], i = l.indexOf(sym), j = i + d;
      if (j < 0 || j >= l.length) return;
      [l[i], l[j]] = [l[j], l[i]];
      S.setFavorites(l);
    };
    on(tbl, 'click', 'button', async (e, b) => {
      const sym = b.closest('tr')?.dataset.sym;
      if (!sym) return;
      if (b.hasAttribute('data-up')) move(sym, -1);
      else if (b.hasAttribute('data-down')) move(sym, 1);
      else if (b.hasAttribute('data-rm')) S.setFavorites(S.favorites.filter((s) => s !== sym));
      else if (b.hasAttribute('data-run')) { await post('/api/ai/analyze', { sym }); toast('Analyse demandée', `${esc(S.name(sym))} passe en tête de file`, 'ok', 2500); }
    });
    tbl.addEventListener('dragend', () => { dragSym = null; });
    tbl.addEventListener('dragstart', (e) => { dragSym = e.target.closest('tr')?.dataset.sym; e.dataTransfer.effectAllowed = 'move'; });
    tbl.addEventListener('dragover', (e) => { if (dragSym) e.preventDefault(); });
    tbl.addEventListener('drop', (e) => {
      e.preventDefault();
      const target = e.target.closest('tr')?.dataset.sym;
      const moving = dragSym;
      dragSym = null;
      if (!moving || !target || target === moving) return;
      const l = S.favorites.filter((s) => s !== moving);
      l.splice(l.indexOf(target) + (S.favorites.indexOf(moving) < S.favorites.indexOf(target) ? 1 : 0), 0, moving);
      S.setFavorites(l);
    });
    renderPolicy();
    render();
    await loadSparks();
    render();
    let t = 0;
    const offs = [S.on('favorites', () => loadSparks().then(render)), S.on('ai', (m) => { if (m.ev === 'queue') render(); }), S.on('screener', render),
      S.on('quotes', () => { if (performance.now() - t > 600) { t = performance.now(); render(); } }), S.on('settings', renderPolicy)];
    return { unmount() { offs.forEach((f) => f()); } };
  },
};
void [el, live, meter, dur];

// ============================================================================
//  BOURSO :: chart/engine.js — moteur du graphique pro.
//
//  • Séries dessinées par le GPU (WebGL2, cf. gl.js) : bougies, bougies creuses, barres OHLC,
//    ligne, aire, Heikin-Ashi ; volumes en surimpression ; profil de volume de la zone visible
//    (POC, zone de valeur 70 %) ; indicateurs sur les cours et en panneaux (lignes épaisses,
//    histogrammes 4 couleurs, points, bandes, nuage d'Ichimoku projeté dans le futur).
//  • Calque 2D : axes au format français, grille hiérarchisée, réticule (aimanté sur l'OHLC),
//    étiquettes (dernier cours + compte à rebours de la bougie, réticule, indicateurs, niveaux),
//    plus haut / plus bas visibles, lignes de prix (plan de l'IA, ordres, alertes, PRU),
//    repères (décisions de l'IA, exécutions, actualités), tracés (drawings.js).
//  • Interactions : glisser (déplacement), molette (zoom centré), axes (échelles), séparateurs
//    de panneaux, double-clic (recadrage), clavier, clic droit (menu contextuel).
//  Les prix → pixels sont calculés en double précision ; seules les bougies visibles sont
//  envoyées au GPU, regroupées quand il y en a plus que de pixels (jamais de perte d'extrêmes).
// ============================================================================
import { GlBatch, parseColor } from './gl.js';
import { INDICATORS, labelOf } from './indicators.js';
import { heikinAshi } from '/src/core/quant/indicators.js';
import { Emitter } from '../core/live.js';
import { num, esc, decOf } from '../core/fmt.js';

const css = (k) => getComputedStyle(document.documentElement).getPropertyValue(k).trim();
const NF = new Map();
const nf = (d) => {
  if (!NF.has(d)) NF.set(d, new Intl.NumberFormat('fr-FR', { minimumFractionDigits: d, maximumFractionDigits: d }));
  return NF.get(d);
};
const STEPS = [1, 2, 2.5, 5, 10];

export const CHART_TYPES = { candles: 'Bougies', hollow: 'Bougies creuses', heikin: 'Heikin-Ashi', bars: 'Barres OHLC', line: 'Ligne', area: 'Aire' };

export class ProChart extends Emitter {
  /**
   * @param {HTMLElement} wrap conteneur (.chart-wrap)
   * @param {{ type?:string, log?:boolean, volume?:boolean, vp?:boolean, magnet?:string, rightPad?:number }} opts
   */
  constructor(wrap, opts = {}) {
    super();
    this.wrap = wrap;
    this.cvGl = document.createElement('canvas');
    this.cvOv = document.createElement('canvas');
    this.cvOv.className = 'ov';
    this.legend = document.createElement('div');
    this.legend.className = 'chart-legend';
    wrap.append(this.cvGl, this.cvOv, this.legend);
    this.ctx = this.cvOv.getContext('2d');
    this.gl = new GlBatch(this.cvGl);
    this.opt = { type: 'candles', log: false, volume: true, vp: false, magnet: 'weak', rightPad: 8, sessions: true, hiLo: true, watermark: true, ...opts };
    this.view = { left: 0, ppb: 8, follow: true };
    this.indicators = [];
    this.outs = new Map();
    this.priceLines = [];
    this.zones = [];
    this.markers = [];
    this.mouse = { x: -1, y: -1, inside: false, pane: null };
    this.drag = null;
    this.data = null;
    this.drawings = null;
    this.clockSec = null;
    this.stats = { frameMs: 0, verts: 0, slots: 0, k: 1, renderer: this.gl.renderer };
    this.#theme();
    this.#bind();
    this.ro = new ResizeObserver(() => this.#resize());
    this.ro.observe(wrap);
    this.#resize();
  }

  destroy() {
    this.dead = true;
    this.ro.disconnect();
    window.removeEventListener('keydown', this.onKey);
    this.wrap.innerHTML = '';
  }

  // ======================================================================= données
  /**
   * @param {{ sym, name, tf, tfLabel, tick, ccy, o, h, l, c, v, ts }} d  (ts = buildTimescale)
   * @param {{ keepView?:boolean }} o
   */
  setData(d, { keepView = false } = {}) {
    const n = d.c.length, cap = Math.max(64, Math.ceil(n * 1.25) + 64);
    const grow = (a) => { const x = new Float64Array(cap); x.set(a); return x; };
    const prev = this.data;
    this.data = { ...d, n, cap, o: grow(d.o), h: grow(d.h), l: grow(d.l), c: grow(d.c), v: grow(d.v), t: grow(d.ts.t) };
    this.dec = decOf(d.tick);
    this.indDirty = true;
    this.haDirty = true;
    if (!keepView || !prev) {
      this.view.ppb = Math.max(1, Math.min(18 * this.dpr, this.plotW / 140));
      this.view.follow = true;
      for (const p of this.panes ?? []) { p.manual = null; }
    }
    if (this.view.follow) this.#follow();
    this.#layout();
    this.invalidate();
  }

  get n() {
    return this.data?.n ?? 0;
  }

  /** Remplace la dernière bougie (mise à jour en direct). */
  updateLast(o, h, l, c, v) {
    const d = this.data;
    if (!d || !d.n) return;
    const i = d.n - 1;
    d.o[i] = o; d.h[i] = h; d.l[i] = l; d.c[i] = c; d.v[i] = v;
    this.indDirty = true;
    this.haDirty = true;
    this.invalidate();
  }

  /** Ajoute une bougie (t = clé de temps). */
  append(o, h, l, c, v, t) {
    const d = this.data;
    if (!d) return;
    if (d.n >= d.cap) {
      const cap = Math.ceil(d.cap * 1.5);
      for (const k of ['o', 'h', 'l', 'c', 'v', 't']) { const x = new Float64Array(cap); x.set(d[k]); d[k] = x; }
      d.cap = cap;
    }
    const i = d.n++;
    d.o[i] = o; d.h[i] = h; d.l[i] = l; d.c[i] = c; d.v[i] = v; d.t[i] = t;
    if (this.view.follow) this.#follow();
    this.indDirty = true;
    this.haDirty = true;
    this.invalidate();
  }

  last() {
    const d = this.data, i = d.n - 1;
    return { i, o: d.o[i], h: d.h[i], l: d.l[i], c: d.c[i], v: d.v[i], t: d.t[i] };
  }

  /** Série vue par les indicateurs (tableaux exacts de longueur n). */
  series() {
    const d = this.data, n = d.n;
    return { o: d.o.subarray(0, n), h: d.h.subarray(0, n), l: d.l.subarray(0, n), c: d.c.subarray(0, n), v: d.v.subarray(0, n), perSession: d.ts.perSession, periodsPerYear: d.ts.intraday ? 252 * (d.ts.perSession ?? 1) : d.tf === '1W' ? 52 : d.tf === '1M' ? 12 : 252 };
  }

  // ======================================================================= options, indicateurs, repères
  setOptions(patch) {
    Object.assign(this.opt, patch);
    if ('type' in patch) this.haDirty = true;
    if ('log' in patch && this.panes) this.panes[0].manual = null;
    this.invalidate();
  }

  setIndicators(list) {
    this.indicators = list;
    this.indDirty = true;
    this.#layout();
    this.invalidate();
  }

  setPriceLines(lines) { this.priceLines = lines ?? []; this.invalidate(); }
  setZones(z) { this.zones = z ?? []; this.invalidate(); }
  setMarkers(m) { this.markers = (m ?? []).slice().sort((a, b) => a.t - b.t); this.invalidate(); }
  setClock(sec) { this.clockSec = sec; }

  // ======================================================================= vue
  #follow() {
    const v = this.view;
    v.left = this.n + this.opt.rightPad - this.plotW / v.ppb;
  }
  resetView() {
    this.view.follow = true;
    this.view.ppb = Math.max(1, Math.min(18 * this.dpr, this.plotW / 140));
    for (const p of this.panes ?? []) p.manual = null;
    this.#follow();
    this.invalidate();
  }
  showAll() {
    this.view.follow = false;
    this.view.ppb = this.plotW / Math.max(30, this.n + this.opt.rightPad);
    this.view.left = 0;
    this.invalidate();
  }
  /** Affiche les `bars` dernières bougies. */
  showLast(bars) {
    this.view.ppb = Math.max(0.05, this.plotW / Math.max(10, bars + this.opt.rightPad));
    this.view.follow = true;
    this.#follow();
    this.invalidate();
  }
  zoom(f, ax = this.plotW * 0.85) {
    const v = this.view, idx = v.left + ax / v.ppb;
    v.ppb = Math.min(60 * this.dpr, Math.max(this.plotW / Math.max(40, (this.n + 50) * 1.05), v.ppb * f));
    if (v.follow) this.#follow();
    else v.left = idx - ax / v.ppb;
    this.#clamp();
    this.invalidate();
  }
  pan(bars) {
    this.view.left += bars;
    this.view.follow = false;
    this.#clamp();
    if (this.view.left + this.plotW / this.view.ppb >= this.n + this.opt.rightPad - 0.5) { this.view.follow = true; this.#follow(); }
    this.invalidate();
  }
  #clamp() {
    const v = this.view, span = this.plotW / v.ppb;
    v.left = Math.max(-span * 0.8, Math.min(this.n - 2, v.left));
  }

  // -------------------------------------------- conversions (pixels physiques)
  X(i) { return (i + 0.5 - this.view.left) * this.view.ppb; }
  indexAt(x) { return this.view.left + x / this.view.ppb - 0.5; }
  /** Clé de temps → position fractionnaire de bougie (interpolation ; extrapolation au-delà). */
  indexOfTime(t) {
    const d = this.data, n = d.n, T = d.t;
    if (!n) return 0;
    if (t <= T[0]) return (t - T[0]) / d.ts.stepT;
    if (t >= T[n - 1]) return n - 1 + (t - T[n - 1]) / d.ts.stepT;
    let a = 0, b = n - 1;
    while (b - a > 1) { const m = (a + b) >> 1; if (T[m] <= t) a = m; else b = m; }
    const span = T[b] - T[a];
    return a + (span > 0 ? Math.min(1, (t - T[a]) / Math.min(span, d.ts.stepT)) : 0);
  }
  timeOfIndex(f) {
    const d = this.data, n = d.n;
    if (!n) return 0;
    if (f <= 0) return d.t[0] + f * d.ts.stepT;
    if (f >= n - 1) return d.t[n - 1] + (f - (n - 1)) * d.ts.stepT;
    const a = Math.floor(f), fr = f - a;
    return d.t[a] + fr * Math.min(d.t[a + 1] - d.t[a], d.ts.stepT);
  }
  get price() { return this.panes?.[0]; }
  yOfPrice(p) { return this.panes[0].toY(p); }
  priceAt(y) { return this.panes[0].fromY(y); }

  // ======================================================================= mise en page
  #theme() {
    const g = (k) => css(k);
    this.th = {
      bg: g('--c-bg'), grid: g('--c-grid'), gridMajor: g('--c-grid-major'), text: g('--c-text'), axisBg: g('--c-axis-bg'), axisLine: g('--c-axis-line'),
      cross: g('--c-cross'), tagBg: g('--c-tag-bg'), tagFg: g('--c-tag-fg'), up: g('--c-up'), down: g('--c-down'), volUp: g('--c-vol-up'), volDown: g('--c-vol-down'),
      line: g('--c-line'), area: g('--c-area'), vpIn: g('--c-vp-in'), vpOut: g('--c-vp-out'), poc: g('--c-poc'), session: g('--c-session'), watermark: g('--c-watermark'),
      legendBg: g('--c-legend-bg'), legendText: g('--c-legend-text'), draw: g('--c-draw'), select: g('--c-select'),
    };
    const P = (c, a = null) => parseColor(c, a);
    this.col = {
      bg: P(this.th.bg), grid: P(this.th.grid), gridMajor: P(this.th.gridMajor), up: P(this.th.up), down: P(this.th.down), volUp: P(this.th.volUp), volDown: P(this.th.volDown),
      line: P(this.th.line), areaTop: P(this.th.line, 0.28), areaBot: P(this.th.line, 0.02), vpIn: P(this.th.vpIn, 0.5), vpOut: P(this.th.vpOut, 0.45), poc: P(this.th.poc, 0.85),
      session: P(this.th.session), upSoft: P(this.th.up, 0.55), downSoft: P(this.th.down, 0.55),
    };
  }
  refreshTheme() {
    this.#theme();
    this.invalidate();
  }

  #resize() {
    const dpr = window.devicePixelRatio || 1, r = this.wrap.getBoundingClientRect();
    const W = Math.max(100, Math.round(r.width * dpr)), H = Math.max(100, Math.round(r.height * dpr));
    for (const c of [this.cvGl, this.cvOv]) { c.width = W; c.height = H; }
    const oldW = this.plotW;
    this.dpr = dpr;
    this.W = W;
    this.H = H;
    this.axisW = Math.round(74 * dpr);
    this.axisH = Math.round(22 * dpr);
    this.plotW = W - this.axisW;
    this.plotH = H - this.axisH;
    if (oldW && this.view.follow) this.#follow();
    this.#layout();
    this.invalidate();
  }

  /** Panneaux : cours (hauteur restante) + un panneau par indicateur hors cours. */
  #layout() {
    if (!this.plotH) return;
    const sub = this.indicators.filter((x) => !INDICATORS[x.type].overlay && x.visible !== false);
    const H = this.plotH, gap = Math.round(1 * this.dpr), minH = Math.round(48 * this.dpr);
    let used = 0;
    const subH = sub.map((ind) => {
      const h = Math.max(minH, Math.round((ind.height || 0.18) * H));
      used += h + gap;
      return h;
    });
    const priceH = Math.max(Math.round(H * 0.3), H - used);
    const old = new Map((this.panes ?? []).map((p) => [p.id, p]));
    const mk = (id, ind, y0, h) => {
      const p = old.get(id) ?? { id, manual: null };
      Object.assign(p, { ind, y0, h, def: ind ? INDICATORS[ind.type] : null });
      return p;
    };
    const panes = [mk('price', null, 0, priceH)];
    let y = priceH + gap;
    sub.forEach((ind, k) => { panes.push(mk(ind.id, ind, y, subH[k])); y += subH[k] + gap; });
    this.panes = panes;
    for (const p of panes) this.#scaleFns(p);
    this.#legendDom();
  }

  #scaleFns(p) {
    const log = p.id === 'price' && this.opt.log;
    p.log = log;
    const f = log ? (v) => Math.log(v) : (v) => v, g = log ? (v) => Math.exp(v) : (v) => v;
    p.f = f;
    p.toY = (v) => p.y0 + p.h - ((f(v) - p.lo) / (p.hi - p.lo)) * p.h;
    p.fromY = (y) => g(p.lo + ((p.y0 + p.h - y) / p.h) * (p.hi - p.lo));
  }

  // ======================================================================= calcul des indicateurs
  #compute() {
    const d = this.data;
    if (!d || !d.n) return;
    const s = this.series();
    this.outs.clear();
    for (const ind of this.indicators) {
      const def = INDICATORS[ind.type];
      if (!def || (def.intradayOnly && !d.ts.intraday)) { this.outs.set(ind.id, []); continue; }
      try {
        const outs = def.compute(s, ind.params);
        outs.forEach((o, k) => { o.color = ind.colors?.[k] ?? def.colors[k % def.colors.length] ?? '#888'; });
        this.outs.set(ind.id, outs);
      } catch (e) {
        console.error(`indicateur ${ind.type}`, e);
        this.outs.set(ind.id, []);
      }
    }
    this.indDirty = false;
    this.computedAt = performance.now();
    this.emit('computed');
  }

  #ha() {
    if (this.opt.type === 'heikin' && this.haDirty) {
      const s = this.series();
      this.haData = heikinAshi(s.o, s.h, s.l, s.c);
    }
    this.haDirty = false;
  }

  /** Valeurs d'un indicateur (sorties) — pour la légende et la page. */
  outputs(id) {
    return this.outs.get(id) ?? [];
  }

  // ======================================================================= rendu
  invalidate() {
    if (this.raf || this.dead) return;
    this.raf = requestAnimationFrame(() => { this.raf = 0; this.render(); });
  }

  render() {
    if (!this.data || !this.panes || this.dead) return;
    const t0 = performance.now();
    if (this.indDirty && (!this.computedAt || t0 - this.computedAt > 150 || this.outs.size !== this.indicators.length)) this.#compute();
    else if (this.indDirty) this.invalidate();
    this.#ha();
    const d = this.data, v = this.view, n = d.n, ppb = v.ppb;
    if (v.follow) this.#follow();
    // plage visible et regroupement (au moins ~2 px par créneau)
    const k = ppb >= 2 ? 1 : Math.ceil(2 / ppb);
    const i0 = Math.max(0, Math.floor(v.left) - 1), i1 = Math.min(n - 1, Math.ceil(v.left + this.plotW / ppb) + 1);
    this.vis = { i0, i1, k };
    const src = this.opt.type === 'heikin' && this.haData ? { o: this.haData.open, h: this.haData.high, l: this.haData.low, c: this.haData.close } : d;
    // créneaux (bougies regroupées)
    const slots = [];
    if (i1 >= i0) {
      const s0 = Math.floor(i0 / k) * k;
      for (let a = s0; a <= i1; a += k) {
        const b = Math.min(n - 1, a + k - 1);
        let H = -Infinity, L = Infinity, V = 0;
        for (let i = a; i <= b; i++) { if (src.h[i] > H) H = src.h[i]; if (src.l[i] < L) L = src.l[i]; V += d.v[i]; }
        slots.push({ a, b, x: this.X((a + b) / 2), o: src.o[a], h: H, l: L, c: src.c[b], v: V });
      }
    }
    this.slots = slots;
    this.#ranges(slots, i0, i1);
    this.#drawGl(slots, src);
    this.#drawOverlay(slots);
    this.#legendValues();
    this.stats.frameMs = performance.now() - t0;
    this.stats.slots = slots.length;
    this.stats.k = k;
    this.emit('render');
  }

  /** Échelles verticales automatiques (sauf panneau réglé à la main). */
  #ranges(slots, i0, i1) {
    for (const p of this.panes) {
      let lo = Infinity, hi = -Infinity;
      const take = (x) => { if (Number.isFinite(x)) { if (x < lo) lo = x; if (x > hi) hi = x; } };
      if (p.id === 'price') {
        for (const s of slots) { take(s.h); take(s.l); }
        for (const ind of this.indicators) {
          const def = INDICATORS[ind.type];
          if (!def?.overlay || ind.visible === false) continue;
          for (const o of this.outputs(ind.id)) {
            if (!o.values || o.type === 'band' || o.type === 'cloud' || o.noScale) continue;
            const off = o.offset ?? 0;
            for (let i = Math.max(0, i0 - off); i <= Math.min(o.values.length - 1, i1 - off); i++) take(o.values[i]);
          }
        }
        if (!Number.isFinite(lo)) { lo = 0; hi = 1; }
        if (this.opt.log) { lo = Math.log(Math.max(lo, 1e-9)); hi = Math.log(Math.max(hi, 1e-9)); }
        const span = hi - lo || Math.abs(hi) * 0.01 || 1, padTop = span * 0.07, padBot = span * (this.opt.volume ? 0.2 : 0.07);
        lo -= padBot;
        hi += padTop;
      } else {
        const def = p.def;
        if (def.range) [lo, hi] = def.range;
        else {
          for (const o of this.outputs(p.ind.id)) {
            if (!o.values || o.type === 'band' || o.type === 'cloud') continue;
            const off = o.offset ?? 0;
            for (let i = Math.max(0, i0 - off); i <= Math.min(o.values.length - 1, i1 - off); i++) take(o.values[i]);
            if (o.type === 'hist') take(0);
          }
          if (!Number.isFinite(lo)) { lo = 0; hi = 1; }
          const span = hi - lo || Math.abs(hi) * 0.1 || 1;
          lo -= span * 0.08;
          hi += span * 0.08;
        }
      }
      if (p.manual) { lo = p.manual.lo; hi = p.manual.hi; }
      if (hi === lo) hi = lo + 1;
      p.lo = lo;
      p.hi = hi;
    }
  }

  /** Graduations « rondes » d'un panneau (valeurs non transformées). */
  #ticks(p) {
    const minPx = 34 * this.dpr, count = Math.max(2, Math.floor(p.h / minPx));
    if (p.log) {
      const a = Math.exp(p.lo), b = Math.exp(p.hi), out = [];
      // échelle log : graduations rondes réparties en proportion
      const raw = (b - a) / count, pow = 10 ** Math.floor(Math.log10(raw));
      let step = (STEPS.find((s) => s * pow >= raw) ?? 10) * pow;
      for (let v = Math.ceil(a / step) * step; v <= b; v += step) {
        if (out.length && p.toY(out.at(-1)) - p.toY(v) < minPx * 0.8) continue;
        out.push(v);
      }
      return { ticks: out, dec: Math.max(0, -Math.floor(Math.log10(step))) };
    }
    const raw = (p.hi - p.lo) / count, pow = 10 ** Math.floor(Math.log10(raw));
    const step = (STEPS.find((s) => s * pow >= raw) ?? 10) * pow, out = [];
    for (let v = Math.ceil(p.lo / step) * step; v <= p.hi; v += step) out.push(Math.abs(v) < step * 1e-9 ? 0 : v);
    return { ticks: out, dec: Math.max(0, -Math.floor(Math.log10(step) + 1e-9)) };
  }

  #fmtPane(p, v, dec) {
    if (p.id === 'price') return nf(Math.max(this.dec, Math.min(dec, 6))).format(v);
    const a = Math.abs(v);
    if (a >= 1e9) return `${nf(2).format(v / 1e9)} Md`;
    if (a >= 1e6) return `${nf(2).format(v / 1e6)} M`;
    if (a >= 1e4) return `${nf(1).format(v / 1e3)} k`;
    return nf(Math.min(4, Math.max(dec, a < 10 ? 2 : 0))).format(v);
  }

  fmtPrice(v) {
    return Number.isFinite(v) ? nf(this.dec).format(v) : '—';
  }

  #drawGl(slots, src) {
    const G = this.gl, d = this.data, dpr = this.dpr, col = this.col, ppb = this.view.ppb, k = this.vis.k;
    G.begin(this.W, this.H, col.bg);
    const pw = this.plotW;
    this.timeMarks = d.ts.pick(this.vis.i0, this.vis.i1, (i) => this.X(i), 86 * dpr);
    for (const p of this.panes) {
      G.scissor(0, p.y0, pw, p.h);
      // grille
      const tk = this.#ticks(p);
      p.tk = tk;
      for (const v of tk.ticks) { const y = Math.round(p.toY(v)); G.rect(0, y, pw, y + Math.max(1, Math.round(dpr * 0.75)), col.grid); }
      for (const m of this.timeMarks) { const x = Math.round(this.X(m.i - 0.5)); G.rect(x, p.y0, x + Math.max(1, Math.round(dpr * 0.75)), p.y0 + p.h, m.major ? col.gridMajor : col.grid); }
      if (this.opt.sessions && d.ts.intraday && d.ts.perSession > 1) {
        const P = d.ts.perSession;
        for (let s = Math.ceil(this.vis.i0 / P) * P; s <= this.vis.i1; s += P) { const x = Math.round(this.X(s - 0.5)); G.rect(x, p.y0, x + Math.max(1, Math.round(dpr)), p.y0 + p.h, col.session); }
      }
      if (p.id === 'price') this.#glPrice(G, p, slots, src, k, ppb);
      else this.#glPane(G, p, k, ppb);
    }
    G.flush();
    this.stats.verts = G.n;
  }

  #glPrice(G, p, slots, src, k, ppb) {
    const d = this.data, col = this.col, dpr = this.dpr, pw = this.plotW;
    // zones (plan de l'IA : zone d'entrée…)
    for (const z of this.zones) {
      const ya = p.toY(z.from), yb = p.toY(z.to);
      G.rect(0, Math.min(ya, yb), pw, Math.max(ya, yb), parseColor(z.color, z.alpha ?? 0.12));
    }
    // volumes en surimpression (20 % bas du panneau)
    if (this.opt.volume && slots.length) {
      let vmax = 0;
      for (const s of slots) if (s.v > vmax) vmax = s.v;
      const base = p.y0 + p.h, hMax = p.h * 0.18, w = Math.max(1, Math.round(ppb * k * 0.72));
      if (vmax > 0) for (const s of slots) {
        const hh = (s.v / vmax) * hMax, x = Math.round(s.x - w / 2);
        G.rect(x, base - hh, x + w, base, s.c >= s.o ? col.volUp : col.volDown);
      }
    }
    // profil de volume de la zone visible
    if (this.opt.vp) this.#glVp(G, p);
    // indicateurs « remplis » (bandes, nuage) sous les bougies
    this.#glOverlays(G, p, k, ppb, true);
    // séries de cours
    const t = this.opt.type, n = slots.length;
    if (t === 'line' || t === 'area') {
      const xs = new Float64Array(n), ys = new Float64Array(n);
      for (let j = 0; j < n; j++) { xs[j] = slots[j].x; ys[j] = p.toY(slots[j].c); }
      if (t === 'area') G.band(xs, ys, p.y0 + p.h, n, col.areaTop, col.areaBot);
      G.polyline(xs, ys, n, Math.max(1.5, 2 * dpr), col.line);
    } else {
      const w = ppb * k, body = Math.max(1, Math.round(w * 0.72) - (Math.round(w * 0.72) % 2 === 0 && w > 3 ? 1 : 0)), wick = Math.max(1, Math.round(dpr));
      const hollow = t === 'hollow', bars = t === 'bars';
      for (const s of slots) {
        const up = s.c >= s.o, c = up ? col.up : col.down, x = Math.round(s.x);
        const yh = p.toY(s.h), yl = p.toY(s.l), yo = p.toY(s.o), yc = p.toY(s.c);
        if (bars) {
          G.rect(x - wick / 2, yh, x + wick / 2, Math.max(yl, yh + 1), c);
          const tk = Math.max(1, Math.floor(body / 2));
          G.rect(x - tk, Math.round(yo) - wick / 2, x, Math.round(yo) + wick / 2, c);
          G.rect(x, Math.round(yc) - wick / 2, x + tk, Math.round(yc) + wick / 2, c);
          continue;
        }
        if (body <= 2) { G.rect(x - Math.max(0.5, body / 2), yh, x + Math.max(0.5, body / 2), Math.max(yl, yh + 1), c); continue; }
        const top = Math.min(yo, yc), bot = Math.max(Math.max(yo, yc), top + 1), bx0 = x - body / 2, bx1 = x + body / 2;
        G.rect(x - wick / 2, yh, x + wick / 2, top, c);
        G.rect(x - wick / 2, bot, x + wick / 2, Math.max(yl, bot), c);
        if (hollow && up) {
          G.rect(bx0, top, bx1, top + wick, c); G.rect(bx0, bot - wick, bx1, bot, c);
          G.rect(bx0, top, bx0 + wick, bot, c); G.rect(bx1 - wick, top, bx1, bot, c);
        } else G.rect(bx0, top, bx1, bot, c);
      }
    }
    // lignes d'indicateurs par-dessus
    this.#glOverlays(G, p, k, ppb, false);
    void d;
  }

  /** Profil de volume : volumes de la zone visible répartis par tranches de prix. */
  #glVp(G, p) {
    const d = this.data, { i0, i1 } = this.vis;
    const rows = Math.max(24, Math.min(140, Math.round(p.h / (5 * this.dpr))));
    const lo = p.fromY(p.y0 + p.h), hi = p.fromY(p.y0);
    if (!(hi > lo)) return;
    const step = (hi - lo) / rows, vol = new Float64Array(rows);
    for (let i = i0; i <= i1; i++) {
      const H = d.h[i], L = d.l[i], V = d.v[i];
      if (!(V > 0)) continue;
      const a = Math.max(0, Math.floor((L - lo) / step)), b = Math.min(rows - 1, Math.floor((H - lo) / step));
      if (b < 0 || a > rows - 1) continue;
      if (H <= L) { vol[Math.max(0, Math.min(rows - 1, a))] += V; continue; }
      for (let r = a; r <= b; r++) {
        const r0 = lo + r * step, r1 = r0 + step, ov = Math.min(H, r1) - Math.max(L, r0);
        if (ov > 0) vol[r] += (V * ov) / (H - L);
      }
    }
    let poc = 0, tot = 0;
    for (let r = 0; r < rows; r++) { tot += vol[r]; if (vol[r] > vol[poc]) poc = r; }
    if (!tot) return;
    let a = poc, b = poc, acc = vol[poc];
    while (acc < tot * 0.7 && (a > 0 || b < rows - 1)) {
      const dn = a > 0 ? vol[a - 1] : -1, up = b < rows - 1 ? vol[b + 1] : -1;
      if (up >= dn) acc += vol[++b]; else acc += vol[--a];
    }
    const width = this.plotW * 0.24, max = vol[poc];
    for (let r = 0; r < rows; r++) {
      if (!vol[r]) continue;
      const y0 = p.toY(lo + (r + 1) * step), y1 = p.toY(lo + r * step), w = (vol[r] / max) * width;
      G.rect(this.plotW - w, Math.round(y0) + 1, this.plotW, Math.round(y1), r === poc ? this.col.poc : r >= a && r <= b ? this.col.vpIn : this.col.vpOut);
    }
    this.vp = { poc: lo + (poc + 0.5) * step, vah: lo + (b + 1) * step, val: lo + a * step, step };
  }

  /** Indicateurs du panneau des cours (filled = bandes/nuage d'abord, puis lignes). */
  #glOverlays(G, p, k, ppb, filled) {
    for (const ind of this.indicators) {
      const def = INDICATORS[ind.type];
      if (!def?.overlay || ind.visible === false) continue;
      this.#glOutputs(G, p, this.outputs(ind.id), k, ppb, filled);
    }
  }

  #glPane(G, p, k, ppb) {
    if (p.def.zones) for (const [a, b, tone] of p.def.zones) {
      G.rect(0, p.toY(b), this.plotW, p.toY(a), parseColor(tone === 'up' ? this.th.up : this.th.down, 0.06));
    }
    const outs = this.outputs(p.ind.id);
    this.#glOutputs(G, p, outs, k, ppb, true);
    this.#glOutputs(G, p, outs, k, ppb, false);
  }

  /** Trace les sorties d'un indicateur sur la plage visible (décalage, regroupement). */
  #glOutputs(G, p, outs, k, ppb, filled) {
    const { i0, i1 } = this.vis, dpr = this.dpr, byKey = new Map(outs.map((o) => [o.key, o]));
    const span = (o) => {
      const off = o.offset ?? 0, a = Math.max(0, Math.floor((i0 - Math.max(0, off) - 1) / k) * k), b = Math.min(o.values.length - 1, i1 - off + (off > 0 ? off : 0) + 1);
      return { off, a, b };
    };
    for (const o of outs) {
      if (filled !== (o.type === 'band' || o.type === 'cloud')) continue;
      if (o.type === 'band' || o.type === 'cloud') {
        const U = byKey.get(o.upper), L = byKey.get(o.lower);
        if (!U || !L) continue;
        const { off, a, b } = span(U), m = Math.max(0, Math.floor((b - a) / k) + 1), xs = new Float64Array(m), yu = new Float64Array(m), yl = new Float64Array(m), sgn = new Int8Array(m);
        let j = 0;
        for (let i = a; i <= b; i += k) {
          const ii = Math.min(b, i + k - 1);
          xs[j] = this.X(ii + off);
          yu[j] = p.toY(U.values[ii]);
          yl[j] = p.toY(L.values[ii]);
          sgn[j] = U.values[ii] >= L.values[ii] ? 1 : -1;
          j++;
        }
        if (o.type === 'band') G.band(xs, yu, yl, j, parseColor(U.color, o.alpha ?? 0.08));
        else {
          const cu = parseColor(this.th.up, o.alpha ?? 0.13), cd = parseColor(this.th.down, o.alpha ?? 0.13);
          for (let q = 1; q < j; q++) {
            if (![yu[q - 1], yu[q], yl[q - 1], yl[q]].every(Number.isFinite)) continue;
            const c = sgn[q] > 0 ? cu : cd;
            G.tri(xs[q - 1], yu[q - 1], xs[q], yu[q], xs[q - 1], yl[q - 1], c);
            G.tri(xs[q], yu[q], xs[q], yl[q], xs[q - 1], yl[q - 1], c);
          }
        }
        continue;
      }
      if (!o.values) continue;
      const { off, a, b } = span(o), color = parseColor(o.color);
      if (o.type === 'hist') {
        const base = p.toY(0), w = Math.max(1, Math.round(ppb * k * 0.62));
        let prev = NaN;
        for (let i = a; i <= b; i += k) {
          const ii = Math.min(b, i + k - 1), v = o.values[ii];
          if (!Number.isFinite(v)) { prev = v; continue; }
          let c = color;
          if (o.fourColor) c = v >= 0 ? (v >= prev ? this.col.up : this.col.upSoft) : v <= prev ? this.col.down : this.col.downSoft;
          else if (o.risingColor) c = v >= prev ? this.col.up : this.col.down;
          else if (o.signColor) c = v >= 0 ? this.col.up : this.col.down;
          prev = v;
          const x = Math.round(this.X(ii + off) - w / 2), y = p.toY(v);
          G.rect(x, Math.min(y, base), x + w, Math.max(y, base) + (Math.abs(y - base) < 1 ? 1 : 0), c);
        }
        continue;
      }
      if (o.type === 'dots') {
        const r = Math.max(1.2, 1.6 * dpr);
        for (let i = a; i <= b; i += k) {
          const ii = Math.min(b, i + k - 1), v = o.values[ii];
          if (!Number.isFinite(v)) continue;
          const x = this.X(ii + off), y = p.toY(v);
          G.rect(x - r, y - r, x + r, y + r, color);
        }
        continue;
      }
      if (o.step) {
        const w = Math.max(1, (o.width ?? 1) * dpr), half = (ppb * k) / 2;
        for (let i = a; i <= b; i += k) {
          const ii = Math.min(b, i + k - 1), v = o.values[ii];
          if (!Number.isFinite(v)) continue;
          const x = this.X(ii + off), y = p.toY(v);
          if (o.dash && (Math.floor(ii / k) & 1)) continue;
          G.rect(x - half, y - w / 2, x + half, y + w / 2, color);
        }
        continue;
      }
      const m = Math.floor((b - a) / k) + 1;
      if (m < 1) continue;
      const P = this.data.ts.perSession ?? 1, brk = o.sessionBreak && P > 1;
      const xs = new Float64Array(brk ? m * 2 : m), ys = new Float64Array(brk ? m * 2 : m);
      let j = 0;
      for (let i = a; i <= b; i += k) {
        const ii = Math.min(b, i + k - 1);
        if (brk && j && Math.floor(ii / P) !== Math.floor((ii - k) / P)) { xs[j] = NaN; ys[j] = NaN; j++; }
        xs[j] = this.X(ii + off);
        ys[j] = p.toY(o.values[ii]);
        j++;
      }
      G.polyline(xs, ys, j, Math.max(1, (o.width ?? 1.5) * dpr), color, Boolean(o.dash));
    }
  }

  // ======================================================================= calque 2D
  #drawOverlay(slots) {
    const ctx = this.ctx, dpr = this.dpr, th = this.th, d = this.data, W = this.W, H = this.H, pw = this.plotW, ph = this.plotH;
    const fs = Math.round(10.5 * dpr);
    ctx.clearRect(0, 0, W, H);
    ctx.font = `${fs}px Verdana, Tahoma, sans-serif`;
    ctx.textBaseline = 'middle';
    const price = this.panes[0];
    // filigrane
    if (this.opt.watermark) {
      ctx.save();
      ctx.fillStyle = th.watermark;
      ctx.font = `bold ${Math.round(Math.min(58 * dpr, price.h / 6))}px Georgia, serif`;
      ctx.textAlign = 'center';
      ctx.fillText(`${d.code ?? ''} · ${d.tfLabel ?? ''}`, pw / 2, price.y0 + price.h * 0.42);
      ctx.restore();
    }
    // fonds des axes
    ctx.fillStyle = th.axisBg;
    ctx.fillRect(pw, 0, W - pw, H);
    ctx.fillRect(0, ph, pw, H - ph);
    ctx.fillStyle = th.axisLine;
    ctx.fillRect(pw, 0, Math.max(1, Math.round(dpr)), H);
    ctx.fillRect(0, ph, pw, Math.max(1, Math.round(dpr)));
    // séparateurs de panneaux
    for (const p of this.panes.slice(1)) ctx.fillRect(0, p.y0 - Math.round(dpr), W, Math.max(1, Math.round(dpr)));

    const tags = [];
    // niveaux de référence des panneaux (RSI 30/70…)
    ctx.setLineDash([4 * dpr, 4 * dpr]);
    ctx.lineWidth = Math.max(1, dpr * 0.8);
    for (const p of this.panes.slice(1)) {
      for (const lv of p.def.levels ?? []) {
        const y = Math.round(p.toY(lv)) + 0.5;
        if (y < p.y0 || y > p.y0 + p.h) continue;
        ctx.strokeStyle = th.cross;
        ctx.globalAlpha = 0.55;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(pw, y); ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }
    ctx.setLineDash([]);
    // graduations de prix
    ctx.textAlign = 'left';
    for (const p of this.panes) {
      ctx.fillStyle = th.text;
      for (const v of p.tk?.ticks ?? []) {
        const y = Math.round(p.toY(v));
        if (y < p.y0 + fs * 0.6 || y > p.y0 + p.h - fs * 0.6) continue;
        ctx.fillText(this.#fmtPane(p, v, p.tk.dec), pw + 6 * dpr, y);
      }
    }
    // axe du temps
    ctx.textAlign = 'center';
    const fN = `${fs}px Verdana, Tahoma, sans-serif`, fB = `bold ${fs}px Verdana, Tahoma, sans-serif`;
    for (const m of this.timeMarks ?? []) {
      const x = this.X(m.i - 0.5);
      ctx.font = m.major || m.level >= 7 ? fB : fN;
      const w = ctx.measureText(m.label).width;
      if (x - w / 2 < 2 * dpr || x + w / 2 > pw - 2 * dpr) continue;
      ctx.fillStyle = th.text;
      ctx.fillText(m.label, x, ph + (H - ph) / 2);
    }
    ctx.font = fN;
    // plus haut / plus bas de la zone visible
    if (this.opt.hiLo && slots.length > 3) {
      let hs = slots[0], ls = slots[0];
      for (const s of slots) { if (s.h > hs.h) hs = s; if (s.l < ls.l) ls = s; }
      const lab = (s, v, above) => {
        const x = s.x, y = price.toY(v) + (above ? -9 : 9) * dpr, t = this.fmtPrice(v);
        ctx.fillStyle = th.text;
        ctx.textAlign = x > pw * 0.8 ? 'right' : 'left';
        ctx.fillText(`${above ? '▲' : '▼'} ${t}`, x + (x > pw * 0.8 ? -4 : 4) * dpr, y);
      };
      if (this.opt.type !== 'line' && this.opt.type !== 'area') { lab(hs, hs.h, true); lab(ls, ls.l, false); }
    }
    // lignes de prix (plan de l'IA, ordres, alertes, prix de revient)
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, price.y0, pw, price.h);
    ctx.clip();
    const offRow = { top: 0, bottom: 0 };
    for (const L of this.priceLines) {
      const y = Math.round(price.toY(L.price)) + 0.5;
      if (y < price.y0 || y > price.y0 + price.h) {
        // hors de l'échelle visible : pastille au bord du graphique (empilées), flèche vers le niveau
        const top = y < price.y0, k = top ? offRow.top++ : offRow.bottom++;
        const text = `${top ? '▲' : '▼'} ${L.label ?? ''} ${this.fmtPrice(L.price)}`.trim();
        ctx.font = fN;
        const tw = ctx.measureText(text).width + 8 * dpr, hh = fs * 1.4;
        const yy = top ? price.y0 + 3 * dpr + k * (hh + 2 * dpr) : price.y0 + price.h - 3 * dpr - hh - k * (hh + 2 * dpr);
        ctx.fillStyle = L.color;
        ctx.globalAlpha = 0.9;
        ctx.fillRect(pw - tw - 4 * dpr, yy, tw, hh);
        ctx.globalAlpha = 1;
        ctx.fillStyle = '#fff';
        ctx.textAlign = 'left';
        ctx.fillText(text, pw - tw, yy + hh * 0.52);
        continue;
      }
      ctx.strokeStyle = L.color;
      ctx.lineWidth = (L.width ?? 1) * dpr;
      ctx.setLineDash(L.dash === false ? [] : [6 * dpr, 4 * dpr]);
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(pw, y); ctx.stroke();
      ctx.setLineDash([]);
      if (L.label) {
        ctx.font = fN;
        const tw = ctx.measureText(L.label).width + 8 * dpr;
        ctx.fillStyle = L.color;
        ctx.globalAlpha = 0.9;
        ctx.fillRect(pw - tw - 4 * dpr, y - fs * 0.75 - 4 * dpr, tw, fs * 1.4);
        ctx.globalAlpha = 1;
        ctx.fillStyle = '#fff';
        ctx.textAlign = 'left';
        ctx.fillText(L.label, pw - tw, y - fs * 0.05 - 4 * dpr);
      }
      tags.push({ y, text: this.fmtPrice(L.price), bg: L.color, fg: '#fff' });
    }
    // repères (décisions de l'IA, exécutions, actualités)
    this.#markers(ctx, price);
    // tracés
    if (this.drawings) this.drawings.render(ctx, { dpr, fs, th });
    ctx.restore();
    // profil de volume : étiquette POC
    if (this.opt.vp && this.vp) tags.push({ y: price.toY(this.vp.poc), text: `POC ${this.fmtPrice(this.vp.poc)}`, bg: th.poc, fg: '#fff' });
    // dernières valeurs des indicateurs
    for (const p of this.panes) {
      const list = p.id === 'price' ? this.indicators.filter((x) => INDICATORS[x.type]?.overlay && x.visible !== false) : [p.ind];
      for (const ind of list) {
        const outs = this.outputs(ind.id);
        for (const o of outs) {
          if (!o.values || o.type === 'band' || o.type === 'cloud' || (o.offset ?? 0) !== 0) continue;
          if (p.id === 'price' && o !== outs[0] && !['mid', 'up', 'lo'].includes(o.key)) continue;
          const v = o.values[Math.min(o.values.length - 1, this.n - 1)];
          if (!Number.isFinite(v)) continue;
          const y = p.toY(v);
          if (y < p.y0 || y > p.y0 + p.h) continue;
          tags.push({ y, text: this.#fmtPane(p, v, p.tk?.dec ?? 2), bg: o.type === 'hist' ? (v >= 0 ? th.up : th.down) : o.color, fg: '#fff', small: true });
        }
      }
    }
    // dernier cours + compte à rebours de la bougie
    const lb = this.last(), lastUp = lb.c >= (this.n > 1 ? d.c[this.n - 2] : lb.o);
    let cd = null;
    if (d.ts.intraday && Number.isFinite(this.clockSec)) {
      const B = d.ts.barSeconds, rem = Math.max(0, B - (Math.floor(this.clockSec) % B));
      cd = B >= 3600 ? `${Math.floor(rem / 3600)}:${String(Math.floor((rem % 3600) / 60)).padStart(2, '0')}:${String(rem % 60).padStart(2, '0')}` : `${String(Math.floor(rem / 60)).padStart(2, '0')}:${String(rem % 60).padStart(2, '0')}`;
    }
    const ly = price.toY(lb.c);
    if (ly >= price.y0 && ly <= price.y0 + price.h) {
      ctx.strokeStyle = lastUp ? th.up : th.down;
      ctx.globalAlpha = 0.6;
      ctx.setLineDash([2 * dpr, 3 * dpr]);
      ctx.lineWidth = Math.max(1, dpr * 0.8);
      ctx.beginPath(); ctx.moveTo(0, Math.round(ly) + 0.5); ctx.lineTo(pw, Math.round(ly) + 0.5); ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
    }
    tags.push({ y: Math.max(price.y0 + 8 * dpr, Math.min(price.y0 + price.h - 8 * dpr, ly)), text: this.fmtPrice(lb.c), sub: cd, bg: lastUp ? th.up : th.down, fg: '#fff', main: true });
    // réticule
    const m = this.mouse;
    if (m.inside && m.pane) {
      const idx = Math.round(this.indexAt(m.x)), x = Math.round(this.X(idx)) + 0.5;
      let y = m.y;
      if (m.snapY !== undefined) y = m.snapY;
      ctx.strokeStyle = th.cross;
      ctx.lineWidth = Math.max(1, dpr * 0.8);
      ctx.setLineDash([4 * dpr, 4 * dpr]);
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, ph); ctx.moveTo(0, Math.round(y) + 0.5); ctx.lineTo(pw, Math.round(y) + 0.5); ctx.stroke();
      ctx.setLineDash([]);
      const p = m.pane;
      tags.push({ y, text: p.id === 'price' ? this.fmtPrice(p.fromY(y)) : this.#fmtPane(p, p.fromY(y), (p.tk?.dec ?? 2) + 1), bg: th.tagBg, fg: th.tagFg, cross: true });
      if (idx >= 0 && idx < this.n) {
        const t = d.ts.label(idx), tw = ctx.measureText(t).width + 12 * dpr;
        ctx.fillStyle = th.tagBg;
        ctx.fillRect(Math.min(pw - tw, Math.max(0, x - tw / 2)), ph + 1, tw, H - ph - 1);
        ctx.fillStyle = th.tagFg;
        ctx.textAlign = 'center';
        ctx.fillText(t, Math.min(pw - tw / 2, Math.max(tw / 2, x)), ph + (H - ph) / 2);
      }
    }
    this.#tags(tags);
  }

  /** Étiquettes de l'axe des prix, sans chevauchement (le réticule et le dernier cours priment). */
  #tags(tags) {
    const ctx = this.ctx, dpr = this.dpr, fs = Math.round(10.5 * dpr), h = Math.round(15 * dpr), x = this.plotW;
    const order = (t) => (t.cross ? 3 : t.main ? 2 : t.small ? 0 : 1);
    const placed = [];
    for (const t of [...tags].sort((a, b) => order(b) - order(a))) {
      const hh = t.sub ? h * 2 : h;
      let y = t.y - h / 2;
      if (placed.some((p) => y < p.y + p.h && y + hh > p.y)) {
        if (t.small) continue;
        const clash = placed.find((p) => y < p.y + p.h && y + hh > p.y);
        y = clash.y + clash.h + 1;
      }
      placed.push({ y, h: hh });
      ctx.fillStyle = t.bg;
      ctx.fillRect(x + dpr, y, this.W - x - dpr, hh);
      ctx.fillStyle = t.fg;
      ctx.font = `${t.main || t.cross ? 'bold ' : ''}${t.small ? Math.round(9.5 * dpr) : fs}px Verdana, Tahoma, sans-serif`;
      ctx.textAlign = 'left';
      ctx.fillText(t.text, x + 5 * dpr, y + h / 2 + 0.5);
      if (t.sub) { ctx.font = `${Math.round(9.5 * dpr)}px Verdana, Tahoma, sans-serif`; ctx.fillText(t.sub, x + 5 * dpr, y + h * 1.5); }
    }
  }

  #markers(ctx, price) {
    if (!this.markers.length) return;
    const dpr = this.dpr, { i0, i1 } = this.vis, d = this.data, th = this.th;
    this.markerHits = [];
    const stack = new Map();
    for (const mk of this.markers) {
      const f = this.indexOfTime(mk.t), i = Math.round(f);
      if (i < i0 || i > i1 || i < 0 || i >= this.n) continue;
      const x = this.X(i), key = `${i}|${mk.pos}`, nth = stack.get(key) ?? 0;
      stack.set(key, nth + 1);
      const above = mk.pos === 'above', base = above ? price.toY(d.h[i]) - (8 + nth * 16) * dpr : price.toY(d.l[i]) + (8 + nth * 16) * dpr;
      const r = 6 * dpr;
      ctx.fillStyle = mk.color ?? th.draw;
      ctx.beginPath();
      if (mk.shape === 'up') { ctx.moveTo(x, base - r); ctx.lineTo(x + r, base + r * 0.7); ctx.lineTo(x - r, base + r * 0.7); }
      else if (mk.shape === 'down') { ctx.moveTo(x, base + r); ctx.lineTo(x + r, base - r * 0.7); ctx.lineTo(x - r, base - r * 0.7); }
      else ctx.arc(x, base, r * 0.85, 0, Math.PI * 2);
      ctx.closePath();
      ctx.fill();
      if (mk.letter) {
        ctx.fillStyle = '#fff';
        ctx.font = `bold ${Math.round(8.5 * dpr)}px Verdana, sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText(mk.letter, x, base + (mk.shape === 'up' ? 1.5 : mk.shape === 'down' ? -1.5 : 0.5) * dpr);
      }
      if (mk.text && this.view.ppb > 5 * dpr) {
        ctx.fillStyle = mk.color ?? th.draw;
        ctx.font = `${Math.round(9.5 * dpr)}px Verdana, sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText(mk.text, x, base + (above ? -13 : 13) * dpr);
      }
      this.markerHits.push({ x, y: base, r: r * 1.4, mk });
    }
  }

  // ======================================================================= légendes (HTML)
  #legendDom() {
    const rows = this.panes.map((p) => {
      const inds = p.id === 'price' ? this.indicators.filter((x) => INDICATORS[x.type]?.overlay) : [p.ind];
      const lines = inds.map((ind) => `<div class="ln" data-id="${ind.id}"><span class="nm" style="color:${(ind.colors?.[0] ?? INDICATORS[ind.type].colors[0])}">${esc(labelOf(ind))}</span><span class="v" data-v></span>
        <span class="ctl"><button data-act="vis" title="Masquer / afficher">${ind.visible === false ? '◌' : '◉'}</button><button data-act="edit" title="Paramètres">⚙</button>${p.id === 'price' ? '' : '<button data-act="up" title="Monter">▲</button><button data-act="down" title="Descendre">▼</button>'}<button data-act="del" title="Retirer">✕</button></span></div>`).join('');
      return `<div class="pane-legend" data-pane="${p.id}" style="position:absolute;left:0;top:${p.y0 / this.dpr + 3}px">${p.id === 'price' ? '<div class="ln main"><span class="nm" data-main></span><span class="v" data-ohlc></span></div>' : ''}${lines}</div>`;
    }).join('');
    this.legend.innerHTML = rows;
    this.legend.style.top = '0';
    this.legend.onclick = (e) => {
      const b = e.target.closest('button[data-act]');
      if (!b) return;
      const id = b.closest('.ln').dataset.id;
      this.emit('indicator', { id, act: b.dataset.act });
    };
  }

  #legendValues() {
    if (!this.legend.firstChild) return;
    const d = this.data, m = this.mouse;
    if (!d || !this.n) {
      // aucune bougie (données réelles pas encore chargées, source en pause)
      const mainEl = this.legend.querySelector('[data-main]'), ohlc = this.legend.querySelector('[data-ohlc]');
      if (mainEl) mainEl.textContent = `${d?.name ?? d?.sym ?? ''} · ${d?.tfLabel ?? ''}`;
      if (ohlc) ohlc.textContent = 'pas encore de données : historique en cours de chargement ou source en pause';
      return;
    }
    let i = m.inside ? Math.round(this.indexAt(m.x)) : this.n - 1;
    i = Math.max(0, Math.min(this.n - 1, i));
    const src = this.opt.type === 'heikin' && this.haData ? { o: this.haData.open, h: this.haData.high, l: this.haData.low, c: this.haData.close } : d;
    const prev = i > 0 ? d.c[i - 1] : d.o[i], ch = (d.c[i] / prev - 1) * 100;
    const mainEl = this.legend.querySelector('[data-main]'), ohlc = this.legend.querySelector('[data-ohlc]');
    const f = (v) => this.fmtPrice(v), up = src.c[i] >= src.o[i];
    if (mainEl) mainEl.textContent = `${d.name ?? d.sym} · ${d.tfLabel} · ${d.ts.label(i)}`;
    if (ohlc) ohlc.innerHTML = `O <b>${f(src.o[i])}</b> H <b class="up">${f(src.h[i])}</b> B <b class="down">${f(src.l[i])}</b> C <b class="${up ? 'up' : 'down'}">${f(src.c[i])}</b> <span class="${ch >= 0 ? 'up' : 'down'}">${ch >= 0 ? '+' : ''}${num(ch, 2)} %</span> · Vol. ${Math.round(d.v[i]).toLocaleString('fr-FR')}`;
    for (const el of this.legend.querySelectorAll('.ln[data-id]')) {
      const outs = this.outputs(el.dataset.id), p = this.panes.find((x) => x.ind?.id === el.dataset.id) ?? this.panes[0];
      const vals = outs.filter((o) => o.values && o.type !== 'band' && o.type !== 'cloud').map((o) => {
        const v = o.values[i - (o.offset ?? 0)];
        return Number.isFinite(v) ? `<span style="color:${o.type === 'hist' ? (v >= 0 ? this.th.up : this.th.down) : o.color}">${p.id === 'price' ? f(v) : this.#fmtPane(p, v, 2)}</span>` : '';
      }).filter(Boolean);
      const vEl = el.querySelector('[data-v]');
      const html = vals.join(' ');
      if (vEl._h !== html) { vEl.innerHTML = html; vEl._h = html; }
    }
  }

  // ======================================================================= interactions
  #pos(e) {
    const r = this.cvOv.getBoundingClientRect();
    return { x: (e.clientX - r.left) * this.dpr, y: (e.clientY - r.top) * this.dpr };
  }
  paneAt(y) {
    return this.panes?.find((p) => y >= p.y0 && y < p.y0 + p.h) ?? null;
  }

  /** Point aimanté (outils de tracé) : l'OHLC de la bougie la plus proche si l'aimant est actif. */
  snap(x, y, force = false) {
    const p = this.panes[0], idx = Math.round(this.indexAt(x)), mode = force ? 'strong' : this.opt.magnet;
    const raw = { t: this.timeOfIndex(this.indexAt(x)), p: p.fromY(y), idx: this.indexAt(x), snapped: false };
    if (mode === 'off' || idx < 0 || idx >= this.n) return raw;
    const d = this.data, cands = [d.o[idx], d.h[idx], d.l[idx], d.c[idx]];
    let best = null, bd = mode === 'strong' ? Infinity : 14 * this.dpr;
    for (const v of cands) { const dd = Math.abs(p.toY(v) - y); if (dd < bd) { bd = dd; best = v; } }
    return best === null ? raw : { t: d.t[idx], p: best, idx, snapped: true };
  }

  #bind() {
    const el = this.cvOv;
    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      const { x, y } = this.#pos(e);
      const f = Math.exp(-e.deltaY * (e.deltaMode ? 0.05 : 0.0016));
      if (x > this.plotW) {
        const p = this.paneAt(y);
        if (!p) return;
        const c = (p.lo + p.hi) / 2, half = ((p.hi - p.lo) / 2) / f;
        p.manual = { lo: c - half, hi: c + half };
        this.invalidate();
      } else if (e.shiftKey || Math.abs(e.deltaX) > Math.abs(e.deltaY)) this.pan((e.deltaX || e.deltaY) / this.view.ppb * 0.6);
      else {
        if (f < 1) this.view.follow = this.view.follow && true;
        this.zoom(f, x);
      }
    }, { passive: false });
    el.addEventListener('pointerdown', (e) => {
      if (e.button === 2) return;
      const { x, y } = this.#pos(e);
      el.setPointerCapture(e.pointerId);
      this.wrap.focus?.({ preventScroll: true });
      // séparateur de panneaux
      const sep = this.panes.slice(1).findIndex((p) => Math.abs(y - p.y0) < 4 * this.dpr && x < this.plotW);
      if (sep >= 0) { this.drag = { type: 'resize', k: sep + 1, y, h0: this.panes[sep + 1].h, hp: this.panes[sep].h }; return; }
      if (y > this.plotH) { this.drag = { type: 'scaleX', x, ppb: this.view.ppb }; return; }
      const p = this.paneAt(y);
      if (x > this.plotW) { if (p) this.drag = { type: 'scaleY', p, y, lo: p.lo, hi: p.hi }; return; }
      if (this.drawings && p?.id === 'price' && this.drawings.onDown(x, y, e)) { this.drag = { type: 'drawing' }; return; }
      const mk = this.markerHits?.find((h) => Math.hypot(h.x - x, h.y - y) < h.r);
      if (mk) { this.emit('marker', mk.mk); return; }
      this.drag = { type: 'pan', x, y, left: this.view.left, p, lo: p?.lo, hi: p?.hi, manual: Boolean(p?.manual) };
    });
    el.addEventListener('pointermove', (e) => {
      const { x, y } = this.#pos(e), p = this.paneAt(y);
      this.mouse = { x, y, inside: x < this.plotW && y < this.plotH && Boolean(p), pane: p };
      if (this.mouse.inside && p?.id === 'price' && this.opt.magnet === 'strong' && !this.drawings?.busy) {
        const s = this.snap(x, y, true);
        this.mouse.snapY = p.toY(s.p);
      }
      const dr = this.drag;
      if (dr?.type === 'drawing') this.drawings.onMove(x, y, e);
      else if (dr?.type === 'pan') {
        this.view.left = dr.left - (x - dr.x) / this.view.ppb;
        this.view.follow = false;
        this.#clamp();
        if (dr.p && dr.manual) {
          const dv = ((y - dr.y) / dr.p.h) * (dr.hi - dr.lo);
          dr.p.manual = { lo: dr.lo + dv, hi: dr.hi + dv };
        }
      } else if (dr?.type === 'scaleY') {
        const f = Math.exp((y - dr.y) * 0.004), c = (dr.lo + dr.hi) / 2, half = ((dr.hi - dr.lo) / 2) * f;
        dr.p.manual = { lo: c - half, hi: c + half };
      } else if (dr?.type === 'scaleX') {
        this.view.ppb = Math.max(0.05, Math.min(60 * this.dpr, dr.ppb * Math.exp((x - dr.x) * 0.006)));
        if (this.view.follow) this.#follow();
      } else if (dr?.type === 'resize') {
        const a = this.panes[dr.k - 1], b = this.panes[dr.k], dy = y - dr.y, min = 40 * this.dpr;
        const hb = Math.max(min, Math.min(dr.h0 + dr.hp - min, dr.h0 - dy));
        if (b.ind) b.ind.height = hb / this.plotH;
        if (a.ind) a.ind.height = (dr.h0 + dr.hp - hb) / this.plotH;
        this.#layout();
        this.emit('layout');
      } else if (this.drawings) this.drawings.onHover(x, y, e);
      el.style.cursor = this.#cursor(x, y);
      this.invalidate();
      this.emit('cross', this.mouse.inside ? { i: Math.round(this.indexAt(x)), price: p?.fromY(y), pane: p?.id } : null);
    });
    const end = (e) => {
      const dr = this.drag;
      this.drag = null;
      if (dr?.type === 'drawing') this.drawings.onUp(...Object.values(this.#pos(e)), e);
      if (dr?.type === 'pan' && this.view.left + this.plotW / this.view.ppb >= this.n + this.opt.rightPad - 1) { this.view.follow = true; this.#follow(); }
      this.invalidate();
    };
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
    el.addEventListener('pointerleave', () => { this.mouse.inside = false; this.invalidate(); this.emit('cross', null); });
    el.addEventListener('dblclick', (e) => {
      const { x, y } = this.#pos(e);
      if (this.drawings?.onDblClick(x, y)) return;
      if (x > this.plotW) { const p = this.paneAt(y); if (p) p.manual = null; this.invalidate(); return; }
      this.resetView();
    });
    el.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      const { x, y } = this.#pos(e), p = this.paneAt(y);
      const hit = this.drawings?.hitTest(x, y);
      this.emit('context', { clientX: e.clientX, clientY: e.clientY, price: p?.id === 'price' ? p.fromY(y) : null, pane: p?.id, drawing: hit, index: Math.round(this.indexAt(x)) });
    });
    this.hover = false;
    this.wrap.tabIndex = 0;
    this.wrap.style.outline = 'none';
    this.wrap.addEventListener('mouseenter', () => { this.hover = true; });
    this.wrap.addEventListener('mouseleave', () => { this.hover = false; });
    this.onKey = (e) => {
      if (!this.hover && document.activeElement !== this.wrap) return;
      if (/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName ?? '')) return;
      if (this.drawings?.onKey(e)) { e.preventDefault(); return; }
      const step = Math.max(1, Math.round(this.plotW / this.view.ppb / 10));
      if (e.key === 'ArrowLeft') { this.pan(-step); e.preventDefault(); }
      else if (e.key === 'ArrowRight') { this.pan(step); e.preventDefault(); }
      else if (e.key === '+' || e.key === '=') this.zoom(1.25);
      else if (e.key === '-' || e.key === '_') this.zoom(0.8);
      else if (e.key === 'End') this.resetView();
      else if (e.key === 'Home') this.showAll();
    };
    window.addEventListener('keydown', this.onKey);
  }

  #cursor(x, y) {
    if (this.drag?.type === 'pan') return 'grabbing';
    if (this.drag?.type === 'resize' || this.panes?.slice(1).some((p) => Math.abs(y - p.y0) < 4 * this.dpr && x < this.plotW)) return 'row-resize';
    if (y > this.plotH) return 'ew-resize';
    if (x > this.plotW) return 'ns-resize';
    if (this.drawings) { const c = this.drawings.cursor(x, y); if (c) return c; }
    if (this.markerHits?.some((h) => Math.hypot(h.x - x, h.y - y) < h.r)) return 'pointer';
    return 'crosshair';
  }

  /** Image PNG du graphique (séries GPU + calque) avec un titre. */
  snapshot(title = '') {
    this.render();
    const c = document.createElement('canvas');
    c.width = this.W;
    c.height = this.H + Math.round(26 * this.dpr);
    const x = c.getContext('2d');
    x.fillStyle = this.th.axisBg;
    x.fillRect(0, 0, c.width, c.height);
    x.fillStyle = this.th.legendText;
    x.font = `bold ${Math.round(13 * this.dpr)}px Verdana, sans-serif`;
    x.textBaseline = 'middle';
    x.fillText(title, 8 * this.dpr, 13 * this.dpr);
    x.drawImage(this.cvGl, 0, Math.round(26 * this.dpr));
    x.drawImage(this.cvOv, 0, Math.round(26 * this.dpr));
    return c.toDataURL('image/png');
  }
}

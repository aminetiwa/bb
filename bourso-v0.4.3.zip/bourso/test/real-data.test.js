// Données RÉELLES : correspondance des symboles, lecture des formats des sources (Yahoo, BCE,
// Frankfurter, RSS/Atom, Google Actualités, GDELT, CSV), client réseau poli (débit, coupe-circuit),
// marché réel complet contre un faux internet (cotations, historiques datés dans le fuseau de la
// place, grilles intraday sans trou, indices, change, actualités, cache disque), puis le serveur
// de bout en bout en mode réel (API, recherche mondiale et ajout, IA, ordres fictifs, bascule démo).
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { parseChart, parseSpark, parseSearch, localParts, Yahoo } from '../src/data/yahoo.js';
import { parseEcbXml, parseFrankfurter } from '../src/data/fx-real.js';
import { parseFeed, splitGoogleTitle, parseGdelt, clean, httpUrl } from '../src/data/news-real.js';
import { parseDailyCsv } from '../src/data/keyed.js';
import { yahooSymbol, micOfYahoo, codeOfYahoo, stooqSymbol, ccyOfYahoo } from '../src/data/symbols.js';
import { Net, redact } from '../src/data/net.js';
import { ttfStatus, TTF_ISINS } from '../src/data/ttf.js';
import { publicSettings, hostAllowed } from '../src/server/http.js';
import { hostAllowList, machineAddresses } from '../src/server/main.js';
import { RealMarket } from '../src/market/real.js';
import { UNIVERSE, isinCheckDigit } from '../src/market/universe.js';
import { EXCHANGES } from '../src/market/exchanges.js';
import { startFakeInternet, utcOf } from './fixtures/fake-internet.js';
import { marketState, nextSessions } from '../src/market/exchanges.js';
import { Portfolio } from '../src/server/portfolio.js';
import { startMockOllama } from '../src/ai/mock-ollama-server.js';
import { startServer } from '../src/server/main.js';

const until = async (fn, ms = 30_000, step = 100) => {
  const end = Date.now() + ms;
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() > end) throw new Error('délai dépassé');
    await new Promise((r) => setTimeout(r, step));
  }
};
const meta = (code, mic) => ({ code, mic });

test('symboles : correspondance Bourso ↔ Yahoo / Stooq, places des résultats de recherche', () => {
  assert.equal(yahooSymbol(meta('MC', 'XPAR')), 'MC.PA');
  assert.equal(yahooSymbol(meta('BP.', 'XLON')), 'BP.L');
  assert.equal(yahooSymbol(meta('BT.A', 'XLON')), 'BT-A.L');
  assert.equal(yahooSymbol(meta('NOVO B', 'XCSE')), 'NOVO-B.CO');
  assert.equal(yahooSymbol(meta('700', 'XHKG')), '0700.HK');
  assert.equal(yahooSymbol(meta('600519', 'XSHG')), '600519.SS');
  assert.equal(yahooSymbol(meta('000858', 'XSHG')), '000858.SZ');
  assert.equal(yahooSymbol(meta('BRK.B', 'XNYS')), 'BRK-B');
  assert.equal(yahooSymbol(meta('NDA FI', 'XHEL')), 'NDA-FI.HE');
  // toutes les valeurs de l'univers ont un symbole plausible, et on retrouve leur place
  for (const u of UNIVERSE) {
    const y = yahooSymbol(u);
    assert.match(y, /^[A-Z0-9&-]+(\.[A-Z]{1,2})?$/, `${u.sym} → ${y}`);
    const mic = micOfYahoo(y);
    assert.ok(mic === u.mic || (u.mic === 'XNAS' && mic === 'XNYS'), `${y} → ${mic} (attendu ${u.mic})`);
  }
  assert.equal(micOfYahoo('RHM.DE'), 'XETR');
  assert.equal(micOfYahoo('X', 'NMS'), 'XNAS');
  assert.equal(micOfYahoo('7203.T'), 'XTKS');
  assert.equal(micOfYahoo('ZZZ.ZZ'), null, 'place inconnue');
  assert.equal(codeOfYahoo('0700.HK', 'XHKG'), '700');
  assert.equal(codeOfYahoo('RHM.DE', 'XETR'), 'RHM');
  assert.equal(stooqSymbol(meta('SAP', 'XETR')), 'sap.de');
  assert.equal(stooqSymbol(meta('BRK.B', 'XNYS')), 'brk-b.us');
  assert.equal(stooqSymbol(meta('MC', 'XPAR')), null, 'Paris non couvert par Stooq');
  assert.equal(ccyOfYahoo('GBp'), 'GBX');
  assert.equal(ccyOfYahoo('ZAc'), 'ZAC');
});

test('Yahoo : graphique (barres nulles retirées, dividendes), cotations groupées (deux formats), recherche', () => {
  const chart = { chart: { result: [{
    meta: { currency: 'EUR', symbol: 'MC.PA', exchangeName: 'PAR', instrumentType: 'EQUITY', exchangeTimezoneName: 'Europe/Paris', regularMarketPrice: 612.3, regularMarketTime: 1793118600,
      chartPreviousClose: 600, regularMarketDayHigh: 615, regularMarketDayLow: 598.2, regularMarketVolume: 412345, longName: 'LVMH Moët Hennessy - Louis Vuitton, Société Européenne', fiftyTwoWeekHigh: 700, fiftyTwoWeekLow: 500 },
    timestamp: [1793088000, 1793088060, 1793088120],
    indicators: { quote: [{ open: [600, null, 601], high: [602, null, 603], low: [599, null, 600.5], close: [601, null, 602.5], volume: [100, null, 50] }], adjclose: [{ adjclose: [590, null, 591] }] },
    events: { dividends: { 1780000000: { amount: 7.5, date: 1780000000 } } },
  }], error: null } };
  const c = parseChart(chart);
  assert.deepEqual(c.bars.close, [601, 602.5], 'barre nulle retirée');
  assert.equal(c.meta.price, 612.3);
  assert.equal(c.meta.time, 1793118600 * 1000);
  assert.equal(c.meta.prevClose, 600);
  assert.equal(c.meta.dayVolume, 412345);
  assert.equal(c.dividends[0].amount, 7.5);
  assert.throws(() => parseChart({ chart: { result: null, error: { code: 'Not Found', description: 'No data found, symbol may be delisted' } } }), /No data found/);
  const nested = { spark: { result: [{ symbol: 'AAPL', response: [{ meta: { regularMarketPrice: 118.31, chartPreviousClose: 119.21, regularMarketTime: 1605300000, currency: 'USD' }, timestamp: [1605277800, 1605279000], indicators: { quote: [{ close: [118.27, 118.31] }] } }] }], error: null } };
  const flat = { AAPL: { symbol: 'AAPL', timestamp: [1605277800, 1605279000], close: [118.27, 118.31], chartPreviousClose: 119.21, previousClose: 119.21 } };
  for (const j of [nested, flat]) {
    const m = parseSpark(j);
    assert.equal(m.get('AAPL').price, 118.31);
    assert.equal(m.get('AAPL').prevClose, 119.21);
  }
  const s = parseSearch({ quotes: [{ symbol: 'RHM.DE', longname: 'Rheinmetall AG', exchange: 'GER', exchDisp: 'XETRA', quoteType: 'EQUITY', isYahooFinance: true }, { symbol: 'X', isYahooFinance: false }], news: [{ uuid: 'u1', title: 'Rheinmetall wins order', publisher: 'Reuters', link: 'https://x', providerPublishTime: 1793118600 }] });
  assert.equal(s.quotes.length, 1);
  assert.equal(s.news[0].ts, 1793118600 * 1000);
  assert.deepEqual(localParts(Date.UTC(2026, 9, 27, 8, 0), 'Europe/Paris'), { ymd: '2026-10-27', min: 9 * 60 }, 'heure de Paris (UTC+1 en hiver)');
  assert.deepEqual(localParts(Date.UTC(2026, 9, 27, 2, 0), 'Asia/Tokyo'), { ymd: '2026-10-27', min: 11 * 60 });
});

test('BCE, Frankfurter, RSS 2.0, Atom, Google Actualités, GDELT, CSV', () => {
  const ecb = parseEcbXml(`<gesmes:Envelope><Cube><Cube time='2026-10-27'><Cube currency='USD' rate='1.0850'/><Cube currency="JPY" rate="162.50"/></Cube></Cube></gesmes:Envelope>`);
  assert.deepEqual(ecb, { date: '2026-10-27', rates: { USD: 1.085, JPY: 162.5 } });
  assert.throws(() => parseEcbXml('<html>maintenance</html>'));
  assert.equal(parseFrankfurter({ amount: 1, base: 'EUR', date: '2026-10-27', rates: { USD: 1.08 } }).rates.USD, 1.08);
  const rss = `<rss><channel><item><title><![CDATA[LVMH &amp; Hermès : le luxe rebondit]]></title><link>https://a/1</link><pubDate>Mon, 27 Oct 2026 14:05:00 GMT</pubDate><description>&lt;b&gt;texte&lt;/b&gt;</description></item>
    <item><title>Airbus livre 60 avions - Les Echos</title><link>https://news.google.com/x</link><pubDate>Mon, 27 Oct 2026 13:00:00 +0100</pubDate><source url="https://lesechos.fr">Les Echos</source></item></channel></rss>`;
  const it = parseFeed(rss);
  assert.equal(it[0].title, 'LVMH & Hermès : le luxe rebondit');
  assert.equal(it[0].summary, 'texte');
  assert.equal(it[0].ts, Date.UTC(2026, 9, 27, 14, 5));
  assert.equal(it[1].ts, Date.UTC(2026, 9, 27, 12, 0), 'fuseau du flux respecté');
  const g = splitGoogleTitle({ title: 'Airbus livre 60 avions - Les Echos', source: null });
  assert.deepEqual([g.title, g.source], ['Airbus livre 60 avions', 'Les Echos']);
  const atom = parseFeed('<feed><entry><title type="html">Apple beats</title><link rel="alternate" href="https://a/2"/><updated>2026-10-27T20:00:00Z</updated></entry></feed>');
  assert.deepEqual([atom[0].title, atom[0].url, atom[0].ts], ['Apple beats', 'https://a/2', Date.UTC(2026, 9, 27, 20)]);
  const gd = parseGdelt({ articles: [{ url: 'https://x', title: 'TotalEnergies recule', seendate: '20261027T153000Z', domain: 'lemonde.fr', language: 'French' }] });
  assert.equal(gd[0].ts, Date.UTC(2026, 9, 27, 15, 30));
  assert.equal(clean('a b\u0000c  d'), 'a b c d', 'séparateurs et caractères de contrôle neutralisés');
  const csv = parseDailyCsv('Date,Open,High,Low,Close,Volume\n2026-10-26,10,11,9,10.5,1000\n2026-10-27,10.5,12,10,11.5,2000\n');
  assert.deepEqual(csv.close, [10.5, 11.5]);
  assert.throws(() => parseDailyCsv('Get your apikey: https://stooq.com/q/d/?s=sap.de&get_apikey'), /clé API/);
});

test('TTF : liste officielle 2026 (BOFiP) ; clés d\'API masquées ; adresses d\'articles sûres', () => {
  assert.equal(TTF_ISINS.size, 121);
  for (const isin of TTF_ISINS) assert.equal(String(isinCheckDigit(isin.slice(0, 11))), isin[11], `chiffre de contrôle de ${isin}`);
  const at = Date.parse('2026-06-15T10:00:00Z');
  assert.equal(ttfStatus('FR0000121014', null, at).eligible, true, 'LVMH : dans la liste');
  assert.equal(ttfStatus('FR0000054470', 5e9, at).eligible, false, 'Ubisoft : hors liste 2026, quelle que soit la capitalisation estimée');
  assert.equal(ttfStatus('NL0000235190', null, at).eligible, false, 'Airbus : société néerlandaise');
  assert.equal(ttfStatus('FR0014000MR3', null, at).eligible, false, 'Eurofins : siège au Luxembourg');
  assert.equal(ttfStatus(null, null, at).eligible, false);
  assert.equal(ttfStatus('FR0000054470', 2e9, Date.parse('2027-03-01T10:00:00Z')).eligible, true, 'année sans liste intégrée : capitalisation connue');
  assert.equal(redact('Finnhub : HTTP 401 — invalid token abcd1234xyz', 'https://finnhub.io/api/v1/quote?symbol=A&token=abcd1234xyz'), 'Finnhub : HTTP 401 — invalid token •••');
  assert.equal(redact('rien à masquer', 'https://query1.finance.yahoo.com/v8/finance/chart/MC.PA?range=5y'), 'rien à masquer');
  assert.equal(httpUrl('javascript:alert(1)'), null);
  assert.equal(httpUrl('data:text/html,<b>x</b>'), null);
  assert.equal(httpUrl(' https://www.lesechos.fr/a?b=1 '), 'https://www.lesechos.fr/a?b=1');
  const pub = publicSettings({ ai: { model: null }, data: { mode: 'real', keys: { finnhub: 'abcd1234efgh', fmp: '' } } });
  assert.equal(pub.data.keys.finnhub, '••••efgh');
  assert.equal(pub.data.keys.fmp, '');
  assert.equal(pub.data.mode, 'real');
});

test('écoute sur 0.0.0.0 : adresses de la machine acceptées (réseau, Tailscale), noms étrangers refusés', () => {
  const list = hostAllowList('0.0.0.0', 'amine-ms-7d98.tail1234.ts.net');
  assert.equal(typeof list, 'function', 'liste relue (une interface peut changer)');
  const mine = machineAddresses().find((a) => a.v4 && !a.internal)?.address ?? '127.0.0.1';
  assert.ok(hostAllowed(`${mine}:3001`, list), `adresse de la machine acceptée (${mine})`);
  assert.ok(hostAllowed('localhost:3001', list) && hostAllowed('127.0.0.1:3001', list));
  assert.ok(hostAllowed('amine-ms-7d98.tail1234.ts.net:3001', list), 'nom ajouté par BOURSO_ALLOW_HOSTS');
  assert.ok(!hostAllowed('evil.example:3001', list), 'un site piégé (DNS rebinding) reste refusé');
  assert.ok(!hostAllowed('100.68.115.10:3001', hostAllowList('127.0.0.1', '')), 'écoute locale : rien d\'autre que localhost');
  assert.deepEqual(hostAllowList('100.68.115.10', ''), ['100.68.115.10']);
});

test('ordre « jour » : valable pour sa séance puis expiré ; « à révocation » conservé ; attente motivée ; TTF officielle', () => {
  const clk = { state: 'OPEN', today: '2026-06-15', ex: { short: 'Paris' }, sec: 3600 };
  const inst = { meta: { sym: 'MC:XPAR', name: 'LVMH', currency: 'EUR', isin: 'FR0000121014' }, clk, capEur: null };
  const q = { last: 600, bid: 599.7, ask: 600.3, quoteSession: '2026-06-15' };
  const market = { real: true, sim: { quote: () => q, fx: { toEur: () => 1 } }, get: () => inst };
  const store = { state: {}, settings: { trading: { initialCash: 100_000, commissionPct: 0.1, commissionMin: 1, ttfPct: 0.4, allowShort: true } }, save() {} };
  const pf = new Portfolio({ market, store });
  const day = pf.place({ sym: 'MC:XPAR', side: 'BUY', type: 'LMT', limit: 500, qty: 1, tif: 'DAY' });
  const gtc = pf.place({ sym: 'MC:XPAR', side: 'BUY', type: 'LMT', limit: 500, qty: 1, tif: 'GTC' });
  assert.equal(day.status, 'WORKING');
  assert.equal(day.day, '2026-06-15');
  // après la clôture : en attente, motif donné
  clk.state = 'POST';
  pf.tick();
  assert.match(day.waiting, /ouverture/);
  // séance suivante : l'ordre « jour » expire, l'ordre « à révocation » reste
  Object.assign(clk, { state: 'OPEN', today: '2026-06-16' });
  pf.tick();
  assert.equal(day.status, 'EXPIRED');
  assert.match(day.note, /jour/);
  assert.equal(gtc.status, 'WORKING');
  // séance ouverte mais cours pas encore du jour : on attend un cours de la séance
  assert.match(gtc.waiting ?? '', /séance/);
  q.quoteSession = '2026-06-16';
  q.ask = 499;
  pf.tick();
  assert.equal(gtc.status, 'FILLED');
  assert.equal(gtc.avgPx, 499);
  // frais : TTF 0,4 % à l'achat d'une valeur de la liste officielle, pas à la vente
  const fb = pf.fees('MC:XPAR', 'BUY', 10, 600, Date.parse('2026-06-16T10:00:00Z')), fs = pf.fees('MC:XPAR', 'SELL', 10, 600);
  assert.ok(Math.abs(fb.ttf - 24) < 1e-9, `TTF ${fb.ttf}`);
  assert.equal(fb.ttfEligible, true);
  assert.equal(fs.ttf, 0);
});

test('client réseau : débit régulé, coupe-circuit sur « trop de requêtes » (429), rien n\'est forcé', async () => {
  const fi = await startFakeInternet({ yahoo429After: 3 });
  try {
    const net = new Net({ rewrite: fi.rewrite, limits: { 'query1.finance.yahoo.com': { concurrency: 1, minIntervalMs: 60 } } });
    const url = (s) => `https://query1.finance.yahoo.com/v8/finance/chart/${s}?range=5d&interval=1d`;
    const t0 = Date.now();
    for (const s of ['MC.PA', 'SAP.DE', 'AAPL']) await net.get(url(s));
    assert.ok(Date.now() - t0 >= 120, 'intervalle minimal respecté entre deux requêtes');
    await assert.rejects(net.get(url('OR.PA')), (e) => e.blocked && e.status === 429);
    const before0 = fi.st.yahooRequests;
    await assert.rejects(net.get(url('AI.PA')), (e) => e.blocked && /en pause/.test(e.message));
    assert.equal(fi.st.yahooRequests, before0, 'coupe-circuit ouvert : la source n\'est plus sollicitée');
    const info = net.info().find((g) => g.host === 'query1.finance.yahoo.com');
    assert.equal(info.state, 'coupé');
    assert.ok(info.pausedUntil > Date.now() + 50_000, 'pause d\'au moins une minute');
  } finally {
    await fi.close();
  }
});

test('client réseau : après un refus, rien ne part pendant la pause (file annulée), une seule escalade, requêtes identiques partagées', async () => {
  const fi = await startFakeInternet({ yahoo429After: 1 });
  try {
    const logs = [];
    const net = new Net({ rewrite: fi.rewrite, log: (m) => logs.push(m), limits: { 'query1.finance.yahoo.com': { concurrency: 1, minIntervalMs: 30 } } });
    const url = (s) => `https://query1.finance.yahoo.com/v8/finance/chart/${s}?range=5d&interval=1d`;
    const [a, b] = await Promise.all([net.get(url('MC.PA')), net.get(url('MC.PA'))]);
    assert.equal(a, b);
    assert.equal(fi.st.yahooRequests, 1, 'deux demandes identiques simultanées → une seule requête');
    // rafale de 12 requêtes : la 1re reçoit 429 ; les 11 autres attendaient leur tour → annulées, pas envoyées
    const syms = ['SAP.DE', 'AAPL', 'OR.PA', 'AI.PA', 'SU.PA', 'BN.PA', 'EL.PA', 'RI.PA', 'KER.PA', 'CS.PA', 'DG.PA', 'SAN.PA'];
    const res = await Promise.allSettled(syms.map((x) => net.get(url(x))));
    assert.ok(res.every((r) => r.status === 'rejected' && r.reason.blocked));
    assert.equal(fi.st.yahooRequests, 2, `une seule requête envoyée pendant la rafale (et non ${fi.st.yahooRequests - 1})`);
    assert.equal(logs.filter((l) => /refuse les requêtes/.test(l)).length, 1, 'une seule ligne de journal pour cette pause');
    const left = net.pausedUntil('query1.finance.yahoo.com') - Date.now();
    assert.ok(left > 50_000 && left <= 61_000, `première pause d'une minute, sans escalade en cascade (${left} ms)`);
    assert.ok(res[5].reason.pausedUntil > Date.now(), 'l\'erreur dit jusqu\'à quand');
  } finally {
    await fi.close();
  }
});

test('Yahoo : en-tête minimal « Mozilla/5.0 » (aucune imitation de navigateur) — un faux Chrome serait refusé', async () => {
  const fi = await startFakeInternet();
  try {
    const net = new Net({ rewrite: fi.rewrite, limits: { 'query1.finance.yahoo.com': { concurrency: 1, minIntervalMs: 5 } } });
    const y = new Yahoo(net);
    const r = await y.chart('MC.PA', { range: '1mo', interval: '1d', events: false });
    assert.ok(r.bars.close.length > 10);
    assert.deepEqual([...fi.st.yahooUAs], ['Mozilla/5.0']);
    // le faux internet se comporte comme Yahoo : un « Chrome » sans cookies reçoit 429
    const chrome = await fetch(fi.rewrite('https://query1.finance.yahoo.com/v8/finance/chart/MC.PA?range=5d&interval=1d'), { headers: { 'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36' } });
    assert.equal(chrome.status, 429);
  } finally {
    await fi.close();
  }
});

// ---------------------------------------------------------------- marché réel contre le faux internet
const SUB = UNIVERSE.filter((u) => ['XPAR', 'XETR', 'XLON', 'XNYS', 'XTKS', 'XHKG'].includes(u.mic)).filter((u, i) => i % 5 === 0 || u.sym === 'MC:XPAR');
const fast = (rm) => {
  for (const h of ['query1.finance.yahoo.com', 'news.google.com', 'api.gdeltproject.org', 'www.ecb.europa.eu', '*']) rm.net.setLimit(h, { concurrency: 4, minIntervalMs: 2 });
  rm.cfg = { ...rm.cfg, histMs: 5, detailMs: 20, hotSec: 1 };
  rm.tickMs = 40;
};

test('marché réel : cotations, historiques datés, minutes sans trou, bougies natives, indices, change, actualités, cache disque', async () => {
  const fi = await startFakeInternet();
  const dir = mkdtempSync(join(tmpdir(), 'bourso-real-'));
  let rm = new RealMarket({ dataDir: dir, rewrite: fi.rewrite, universe: SUB, hot: () => ['MC:XPAR'] });
  try {
    fast(rm);
    await rm.init();
    rm.start();
    await until(() => SUB.every((u) => Number.isFinite(rm.quote(u.sym).last)) && rm.instruments.every((x) => x.daily.n > 1000), 60_000);
    for (const u of SUB) {
      const q = rm.quote(u.sym), x = rm.get(u.sym), d = rm.daily(u.sym);
      assert.ok(q.last > 0 && q.prev > 0 && q.bid < q.ask && q.spreadEstimated, `${u.sym} cotation`);
      // séances terminées seulement, dates croissantes, dans le fuseau de la place
      assert.ok(d.dates.every((t, i) => i === 0 || t > d.dates[i - 1]), `${u.sym} dates croissantes`);
      assert.ok(d.dates.at(-1) < x.clk.today, `${u.sym} : la séance en cours n'est pas dans l'historique`);
      assert.equal(d.close.length, d.dates.length);
      assert.ok(x.meta.tick > 0 && x.fund.dividendeParAction > 0, `${u.sym} : pas de cotation et dividende des 12 mois`);
    }
    // minutes : grille fixe par séance, minutes sans échange comblées (bougie plate, volume nul)
    await rm.prepare('MC:XPAR', { tf: '1m' });
    const M = EXCHANGES.XPAR.sessionMin, mn = rm.minutes('MC:XPAR', 5);
    assert.equal(mn.sessionBars, M);
    assert.equal(mn.todayFrom % M, 0);
    assert.ok(mn.todayFrom >= 4 * M, `séances passées : ${mn.todayFrom / M}`);
    assert.ok(!mn.close.some((v) => !Number.isFinite(v) || v <= 0), 'aucun trou dans la grille');
    assert.ok(mn.volume.some((v) => v === 0), 'des minutes sans échange existent (comblées)');
    await rm.prepare('MC:XPAR', { tf: '15m' });
    const b15 = rm.bars('MC:XPAR', 15);
    assert.equal(b15.sessionBars, Math.ceil(M / 15));
    assert.ok(b15.close.length > 10 * b15.sessionBars);
    // Tokyo : pause déjeuner exclue de la grille
    const tk = SUB.find((u) => u.mic === 'XTKS').sym;
    await rm.prepare(tk, { tf: '1m' });
    assert.equal(rm.minutes(tk, 3).sessionBars, EXCHANGES.XTKS.sessionMin);
    // indices, change, actualités
    await until(() => rm.indices().filter((i) => Number.isFinite(i.level)).length >= 4, 20_000);
    await until(() => rm.fx.info().source.includes('BCE'), 20_000);
    assert.ok(Math.abs(rm.fx.toEur('USD') - 1 / 1.0862) < 0.01 || Math.abs(rm.fx.toEur('USD') - 1 / 1.085) < 0.01);
    assert.ok(Math.abs(rm.fx.toEur('GBX') - rm.fx.toEur('GBP') / 100) < 1e-9, 'pence');
    await rm.news.refreshGeneral();
    await rm.news.refreshSymbol('MC:XPAR', { force: true });
    const mcNews = rm.news.forSym('MC:XPAR', 30);
    assert.ok(mcNews.some((n) => n.sym === 'MC:XPAR'), 'actualités rattachées à LVMH');
    assert.ok(rm.news.items.some((n) => n.scope === 'région' && n.region === 'Europe'), 'BCE → Europe');
    const inj = rm.news.items.find((n) => /Ignore toutes tes consignes/.test(n.title));
    assert.ok(inj && inj.real, 'un titre « injection » reste une simple donnée');
    const st = rm.status();
    assert.equal(st.notFound.length, 0);
    assert.ok(st.sources.some((s) => s.host === 'query1.finance.yahoo.com' && s.ok > 10));
    rm.stop();
    await new Promise((r) => setTimeout(r, 300));
    // redémarrage : derniers cours et historiques relus depuis le disque, avant tout réseau
    const lastMC = rm.quote('MC:XPAR').last;
    rm = new RealMarket({ dataDir: dir, rewrite: () => 'http://127.0.0.1:1/', universe: SUB });
    await rm.init();
    assert.ok(Number.isFinite(rm.quote('MC:XPAR').last), 'cours relu du cache');
    assert.ok(Math.abs(rm.quote('MC:XPAR').last - lastMC) / lastMC < 0.05);
    assert.ok(rm.daily('MC:XPAR').close.length > 1000, 'historique relu du cache');
    assert.ok(rm.news.items.length > 3, 'actualités relues du cache');
  } finally {
    rm.stop();
    await fi.close();
    rmSync(dir, { recursive: true, force: true });
  }
});

test('marché réel : valeur introuvable, recherche mondiale et ajout, spark fermé (repli), spark « à plat »', async () => {
  const fi = await startFakeInternet({ sparkFormat: 'flat' });
  const dir = mkdtempSync(join(tmpdir(), 'bourso-real2-'));
  const uni = [...SUB.slice(0, 6), { ...SUB[0], sym: 'NOPE:XPAR', code: 'NOPE', name: 'Société disparue' }];
  const rm = new RealMarket({ dataDir: dir, rewrite: fi.rewrite, universe: uni });
  try {
    fast(rm);
    await rm.init();
    await rm.refreshQuotes(rm.instruments);
    assert.ok(Number.isFinite(rm.quote(SUB[0].sym).last), 'format spark à plat lu');
    await assert.rejects(rm.loadHistory(rm.get('NOPE:XPAR')));
    assert.equal(rm.get('NOPE:XPAR').dead, true, 'valeur introuvable : plus interrogée');
    const found = await rm.searchExternal('nouvelle valeur');
    assert.equal(found[0].yahoo, 'NOUV.PA');
    assert.equal(found[0].mic, 'XPAR');
    const sym = await rm.addSymbol({ yahoo: 'NOUV.PA', name: 'Nouvelle Valeur', sector: 'Technology' });
    assert.equal(sym, 'NOUV:XPAR');
    assert.equal(rm.get(sym).meta.sectorKey, 'TECH');
    await until(() => rm.daily(sym).close.length > 1000, 20_000);
    // spark fermé (401) : cotations une par une, sans planter
    fi.st.sparkBroken = true;
    const rm2 = new RealMarket({ dataDir: mkdtempSync(join(tmpdir(), 'bourso-real3-')), rewrite: fi.rewrite, universe: SUB.slice(0, 3) });
    fast(rm2);
    await rm2.init();
    await rm2.refreshQuotes(rm2.instruments);
    assert.equal(rm2.yahoo.sparkBroken, true);
    rm2.detailCursor = 0;
    await rm2.refreshQuotes(rm2.instruments);
    assert.ok(rm2.instruments.some((x) => Number.isFinite(x.last)), 'repli : graphique du jour valeur par valeur');
    rm2.stop();
  } finally {
    rm.stop();
    await fi.close();
    rmSync(dir, { recursive: true, force: true });
  }
});

test('séance OUVERTE (horloge simulée : Paris 10 h 30) : bougies du jour partielles, cours du jour, ordre fictif exécuté', async () => {
  const ex = EXCHANGES.XPAR, today = nextSessions(ex, marketState(ex).localYmd, 1)[0];
  const t0 = Date.now(), start = utcOf(today, 10 * 60 + 30, ex.tz);
  const now = () => start + (Date.now() - t0);
  const fi = await startFakeInternet({ now });
  const dir = mkdtempSync(join(tmpdir(), 'bourso-open-'));
  const uni = SUB.filter((u) => u.mic === 'XPAR');
  const rm = new RealMarket({ dataDir: dir, rewrite: fi.rewrite, universe: uni, now, hot: () => ['MC:XPAR'] });
  try {
    fast(rm);
    await rm.init();
    rm.start();
    const x = rm.get('MC:XPAR');
    assert.equal(x.clk.state, 'OPEN');
    assert.equal(x.clk.today, today);
    await until(() => rm.quote('MC:XPAR').quoteSession === today && x.daily.n > 1000, 30_000);
    await rm.prepare('MC:XPAR', { tf: '1m' });
    const M = ex.sessionMin, mn = rm.minutes('MC:XPAR', 5);
    const todayBars = mn.close.length - mn.todayFrom;
    assert.ok(todayBars >= 85 && todayBars <= 95, `≈ 90 minutes écoulées depuis 9 h : ${todayBars}`);
    assert.ok(mn.todayFrom % M === 0 && mn.todayFrom >= 4 * M);
    const q = rm.quote('MC:XPAR');
    assert.ok(q.high >= q.last && q.low <= q.last && q.high >= q.open && q.low <= q.open, 'plus haut / plus bas cohérents');
    assert.ok(q.volume > 0 && q.vwap > 0);
    assert.equal(q.open, mn.open[mn.todayFrom], 'ouverture = première bougie du jour');
    assert.ok(q.prev === rm.daily('MC:XPAR').close.at(-1), 'veille = dernière séance terminée');
    await rm.prepare('MC:XPAR', { tf: '15m' });
    const b15 = rm.bars('MC:XPAR', 15);
    assert.equal(b15.close.length - b15.todayFrom, 7, 'bougies 15 min du jour : 9 h 00 … 10 h 30');
    // ordre fictif au marché pendant la séance : exécuté au prix vendeur ESTIMÉ (dernier cours + demi-fourchette)
    const store = { state: {}, settings: { trading: { initialCash: 100_000, commissionPct: 0.1, commissionMin: 1, ttfPct: 0.4, allowShort: true } }, save() {} };
    const pf = new Portfolio({ market: { real: true, sim: rm, get: (s) => rm.get(s) }, store });
    const o = pf.place({ sym: 'MC:XPAR', side: 'BUY', type: 'MKT', qty: 2 });
    assert.equal(o.status, 'FILLED');
    assert.equal(o.avgPx, rm.quote('MC:XPAR').ask);
    assert.ok(store.state.portfolioReal && !store.state.portfolio, 'compte réel distinct du compte de démonstration');
  } finally {
    rm.stop();
    await fi.close();
    rmSync(dir, { recursive: true, force: true });
  }
});

// ---------------------------------------------------------------- serveur complet en mode réel
let fi, mock, srv, base, dir;
const J = { 'content-type': 'application/json' };
const get = async (p) => { const r = await fetch(`${base}${p}`); return { status: r.status, body: r.headers.get('content-type')?.includes('json') ? await r.json() : await r.arrayBuffer() }; };
const send = async (method, p, data) => { const r = await fetch(`${base}${p}`, { method, headers: J, body: data === undefined ? undefined : JSON.stringify(data) }); return { status: r.status, body: await r.json() }; };

before(async () => {
  fi = await startFakeInternet();
  dir = mkdtempSync(join(tmpdir(), 'bourso-real-srv-'));
  mock = await startMockOllama({ port: 0, tokenDelayMs: 0 });
  srv = await startServer({ port: 0, dataDir: dir, ollamaHost: `127.0.0.1:${mock.address().port}`, gpu: 'off', autoAnalysis: false, quiet: true, market: 'real', dataRewrite: fi.rewrite });
  fast(srv.market.sim);
  base = `http://127.0.0.1:${srv.port}`;
});

after(async () => {
  await srv?.close();
  await new Promise((r) => mock?.close(r));
  await fi?.close();
  rmSync(dir, { recursive: true, force: true });
});

test('serveur en mode réel : méta, cotation, historiques (jour, 15 min, 1 min, 1 s substituée), carnet indisponible', async () => {
  const m = (await get('/api/meta')).body;
  assert.equal(m.data.mode, 'real');
  assert.equal(m.data.capabilities.book, false);
  const q = await until(async () => { const r = (await get('/api/quote/MC:XPAR')).body; return Number.isFinite(r.quote.last) ? r : null; });
  assert.equal(q.meta.real, true);
  assert.ok(q.quote.source);
  const d = (await get('/api/history?sym=MC:XPAR&tf=1D&format=json')).body;
  assert.ok(d.header.count > 1000);
  assert.ok(d.header.dates.every((t, i) => i === 0 || t > d.header.dates[i - 1]));
  const h15 = (await get('/api/history?sym=MC:XPAR&tf=15m&format=json')).body;
  assert.equal(h15.header.perSession, Math.ceil(EXCHANGES.XPAR.sessionMin / 15));
  assert.ok(h15.header.count > 200);
  const h1 = (await get('/api/history?sym=MC:XPAR&tf=1m&format=json')).body;
  assert.equal(h1.header.perSession, EXCHANGES.XPAR.sessionMin);
  assert.ok(!h1.close.some((v) => !Number.isFinite(v)));
  const hs = (await get('/api/history?sym=MC:XPAR&tf=1s&format=json')).body;
  assert.equal(hs.header.substituted, '1m', 'pas de seconde en données gratuites : minute à la place');
  const b = (await get('/api/book?sym=MC:XPAR')).body;
  assert.equal(b.unavailable, true);
  const st = (await get('/api/data/status')).body;
  assert.equal(st.mode, 'real');
  assert.ok(st.sources.some((s) => s.host === 'query1.finance.yahoo.com'));
});

test('serveur en mode réel : recherche mondiale, ajout d\'une valeur, actualités, analyse IA sur données réelles', async () => {
  const r = (await get('/api/search?q=nouvelle%20valeur')).body;
  const ext = r.find((x) => x.external);
  assert.equal(ext.yahoo, 'NOUV.PA');
  const add = await send('POST', '/api/data/add', { yahoo: ext.yahoo, name: ext.name, exchange: 'PAR', sector: ext.sector });
  assert.equal(add.status, 200);
  assert.equal(add.body.sym, 'NOUV:XPAR');
  assert.equal((await get('/api/quote/NOUV:XPAR')).status, 200);
  const n = (await get('/api/news?sym=MC:XPAR&limit=20')).body;
  assert.ok(n.some((x) => x.sym === 'MC:XPAR' && x.real));
  // dossier : les données sont annoncées comme RÉELLES, les titres comme documents non fiables
  const dos = (await get('/api/ai/dossier?sym=MC:XPAR')).body;
  assert.match((dos.dossier ?? dos).sections.identite.donnees, /^RÉELLES/);
  assert.ok(String(dos.text ?? '').includes('<<<DOC actualités') || !dos.text);
  const job = await send('POST', '/api/ai/analyze', { sym: 'MC:XPAR' });
  const sig = await until(async () => { const s = await get(`/api/ai/signal/${job.body.id}`); return s.status === 200 ? s.body : null; }, 60_000);
  assert.equal(sig.dataMode, 'real');
  assert.ok(sig.mc && sig.mc.paths > 0);
});

test('ordres fictifs sur cours réels : exécution en séance seulement ; comptes réel et démo séparés ; bascule de mode', async () => {
  const o = (await send('POST', '/api/orders', { sym: 'MC:XPAR', side: 'BUY', type: 'MKT', qty: 3 })).body;
  const clk = srv.market.get('MC:XPAR').clk;
  if (clk.state === 'OPEN') assert.equal(o.status, 'FILLED');
  else {
    assert.equal(o.status, 'WORKING', 'place fermée : l\'ordre attend l\'ouverture');
    assert.match(o.waiting, /ouverture/);
  }
  const pfReal = (await get('/api/portfolio')).body;
  const m = await send('POST', '/api/data/mode', { mode: 'demo' });
  assert.equal(m.body.mode, 'demo');
  assert.equal(srv.market.real, false);
  const pfDemo = (await get('/api/portfolio')).body;
  assert.ok(!pfDemo.orders.some((x) => x.id === o.id), 'le compte de démonstration ne voit pas les ordres du compte réel');
  const back = await send('POST', '/api/data/mode', { mode: 'real' });
  assert.equal(back.body.mode, 'real');
  assert.ok((await get('/api/portfolio')).body.orders.some((x) => x.id === o.id), 'compte réel retrouvé');
  void pfReal;
});

test('réglages « Données » : clés jamais renvoyées en clair, flux contrôlés, test des sources, taille réelle des valeurs, TTF', async () => {
  let r = await send('PUT', '/api/settings', { data: { keys: { finnhub: 'abcd1234efgh' } } });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.keys.finnhub, '••••efgh', 'clé masquée dans la réponse');
  assert.equal(srv.store.settings.data.keys.finnhub, 'abcd1234efgh', 'clé enregistrée en clair sur le disque local');
  assert.equal(srv.market.sim.keyed.keys.finnhub, 'abcd1234efgh', 'clé transmise aux sources');
  r = await send('PUT', '/api/settings', { data: { keys: { finnhub: '••••efgh' } } });
  assert.equal(srv.store.settings.data.keys.finnhub, 'abcd1234efgh', 'le masque renvoyé tel quel ne remplace pas la clé');
  assert.equal((await get('/api/meta')).body.settings.data.keys.finnhub, '••••efgh');
  assert.equal((await get('/api/settings')).body.data.keys.finnhub, '••••efgh');
  assert.equal((await send('PUT', '/api/settings', { data: { keys: { fmp: 'a b<c>' } } })).status, 400);
  assert.equal((await send('PUT', '/api/settings', { data: { feeds: [{ name: 'x', url: 'javascript:alert(1)' }] } })).status, 400);
  assert.equal((await send('PUT', '/api/settings', { data: { intensity: 'folle' } })).status, 400);
  await send('PUT', '/api/settings', { data: { keys: { finnhub: '' } } });
  assert.equal(srv.store.settings.data.keys.finnhub, '', 'clé effacée');
  // flux personnalisés, puis retour aux flux par défaut
  await send('PUT', '/api/settings', { data: { feeds: [{ name: 'Mon flux', url: 'https://example.org/rss.xml', lang: 'fr' }] } });
  assert.deepEqual(srv.market.sim.news.feeds.map((f) => f.url), ['https://example.org/rss.xml']);
  await send('PUT', '/api/settings', { data: { feeds: [] } });
  assert.ok(srv.market.sim.news.feeds.length >= 5, 'flux par défaut rétablis');
  // test des sources (contre le faux internet) : tout répond, le verdict est positif
  const c = (await send('POST', '/api/data/check')).body;
  assert.ok(c.summary.essentialOk, JSON.stringify(c.results.filter((x) => !x.ok)));
  assert.ok(c.results.some((x) => x.group === 'Change' && x.ok));
  assert.ok(c.results.some((x) => x.group === 'Actualités' && x.ok));
  assert.ok(c.results.every((x) => x.ok), JSON.stringify(c.results.filter((x) => !x.ok)));
  assert.equal((await get('/api/data/check')).body.at, c.at);
  // taille des valeurs : capitaux moyens échangés (réels) ; capitalisation inconnue sans clé
  const rows = await until(async () => { const x = (await get('/api/screener')).body.rows.filter((y) => y.size > 0); return x.length ? x : null; });
  assert.equal(rows[0].capEur, null);
  assert.ok(rows[0].liqEur > 0 && rows[0].size === rows[0].liqEur);
  const sec = (await get('/api/sectors')).body;
  assert.ok(sec.every((x) => Number.isFinite(x.chg)), 'variations de secteur calculées sur les seules valeurs cotées');
  // frais : TTF d'après la liste officielle, motif donné
  const f = (await get('/api/fees?sym=MC:XPAR&side=BUY&qty=10&px=600')).body;
  assert.equal(f.ttfEligible, true);
  assert.ok(f.ttf > 0);
  assert.match(f.ttfSource, /BOFiP/);
  const f2 = (await get('/api/fees?sym=MC:XPAR&side=SELL&qty=10&px=600')).body;
  assert.equal(f2.ttf, 0);
});

test('Yahoo refuse (429) : plus aucune requête pendant la pause, les analyses ATTENDENT les données (pas d\'échec), état visible', async () => {
  const fi2 = await startFakeInternet({ yahoo429After: 1 });
  const dir2 = mkdtempSync(join(tmpdir(), 'bourso-429-'));
  const mock2 = await startMockOllama({ port: 0, tokenDelayMs: 0 });
  const srv2 = await startServer({ port: 0, dataDir: dir2, ollamaHost: `127.0.0.1:${mock2.address().port}`, gpu: 'off', autoAnalysis: false, quiet: true, market: 'real', dataRewrite: fi2.rewrite });
  const base2 = `http://127.0.0.1:${srv2.port}`;
  try {
    const st = await until(async () => { const r = await (await fetch(`${base2}/api/data/status`)).json(); return r.yahooPausedUntil ? r : null; }, 20_000);
    assert.ok(st.yahooPausedUntil > Date.now() + 50_000);
    const sent = fi2.st.yahooRequests;
    await new Promise((r) => setTimeout(r, 2500));
    assert.ok(fi2.st.yahooRequests - sent <= 1, `pendant la pause, Yahoo n'est plus sollicité (${fi2.st.yahooRequests - sent} requête(s))`);
    // une analyse demandée maintenant attend les données au lieu d'échouer
    const job = await (await fetch(`${base2}/api/ai/analyze`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ sym: 'SAP:XETR' }) })).json();
    assert.ok(job.id);
    const row = await until(async () => {
      const q = await (await fetch(`${base2}/api/ai/status`)).json();
      const f = (q.queue.favorites ?? []).find((x) => x.sym === 'SAP:XETR') ?? (q.queue.rows ?? []).find?.((x) => x.sym === 'SAP:XETR');
      return f && f.state === 'waiting' && /attente des données/.test(f.reason ?? '') ? f : null;
    }, 20_000);
    assert.match(row.reason, /attente des données/);
    assert.equal(srv2.analysis.stats.errors, 0, 'pas compté comme un échec de l\'IA');
    assert.ok(!(srv2.analysis.pauseUntil > Date.now()), 'pas de pause « anti-boucle » de la file des favoris');
    // la page Système et la barre d'état disposent de la fin de pause
    const sys = await (await fetch(`${base2}/api/system`)).json();
    assert.ok(sys.market.yahooPausedUntil > Date.now());
    // une page qui demande un calcul sans données ne fait pas tomber le serveur (réponse claire)
    const tech = await fetch(`${base2}/api/lab/technical`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ sym: 'MC:XPAR', tf: '1D' }) });
    assert.ok([422, 503].includes(tech.status), `résumé technique sans données : ${tech.status}`);
    assert.match((await tech.json()).error, /bougies|pause|indisponible/);
    // erreur d'une source remontée jusqu'au serveur HTTP : code 503 / 422, pas d'arrêt (avant : code 0 → plantage)
    const dos = await fetch(`${base2}/api/ai/dossier?sym=MC:XPAR`);
    assert.ok([422, 502, 503].includes(dos.status), `dossier sans données : ${dos.status}`);
    for (const p of ['/api/fundamentals/MC:XPAR', '/api/quote/MC:XPAR', '/api/history?sym=MC:XPAR&tf=15m&format=json']) {
      const r = await fetch(`${base2}${p}`);
      assert.ok(r.status < 600 && r.status !== 0, p);
    }
    assert.equal((await fetch(`${base2}/api/health`)).status, 200, 'le serveur est toujours debout');
  } finally {
    await srv2.close();
    await new Promise((r) => mock2.close(r));
    await fi2.close();
    rmSync(dir2, { recursive: true, force: true });
  }
});

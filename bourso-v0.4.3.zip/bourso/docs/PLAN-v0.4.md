# Bourso v0.4 : notes techniques — données réelles

## Tes demandes et leur traitement

| Demande | Où c'est fait |
|---|---|
| « Branche-moi sur les vraies données : vraies actions, prix, cours, actualités » | `src/market/real.js` (marché réel, même interface que le simulateur), `src/data/*` (sources) |
| « Utilise toutes les API gratuites » | Yahoo Finance (cours, historiques, intraday, recherche mondiale), BCE + Frankfurter (change), Google Actualités, GDELT, flux RSS de presse ; Finnhub, FMP, Twelve Data, Stooq avec une clé gratuite facultative |
| « Siphonne le web » | Oui, mais poliment : débit par site, cache, coupe-circuit, et **aucun contournement** (captcha, consentement, connexion, paywall). Voir plus bas |
| Anti-boucle de l'IA, décisions complètes, erreur « chtimes » | Livré en 0.3.2 (voir `PLAN-v0.3.md`) |

## Architecture

- **`RealMarket`** (`src/market/real.js`) expose exactement l'interface du simulateur (`quote`,
  `daily`, `minutes`, `bars`, `clockInfo`, `indices`, `fx`, `news`…). Le reste de Bourso (graphique,
  screener, dossier de l'IA, agent, portefeuille) fonctionne sans savoir d'où viennent les chiffres.
  `MarketService` choisit le mode (`real` par défaut, `demo` au choix) et bascule à chaud.
- **Client réseau poli** (`src/data/net.js`) : une « porte » par site (requêtes simultanées,
  intervalle minimal, budget quotidien), cache mémoire avec durée de vie, coupe-circuit 1/2/5/15/30
  min sur 429/403 (ou `Retry-After`), deux nouvelles tentatives sur erreur réseau ou 5xx, arrêt net
  sur page de consentement ou de vérification. Les clés d'API sont masquées dans tous les messages.
- **Horloges réelles** : chaque place a son état réel (avant l'ouverture, séance, pause, clôturée,
  week-end, férié) dans son fuseau. Les bougies intraday sont recalées sur la grille de la séance
  (pauses exclues, enchère de clôture fusionnée dans la dernière bougie, minute sans échange = bougie
  plate sans volume). Le quotidien ne contient que des séances **terminées** ; la séance du jour est
  construite à part.
- **Ordonnanceur** : cotations groupées (spark, repli valeur par valeur), valeurs « chaudes »
  (favoris, valeur affichée, positions, alertes) plus souvent, file d'historiques, indices, change,
  actualités générales et par valeur. Trois intensités.
- **Cache disque** `data/cache` : cotations, historiques, change, actualités, valeurs ajoutées. Au
  redémarrage, Bourso affiche tout de suite les derniers chiffres connus, puis les rafraîchit.

## Honnêteté des chiffres

- Chaque cours porte son **heure** et sa **source** (« cours du 27/10 17:30 · différé · Yahoo »).
- Le dossier de l'IA annonce « données RÉELLES — cours différé ; carnet et flux non disponibles » ;
  les titres d'actualités lui sont transmis entre balises de document « non fiables ».
- Ce que les sources gratuites ne donnent pas est **dit**, pas inventé : carnet d'ordres, bande des
  transactions, secondes, PER sans clé, consensus sans clé. La fourchette est **estimée** (± 0,05 %)
  et étiquetée comme telle.
- Taille des valeurs sans clé : **capitaux moyens échangés par jour** (20 séances), mesure réelle,
  plutôt qu'une capitalisation estimée.
- **TTF** : la liste officielle 2026 (BOFiP BOI-ANNX-000467-20251217, 121 sociétés, ISIN vérifiés par
  leur chiffre de contrôle) remplace l'ancienne règle « capitalisation > 1 Md€ » (qui ne pouvait pas
  marcher sans capitalisation). Exemples : LVMH oui ; Airbus, STMicroelectronics (sociétés
  néerlandaises) et Eurofins (Luxembourg) non ; Ubisoft, Worldline, Soitec non en 2026.
- Ordres fictifs : exécution seulement pendant la séance de la place et sur un cours du jour ; motif
  d'attente affiché ; validité « jour » respectée (expiration à la séance suivante).
- Fiabilité de l'IA mesurée **séparément** en réel et en démonstration, avec un suivi adapté à
  l'horizon de la décision (intraday 8 h, swing ≈ horizon × 1,45 jour, position 30 jours).

## Ce qui n'est volontairement pas fait

- **Pas d'automatisation du « crumb » Yahoo** (jeton de session réservé à leurs pages) : c'est une
  mesure anti-automatisation. Les points d'accès ouverts suffisent pour les cours et historiques.
- **Stooq** exige depuis 2026 une clé obtenue après un captcha : la clé s'obtient dans **ton**
  navigateur, Bourso ne résout aucun captcha.
- Pas de scraping de pages HTML : seulement des API publiques, des flux RSS/Atom et des fichiers
  publiés pour être téléchargés (BCE).

## Interface

- Bandeau bleu « données réelles, ordres fictifs », barre d'état (cours reçus / historiques).
- Recherche mondiale : toute action Yahoo s'ajoute d'un clic (« + ajouter »), y compris depuis le
  bon d'ordre du portefeuille.
- Fiche valeur : heure et source du cours, encadré « Données de cette valeur » à la place du carnet,
  fondamentaux réels (dividendes versés, rendement 12 mois, 52 semaines ; PER, consensus avec clé).
- Marchés : colonne « Capitaux / jour (20 j) », carte du marché dimensionnée par cette mesure, places
  avec leurs états réels, devises avec leur source (BCE / séance).
- Actualités : liens vers les articles (`http(s)` seulement, `noopener`), portée « Marché ».
- Système : état de chaque site (requêtes, réussites, refus, pauses, latence, budget, dernière
  erreur), actualités par source, valeurs introuvables, dernières erreurs.
- Réglages → Données de marché : mode, intensité, clés (masquées), flux RSS, test des sources.

## Vérification

- `npm test` : les sources sont imitées **au format exact** par un « faux internet »
  (`test/fixtures/fake-internet.js`) : Yahoo v8 chart et spark (deux formats), v1 search, BCE XML,
  Frankfurter, Google Actualités, GDELT, presse. Scénarios : séance ouverte simulée (horloge à
  Paris 10 h 30), 429 et coupe-circuit, spark fermé (repli), valeur introuvable, ajout d'une valeur,
  ordres fictifs, bascule réel ↔ démonstration, clés masquées, flux contrôlés, TTF officielle,
  validité « jour ».
- `npm run data:check` : les vraies sources, depuis ta machine (le bac à sable de développement n'a
  pas accès à Internet ; ce test est fait pour être lancé chez toi).
- Visite Playwright de toutes les pages dans les deux modes : aucune erreur de console, aucun
  « NaN » / « undefined » affiché.

## 0.4.1 — Yahoo refusait tout (HTTP 429) au premier lancement

Ce que montrait ton journal : dès le démarrage, Yahoo répondait 429 à chaque requête, et Bourso
continuait d'envoyer celles qui attendaient leur tour (une vingtaine en trois secondes), en
allongeant la pause à chaque refus (1, 2, 5, 15 puis 30 min en une seconde).

- **Cause principale** : Bourso s'annonçait à Yahoo comme un Chrome complet. Depuis octobre 2026,
  Yahoo refuse en 429 les requêtes qui se disent navigateur de bureau sans en avoir les cookies,
  alors que l'en-tête minimal `Mozilla/5.0` est accepté (signalé le 20 octobre 2026 par d'autres
  logiciels). Bourso envoie désormais `Mozilla/5.0` tout court : il n'imite plus aucun navigateur.
- **Coupe-circuit corrigé** (`src/data/net.js`) : les requêtes en file sont annulées dès le premier
  refus et le coupe-circuit est revérifié après chaque attente, donc rien ne part pendant une pause ;
  un refus reçu pendant une pause déjà ouverte ne l'allonge plus ; une seule ligne de journal par
  pause ; deux demandes identiques simultanées n'envoient qu'une requête.
- **Ordonnanceur plus sobre** (`src/market/real.js`) : une requête Yahoo à la fois, au plus une par seconde,
  places traitées l'une après l'autre au lieu de 31 en parallèle, rien n'est demandé à Yahoo pendant
  une pause, historiques chargés toutes les 4 s (favoris d'abord) ; les valeurs refusées reprennent
  leur place dans la file. En « normale » : ≈ 15 requêtes/min une fois le cache rempli.
- **Analyses de l'IA** : si les données ne sont pas encore là (Yahoo en pause, historique en
  chargement), l'analyse **attend** au lieu d'échouer : pas de pause « anti-boucle », pas de message
  répété ; elle repart seule.
- **Visibilité** : « Yahoo en pause jusqu'à … » dans la barre d'état et la page Système ;
  `npm run data:check` explique un 429 de Yahoo (et ne répète pas la même piste six fois).
- **Divers** : un Ctrl+C n'est plus pris pour un plantage du pilote GPU ; message clair quand le
  module C++ n'est pas compilé ; piste juste pour GDELT (serveur souvent saturé, non essentiel).
- **Correction de la doc** : l'offre gratuite de Twelve Data ne couvre que les actions américaines.

## 0.4.2 — accès par le réseau (Tailscale), fiche valeur sans cours

- **`BOURSO_HOST=0.0.0.0`** fonctionne : Bourso écoute en local ET sur le réseau ; les adresses de la
  machine (Wi-Fi, Ethernet, Tailscale 100.x) sont acceptées et affichées au démarrage
  (« réseau : http://100.68.115.10:3001 (Tailscale) »). Un nom MagicDNS s'ajoute avec
  `BOURSO_ALLOW_HOSTS`. Un site piégé qui arrive avec son propre nom de domaine reste refusé.
  Pas de mot de passe : réseau de confiance seulement.
- **« Erreur d'affichage » de la fiche valeur** quand aucun cours n'est encore connu (Yahoo en
  pause, premier lancement) : le bon d'ordre lisait un cours vide. Corrigé partout : cours
  manquant = « — », graphique « pas encore de données », ordre accepté et mis « en attente d'un
  premier cours », pas de ligne de prix pour un ordre au marché.
- **Le serveur ne peut plus tomber sur une erreur de source** : une erreur réseau remontée jusqu'au
  serveur HTTP (code 0) faisait planter le processus ; elle devient une réponse 503 / 502 claire.

## 0.4.3 — l'IA disait « Attendre / Conserver » presque à chaque fois

Deux biais systématiques, mesurés sur 24 valeurs avec la réponse simulée (même logique que le dossier
transmis au modèle) : 19 « Conserver », 5 « Vendre », **0 « Acheter »**.

- **Monte Carlo mal lu** : l'objectif est à +2 ATR et le stop à −1 ATR. Sur un marché sans tendance,
  l'objectif n'est touché d'abord qu'une fois sur trois, et c'est l'ÉQUILIBRE (gagner 2 une fois sur
  trois = perdre 1 deux fois sur trois). Le dossier comparait pourtant directement « objectif 30 %
  contre stop 62 % » : un fait BAISSIER de poids 2, en tête de liste, pour TOUTES les valeurs, et un
  score Monte Carlo négatif partout. L'avantage se mesure maintenant contre le seuil de rentabilité
  (`seuilRentabilite`, `avantagePoints`, `esperanceR`) ; il n'est retenu que s'il dépasse 5 points
  et 3 erreurs standard. Le modèle reçoit la consigne de ne plus comparer objectif et stop entre eux ;
  l'outil `monte_carlo` de l'agent donne les mêmes champs.
- **Veto des actualités trop sensible** : une tonalité de titres à peine positive (0,15) suffisait
  à bloquer une vente technique (« actualités et marché se contredisent → HOLD »). Il faut
  désormais une tonalité nette (≥ 0,35, confiance ≥ 0,5) pour contredire le marché.

Après correction, sur 16 valeurs aux cours sans tendance (faux internet) : 7 « Acheter », 6 « Vendre »,
3 « Conserver », aucun veto. « Conserver » reste la bonne réponse quand rien ne se dégage : la
fiabilité réelle est mesurée sur la page Analyse IA.

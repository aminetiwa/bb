// Tests natifs + micro-bench du noyau (sans Node).
//   g++ -std=c++17 -O3 -march=native -Wall -Wextra -Inative/include native/test/test_core.cc -o build/test_core
#include <chrono>
#include <cmath>
#include <cstdio>
#include <random>
#include <vector>

#include "kalman.hpp"
#include "volume_profile.hpp"

static int g_fail = 0;
#define CHECK(cond, ...)                                  \
  do {                                                    \
    if (!(cond)) {                                        \
      ++g_fail;                                           \
      std::printf("  ✗ %s:%d  ", __FILE__, __LINE__);     \
      std::printf(__VA_ARGS__);                           \
      std::printf("\n");                                  \
    }                                                     \
  } while (0)

static void test_kalman_trend() {
  // Tendance vraie +0,01 €/s, bruit de microstructure σ=0,02 €, un tick toutes les 100 ms.
  bourso::KalmanParams p = bourso::LocalTrendKalman::for_instrument(100.0, 0.01, 0.25, 30.0);
  p.r = 0.02 * 0.02;
  bourso::LocalTrendKalman kf(p);
  std::mt19937_64 rng(42);
  std::normal_distribution<double> noise(0.0, 0.02);
  double t_us = 1.7e15, truth = 100.0;
  bourso::KalmanStep s{};
  double maxPd = 1.0;  // min du déterminant de P (positivité)
  for (int i = 0; i < 20000; ++i) {
    t_us += 100000.0;
    truth += 0.01 * 0.1;
    s = kf.step(t_us, truth + noise(rng));
    const double det = kf.var_level() * kf.var_slope() - kf.cov() * kf.cov();
    if (i > 10) maxPd = std::min(maxPd, det);
  }
  std::printf("  kalman: niveau=%.5f (vrai %.5f)  pente=%.5f €/s (vraie 0.01)  R=%.3e\n", s.level, truth, s.slope, kf.r());
  CHECK(std::fabs(s.level - truth) < 0.02, "niveau trop loin : %.5f vs %.5f", s.level, truth);
  CHECK(std::fabs(s.slope - 0.01) < 0.003, "pente trop loin : %.5f", s.slope);
  CHECK(maxPd > 0.0, "covariance non définie positive (det=%.3e)", maxPd);
  CHECK(std::fabs(std::sqrt(kf.r()) - 0.02) < 0.006, "R adaptatif mal estimé : σ=%.4f", std::sqrt(kf.r()));
}

static void test_kalman_huber() {
  bourso::KalmanParams p = bourso::LocalTrendKalman::for_instrument(50.0, 0.01, 0.20, 30.0);
  bourso::LocalTrendKalman robust(p);
  p.huber_k = 0.0;
  bourso::LocalTrendKalman naive(p);
  double t = 0;
  for (int i = 0; i < 500; ++i) { t += 50000; robust.step(t, 50.0); naive.step(t, 50.0); }
  t += 50000;
  const auto a = robust.step(t, 55.0);  // print aberrant +10 %
  const auto b = naive.step(t, 55.0);
  std::printf("  huber : après print +10%% → robuste %.4f  naïf %.4f  NIS=%.0f\n", a.level, b.level, a.nis);
  CHECK(std::fabs(a.level - 50.0) < std::fabs(b.level - 50.0) / 5.0, "Huber n'atténue pas assez");
  CHECK(a.nis > 9.0, "NIS devrait signaler l'anomalie");
}

static void test_kalman_gap() {
  bourso::KalmanParams p = bourso::LocalTrendKalman::for_instrument(100.0, 0.01, 0.25, 30.0);
  bourso::LocalTrendKalman kf(p);
  double t = 0, px = 100.0;
  for (int i = 0; i < 2000; ++i) { t += 100000; px += 0.002; kf.step(t, px); }
  t += 15.5 * 3600e6;  // nuit
  const auto s = kf.step(t, px);
  CHECK(std::fabs(s.level - px) < 0.05, "pas d'extrapolation de pente sur un trou : %.4f vs %.4f", s.level, px);
}

static void test_vp_value_area() {
  // Prix exprimés en flottants « piégeux » : 100.1, 100.2… (non représentables exactement)
  const double px[] = {100.0, 100.1, 100.2, 100.3, 100.4};
  const double vol[] = {10, 30, 50, 20, 5};
  bourso::VolumeProfile vp2(0.1, 1, 0.70, 2), vp1(0.1, 1, 0.70, 1);
  vp2.add_trades(px, vol, nullptr, 5);
  vp1.add_trades(px, vol, nullptr, 5);
  const auto s2 = vp2.stats(), s1 = vp1.stats();
  CHECK(s2.valid && vp2.row_low_price(s2.poc_row) == 100.2, "POC attendu 100.2");
  CHECK(vp2.row_low_price(s2.val_row) == 100.0 && vp2.row_high_price(s2.vah_row) == 100.2,
        "VA (pas 2) attendue [100.0, 100.2], obtenue [%.2f, %.2f]", vp2.row_low_price(s2.val_row),
        vp2.row_high_price(s2.vah_row));
  CHECK(vp1.row_low_price(s1.val_row) == 100.1 && vp1.row_high_price(s1.vah_row) == 100.3,
        "VA (pas 1) attendue [100.1, 100.3], obtenue [%.2f, %.2f]", vp1.row_low_price(s1.val_row),
        vp1.row_high_price(s1.vah_row));
  CHECK(s2.va_volume >= 0.7 * s2.total_volume, "VA < 70 %%");
}

static void test_vp_binning_exact() {
  // 712.35 / 0.05 = 14246.999999999998 en flottant : doit tomber sur la ligne 14247.
  bourso::VolumeProfile vp(0.05);
  vp.add_trade(712.35, 1.0);
  CHECK(vp.first_row() == 14247, "binning flottant faux : ligne %lld", static_cast<long long>(vp.first_row()));
  CHECK(vp.row_low_price(vp.first_row()) == 712.35, "prix de ligne non arrondi à la grille");
}

static void test_vp_bars_and_growth() {
  bourso::VolumeProfile vp(0.01, 5);
  double sum = 0;
  std::mt19937_64 rng(7);
  std::uniform_real_distribution<double> u(0, 1);
  for (int i = 0; i < 10000; ++i) {
    const double mid = 10.0 + 990.0 * u(rng);  // 10 € → 1000 € : croissance des deux côtés
    const double v = 1 + 1000 * u(rng);
    vp.add_bar(mid + 0.3, mid - 0.3, v);
    sum += v;
  }
  double tot = 0;
  for (size_t i = 0; i < vp.rows(); ++i) tot += vp.total()[i];
  CHECK(std::fabs(tot - sum) < 1e-6 * sum, "volume non conservé : %.3f vs %.3f", tot, sum);
  CHECK(vp.rows() > 19000, "plage de lignes inattendue : %zu", vp.rows());
}

static void bench() {
  const size_t n = 10'000'000;
  std::vector<double> t(n), z(n), lv(n);
  std::mt19937_64 rng(1);
  std::normal_distribution<double> nd(0, 0.01);
  double px = 600.0, ts = 1.7e15;
  for (size_t i = 0; i < n; ++i) { ts += 250; px += nd(rng); t[i] = ts; z[i] = px; }
  bourso::LocalTrendKalman kf(bourso::LocalTrendKalman::for_instrument(600, 0.1, 0.25));
  auto t0 = std::chrono::steady_clock::now();
  kf.run(t.data(), z.data(), n, lv.data(), nullptr, nullptr);
  auto t1 = std::chrono::steady_clock::now();
  bourso::VolumeProfile vp(0.1);
  std::vector<double> vol(n, 100.0);
  auto t2 = std::chrono::steady_clock::now();
  vp.add_trades(z.data(), vol.data(), nullptr, n);
  const auto st = vp.stats();
  auto t3 = std::chrono::steady_clock::now();
  const double kns = std::chrono::duration<double, std::nano>(t1 - t0).count() / n;
  const double vns = std::chrono::duration<double, std::nano>(t3 - t2).count() / n;
  std::printf("  bench : Kalman %.1f ns/tick (%.0f M ticks/s) | VolumeProfile %.1f ns/trade (%.0f M/s) | POC=%.1f\n",
              kns, 1e3 / kns, vns, 1e3 / vns, vp.row_low_price(st.poc_row));
}

int main() {
  std::printf("BOURSO native core — tests\n");
  test_kalman_trend();
  test_kalman_huber();
  test_kalman_gap();
  test_vp_value_area();
  test_vp_binning_exact();
  test_vp_bars_and_growth();
  bench();
  std::printf(g_fail ? "ÉCHEC : %d assertion(s)\n" : "OK : toutes les assertions passent\n", g_fail);
  return g_fail ? 1 : 0;
}

// ============================================================================
//  BOURSO :: addon.cc — liaison N-API (node-addon-api, exceptions C++)
//
//  Toutes les entrées/sorties de masse sont des Float64Array lues/écrites EN PLACE :
//  aucun memcpy, que le buffer soit un ArrayBuffer ou un SharedArrayBuffer
//  (vue d'un anneau SoA partagé entre Worker Threads).
//  Module « context-aware » (aucun état global) → chargeable dans chaque Worker.
// ============================================================================
#include <napi.h>

#include <algorithm>
#include <cstring>
#include <memory>
#include <string>

#include <chrono>
#include <thread>
#include <vector>

#include "backtest.hpp"
#include "kalman.hpp"
#include "montecarlo.hpp"
#include "volume_profile.hpp"

namespace {

double OptNumber(const Napi::Object& o, const char* key, double fallback) {
  const Napi::Value v = o.Get(key);
  if (v.IsUndefined() || v.IsNull()) return fallback;
  if (!v.IsNumber()) {
    throw Napi::TypeError::New(o.Env(), std::string("bourso-native: '") + key + "' doit être un nombre");
  }
  return v.As<Napi::Number>().DoubleValue();
}

// Pointeur direct dans un Float64Array (zero-copy). Lève TypeError sinon.
double* F64(const Napi::Env& env, const Napi::Value& v, const char* what, size_t* len) {
  if (!v.IsTypedArray() || v.As<Napi::TypedArray>().TypedArrayType() != napi_float64_array) {
    throw Napi::TypeError::New(env, std::string("bourso-native: ") + what + " doit être un Float64Array");
  }
  Napi::Float64Array a = v.As<Napi::Float64Array>();
  if (len) *len = a.ElementLength();
  return a.Data();
}

bool Present(const Napi::CallbackInfo& info, size_t i) {
  return info.Length() > i && !info[i].IsUndefined() && !info[i].IsNull();
}

Napi::Float64Array CopyOut(Napi::Env env, const double* src, size_t n) {
  Napi::Float64Array out = Napi::Float64Array::New(env, n);
  if (n) std::memcpy(out.Data(), src, n * sizeof(double));
  return out;
}

// ---------------------------------------------------------------------------
//  KalmanFilter
// ---------------------------------------------------------------------------
class KalmanWrap : public Napi::ObjectWrap<KalmanWrap> {
 public:
  static Napi::Function Init(Napi::Env env) {
    return DefineClass(env, "KalmanFilter",
                       {
                           InstanceMethod("step", &KalmanWrap::Step),
                           InstanceMethod("stepInto", &KalmanWrap::StepInto),
                           InstanceMethod("run", &KalmanWrap::Run),
                           InstanceMethod("reset", &KalmanWrap::Reset),
                           InstanceMethod("state", &KalmanWrap::State),
                       });
  }

  explicit KalmanWrap(const Napi::CallbackInfo& info) : Napi::ObjectWrap<KalmanWrap>(info) {
    bourso::KalmanParams p;
    if (info.Length() > 0 && info[0].IsObject()) {
      const Napi::Object o = info[0].As<Napi::Object>();
      p.q_level = OptNumber(o, "qLevel", p.q_level);
      p.q_slope = OptNumber(o, "qSlope", p.q_slope);
      p.r = OptNumber(o, "r", p.r);
      p.r_min = OptNumber(o, "rMin", p.r_min);
      p.adapt = OptNumber(o, "adapt", p.adapt);
      p.huber_k = OptNumber(o, "huberK", p.huber_k);
      p.max_dt = OptNumber(o, "maxDt", p.max_dt);
      p.p0_level = OptNumber(o, "p0Level", p.p0_level);
      p.p0_slope = OptNumber(o, "p0Slope", p.p0_slope);
    }
    kf_.set_params(p);
    kf_.reset();
  }

 private:
  // step(tUs, price) → niveau filtré
  Napi::Value Step(const Napi::CallbackInfo& info) {
    const double t = info[0].As<Napi::Number>().DoubleValue();
    const double z = info[1].As<Napi::Number>().DoubleValue();
    return Napi::Number::New(info.Env(), kf_.step(t, z).level);
  }

  // stepInto(tUs, price, out) → out[0..4] = [niveau, pente, innovation, nis, gain]
  Napi::Value StepInto(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    const double t = info[0].As<Napi::Number>().DoubleValue();
    const double z = info[1].As<Napi::Number>().DoubleValue();
    size_t len = 0;
    double* out = F64(env, info[2], "out", &len);
    if (len < 5) throw Napi::RangeError::New(env, "bourso-native: out doit contenir ≥ 5 éléments");
    const bourso::KalmanStep s = kf_.step(t, z);
    out[0] = s.level; out[1] = s.slope; out[2] = s.innovation; out[3] = s.nis; out[4] = s.gain;
    return env.Undefined();
  }

  // run(tUs, price, outLevel?, outSlope?, outNis?) → nombre de ticks traités
  Napi::Value Run(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    size_t nt = 0, nz = 0;
    const double* t = F64(env, info[0], "tUs", &nt);
    const double* z = F64(env, info[1], "price", &nz);
    const size_t n = std::min(nt, nz);
    static const char* kNames[3] = {"outLevel", "outSlope", "outNis"};
    double* outs[3] = {nullptr, nullptr, nullptr};
    for (size_t k = 0; k < 3; ++k) {
      if (!Present(info, 2 + k)) continue;
      size_t len = 0;
      outs[k] = F64(env, info[2 + k], kNames[k], &len);
      if (len < n) throw Napi::RangeError::New(env, std::string("bourso-native: ") + kNames[k] + " trop court");
    }
    kf_.run(t, z, n, outs[0], outs[1], outs[2]);
    return Napi::Number::New(env, static_cast<double>(n));
  }

  Napi::Value Reset(const Napi::CallbackInfo& info) {
    kf_.reset();
    return info.Env().Undefined();
  }

  Napi::Value State(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    Napi::Object o = Napi::Object::New(env);
    o.Set("level", kf_.level());
    o.Set("slope", kf_.slope());
    o.Set("varLevel", kf_.var_level());
    o.Set("varSlope", kf_.var_slope());
    o.Set("cov", kf_.cov());
    o.Set("r", kf_.r());
    o.Set("lastTUs", kf_.last_t_us());
    o.Set("count", static_cast<double>(kf_.count()));
    o.Set("initialized", kf_.initialized());
    return o;
  }

  bourso::LocalTrendKalman kf_;
};

// ---------------------------------------------------------------------------
//  VolumeProfile
// ---------------------------------------------------------------------------
class VolumeProfileWrap : public Napi::ObjectWrap<VolumeProfileWrap> {
 public:
  static Napi::Function Init(Napi::Env env) {
    return DefineClass(env, "VolumeProfile",
                       {
                           InstanceMethod("addTrade", &VolumeProfileWrap::AddTrade),
                           InstanceMethod("addTrades", &VolumeProfileWrap::AddTrades),
                           InstanceMethod("addBar", &VolumeProfileWrap::AddBar),
                           InstanceMethod("reset", &VolumeProfileWrap::Reset),
                           InstanceMethod("snapshot", &VolumeProfileWrap::Snapshot),
                           InstanceMethod("stats", &VolumeProfileWrap::Stats),
                       });
  }

  explicit VolumeProfileWrap(const Napi::CallbackInfo& info) : Napi::ObjectWrap<VolumeProfileWrap>(info) {
    Napi::Env env = info.Env();
    if (info.Length() < 1 || !info[0].IsObject()) {
      throw Napi::TypeError::New(env, "bourso-native: VolumeProfile({ tickSize, ticksPerRow?, valueAreaPct?, vaStep? })");
    }
    const Napi::Object o = info[0].As<Napi::Object>();
    const double tick = OptNumber(o, "tickSize", 0.0);
    if (!(tick > 0.0)) throw Napi::RangeError::New(env, "bourso-native: tickSize doit être > 0");
    vp_ = std::make_unique<bourso::VolumeProfile>(tick, static_cast<int>(OptNumber(o, "ticksPerRow", 1)),
                                                  OptNumber(o, "valueAreaPct", 0.70),
                                                  static_cast<int>(OptNumber(o, "vaStep", 2)));
  }

 private:
  Napi::Value AddTrade(const Napi::CallbackInfo& info) {
    const double side = Present(info, 2) ? info[2].As<Napi::Number>().DoubleValue() : 0.0;
    vp_->add_trade(info[0].As<Napi::Number>().DoubleValue(), info[1].As<Napi::Number>().DoubleValue(), side);
    return info.Env().Undefined();
  }

  // addTrades(px, vol, side?) — Float64Array (zero-copy) → nombre de trades
  Napi::Value AddTrades(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    size_t np = 0, nv = 0, ns = 0;
    const double* px = F64(env, info[0], "px", &np);
    const double* vol = F64(env, info[1], "vol", &nv);
    size_t n = std::min(np, nv);
    const double* side = nullptr;
    if (Present(info, 2)) {
      side = F64(env, info[2], "side", &ns);
      n = std::min(n, ns);
    }
    vp_->add_trades(px, vol, side, n);
    return Napi::Number::New(env, static_cast<double>(n));
  }

  Napi::Value AddBar(const Napi::CallbackInfo& info) {
    vp_->add_bar(info[0].As<Napi::Number>().DoubleValue(), info[1].As<Napi::Number>().DoubleValue(),
                 info[2].As<Napi::Number>().DoubleValue());
    return info.Env().Undefined();
  }

  Napi::Value Reset(const Napi::CallbackInfo& info) {
    vp_->reset();
    return info.Env().Undefined();
  }

  Napi::Value Snapshot(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    const size_t n = vp_->rows();
    Napi::Object o = Napi::Object::New(env);
    o.Set("tickSize", vp_->tick());
    o.Set("ticksPerRow", vp_->ticks_per_row());
    o.Set("firstRow", n ? static_cast<double>(vp_->first_row()) : 0.0);
    o.Set("lowPrice", n ? vp_->row_low_price(vp_->first_row()) : 0.0);
    o.Set("rows", static_cast<double>(n));
    o.Set("total", CopyOut(env, n ? vp_->total() : nullptr, n));
    o.Set("buy", CopyOut(env, n ? vp_->buy() : nullptr, n));
    o.Set("sell", CopyOut(env, n ? vp_->sell() : nullptr, n));
    return o;
  }

  Napi::Value Stats(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    const bourso::VolumeProfileStats s = vp_->stats();
    Napi::Object o = Napi::Object::New(env);
    o.Set("valid", s.valid);
    if (!s.valid) return o;
    o.Set("poc", vp_->row_low_price(s.poc_row));
    o.Set("vah", vp_->row_high_price(s.vah_row));
    o.Set("val", vp_->row_low_price(s.val_row));
    o.Set("pocRow", static_cast<double>(s.poc_row));
    o.Set("vahRow", static_cast<double>(s.vah_row));
    o.Set("valRow", static_cast<double>(s.val_row));
    o.Set("pocVolume", s.poc_volume);
    o.Set("totalVolume", s.total_volume);
    o.Set("valueAreaVolume", s.va_volume);
    return o;
  }

  std::unique_ptr<bourso::VolumeProfile> vp_;
};


// ---------------------------------------------------------------------------
//  Calcul lourd hors du thread JavaScript (AsyncWorker → pool de std::thread)
// ---------------------------------------------------------------------------
std::vector<double> CopyF64(const Napi::Env& env, const Napi::Value& v, const char* what) {
  size_t n = 0;
  const double* p = F64(env, v, what, &n);
  return std::vector<double>(p, p + n);
}

class McWorker : public Napi::AsyncWorker {
 public:
  McWorker(Napi::Env env, bourso::McSpec spec, std::vector<double> returns, int threads)
      : Napi::AsyncWorker(env), spec_(std::move(spec)), returns_(std::move(returns)), threads_(threads), deferred_(Napi::Promise::Deferred::New(env)) {}
  Napi::Promise Promise() { return deferred_.Promise(); }

 protected:
  void Execute() override {
    spec_.returns = returns_.empty() ? nullptr : returns_.data();
    spec_.n_returns = static_cast<int>(returns_.size());
    const auto t0 = std::chrono::steady_clock::now();
    res_ = bourso::mc_run(spec_, threads_);
    ms_ = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    used_ = threads_ > 0 ? threads_ : static_cast<int>(std::max(1u, std::thread::hardware_concurrency()));
  }
  void OnOK() override {
    Napi::Env env = Env();
    Napi::Object o = Napi::Object::New(env);
    auto hist = Napi::Uint32Array::New(env, res_.hist.size());
    std::memcpy(hist.Data(), res_.hist.data(), res_.hist.size() * sizeof(uint32_t));
    auto cp = Napi::Uint32Array::New(env, res_.cp_hist.size());
    if (!res_.cp_hist.empty()) std::memcpy(cp.Data(), res_.cp_hist.data(), res_.cp_hist.size() * sizeof(uint32_t));
    o.Set("hist", hist);
    o.Set("cpHist", cp);
    o.Set("sum", res_.sum);
    o.Set("sum2", res_.sum2);
    o.Set("minSum", res_.min_sum);
    o.Set("upCount", static_cast<double>(res_.up_count));
    o.Set("hitUp", static_cast<double>(res_.hit_up));
    o.Set("hitDown", static_cast<double>(res_.hit_down));
    o.Set("paths", static_cast<double>(res_.paths));
    o.Set("ms", ms_);
    o.Set("threads", used_);
    deferred_.Resolve(o);
  }
  void OnError(const Napi::Error& e) override { deferred_.Reject(e.Value()); }

 private:
  bourso::McSpec spec_;
  std::vector<double> returns_;
  int threads_;
  Napi::Promise::Deferred deferred_;
  bourso::McResult res_;
  double ms_ = 0;
  int used_ = 1;
};

/** monteCarlo(spec) → Promise<{ hist, cpHist, sum, sum2, minSum, upCount, hitUp, hitDown, paths, ms, threads }> */
Napi::Value MonteCarlo(const Napi::CallbackInfo& info) {
  Napi::Env env = info.Env();
  if (!info[0].IsObject()) throw Napi::TypeError::New(env, "bourso-native: monteCarlo(spec)");
  const Napi::Object o = info[0].As<Napi::Object>();
  bourso::McSpec s;
  s.garch = o.Get("model").ToString().Utf8Value() != "bootstrap";
  s.steps = static_cast<int>(OptNumber(o, "steps", 1));
  s.seed = static_cast<uint32_t>(OptNumber(o, "seed", 1));
  s.mu = OptNumber(o, "mu", 0);
  s.omega = OptNumber(o, "omega", 0);
  s.alpha = OptNumber(o, "alpha", 0);
  s.beta = OptNumber(o, "beta", 0);
  s.h0 = OptNumber(o, "h0", 0);
  s.nu = static_cast<int>(OptNumber(o, "nu", 0));
  s.block = OptNumber(o, "block", 10);
  const double s0 = OptNumber(o, "s0", 1), up = OptNumber(o, "up", 0), down = OptNumber(o, "down", 0);
  if (up > 0) s.ln_up = std::log(up / s0);
  if (down > 0) s.ln_down = std::log(down / s0);
  s.bins = static_cast<int>(OptNumber(o, "bins", 2048));
  s.lo = OptNumber(o, "rangeLo", -0.3);
  s.hi = OptNumber(o, "rangeHi", 0.3);
  const Napi::Value cps = o.Get("checkpoints");
  if (cps.IsArray()) {
    const Napi::Array a = cps.As<Napi::Array>();
    for (uint32_t i = 0; i < a.Length(); ++i) s.checkpoints.push_back(a.Get(i).As<Napi::Number>().Int32Value());
  }
  s.from = static_cast<int64_t>(OptNumber(o, "pathFrom", 0));
  s.to = static_cast<int64_t>(OptNumber(o, "pathTo", OptNumber(o, "paths", 1000)));
  std::vector<double> returns;
  if (!s.garch) returns = CopyF64(env, o.Get("returns"), "returns");
  auto* w = new McWorker(env, std::move(s), std::move(returns), static_cast<int>(OptNumber(o, "threads", 0)));
  auto promise = w->Promise();
  w->Queue();
  return promise;
}

class SweepWorker : public Napi::AsyncWorker {
 public:
  SweepWorker(Napi::Env env, bourso::bt::Data d, int strat, std::vector<double> params, int K, int P, bool shortOk, double cost, int from, int to,
              double bpy, int threads)
      : Napi::AsyncWorker(env), d_(std::move(d)), strat_(strat), params_(std::move(params)), K_(K), P_(P), short_(shortOk), cost_(cost),
        from_(from), to_(to), bpy_(bpy), threads_(threads), deferred_(Napi::Promise::Deferred::New(env)) {}
  Napi::Promise Promise() { return deferred_.Promise(); }

 protected:
  void Execute() override {
    out_.assign(static_cast<size_t>(K_) * bourso::bt::FIELDS, 0.0);
    const auto t0 = std::chrono::steady_clock::now();
    bourso::bt::sweep(d_, strat_, params_.data(), K_, P_, short_, cost_, from_, to_, bpy_, out_.data(), threads_);
    ms_ = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
  }
  void OnOK() override {
    Napi::Env env = Env();
    Napi::Object o = Napi::Object::New(env);
    o.Set("metrics", CopyOut(env, out_.data(), out_.size()));
    o.Set("fields", bourso::bt::FIELDS);
    o.Set("ms", ms_);
    o.Set("threads", threads_ > 0 ? threads_ : static_cast<int>(std::max(1u, std::thread::hardware_concurrency())));
    deferred_.Resolve(o);
  }
  void OnError(const Napi::Error& e) override { deferred_.Reject(e.Value()); }

 private:
  bourso::bt::Data d_;
  int strat_;
  std::vector<double> params_;
  int K_, P_;
  bool short_;
  double cost_;
  int from_, to_;
  double bpy_;
  int threads_;
  Napi::Promise::Deferred deferred_;
  std::vector<double> out_;
  double ms_ = 0;
};

/** sweep({ open, high, low, close, strategy, params, K, P, short, costBps, from, to, barsPerYear, threads }) → Promise */
Napi::Value Sweep(const Napi::CallbackInfo& info) {
  Napi::Env env = info.Env();
  if (!info[0].IsObject()) throw Napi::TypeError::New(env, "bourso-native: sweep(spec)");
  const Napi::Object o = info[0].As<Napi::Object>();
  bourso::bt::Data d;
  d.o = CopyF64(env, o.Get("open"), "open");
  d.h = CopyF64(env, o.Get("high"), "high");
  d.l = CopyF64(env, o.Get("low"), "low");
  d.c = CopyF64(env, o.Get("close"), "close");
  std::vector<double> params = CopyF64(env, o.Get("params"), "params");
  const int K = static_cast<int>(OptNumber(o, "K", 0)), P = static_cast<int>(OptNumber(o, "P", 1));
  if (static_cast<size_t>(K) * P > params.size()) throw Napi::RangeError::New(env, "bourso-native: params trop court");
  const int N = static_cast<int>(d.c.size());
  auto* w = new SweepWorker(env, std::move(d), static_cast<int>(OptNumber(o, "strategy", 0)), std::move(params), K, P,
                            o.Get("short").ToBoolean().Value(), OptNumber(o, "costBps", 5), static_cast<int>(OptNumber(o, "from", 1)),
                            static_cast<int>(OptNumber(o, "to", N)), OptNumber(o, "barsPerYear", 252), static_cast<int>(OptNumber(o, "threads", 0)));
  auto promise = w->Promise();
  w->Queue();
  return promise;
}

Napi::Object Init(Napi::Env env, Napi::Object exports) {
  exports.Set("KalmanFilter", KalmanWrap::Init(env));
  exports.Set("VolumeProfile", VolumeProfileWrap::Init(env));
  exports.Set("monteCarlo", Napi::Function::New(env, MonteCarlo));
  exports.Set("sweep", Napi::Function::New(env, Sweep));
  exports.Set("hardwareConcurrency", Napi::Number::New(env, std::max(1u, std::thread::hardware_concurrency())));
  exports.Set("version", Napi::String::New(env, "bourso-native/0.3.0"));
  return exports;
}

}  // namespace

NODE_API_MODULE(bourso_native, Init)

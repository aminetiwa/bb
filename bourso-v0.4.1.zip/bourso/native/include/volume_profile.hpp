// ============================================================================
//  BOURSO :: volume_profile.hpp
//  Profil de volume incrémental haute précision.
//
//   - chaque prix est converti en ticks ENTIERS (llround) : aucun bin faux dû au flottant
//     (712.35 / 0.05 = 14246.999999… ne tombe jamais dans la mauvaise ligne)
//   - O(1) amorti par trade, stockage qui croît des deux côtés (×2)
//   - volumes agresseur acheteur / vendeur séparés → profil de delta
//   - barres OHLCV : volume réparti uniformément sur chaque tick de [low, high]
//   - POC + Value Area (méthode CBOT : comparaison par blocs de va_step lignes)
//
//  Header-only C++17.
// ============================================================================
#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace bourso {

struct VolumeProfileStats {
  bool valid = false;
  int64_t poc_row = 0, vah_row = 0, val_row = 0;  // index de ligne global
  double poc_volume = 0.0, total_volume = 0.0, va_volume = 0.0;
};

class VolumeProfile {
 public:
  VolumeProfile(double tick_size, int ticks_per_row = 1, double va_pct = 0.70, int va_step = 2)
      : tick_(tick_size),
        tpr_(std::max(1, ticks_per_row)),
        va_pct_(std::clamp(va_pct, 0.0, 1.0)),
        va_step_(std::max(1, va_step)),
        decimals_(decimals_of(tick_size)) {}

  void reset() {
    total_.clear(); buy_.clear(); sell_.clear();
    base_ = 0; lo_ = 1; hi_ = 0;
  }

  double tick() const { return tick_; }
  int ticks_per_row() const { return tpr_; }

  int64_t row_of(double price) const {
    return floor_div(static_cast<int64_t>(std::llround(price / tick_)), tpr_);
  }
  // Plus bas / plus haut tick contenu dans la ligne, arrondis à la grille décimale du tick.
  double row_low_price(int64_t row) const { return round_dec(static_cast<double>(row * tpr_) * tick_); }
  double row_high_price(int64_t row) const {
    return round_dec(static_cast<double>(row * tpr_ + tpr_ - 1) * tick_);
  }

  void add_trade(double price, double volume, double side = 0.0) {
    if (!(volume > 0.0) || !std::isfinite(price)) return;
    const std::size_t i = ensure(row_of(price));
    total_[i] += volume;
    if (side > 0.0) buy_[i] += volume;
    else if (side < 0.0) sell_[i] += volume;
  }

  // Lot zero-copy. side peut être nullptr (+1 agresseur acheteur, −1 vendeur, 0 inconnu).
  std::size_t add_trades(const double* px, const double* vol, const double* side, std::size_t n) {
    for (std::size_t i = 0; i < n; ++i) add_trade(px[i], vol[i], side ? side[i] : 0.0);
    return n;
  }

  void add_bar(double high, double low, double volume) {
    if (!(volume > 0.0) || !std::isfinite(high) || !std::isfinite(low)) return;
    if (high < low) std::swap(high, low);
    const int64_t th = std::llround(high / tick_), tl = std::llround(low / tick_);
    const double per_tick = volume / static_cast<double>(th - tl + 1);
    const int64_t r0 = floor_div(tl, tpr_), r1 = floor_div(th, tpr_);
    ensure(r0);
    ensure(r1);  // r1 ≥ r0 : ne peut qu'ajouter en fin, base_ inchangée
    for (int64_t r = r0; r <= r1; ++r) {
      const int64_t a = std::max(tl, r * tpr_), b = std::min(th, r * tpr_ + tpr_ - 1);
      total_[static_cast<std::size_t>(r - base_)] += per_tick * static_cast<double>(b - a + 1);
    }
  }

  bool empty() const { return hi_ < lo_; }
  int64_t first_row() const { return lo_; }
  int64_t last_row() const { return hi_; }
  std::size_t rows() const { return empty() ? 0 : static_cast<std::size_t>(hi_ - lo_ + 1); }
  // Pointeurs sur la plage utilisée [first_row, last_row] (valides tant que le profil ne croît pas).
  const double* total() const { return total_.data() + (lo_ - base_); }
  const double* buy() const { return buy_.data() + (lo_ - base_); }
  const double* sell() const { return sell_.data() + (lo_ - base_); }

  VolumeProfileStats stats() const {
    VolumeProfileStats s;
    if (empty()) return s;
    const double* v = total();
    const int64_t n = hi_ - lo_ + 1;
    const double mid = 0.5 * static_cast<double>(n - 1);
    double tot = 0.0, best = -1.0;
    int64_t poc = 0;
    for (int64_t i = 0; i < n; ++i) {
      tot += v[i];
      // ex æquo : la ligne la plus proche du centre du profil
      if (v[i] > best ||
          (v[i] == best && std::fabs(static_cast<double>(i) - mid) < std::fabs(static_cast<double>(poc) - mid))) {
        best = v[i];
        poc = i;
      }
    }
    if (!(tot > 0.0)) return s;

    const double target = va_pct_ * tot;
    double va = v[poc];
    int64_t up = poc + 1, dn = poc - 1, top = poc, bot = poc;
    while (va < target && (up < n || dn >= 0)) {
      double su = 0.0, sd = 0.0;
      int64_t nu = 0, nd = 0;
      for (int64_t j = 0; j < va_step_ && up + j < n; ++j) { su += v[up + j]; ++nu; }
      for (int64_t j = 0; j < va_step_ && dn - j >= 0; ++j) { sd += v[dn - j]; ++nd; }
      const bool take_up = nu > 0 && (nd == 0 || su >= sd);
      const bool take_dn = nd > 0 && (nu == 0 || sd >= su);  // égalité : on prend les deux
      if (take_up) { va += su; top = up + nu - 1; up += nu; }
      if (take_dn) { va += sd; bot = dn - nd + 1; dn -= nd; }
    }
    s.valid = true;
    s.poc_row = lo_ + poc;
    s.vah_row = lo_ + top;
    s.val_row = lo_ + bot;
    s.poc_volume = best;
    s.total_volume = tot;
    s.va_volume = va;
    return s;
  }

 private:
  static int64_t floor_div(int64_t a, int64_t b) {
    int64_t q = a / b;
    if ((a % b != 0) && ((a < 0) != (b < 0))) --q;
    return q;
  }
  static int decimals_of(double tick) {
    for (int d = 0; d <= 10; ++d) {
      const double s = tick * std::pow(10.0, d);
      if (std::fabs(s - std::round(s)) < 1e-9 * std::max(1.0, s)) return d;
    }
    return 10;
  }
  double round_dec(double x) const {
    const double m = std::pow(10.0, decimals_);
    return std::round(x * m) / m;
  }

  // Garantit que `row` est adressable et renvoie son index local (croissance amortie ×2).
  std::size_t ensure(int64_t row) {
    if (total_.empty()) {
      constexpr int64_t kInit = 256;
      base_ = row - kInit / 2;
      total_.assign(kInit, 0.0); buy_.assign(kInit, 0.0); sell_.assign(kInit, 0.0);
      lo_ = hi_ = row;
      return static_cast<std::size_t>(row - base_);
    }
    const int64_t size = static_cast<int64_t>(total_.size());
    if (row < base_) {
      const int64_t grow = std::max<int64_t>(size, base_ - row + 64);
      total_.insert(total_.begin(), static_cast<std::size_t>(grow), 0.0);
      buy_.insert(buy_.begin(), static_cast<std::size_t>(grow), 0.0);
      sell_.insert(sell_.begin(), static_cast<std::size_t>(grow), 0.0);
      base_ -= grow;
    } else if (row >= base_ + size) {
      const int64_t grow = std::max<int64_t>(size, row - (base_ + size) + 64);
      const std::size_t ns = static_cast<std::size_t>(size + grow);
      total_.resize(ns, 0.0); buy_.resize(ns, 0.0); sell_.resize(ns, 0.0);
    }
    lo_ = std::min(lo_, row);
    hi_ = std::max(hi_, row);
    return static_cast<std::size_t>(row - base_);
  }

  double tick_;
  int tpr_;
  double va_pct_;
  int va_step_;
  int decimals_;
  std::vector<double> total_, buy_, sell_;
  int64_t base_ = 0;       // ligne globale de l'élément 0
  int64_t lo_ = 1, hi_ = 0;  // plage utilisée (vide si hi_ < lo_)
};

}  // namespace bourso

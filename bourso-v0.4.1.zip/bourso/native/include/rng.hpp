// ============================================================================
//  BOURSO :: rng.hpp — générateur xoshiro128** IDENTIQUE à src/core/quant/numeric.js (Rng) :
//  même initialisation (splitmix32), même sortie 53 bits, même Box-Muller (cosinus d'abord,
//  sinus mis de côté). Le C++ et le JavaScript tirent exactement les mêmes nombres : leurs
//  Monte Carlo sont comparables trajectoire par trajectoire.
// ============================================================================
#pragma once
#include <cmath>
#include <cstdint>

namespace bourso {

inline uint32_t rotl32(uint32_t x, int k) { return (x << k) | (x >> (32 - k)); }

/** Graine du flux de la trajectoire p (= pathSeed de montecarlo.js). */
inline uint32_t path_seed(uint32_t seed, uint32_t p) {
  uint32_t z = seed ^ ((p + 1u) * 0x9e3779b9u);
  z = (z ^ (z >> 16)) * 0x85ebca6bu;
  z = (z ^ (z >> 13)) * 0xc2b2ae35u;
  return z ^ (z >> 16);
}

struct Rng {
  uint32_t a, b, c, d;
  double spare = 0.0;
  bool has_spare = false;

  explicit Rng(uint32_t seed) {
    uint32_t s = seed;
    auto nx = [&s]() {
      s += 0x9e3779b9u;
      uint32_t z = s;
      z = (z ^ (z >> 16)) * 0x85ebca6bu;
      z = (z ^ (z >> 13)) * 0xc2b2ae35u;
      return z ^ (z >> 16);
    };
    a = nx(); b = nx(); c = nx(); d = nx();
    if (!(a | b | c | d)) a = 1;
  }

  uint32_t u32() {
    const uint32_t r = rotl32(b * 5u, 7) * 9u;
    const uint32_t t = b << 9;
    c ^= a; d ^= b; b ^= c; a ^= d;
    c ^= t;
    d = rotl32(d, 11);
    return r;
  }

  /** Uniforme ]0, 1[ sur 53 bits. */
  double next() {
    const uint32_t hi = u32() >> 5, lo = u32() >> 6;
    return (static_cast<double>(hi) * 67108864.0 + static_cast<double>(lo) + 0.5) / 9007199254740992.0;
  }

  double normal() {
    if (has_spare) {
      has_spare = false;
      return spare;
    }
    const double u = next(), v = next();
    const double r = std::sqrt(-2.0 * std::log(u)), th = 2.0 * M_PI * v;
    spare = r * std::sin(th);
    has_spare = true;
    return r * std::cos(th);
  }

  int intn(int n) { return static_cast<int>(std::floor(next() * n)); }
};

}  // namespace bourso

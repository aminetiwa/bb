// ============================================================================
//  BOURSO :: kalman.hpp
//  Filtre de Kalman « tendance locale » (niveau + pente) pour flux tick-by-tick.
//
//   état      x = [niveau, pente]            pente en prix/seconde
//   mesure    z = prix (trade, mid ou microprice), H = [1 0]
//   dynamique F(dt) = [[1, dt], [0, 1]]       dt irrégulier (horodatage µs)
//   bruit     Q(dt) = qL·[[dt,0],[0,0]] + qS·[[dt³/3, dt²/2], [dt²/2, dt]]
//
//  Précision :
//   - covariance mise à jour en forme de Joseph → reste symétrique définie positive
//   - robustesse Huber sur l'innovation normalisée (prints aberrants, fat-finger)
//   - bruit de mesure R adaptatif (Sage-Husa à oubli exponentiel, inliers seulement)
//   - trous de cotation (enchères, suspension, nuit) : pas d'extrapolation de pente
//
//  Header-only C++17 : partagé par l'addon N-API, le build WASM et les tests natifs.
// ============================================================================
#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>

namespace bourso {

struct KalmanParams {
  double q_level  = 1e-4;   // densité spectrale de diffusion du niveau     [prix²/s]
  double q_slope  = 1e-7;   // densité spectrale de diffusion de la pente   [prix²/s³]
  double r        = 1e-4;   // variance initiale du bruit de microstructure [prix²]
  double r_min    = 1e-12;  // plancher de R adaptatif                      [prix²]
  double adapt    = 0.01;   // facteur d'oubli de R (0 = R fixe)
  double huber_k  = 3.0;    // seuil de robustesse en sigmas (<= 0 : désactivé)
  double max_dt   = 30.0;   // [s] au-delà : trou de cotation → pente remise à 0
  double p0_level = 1e-2;   // variance initiale du niveau                  [prix²]
  double p0_slope = 1e-4;   // variance initiale de la pente                [prix²/s²]
};

struct KalmanStep {
  double level;       // prix filtré
  double slope;       // pente [prix/s]
  double innovation;  // z − prédiction
  double nis;         // innovation normalisée au carré (χ² à 1 ddl : > 9 ⇒ anomalie 3σ)
  double gain;        // gain appliqué au niveau (0..1)
};

class LocalTrendKalman {
 public:
  explicit LocalTrendKalman(const KalmanParams& p = KalmanParams{}) : p_(p) { reset(); }

  void set_params(const KalmanParams& p) { p_ = p; }
  const KalmanParams& params() const { return p_; }

  void reset() {
    x0_ = x1_ = 0.0;
    p00_ = p_.p0_level; p01_ = 0.0; p11_ = p_.p0_slope;
    r_ = p_.r; t_us_ = 0.0; init_ = false; n_ = 0;
  }

  double level() const { return x0_; }
  double slope() const { return x1_; }
  double var_level() const { return p00_; }
  double var_slope() const { return p11_; }
  double cov() const { return p01_; }
  double r() const { return r_; }
  double last_t_us() const { return t_us_; }
  bool initialized() const { return init_; }
  unsigned long long count() const { return n_; }

  // Un tick. t_us : horodatage en microsecondes (double, exact jusqu'à 2^53 µs ≈ 285 ans).
  KalmanStep step(double t_us, double z) {
    if (!std::isfinite(z) || !std::isfinite(t_us)) return {x0_, x1_, 0.0, 0.0, 0.0};
    ++n_;
    if (!init_) {
      x0_ = z; x1_ = 0.0;
      p00_ = r_; p01_ = 0.0; p11_ = p_.p0_slope;
      t_us_ = t_us; init_ = true;
      return {x0_, x1_, 0.0, 0.0, 1.0};
    }
    double dt = (t_us - t_us_) * 1e-6;
    if (t_us > t_us_) t_us_ = t_us;   // horloge monotone : un tick en retard ne recule pas le temps
    if (!(dt > 0.0)) dt = 0.0;
    if (dt > p_.max_dt) {
      // Trou de cotation : l'incertitude du niveau diffuse, la pente n'est pas extrapolée.
      p00_ += p_.q_level * dt;
      x1_ = 0.0; p01_ = 0.0; p11_ = p_.p0_slope;
      dt = 0.0;
    }
    predict(dt);
    return update(z);
  }

  // Lot zero-copy : pointeurs directs dans des Float64Array (y compris SharedArrayBuffer).
  // Les sorties peuvent être nullptr.
  std::size_t run(const double* t_us, const double* z, std::size_t n,
                  double* out_level, double* out_slope, double* out_nis) {
    for (std::size_t i = 0; i < n; ++i) {
      const KalmanStep s = step(t_us[i], z[i]);
      if (out_level) out_level[i] = s.level;
      if (out_slope) out_slope[i] = s.slope;
      if (out_nis) out_nis[i] = s.nis;
    }
    return n;
  }

  // Paramétrage à partir de grandeurs de marché (prix, pas de cotation, vol annualisée).
  static KalmanParams for_instrument(double price, double tick, double annual_vol,
                                     double trend_tau_s = 30.0) {
    // Euronext / XETRA : séance continue 09:00–17:30 = 8,5 h, 252 séances/an.
    constexpr double kTradingSecondsPerYear = 252.0 * 8.5 * 3600.0;
    const double sigma_s = price * annual_vol / std::sqrt(kTradingSecondsPerYear);  // [prix/√s]
    const double tau = std::max(trend_tau_s, 1e-3);
    KalmanParams p;
    p.q_level  = sigma_s * sigma_s;
    p.q_slope  = p.q_level / (tau * tau);
    p.r        = 0.25 * tick * tick;  // rebond bid/ask ≈ ±½ tick
    p.r_min    = 1e-4 * tick * tick;
    p.p0_level = tick * tick;
    p.p0_slope = p.q_level / tau;
    return p;
  }

 private:
  void predict(double dt) {
    if (dt <= 0.0) return;
    const double dt2 = dt * dt, dt3 = dt2 * dt;
    x0_ += dt * x1_;
    const double a = p00_, b = p01_, c = p11_;
    p00_ = a + 2.0 * dt * b + dt2 * c + p_.q_level * dt + p_.q_slope * dt3 / 3.0;
    p01_ = b + dt * c + 0.5 * p_.q_slope * dt2;
    p11_ = c + p_.q_slope * dt;
  }

  KalmanStep update(double z) {
    const double a = p00_, b = p01_, c = p11_;
    const double y = z - x0_;
    double r = r_;
    double S = a + r;
    const double nis = (y * y) / S;
    bool inlier = true;
    if (p_.huber_k > 0.0) {
      const double m = std::sqrt(nis);  // |innovation| en sigmas
      if (m > p_.huber_k) {
        // Huber : S gonflé d'un facteur m/k → correction bornée à k·σ·gain
        const double s_eff = S * (m / p_.huber_k);
        r = s_eff - a;
        S = s_eff;
        inlier = false;
      }
    }
    const double k0 = a / S, k1 = b / S;
    x0_ += k0 * y;
    x1_ += k1 * y;
    // Forme de Joseph : P = (I−KH)·P·(I−KH)ᵀ + K·R·Kᵀ
    const double g = 1.0 - k0;
    p00_ = g * g * a + r * k0 * k0;
    p01_ = g * (b - k1 * a) + r * k0 * k1;
    p11_ = c - 2.0 * k1 * b + k1 * k1 * a + r * k1 * k1;
    if (inlier && p_.adapt > 0.0) {
      // E[y²] = H·P⁻·Hᵀ + R  ⇒  R̂ = y² − P⁻₀₀ (borné par r_min)
      const double r_hat = std::max(y * y - a, p_.r_min);
      r_ = (1.0 - p_.adapt) * r_ + p_.adapt * r_hat;
    }
    return {x0_, x1_, y, nis, k0};
  }

  KalmanParams p_;
  double x0_ = 0.0, x1_ = 0.0;               // niveau, pente
  double p00_ = 0.0, p01_ = 0.0, p11_ = 0.0;  // covariance (symétrique)
  double r_ = 0.0;                           // bruit de mesure courant
  double t_us_ = 0.0;
  bool init_ = false;
  unsigned long long n_ = 0;
};

}  // namespace bourso

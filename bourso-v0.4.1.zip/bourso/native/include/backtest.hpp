// ============================================================================
//  BOURSO :: backtest.hpp — balayage massif de paramètres de stratégies, natif multi-cœurs.
//
//  Réplique EXACTE (mêmes opérations, même ordre, double précision, -ffp-contract=off) des
//  indicateurs et du moteur de src/core/quant/{indicators,backtest}.js : positions décidées à
//  la clôture, exécutées à l'ouverture suivante, frais par côté, métriques identiques.
//  Sortie : FIELDS valeurs par combinaison de paramètres.
// ============================================================================
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <thread>
#include <vector>

namespace bourso {
namespace bt {

constexpr double NaN = std::numeric_limits<double>::quiet_NaN();
constexpr int RESYNC = 4096;
enum Strategy { EMA_CROSS = 0, SMA_CROSS = 1, RSI_REVERT = 2, BOLL_REVERT = 3, DONCHIAN = 4, MACD_CROSS = 5 };
constexpr int FIELDS = 10;  // total, annRet, sharpe, sortino, maxDD, trades, winRate, profitFactor, exposure, annVol

struct Neumaier {
  double s = 0, c = 0;
  void add(double x) {
    const double t = s + x;
    if (std::fabs(s) >= std::fabs(x)) c += s - t + x;
    else c += x - t + s;
    s = t;
  }
  double value() const { return s + c; }
  void reset() { s = 0; c = 0; }
};

inline int first_finite(const std::vector<double>& x) {
  for (size_t i = 0; i < x.size(); ++i) if (std::isfinite(x[i])) return static_cast<int>(i);
  return static_cast<int>(x.size());
}

inline std::vector<double> sma(const std::vector<double>& x, int n) {
  const int N = static_cast<int>(x.size()), f = first_finite(x);
  std::vector<double> out(N, NaN);
  if (n < 1 || f + n > N) return out;
  Neumaier acc;
  for (int i = f; i < N; ++i) {
    acc.add(x[i]);
    if (i - f >= n) acc.add(-x[i - n]);
    if (i - f >= n - 1) {
      if ((i - f) % RESYNC == 0 && i - f >= n) {
        acc.reset();
        for (int j = i - n + 1; j <= i; ++j) acc.add(x[j]);
      }
      out[i] = acc.value() / n;
    }
  }
  return out;
}

inline std::vector<double> exp_smooth(const std::vector<double>& x, int n, double alpha) {
  const int N = static_cast<int>(x.size()), f = first_finite(x);
  std::vector<double> out(N, NaN);
  if (n < 1 || f + n > N) return out;
  double s = 0;
  for (int i = f; i < f + n; ++i) s += x[i];
  double e = s / n;
  out[f + n - 1] = e;
  for (int i = f + n; i < N; ++i) {
    e += alpha * (x[i] - e);
    out[i] = e;
  }
  return out;
}
inline std::vector<double> ema(const std::vector<double>& x, int n) { return exp_smooth(x, n, 2.0 / (n + 1)); }

inline std::vector<double> rsi(const std::vector<double>& c, int n) {
  const int N = static_cast<int>(c.size()), f = first_finite(c);
  std::vector<double> out(N, NaN);
  if (N - f <= n) return out;
  double g = 0, l = 0;
  for (int i = f + 1; i <= f + n; ++i) {
    const double d = c[i] - c[i - 1];
    if (d > 0) g += d;
    else l -= d;
  }
  g /= n;
  l /= n;
  auto val = [&]() { return l == 0 ? (g == 0 ? 50.0 : 100.0) : 100.0 - 100.0 / (1.0 + g / l); };
  out[f + n] = val();
  for (int i = f + n + 1; i < N; ++i) {
    const double d = c[i] - c[i - 1];
    g = (g * (n - 1) + (d > 0 ? d : 0)) / n;
    l = (l * (n - 1) + (d < 0 ? -d : 0)) / n;
    out[i] = val();
  }
  return out;
}

inline std::vector<double> rolling_std(const std::vector<double>& x, int n) {
  const int N = static_cast<int>(x.size()), f = first_finite(x);
  std::vector<double> out(N, NaN);
  if (f + n > N) return out;
  const double K = x[f];
  Neumaier s1, s2;
  for (int i = f; i < N; ++i) {
    const double d = x[i] - K;
    s1.add(d);
    s2.add(d * d);
    if (i - f >= n) {
      const double e = x[i - n] - K;
      s1.add(-e);
      s2.add(-e * e);
    }
    if (i - f >= n - 1) {
      const double m = s1.value() / n;
      const double varp = std::max(0.0, s2.value() / n - m * m);
      out[i] = std::sqrt(varp);
    }
  }
  return out;
}

template <bool MAX>
inline std::vector<double> rolling_ext(const std::vector<double>& x, int n) {
  const int N = static_cast<int>(x.size());
  std::vector<double> out(N, NaN);
  std::vector<int> dq(N);
  int h = 0, t = 0;
  for (int i = 0; i < N; ++i) {
    while (t > h && (MAX ? x[dq[t - 1]] <= x[i] : x[dq[t - 1]] >= x[i])) --t;
    dq[t++] = i;
    if (dq[h] <= i - n) ++h;
    if (i >= n - 1) out[i] = x[dq[h]];
  }
  return out;
}

struct Data {
  std::vector<double> o, h, l, c;
};

/** Positions cibles (décidées à la clôture), comme STRATEGIES[...].positions en JS. */
inline std::vector<int8_t> positions(const Data& d, int strat, const double* p, bool shortOk) {
  const int N = static_cast<int>(d.c.size());
  std::vector<int8_t> pos(N, 0);
  switch (strat) {
    case EMA_CROSS:
    case SMA_CROSS: {
      const int fast = static_cast<int>(p[0]), slow = static_cast<int>(p[1]);
      const auto f = strat == EMA_CROSS ? ema(d.c, fast) : sma(d.c, fast);
      const auto s = strat == EMA_CROSS ? ema(d.c, slow) : sma(d.c, slow);
      for (int i = 0; i < N; ++i) if (std::isfinite(s[i])) pos[i] = f[i] > s[i] ? 1 : shortOk ? -1 : 0;
      break;
    }
    case RSI_REVERT: {
      const int n = static_cast<int>(p[0]);
      const double lo = p[1], ex = p[2];
      const auto r = rsi(d.c, n);
      int cur = 0;
      for (int i = 0; i < N; ++i) {
        if (!std::isfinite(r[i])) continue;
        if (cur == 0) cur = r[i] < lo ? 1 : shortOk && r[i] > 100 - lo ? -1 : 0;
        else if (cur == 1 && r[i] > ex) cur = 0;
        else if (cur == -1 && r[i] < 100 - ex) cur = 0;
        pos[i] = static_cast<int8_t>(cur);
      }
      break;
    }
    case BOLL_REVERT: {
      const int n = static_cast<int>(p[0]);
      const double k = p[1];
      const auto mid = sma(d.c, n), sd = rolling_std(d.c, n);
      int cur = 0;
      for (int i = 0; i < N; ++i) {
        if (!std::isfinite(mid[i])) continue;
        const double up = mid[i] + k * sd[i], lo = mid[i] - k * sd[i];
        if (cur == 0) cur = d.c[i] < lo ? 1 : shortOk && d.c[i] > up ? -1 : 0;
        else if (cur == 1 && d.c[i] > mid[i]) cur = 0;
        else if (cur == -1 && d.c[i] < mid[i]) cur = 0;
        pos[i] = static_cast<int8_t>(cur);
      }
      break;
    }
    case DONCHIAN: {
      const int n = static_cast<int>(p[0]), half = std::max(2, static_cast<int>(std::round(n / 2.0)));
      const auto hi = rolling_ext<true>(d.h, n), lo = rolling_ext<false>(d.l, half);
      const auto hiL = rolling_ext<true>(d.h, half), loL = rolling_ext<false>(d.l, n);
      int cur = 0;
      for (int i = 1; i < N; ++i) {
        if (!std::isfinite(hi[i - 1]) || !std::isfinite(loL[i - 1])) continue;
        if (cur <= 0 && d.c[i] > hi[i - 1]) cur = 1;
        else if (cur >= 0 && shortOk && d.c[i] < loL[i - 1]) cur = -1;
        else if (cur == 1 && d.c[i] < lo[i - 1]) cur = 0;
        else if (cur == -1 && d.c[i] > hiL[i - 1]) cur = 0;
        pos[i] = static_cast<int8_t>(cur);
      }
      break;
    }
    case MACD_CROSS: {
      const auto a = ema(d.c, static_cast<int>(p[0])), b = ema(d.c, static_cast<int>(p[1]));
      std::vector<double> line(N, NaN);
      for (int i = 0; i < N; ++i) if (std::isfinite(a[i]) && std::isfinite(b[i])) line[i] = a[i] - b[i];
      const auto sig = ema(line, static_cast<int>(p[2]));
      for (int i = 0; i < N; ++i) if (std::isfinite(sig[i])) pos[i] = line[i] > sig[i] ? 1 : shortOk ? -1 : 0;
      break;
    }
    default:
      break;
  }
  return pos;
}

/** Simulation + métriques (= simulate + metrics en JS) ; écrit FIELDS valeurs dans out. */
inline void evaluate(const Data& d, const std::vector<int8_t>& pos, double costBps, int from, int to, double bpy, double* out) {
  const double cost = costBps / 1e4;
  const int N = static_cast<int>(d.c.size());
  to = std::min(to, N);
  std::vector<double> ret(N, 0.0);
  struct Trade { int entry; double r; };
  std::vector<Trade> trades;
  int cur = 0;
  bool open = false;
  Trade ot{0, 0};
  for (int t = std::max(1, from); t < to; ++t) {
    const int target = pos[t - 1];
    double r;
    if (target != cur) {
      r = cur * std::log(d.o[t] / d.c[t - 1]) + target * std::log(d.c[t] / d.o[t]) - cost * std::abs(target - cur);
      if (open && cur != 0) {
        ot.r += cur * std::log(d.o[t] / d.c[t - 1]) - cost * std::abs(cur);
        trades.push_back(ot);
        open = false;
      }
      if (target != 0) {
        ot = Trade{t, target * std::log(d.c[t] / d.o[t]) - cost * std::abs(target)};
        open = true;
      }
      cur = target;
    } else {
      r = cur * std::log(d.c[t] / d.c[t - 1]);
      if (open) ot.r += r;
    }
    ret[t] = r;
  }
  if (open) trades.push_back(ot);
  const int mfrom = std::max(1, from);
  const int n = std::max(1, to - mfrom);
  double sum = 0, peak = 0, eq = 0, maxDD = 0, downs = 0;
  int exposure = 0;
  int wn = 0;
  double wm = 0, ws = 0;
  for (int t = mfrom; t < to; ++t) {
    sum += ret[t];
    eq += ret[t];
    if (eq > peak) peak = eq;
    if (eq - peak < maxDD) maxDD = eq - peak;
    if (ret[t] < 0) downs += ret[t] * ret[t];
    if (pos[t - 1] != 0) ++exposure;
    ++wn;
    const double dl = ret[t] - wm;
    wm += dl / wn;
    ws += dl * (ret[t] - wm);
  }
  const double sd = wn > 1 ? std::sqrt(ws / (wn - 1)) : NaN;
  const double annRet = std::exp((sum / n) * bpy) - 1, annVol = sd * std::sqrt(bpy);
  const double dsd = std::sqrt(downs / n) * std::sqrt(bpy);
  int tn = 0, wins = 0;
  double gw = 0, gl = 0;
  for (const auto& tr : trades) {
    if (tr.entry < mfrom || tr.entry >= to) continue;
    ++tn;
    if (tr.r > 0) { ++wins; gw += tr.r; } else gl -= tr.r;
  }
  const double mdd = std::exp(maxDD) - 1;
  out[0] = std::exp(sum) - 1;
  out[1] = annRet;
  out[2] = sd > 0 ? (wm / sd) * std::sqrt(bpy) : 0;
  out[3] = dsd > 0 ? ((sum / n) * bpy) / dsd : 0;
  out[4] = mdd;
  out[5] = tn;
  out[6] = tn ? static_cast<double>(wins) / tn : 0;
  out[7] = gl > 0 ? gw / gl : (gw > 0 ? std::numeric_limits<double>::infinity() : 0);
  out[8] = static_cast<double>(exposure) / n;
  out[9] = annVol;
}

/** Balaye K combinaisons (P paramètres chacune) sur `threads` cœurs. */
inline void sweep(const Data& d, int strat, const double* params, int K, int P, bool shortOk, double costBps, int from, int to, double bpy,
                  double* out, int threads) {
  int T = threads > 0 ? threads : static_cast<int>(std::max(1u, std::thread::hardware_concurrency()));
  T = std::max(1, std::min(T, K));
  std::vector<std::thread> pool;
  for (int k = 0; k < T; ++k) {
    pool.emplace_back([&, k] {
      for (int j = k; j < K; j += T) {
        const auto pos = positions(d, strat, params + static_cast<size_t>(j) * P, shortOk);
        evaluate(d, pos, costBps, from, to, bpy, out + static_cast<size_t>(j) * FIELDS);
      }
    });
  }
  for (auto& th : pool) th.join();
}

}  // namespace bt
}  // namespace bourso

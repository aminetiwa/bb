// ============================================================================
//  BOURSO :: montecarlo.hpp — Monte Carlo natif, multi-cœurs, double précision.
//
//  Réplique EXACTE de simulateMC (src/core/quant/montecarlo.js) : mêmes modèles (GARCH(1,1) /
//  bootstrap stationnaire), même correction du pont brownien pour les barrières, même flux
//  aléatoire par trajectoire → résultats identiques au JavaScript, mais sur tous les cœurs.
//  Les trajectoires [from, to[ sont réparties entre T threads ; chaque thread accumule ses
//  histogrammes et sommes en local, fusionnés à la fin (aucun verrou dans la boucle chaude).
// ============================================================================
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <thread>
#include <vector>

#include "rng.hpp"

namespace bourso {

struct McSpec {
  bool garch = true;
  int steps = 1;
  uint32_t seed = 1;
  double mu = 0, omega = 0, alpha = 0, beta = 0, h0 = 0;
  int nu = 0;
  const double* returns = nullptr;
  int n_returns = 0;
  double block = 10;
  double ln_up = std::numeric_limits<double>::infinity();
  double ln_down = -std::numeric_limits<double>::infinity();
  int bins = 2048;
  double lo = -0.3, hi = 0.3;
  std::vector<int> checkpoints;
  int64_t from = 0, to = 0;
};

struct McResult {
  std::vector<uint32_t> hist, cp_hist;
  double sum = 0, sum2 = 0, min_sum = 0;
  int64_t up_count = 0, hit_up = 0, hit_down = 0, paths = 0;
};

inline void mc_range(const McSpec& s, int64_t from, int64_t to, McResult& out) {
  const int bins = s.bins, ncp = static_cast<int>(s.checkpoints.size());
  out.hist.assign(bins, 0);
  out.cp_hist.assign(static_cast<size_t>(ncp) * bins, 0);
  const double scale = bins / (s.hi - s.lo);
  auto bin = [&](double x) {
    const double f = std::floor((x - s.lo) * scale);
    return static_cast<int>(std::min<double>(bins - 1, std::max<double>(0.0, f)));
  };
  const double p_new = 1.0 / std::max(1.0, s.block);
  const double t_scale = s.nu > 2 ? std::sqrt((s.nu - 2.0) / s.nu) : 1.0;
  const bool has_up = std::isfinite(s.ln_up), has_down = std::isfinite(s.ln_down);
  for (int64_t p = from; p < to; ++p) {
    Rng rng(path_seed(s.seed, static_cast<uint32_t>(p)));
    double x = 0, h = s.h0, xmin = 0;
    int first = 0, cpk = 0;
    int idx = rng.intn(std::max(1, s.n_returns));
    for (int t = 1; t <= s.steps; ++t) {
      double r, var_step;
      if (s.garch) {
        double z = rng.normal();
        if (s.nu > 2) {
          double chi = 0;
          for (int k = 0; k < s.nu; ++k) { const double g = rng.normal(); chi += g * g; }
          z = (z / std::sqrt(chi / s.nu)) * t_scale;
        }
        const double e = std::sqrt(h) * z;
        r = s.mu + e;
        var_step = h;
        h = s.omega + s.alpha * e * e + s.beta * h;
      } else {
        idx = rng.next() < p_new ? rng.intn(s.n_returns) : (idx + 1) % s.n_returns;
        r = s.returns[idx];
        var_step = std::max(1e-14, r * r);
      }
      const double a = x;
      x += r;
      if (x < xmin) xmin = x;
      if (!first) {
        bool up = x >= s.ln_up, dn = x <= s.ln_down;
        if (!up && has_up) up = rng.next() < std::exp((-2.0 * (s.ln_up - a) * (s.ln_up - x)) / var_step);
        if (!dn && has_down) dn = rng.next() < std::exp((-2.0 * (a - s.ln_down) * (x - s.ln_down)) / var_step);
        if (up && dn) first = rng.next() < 0.5 ? 1 : -1;
        else if (up) first = 1;
        else if (dn) first = -1;
      }
      if (cpk < ncp && t == s.checkpoints[cpk]) {
        out.cp_hist[static_cast<size_t>(cpk) * bins + bin(x)]++;
        ++cpk;
      }
    }
    out.hist[bin(x)]++;
    out.sum += x;
    out.sum2 += x * x;
    out.min_sum += xmin;
    if (x > 0) ++out.up_count;
    if (first == 1) ++out.hit_up;
    else if (first == -1) ++out.hit_down;
    ++out.paths;
  }
}

/** Exécute [from, to[ sur `threads` cœurs (0 : tous). */
inline McResult mc_run(const McSpec& s, int threads) {
  const int64_t n = s.to - s.from;
  int T = threads > 0 ? threads : static_cast<int>(std::max(1u, std::thread::hardware_concurrency()));
  T = static_cast<int>(std::min<int64_t>(T, std::max<int64_t>(1, n / 256)));
  std::vector<McResult> parts(T);
  std::vector<std::thread> pool;
  for (int k = 0; k < T; ++k) {
    const int64_t a = s.from + n * k / T, b = s.from + n * (k + 1) / T;
    pool.emplace_back([&, a, b, k] { mc_range(s, a, b, parts[k]); });
  }
  for (auto& th : pool) th.join();
  McResult out = std::move(parts[0]);
  for (int k = 1; k < T; ++k) {
    for (size_t i = 0; i < out.hist.size(); ++i) out.hist[i] += parts[k].hist[i];
    for (size_t i = 0; i < out.cp_hist.size(); ++i) out.cp_hist[i] += parts[k].cp_hist[i];
    out.sum += parts[k].sum; out.sum2 += parts[k].sum2; out.min_sum += parts[k].min_sum;
    out.up_count += parts[k].up_count; out.hit_up += parts[k].hit_up; out.hit_down += parts[k].hit_down; out.paths += parts[k].paths;
  }
  return out;
}

}  // namespace bourso

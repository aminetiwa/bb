# Bourso v0.3 : notes techniques

## Tes demandes et leur traitement

| Demande | Où c'est fait |
|---|---|
| Site façon Zone Bourse / ancien TradingView, compréhensible | `web/` : portail à onglets. Thèmes clair et sombre. Tout en français, aide et glossaire |
| Pas de slogan ni de point vert dans l'en-tête | `web/index.html` |
| Une seule IA ~30B, uniquement sur les favoris, dans l'ordre | `src/ai/analysis.js` (file de favoris, règle « rien de nouveau », priorités) |
| **Choix du modèle Ollama dans les réglages** | Page Réglages : télécharger, tester, créer « bourso », choisir le modèle des analyses et de l'agent, hôte, contexte, réflexion. API `/api/ollama/*` |
| Beaucoup d'outils pro et d'informations ; l'IA prend tout en compte | 39 indicateurs, 43 tracés, labo quant, outils. Dossier IA complet (`src/core/quant/dossier.js`) |
| Calcul lourd dosé GPU + CPU + RAM, « précision 100 % » | `src/compute/service.js` : dosage mesuré, contrôle croisé GPU/CPU en f64. Tests de calcul exact |
| GPU **natif** côté Node (Ubuntu) | Dawn / Vulkan (`webgpu`), noyaux WGSL (`src/compute/kernels.js`) |
| Toutes les actions du monde, Europe en avant | 678 actions, 31 places (`src/market/universe.js`, `exchanges.js`) |
| Agent boursier « vrai pro » | `src/ai/agent.js` + 15 outils (`tools.js`), page Agent Pro |
| Lancer l'analyse sur n'importe quelle action | Page Analyse IA, bouton sur chaque fiche, outil de l'agent |
| Mémoire de l'IA | `analysis.memory()` (analyses passées et leur issue, fiabilité), `core/quant/analogs.js` (analogues historiques) |

## Ce qui a été ajouté dans cette dernière passe

- **Régimes de Markov honnêtes** :
  - EM régularisé (MAP : a priori normal–inverse-gamma et Dirichlet « collant ») ;
  - libellés par volatilité relative ;
  - comparaison systématique au modèle à 1 état (BIC) ;
  - persistance exigée (≥ 2 états de ≥ 5 séances) ;
  - choix automatique du nombre d'états.
- **Cycles FFT testés** :
  - bruit rouge AR(1), seuil ponctuel et seuil global (Šidák) ;
  - part du spectre mesurée sur le lobe ;
  - spectre rapporté au bruit.
- **Analogues historiques** :
  - k plus proches voisins sur 8 variables d'état ;
  - fenêtres futures disjointes ;
  - test z corrigé du recouvrement, calibré à environ 5 % de faux signaux sur des marches
    aléatoires.
- **Corrélations entre places alignées par date** : avant, les fériés différents décalaient les
  séries, et la corrélation Europe/États-Unis tombait à 0.
- **Marché simulé plus réaliste** :
  - bêtas cohérents avec la volatilité ;
  - corrélations ≈ 0,45 en Europe, ≈ 0,3 Europe/US ;
  - volatilité réalisée calée sur la volatilité nominale (variance des sauts déduite) ;
  - fondamentaux cohérents entre eux, par secteur.
- **Garde-fous** : stop proportionné à la volatilité, entre 0,5 et 2,5 ATR. Un stop à 0,3 %
  d'une valeur à 3,4 % d'ATR ne passe plus.
- **Interface** :
  - lignes de prix hors de l'échelle affichées en pastilles ;
  - saisonnalité avec colonne annuelle ;
  - notation scientifique à la française ;
  - boutons colorés en thème sombre ;
  - tableaux qui ne débordent plus ;
  - légendes courtes des stratégies, walk-forward daté ;
  - onglet « Analogues historiques ».
- **Boucle IA** : les demandes manuelles sont traitées même si l'analyse automatique des favoris
  est coupée.

## Vérification

- `npm test` : 52 tests.
  - Calcul exact et quant (dont les nouveaux tests HMM, FFT et analogues) ;
  - marché ;
  - IA (garde-fous, JSON, cerveau simulé) ;
  - serveur complet avec faux Ollama : sécurité Host/Origin/JSON, API marché, corrélations
    alignées, labo, modèles Ollama (liste, test, téléchargement, choix dans les réglages),
    analyse IA complète avec mémoire, agent avec appels d'outils.
- `npm run test:native` : noyau C++.
- Rendu Playwright de chaque page et de chaque onglet, en thèmes clair et sombre :
  - Accueil, Marchés, Graphique et ses 9 onglets ;
  - Favoris, Analyse IA, Agent, Actualités, Portefeuille ;
  - Labo et ses 9 onglets ;
  - Outils, Système, Réglages, Aide.
- Dawn a été testé ici avec l'ICD Vulkan SwiftShader de Chromium. Sur ta machine Ubuntu, c'est le
  pilote Vulkan de ta carte qui sera utilisé.

## 0.3.1 — correctif : arrêt brutal juste après le démarrage (GPU NVIDIA)

**Symptôme.** `prêt … → http://127.0.0.1:7777` puis `Failed running 'src/server/main.js'`, sans
aucun message d'erreur. L'absence de message JavaScript signe un plantage de **code natif**.

**Cause.** Avec le paquet `webgpu` (dawn.node), l'instance Dawn n'existe que tant que l'objet
renvoyé par `create()` est référencé. Bourso ne le gardait pas, ce qui donnait la séquence suivante :

- l'étalonnage GPU du démarrage passait (le ramasse-miettes n'avait pas encore tourné) ;
- au premier calcul GPU suivant (le Monte Carlo de la première analyse de favori), Dawn était déjà
  détruit sous le device encore utilisé ;
- le processus tombait alors en SIGSEGV ou en SIGABRT.

Reproduit ici avec Dawn sur le Vulkan logiciel (SwiftShader) et un ramasse-miettes forcé : plantage
à chaque essai sans le correctif, aucun avec.

**Corrections.**

- `gpu.js` : l'instance Dawn est gardée en vie par le moteur, et relâchée dans `destroy()`.
- Le GPU tourne dans **son propre processus** (`gpu-host.js` / `gpu-proxy.js`). Si le pilote plante :
  - le serveur continue ;
  - la part GPU du calcul est refaite sur le CPU ;
  - le GPU est relancé deux fois au plus ;
  - la page Système affiche la cause.
- **Superviseur** `scripts/run.js` (`npm start`, `npm run dev`). Si le serveur plante :
  - il affiche le signal et l'opération native en cours ;
  - il écrit un rapport dans `data/logs/` ;
  - il relance le serveur, sans le module C++ si celui-ci est en cause.
- Erreurs JavaScript imprévues : elles sont journalisées en entier, et le serveur continue.
- Port par défaut : **3000** (`http://localhost:3000`).
- Tests :
  - validation GPU ≡ CPU **avec Dawn dans Node** et ramasse-miettes forcé entre chaque calcul ;
  - plantage simulé du processus GPU, avec repli CPU vérifié.

## 0.3.2 — décisions de l'IA complètes, anti-boucle, erreur « chtimes »

**Décisions incomplètes (« Réponse du modèle inexploitable … scenarios[0].description: requis »).**
Le bug venait de Bourso, pas du modèle. Avant d'envoyer le schéma JSON à Ollama, Bourso retire des
mots-clés d'annotation, dont `description`. Il retirait aussi, par erreur, le **champ**
`scenarios[].description`. La grammaire imposée au modèle lui interdisait donc d'écrire ce champ,
que le contrôle exigeait ensuite. Avec un vrai Ollama, toutes les réponses étaient rejetées
(→ HOLD, confiance 0 %).

Corrections :

- `toOllamaFormat` ne retire plus que des mots-clés, jamais des noms de champs. Un test vérifie que
  chaque champ requis figure dans la grammaire envoyée. Le faux Ollama des tests applique désormais
  la grammaire, comme le vrai.
- **Lecture tolérante** (`src/ai/repair.js`) :
  - clés renommées, pourcentages, nombres « 56,20 € », valeurs en clair ;
  - réponse enveloppée, JSON coupé ;
  - seule la décision est bloquante. Le reste est récupéré, puis les champs manquants sont
    redemandés par un **appel court** qui ne porte que sur eux.
- La page Analyse IA affiche tout ce que le modèle a fourni, plus un bloc « Lecture de la réponse
  du modèle » (corrections, compléments, valeurs par défaut).

**Anti-boucle** (`src/ai/loop-guard.js`) :

- détection au fil de l'eau : passage répété, phrase répétée (chiffres ignorés), paragraphe réécrit,
  retours à la ligne en rafale, réflexion trop longue ;
- chiens de garde : pas de première réponse, silence, durée maximale ;
- analyse : la partie utile est gardée, sinon une relance sans réflexion avec pénalité de
  répétition ;
- agent : appels d'outils identiques non relancés, 16 appels au plus, réponse finale forcée ;
- file : pas de doublon, pause progressive d'une valeur qui échoue, puis de la boucle entière si les
  échecs s'enchaînent (bouton « reprendre »).

**Création de « bourso » : `chtimes … operation not permitted`.**

- Ollama n'a pas le droit de modifier ses propres fichiers : propriétaire différent de l'utilisateur
  du serveur, ou disque qui refuse les dates.
- Bourso lit le propriétaire du fichier et l'utilisateur du processus `ollama serve`, puis affiche
  les commandes exactes (`src/ai/ollama-diag.js`).
- « bourso » devient **facultatif** : modèle choisi automatiquement par défaut, et bouton « utiliser
  le modèle de base directement ».

Tests : 68, dont 14 nouveaux (`test/ai-robust.test.js`) avec des modèles volontairement défaillants
(brouillon, boucle, radotage, muet, droits refusés).

// ============================================================================
//  BOURSO :: chart/timescale.js — temps des bougies.
//
//  Chaque bougie reçoit une « clé de temps » t = n° de jour (UTC) + fraction de séance écoulée :
//  les tracés sont enregistrés en (t, prix) et restent au bon endroit quelle que soit l'unité
//  de temps (1 s … 1 mois). Libellés de l'axe au format français, repères hiérarchisés
//  (année > trimestre > mois > semaine > jour > heure) choisis pour ne jamais se chevaucher.
// ============================================================================
import { localTimeOf, EXCHANGES } from '/src/market/exchanges.js';

export const dayNum = (ymd) => {
  const [y, m, d] = ymd.split('-').map(Number);
  return Date.UTC(y, m - 1, d) / 86_400_000;
};
const MONTHS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
const DAYS = ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'];
const dd = (s) => `${s.slice(8, 10)}/${s.slice(5, 7)}`;

/**
 * @param {object} header en-tête de /api/history
 * @returns {{ t:Float64Array, intraday:boolean, bar:(i)=>{date:string, sec:number}, label:(i)=>string, marks:(i0,i1)=>object[],
 *   sessionStart:(i)=>boolean, stepT:number, ex:object, barSeconds:number, perSession:number }}
 */
export function buildTimescale(header) {
  const n = header.count, ex = EXCHANGES[header.ex.mic], t = new Float64Array(n);
  if (header.intraday) {
    const P = header.perSession, B = header.barSeconds, S = header.ex.sessionSec, days = header.dates.map(dayNum);
    for (let i = 0; i < n; i++) t[i] = days[Math.floor(i / P)] + ((i % P) * B) / S;
    const bar = (i) => ({ date: header.dates[Math.floor(i / P)] ?? header.dates.at(-1), sec: (i % P) * B });
    const label = (i) => {
      const b = bar(i), dt = new Date(`${b.date}T12:00:00Z`);
      return `${DAYS[dt.getUTCDay()]} ${dd(b.date)} ${localTimeOf(ex, b.sec, B < 60)}`;
    };
    /** Repères de l'axe : début de chaque séance (date, en gras) + pas régulier depuis l'ouverture. */
    const pick = (i0, i1, xOf, minPx) => {
      const ppb = Math.max(1e-6, xOf(1) - xOf(0)), out = [];
      const dayEvery = [1, 2, 5, 10, 20, 40].find((k) => k * P * ppb >= minPx) ?? 40;
      const steps = [1, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600, 7200, 10800, 14400];
      const step = steps.find((x) => x >= B && x % B === 0 && (x / B) * ppb >= minPx && x < S);
      const a = Math.max(0, i0), b = Math.min(n - 1, i1);
      for (let s0 = Math.floor(a / P) * P; s0 <= b; s0 += P) {
        const day = Math.floor(s0 / P);
        if (s0 >= a && day % dayEvery === 0) out.push({ i: s0, label: dd(header.dates[day] ?? ''), major: true, level: 9 });
        if (!step || dayEvery > 1) continue;
        const kStep = step / B, end = s0 + P;
        for (let i = s0 + kStep; i < end && i <= b; i += kStep) {
          if (i < a) continue;
          if ((end - i) * ppb < minPx * 0.8) break; // trop près de la séance suivante
          out.push({ i, label: localTimeOf(ex, (i - s0) * B, step < 60), level: 1 });
        }
      }
      return out;
    };
    const marks = (i0, i1) => pick(i0, i1, (i) => i, 0);
    return { t, intraday: true, bar, label, marks, pick, sessionStart: (i) => i % P === 0, stepT: B / S, ex, barSeconds: B, perSession: P, dates: header.dates };
  }
  const dates = header.dates;
  for (let i = 0; i < n; i++) t[i] = dayNum(dates[i]);
  const weekly = header.tf === '1W', monthly = header.tf === '1M';
  const bar = (i) => ({ date: dates[i], sec: 0 });
  const label = (i) => {
    const s = dates[i];
    if (!s) return '';
    if (monthly) return `${MONTHS[Number(s.slice(5, 7)) - 1]} ${s.slice(0, 4)}`;
    const dt = new Date(`${s}T12:00:00Z`);
    return weekly ? `sem. du ${dd(s)}/${s.slice(0, 4)}` : `${DAYS[dt.getUTCDay()]} ${dd(s)}/${s.slice(0, 4)}`;
  };
  const marks = (i0, i1) => {
    const out = [];
    for (let i = Math.max(1, i0); i <= Math.min(n - 1, i1); i++) {
      const a = dates[i - 1], b = dates[i];
      if (a.slice(0, 4) !== b.slice(0, 4)) out.push({ i, level: 9, label: b.slice(0, 4), major: true });
      else if (a.slice(5, 7) !== b.slice(5, 7)) {
        const m = Number(b.slice(5, 7));
        out.push({ i, level: (m - 1) % 3 === 0 ? 8 : 7, label: MONTHS[m - 1] });
      } else if (!monthly && !weekly) {
        const da = new Date(`${a}T12:00:00Z`).getUTCDay(), db = new Date(`${b}T12:00:00Z`).getUTCDay();
        out.push({ i, level: db < da ? 6 : 5, label: dd(b) });
      } else if (weekly) out.push({ i, level: 6, label: dd(b) });
    }
    if (i0 <= 0 && n) out.unshift({ i: 0, level: 9, label: monthly ? dates[0].slice(0, 4) : dd(dates[0]), major: true });
    return out;
  };
  return { t, intraday: false, bar, label, marks, pick: (i0, i1, xOf, minPx) => pickMarks(marks(i0, i1), xOf, minPx), sessionStart: () => false, stepT: monthly ? 30.4 : weekly ? 7 : 1.4, ex, barSeconds: header.barSeconds, perSession: 1, dates };
}

/**
 * Choisit les repères à afficher : le plus petit niveau tel que l'espacement moyen des repères
 * de niveau ≥ L dépasse `minPx` ; les repères trop proches d'un repère de niveau supérieur sont omis.
 */
export function pickMarks(marks, xOf, minPx) {
  if (!marks.length) return [];
  const levels = [...new Set(marks.map((m) => m.level))].sort((a, b) => a - b);
  let chosen = marks.filter((m) => m.level >= levels.at(-1));
  for (const L of levels) {
    // espacement des repères de ce niveau entre eux (les repères de niveau supérieur, plus rares,
    // évinceront ensuite les voisins trop proches)
    const same = marks.filter((m) => m.level === L);
    let ok = true;
    for (let k = 1; k < same.length; k++) if (xOf(same[k].i) - xOf(same[k - 1].i) < minPx) { ok = false; break; }
    if (ok) { chosen = marks.filter((m) => m.level >= L); break; }
  }
  // dernier filtre : élimine les chevauchements résiduels (le repère de plus haut niveau gagne)
  const out = [];
  for (const m of chosen) {
    const x = xOf(m.i);
    while (out.length && x - xOf(out.at(-1).i) < minPx * 0.7) {
      if (out.at(-1).level >= m.level) { m.skip = true; break; }
      out.pop();
    }
    if (!m.skip) out.push(m);
    delete m.skip;
  }
  return out;
}

// ============================================================================
//  BOURSO :: chart/gl.js — rendu GPU (WebGL2) des séries du graphique.
//
//  Un seul programme : des triangles colorés en pixels physiques (position f32 + couleur
//  RGBA 8 bits par sommet = 12 octets). Le moteur construit à chaque image la géométrie des
//  seules bougies visibles (corps, mèches, barres, lignes épaisses, aires en dégradé, bandes,
//  histogrammes, points) et l'envoie en un seul tampon ; un découpage (scissor) par panneau.
//  Les prix sont convertis en pixels en double précision côté CPU : aucune perte float32.
// ============================================================================
const VS = `#version 300 es
layout(location = 0) in vec2 a_pos;
layout(location = 1) in vec4 a_col;
uniform vec2 u_size;
out vec4 v_col;
void main() {
  v_col = a_col;
  gl_Position = vec4(a_pos.x / u_size.x * 2.0 - 1.0, 1.0 - a_pos.y / u_size.y * 2.0, 0.0, 1.0);
}`;
const FS = `#version 300 es
precision mediump float;
in vec4 v_col;
out vec4 o;
void main() { o = vec4(v_col.rgb * v_col.a, v_col.a); }`;

/** Couleur CSS (#rgb, #rrggbb, rgb(), rgba()) → [r, g, b, a] 0…255. */
export function parseColor(c, alpha = null) {
  let r = 0, g = 0, b = 0, a = 255;
  const s = String(c ?? '').trim();
  if (s.startsWith('#')) {
    const h = s.slice(1), x = h.length === 3 ? h.split('').map((d) => d + d).join('') : h;
    r = parseInt(x.slice(0, 2), 16); g = parseInt(x.slice(2, 4), 16); b = parseInt(x.slice(4, 6), 16);
    if (x.length === 8) a = parseInt(x.slice(6, 8), 16);
  } else {
    const m = s.match(/rgba?\(([^)]+)\)/);
    if (m) {
      const p = m[1].split(/[,\s/]+/).filter(Boolean).map(Number);
      [r, g, b] = p;
      if (p.length > 3) a = Math.round(p[3] * 255);
    }
  }
  if (alpha !== null) a = Math.round(alpha * 255);
  return [r, g, b, a];
}

export class GlBatch {
  constructor(canvas) {
    const gl = canvas.getContext('webgl2', { antialias: true, alpha: false, depth: false, stencil: false, premultipliedAlpha: true, preserveDrawingBuffer: false, powerPreference: 'high-performance' });
    if (!gl) throw new Error('WebGL2 indisponible (pilote graphique ?)');
    this.gl = gl;
    const sh = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
      return s;
    };
    const p = gl.createProgram();
    gl.attachShader(p, sh(gl.VERTEX_SHADER, VS));
    gl.attachShader(p, sh(gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    this.prog = p;
    this.uSize = gl.getUniformLocation(p, 'u_size');
    this.vao = gl.createVertexArray();
    this.buf = gl.createBuffer();
    gl.bindVertexArray(this.vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buf);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 12, 0);
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(1, 4, gl.UNSIGNED_BYTE, true, 12, 8);
    gl.bindVertexArray(null);
    this.#alloc(1 << 16);
    this.n = 0;
    this.cmds = [];
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    this.renderer = dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
  }

  #alloc(cap) {
    const old = this.ab;
    this.cap = cap;
    this.ab = new ArrayBuffer(cap * 12);
    this.f = new Float32Array(this.ab);
    this.u = new Uint8Array(this.ab);
    if (old) this.u.set(new Uint8Array(old, 0, this.n * 12));
    this.gpuCap = 0;
  }

  /** Début d'image. */
  begin(W, H, bg) {
    this.W = W;
    this.H = H;
    this.bg = bg;
    this.n = 0;
    this.cmds = [];
    this.clip = null;
  }

  /** Zone de découpage (pixels physiques, origine en haut à gauche) des primitives suivantes. */
  scissor(x, y, w, h) {
    this.#close();
    this.clip = [x, y, w, h];
    this.cmds.push({ clip: this.clip, from: this.n, to: this.n });
  }

  #close() {
    const c = this.cmds.at(-1);
    if (c) c.to = this.n;
  }

  #v(x, y, c) {
    if (this.n >= this.cap) this.#alloc(this.cap * 2);
    const k = this.n++;
    this.f[k * 3] = x;
    this.f[k * 3 + 1] = y;
    const o = k * 12 + 8;
    this.u[o] = c[0]; this.u[o + 1] = c[1]; this.u[o + 2] = c[2]; this.u[o + 3] = c[3];
  }

  tri(x0, y0, x1, y1, x2, y2, c0, c1 = c0, c2 = c0) {
    this.#v(x0, y0, c0); this.#v(x1, y1, c1); this.#v(x2, y2, c2);
  }

  rect(x0, y0, x1, y1, c) {
    if (x1 < x0) [x0, x1] = [x1, x0];
    if (y1 < y0) [y0, y1] = [y1, y0];
    this.tri(x0, y0, x1, y0, x0, y1, c);
    this.tri(x1, y0, x1, y1, x0, y1, c);
  }

  /** Rectangle en dégradé vertical (couleur haut → couleur bas). */
  vgrad(x0, y0, x1, y1, ct, cb) {
    this.tri(x0, y0, x1, y0, x0, y1, ct, ct, cb);
    this.tri(x1, y0, x1, y1, x0, y1, ct, cb, cb);
  }

  /** Segment épais (largeur w en pixels physiques). */
  seg(x0, y0, x1, y1, w, c) {
    const dx = x1 - x0, dy = y1 - y0, L = Math.hypot(dx, dy);
    if (!(L > 0)) return;
    const nx = (-dy / L) * w * 0.5, ny = (dx / L) * w * 0.5;
    this.tri(x0 + nx, y0 + ny, x1 + nx, y1 + ny, x0 - nx, y0 - ny, c);
    this.tri(x1 + nx, y1 + ny, x1 - nx, y1 - ny, x0 - nx, y0 - ny, c);
  }

  /** Ligne brisée épaisse ; NaN = coupure. Jointures comblées par un petit carré. */
  polyline(xs, ys, n, w, c, dashed = false) {
    let px = NaN, py = NaN, k = 0;
    for (let i = 0; i < n; i++) {
      const x = xs[i], y = ys[i];
      if (!Number.isFinite(y) || !Number.isFinite(x)) { px = NaN; continue; }
      if (Number.isFinite(px)) {
        if (!dashed || (k++ & 1) === 0) this.seg(px, py, x, y, w, c);
        if (w > 1.5 && !dashed) this.rect(x - w * 0.42, y - w * 0.42, x + w * 0.42, y + w * 0.42, c);
      }
      px = x; py = y;
    }
  }

  /** Aire entre deux courbes (ou une courbe et une ligne de base) : couleurs par sommet. */
  band(xs, yTop, yBot, n, cTop, cBot = cTop) {
    for (let i = 1; i < n; i++) {
      const x0 = xs[i - 1], x1 = xs[i], a0 = yTop[i - 1], a1 = yTop[i];
      const b0 = typeof yBot === 'number' ? yBot : yBot[i - 1], b1 = typeof yBot === 'number' ? yBot : yBot[i];
      if (![a0, a1, b0, b1].every(Number.isFinite)) continue;
      this.tri(x0, a0, x1, a1, x0, b0, cTop, cTop, cBot);
      this.tri(x1, a1, x1, b1, x0, b0, cTop, cBot, cBot);
    }
  }

  /** Envoi au GPU et dessin. */
  flush() {
    const gl = this.gl;
    this.#close();
    gl.viewport(0, 0, this.W, this.H);
    gl.disable(gl.SCISSOR_TEST);
    const bg = this.bg;
    gl.clearColor(bg[0] / 255, bg[1] / 255, bg[2] / 255, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);
    if (!this.n) return;
    gl.useProgram(this.prog);
    gl.uniform2f(this.uSize, this.W, this.H);
    gl.bindVertexArray(this.vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buf);
    if (this.gpuCap < this.n) {
      this.gpuCap = this.cap;
      gl.bufferData(gl.ARRAY_BUFFER, this.cap * 12, gl.DYNAMIC_DRAW);
    }
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.u, 0, this.n * 12);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    gl.enable(gl.SCISSOR_TEST);
    for (const c of this.cmds) {
      if (c.to <= c.from) continue;
      const [x, y, w, h] = c.clip;
      gl.scissor(Math.floor(x), Math.floor(this.H - y - h), Math.ceil(w), Math.ceil(h));
      gl.drawArrays(gl.TRIANGLES, c.from, c.to - c.from);
    }
    gl.disable(gl.SCISSOR_TEST);
    gl.bindVertexArray(null);
  }
}

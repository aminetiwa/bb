// ============================================================================
//  BOURSO :: chart/indicators.js — catalogue des indicateurs du graphique.
//  Les calculs viennent du MÊME code que le serveur (/src/core/quant/indicators.js, exécuté
//  dans le navigateur) : valeurs identiques au dossier de l'IA, au screener et aux backtests.
//
//  Chaque définition : nom, groupe, explication, paramètres, emplacement (sur les cours ou
//  dans un panneau), compute(d, p) → sorties { key, label, values, type, color, … }.
//  Types de sortie : line, hist (histogramme), dots (points), band (aire entre deux sorties),
//  cloud (aire bicolore), step (paliers). `offset` décale une série (nuage d'Ichimoku futur).
// ============================================================================
import * as I from '/src/core/quant/indicators.js';
import { rollingVol } from '/src/core/quant/volatility.js';

const C = { orange: '#f28c18', blue: '#1f6fd1', violet: '#7b4fc9', teal: '#0f8f8f', red: '#d64541', green: '#1e9e55', grey: '#8a95a3', pink: '#c2185b', brown: '#8d6e63', navy: '#1a3d66', gold: '#c49000' };
const P = (k, label, def, min, max, step = 1) => ({ k, label, def, min, max, step });
const nan = (n) => new Float64Array(n).fill(NaN);
const shiftCopy = (a) => Float64Array.from(a);

/** Sessions (intraday) : départ de chaque séance pour VWAP et pivots. */
const sessionStart = (d) => (i) => (d.perSession > 1 ? i % d.perSession === 0 : i === 0);

export const INDICATORS = {
  // ------------------------------------------------------------- moyennes mobiles (sur les cours)
  sma: { name: 'Moyenne mobile simple', short: 'MM', group: 'Moyennes mobiles', overlay: true, params: [P('n', 'Période', 50, 1, 1000)], colors: [C.orange],
    help: 'Moyenne des n dernières clôtures. Cours au-dessus : tendance haussière ; croisements = signaux classiques (MM 50 / MM 200).',
    compute: (d, p) => [{ key: 'v', label: `MM ${p.n}`, values: I.sma(d.c, p.n) }] },
  ema: { name: 'Moyenne mobile exponentielle', short: 'MME', group: 'Moyennes mobiles', overlay: true, params: [P('n', 'Période', 20, 1, 1000)], colors: [C.blue],
    help: 'Moyenne pondérée qui réagit plus vite que la simple (poids décroissant exponentiellement).',
    compute: (d, p) => [{ key: 'v', label: `MME ${p.n}`, values: I.ema(d.c, p.n) }] },
  wma: { name: 'Moyenne mobile pondérée', short: 'MMP', group: 'Moyennes mobiles', overlay: true, params: [P('n', 'Période', 20, 1, 1000)], colors: [C.violet],
    help: 'Poids linéairement croissants : la dernière clôture compte n fois plus que la plus ancienne.',
    compute: (d, p) => [{ key: 'v', label: `MMP ${p.n}`, values: I.wma(d.c, p.n) }] },
  hma: { name: 'Moyenne mobile de Hull', short: 'Hull', group: 'Moyennes mobiles', overlay: true, params: [P('n', 'Période', 21, 2, 500)], colors: [C.teal],
    help: 'Moyenne très réactive et lissée (combinaison de moyennes pondérées).',
    compute: (d, p) => [{ key: 'v', label: `Hull ${p.n}`, values: I.hma(d.c, p.n) }] },
  kama: { name: 'Moyenne adaptative de Kaufman', short: 'KAMA', group: 'Moyennes mobiles', overlay: true, params: [P('n', 'Période', 10, 2, 200), P('fast', 'Rapide', 2, 1, 50), P('slow', 'Lente', 30, 2, 200)], colors: [C.pink],
    help: 'S\'accélère quand le marché est directionnel, ralentit dans le bruit (ratio d\'efficacité).',
    compute: (d, p) => [{ key: 'v', label: `KAMA ${p.n}`, values: I.kama(d.c, p.n, p.fast, p.slow) }] },
  vwma: { name: 'Moyenne pondérée par les volumes', short: 'MMV', group: 'Moyennes mobiles', overlay: true, params: [P('n', 'Période', 20, 1, 500)], colors: [C.brown],
    help: 'Chaque clôture pèse selon son volume : les séances actives comptent davantage.',
    compute: (d, p) => [{ key: 'v', label: `MMV ${p.n}`, values: I.vwma(d.c, d.v, p.n) }] },
  env: { name: 'Enveloppes', short: 'Env.', group: 'Bandes et canaux', overlay: true, params: [P('n', 'Période', 20, 1, 500), P('pct', 'Écart %', 2.5, 0.1, 30, 0.1)], colors: [C.grey, C.grey, C.grey],
    help: 'Moyenne mobile ± un pourcentage fixe : zones d\'excès en marché sans tendance.',
    compute: (d, p) => {
      const m = I.sma(d.c, p.n), up = m.map((x) => x * (1 + p.pct / 100)), lo = m.map((x) => x * (1 - p.pct / 100));
      return [{ key: 'up', label: 'haut', values: up }, { key: 'mid', label: `MM ${p.n}`, values: m, dash: true }, { key: 'lo', label: 'bas', values: lo }, { key: 'f', type: 'band', upper: 'up', lower: 'lo', alpha: 0.05 }];
    } },
  // ------------------------------------------------------------- bandes, canaux
  bb: { name: 'Bandes de Bollinger', short: 'BB', group: 'Bandes et canaux', overlay: true, params: [P('n', 'Période', 20, 2, 500), P('k', 'Écarts-types', 2, 0.5, 5, 0.1)], colors: [C.blue, C.orange, C.blue],
    help: 'Moyenne ± k écarts-types. Bandes resserrées = compression (souvent avant un mouvement) ; sortie de bande = excès ou départ de tendance.',
    compute: (d, p) => {
      const b = I.bollinger(d.c, p.n, p.k);
      return [{ key: 'up', label: 'haute', values: b.up }, { key: 'mid', label: 'milieu', values: b.mid }, { key: 'lo', label: 'basse', values: b.lo }, { key: 'f', type: 'band', upper: 'up', lower: 'lo', alpha: 0.07 }];
    } },
  kc: { name: 'Canal de Keltner', short: 'Keltner', group: 'Bandes et canaux', overlay: true, params: [P('n', 'Période', 20, 2, 500), P('mult', 'Multiple ATR', 2, 0.5, 6, 0.1), P('atrN', 'ATR', 10, 2, 200)], colors: [C.teal, C.teal, C.teal],
    help: 'Moyenne exponentielle ± multiple de l\'ATR. Bollinger à l\'intérieur de Keltner = « squeeze » (compression extrême).',
    compute: (d, p) => {
      const k = I.keltner(d.h, d.l, d.c, p.n, p.mult, p.atrN);
      return [{ key: 'up', label: 'haut', values: k.up }, { key: 'mid', label: 'milieu', values: k.mid, dash: true }, { key: 'lo', label: 'bas', values: k.lo }, { key: 'f', type: 'band', upper: 'up', lower: 'lo', alpha: 0.05 }];
    } },
  dc: { name: 'Canal de Donchian', short: 'Donchian', group: 'Bandes et canaux', overlay: true, params: [P('n', 'Période', 20, 2, 500)], colors: [C.violet, C.grey, C.violet],
    help: 'Plus haut et plus bas des n dernières bougies : la cassure du canal est le signal des « tortues ».',
    compute: (d, p) => {
      const x = I.donchian(d.h, d.l, p.n);
      return [{ key: 'up', label: 'plus haut', values: x.up }, { key: 'mid', label: 'milieu', values: x.mid, dash: true }, { key: 'lo', label: 'plus bas', values: x.lo }, { key: 'f', type: 'band', upper: 'up', lower: 'lo', alpha: 0.04 }];
    } },
  ichi: { name: 'Ichimoku Kinko Hyo', short: 'Ichimoku', group: 'Tendance', overlay: true, params: [P('t', 'Tenkan', 9, 1, 100), P('k', 'Kijun', 26, 1, 200), P('b', 'Senkou B', 52, 1, 300)], colors: [C.blue, C.red, C.green, C.red, C.violet],
    help: 'Tenkan/Kijun (équilibres court/moyen terme), nuage projeté 26 périodes en avant (support/résistance futurs), Chikou (clôture décalée de 26 en arrière).',
    compute: (d, p) => {
      const x = I.ichimoku(d.h, d.l, d.c, p.t, p.k, p.b, p.k);
      return [{ key: 'tenkan', label: 'Tenkan', values: x.tenkan }, { key: 'kijun', label: 'Kijun', values: x.kijun },
        { key: 'a', label: 'Senkou A', values: x.spanAraw, offset: p.k, width: 1 }, { key: 'b', label: 'Senkou B', values: x.spanBraw, offset: p.k, width: 1 },
        { key: 'chikou', label: 'Chikou', values: shiftCopy(d.c), offset: -p.k, width: 1 }, { key: 'cloud', type: 'cloud', upper: 'a', lower: 'b', alpha: 0.13 }];
    } },
  st: { name: 'SuperTrend', short: 'SuperTrend', group: 'Tendance', overlay: true, params: [P('n', 'ATR', 10, 2, 200), P('f', 'Facteur', 3, 0.5, 10, 0.1)], colors: [C.green, C.red],
    help: 'Stop suiveur basé sur l\'ATR : sous les cours en tendance haussière (vert), au-dessus en baissière (rouge).',
    compute: (d, p) => {
      const x = I.supertrend(d.h, d.l, d.c, p.n, p.f), n = d.c.length, up = nan(n), dn = nan(n);
      for (let i = 0; i < n; i++) {
        if (x.dir[i] > 0) { up[i] = x.line[i]; if (i && x.dir[i - 1] < 0) up[i - 1] = x.line[i - 1]; }
        else if (x.dir[i] < 0) { dn[i] = x.line[i]; if (i && x.dir[i - 1] > 0) dn[i - 1] = x.line[i - 1]; }
      }
      return [{ key: 'up', label: 'haussier', values: up, width: 2 }, { key: 'dn', label: 'baissier', values: dn, width: 2 }];
    } },
  psar: { name: 'SAR parabolique', short: 'SAR', group: 'Tendance', overlay: true, params: [P('step', 'Pas', 0.02, 0.001, 0.2, 0.001), P('max', 'Maximum', 0.2, 0.01, 1, 0.01)], colors: [C.violet],
    help: 'Points de stop qui se resserrent avec la tendance ; un retournement des points signale un changement de tendance.',
    compute: (d, p) => [{ key: 'v', label: 'SAR', values: I.psar(d.h, d.l, p.step, p.max).sar, type: 'dots' }] },
  vwap: { name: 'VWAP de séance (± écarts-types)', short: 'VWAP', group: 'Volumes', overlay: true, intradayOnly: true, params: [P('bands', 'Bandes (0-2)', 2, 0, 2)], colors: [C.gold, C.gold, C.gold, C.gold, C.gold],
    help: 'Prix moyen pondéré par les volumes depuis l\'ouverture : référence des professionnels. Bandes à ±1 et ±2 écarts-types (pondérés).',
    compute: (d, p) => {
      const x = I.vwap(d.h, d.l, d.c, d.v, sessionStart(d));
      const out = [{ key: 'mid', label: 'VWAP', values: x.mid, width: 2, sessionBreak: true }];
      if (p.bands >= 1) out.push({ key: 'u1', label: '+1σ', values: x.up1, dash: true, width: 1, sessionBreak: true }, { key: 'l1', label: '−1σ', values: x.lo1, dash: true, width: 1, sessionBreak: true });
      if (p.bands >= 2) out.push({ key: 'u2', label: '+2σ', values: x.up2, width: 1, sessionBreak: true }, { key: 'l2', label: '−2σ', values: x.lo2, width: 1, sessionBreak: true });
      return out;
    } },
  pivots: { name: 'Points pivots de séance', short: 'Pivots', group: 'Niveaux', overlay: true, intradayOnly: true, params: [P('kind', 'Type (0 classique, 1 Fibonacci, 2 Camarilla, 3 Woodie)', 0, 0, 3)], colors: [C.navy, C.red, C.red, C.red, C.green, C.green, C.green],
    help: 'Niveaux calculés sur le plus haut, le plus bas et la clôture de la séance précédente : P, résistances R1-R3, supports S1-S3.',
    compute: (d, p) => {
      const n = d.c.length, S = d.perSession, kinds = ['classic', 'fibonacci', 'camarilla', 'woodie'], keys = ['P', 'R1', 'R2', 'R3', 'S1', 'S2', 'S3'];
      const out = Object.fromEntries(keys.map((k) => [k, nan(n)]));
      for (let s = S; s < n; s += S) {
        let H = -Infinity, L = Infinity;
        for (let i = s - S; i < s; i++) { if (d.h[i] > H) H = d.h[i]; if (d.l[i] < L) L = d.l[i]; }
        const pv = I.pivots(H, L, d.c[s - 1])[kinds[p.kind] ?? 'classic'];
        for (const k of keys) if (pv[k] !== undefined) for (let i = s; i < Math.min(n, s + S); i++) out[k][i] = pv[k];
      }
      return keys.map((k) => ({ key: k, label: k, values: out[k], width: k === 'P' ? 1.5 : 1, dash: k !== 'P', step: true }));
    } },
  zz: { name: 'ZigZag', short: 'ZigZag', group: 'Niveaux', overlay: true, params: [P('pct', 'Seuil %', 3, 0.2, 30, 0.1)], colors: [C.orange],
    help: 'Relie les sommets et creux significatifs (variation ≥ seuil) : structure de marché, vagues, figures.',
    compute: (d, p) => {
      const z = I.zigzag(d.h, d.l, { pct: p.pct / 100 }), n = d.c.length, v = nan(n);
      const pts = [...z.swings, ...(z.provisional ? [z.provisional] : [])];
      for (let k = 1; k < pts.length; k++) {
        const a = pts[k - 1], b = pts[k];
        for (let i = a.i; i <= b.i; i++) v[i] = a.price + ((b.price - a.price) * (i - a.i)) / Math.max(1, b.i - a.i);
      }
      return [{ key: 'v', label: 'ZigZag', values: v, width: 1.5 }];
    } },
  lr: { name: 'Canal de régression linéaire', short: 'Régression', group: 'Bandes et canaux', overlay: true, params: [P('n', 'Période', 100, 10, 2000), P('k', 'Écarts-types', 2, 0.5, 4, 0.1)], colors: [C.blue, C.blue, C.blue],
    help: 'Droite des moindres carrés sur les n dernières bougies ± k écarts-types des résidus : tendance et excès.',
    compute: (d, p) => {
      const n = d.c.length, m = Math.min(p.n, n), mid = nan(n), up = nan(n), lo = nan(n);
      if (m < 3) return [];
      let sx = 0, sy = 0, sxx = 0, sxy = 0;
      for (let j = 0; j < m; j++) { const y = d.c[n - m + j]; sx += j; sy += y; sxx += j * j; sxy += j * y; }
      const b = (m * sxy - sx * sy) / (m * sxx - sx * sx), a = (sy - b * sx) / m;
      let ss = 0;
      for (let j = 0; j < m; j++) ss += (d.c[n - m + j] - (a + b * j)) ** 2;
      const sd = Math.sqrt(ss / Math.max(1, m - 2));
      for (let j = 0; j < m; j++) { const y = a + b * j; mid[n - m + j] = y; up[n - m + j] = y + p.k * sd; lo[n - m + j] = y - p.k * sd; }
      return [{ key: 'up', label: 'haut', values: up, width: 1 }, { key: 'mid', label: 'régression', values: mid, dash: true }, { key: 'lo', label: 'bas', values: lo, width: 1 }, { key: 'f', type: 'band', upper: 'up', lower: 'lo', alpha: 0.05 }];
    } },
  // ------------------------------------------------------------- panneaux : oscillateurs
  rsi: { name: 'RSI (force relative)', short: 'RSI', group: 'Oscillateurs', params: [P('n', 'Période', 14, 2, 200)], colors: [C.violet], range: [0, 100], levels: [30, 50, 70], zones: [[70, 100, 'down'], [0, 30, 'up']],
    help: 'Rapport des hausses aux baisses lissées (Wilder) : > 70 surachat, < 30 survente ; divergences avec les cours = essoufflement.',
    compute: (d, p) => [{ key: 'v', label: `RSI ${p.n}`, values: I.rsi(d.c, p.n) }] },
  macd: { name: 'MACD', short: 'MACD', group: 'Oscillateurs', params: [P('f', 'Rapide', 12, 1, 200), P('s', 'Lente', 26, 2, 400), P('sig', 'Signal', 9, 1, 100)], colors: [C.blue, C.orange], levels: [0],
    help: 'Écart entre deux moyennes exponentielles et sa ligne de signal ; l\'histogramme mesure l\'accélération.',
    compute: (d, p) => {
      const m = I.macd(d.c, p.f, p.s, p.sig);
      return [{ key: 'h', label: 'histogramme', values: m.hist, type: 'hist', fourColor: true }, { key: 'line', label: 'MACD', values: m.line }, { key: 'sig', label: 'signal', values: m.signal }];
    } },
  stoch: { name: 'Stochastique', short: 'Stoch.', group: 'Oscillateurs', params: [P('n', '%K', 14, 1, 200), P('k', 'Lissage %K', 3, 1, 50), P('dd', '%D', 3, 1, 50)], colors: [C.blue, C.orange], range: [0, 100], levels: [20, 80], zones: [[80, 100, 'down'], [0, 20, 'up']],
    help: 'Position de la clôture dans la fourchette des n dernières bougies : > 80 haut de fourchette, < 20 bas.',
    compute: (d, p) => { const s = I.stoch(d.h, d.l, d.c, p.n, p.k, p.dd); return [{ key: 'k', label: '%K', values: s.k }, { key: 'd', label: '%D', values: s.d }]; } },
  stochrsi: { name: 'RSI stochastique', short: 'StochRSI', group: 'Oscillateurs', params: [P('r', 'RSI', 14, 2, 200), P('n', 'Stoch.', 14, 2, 200), P('k', 'K', 3, 1, 50), P('dd', 'D', 3, 1, 50)], colors: [C.blue, C.orange], range: [0, 100], levels: [20, 80],
    help: 'Stochastique appliqué au RSI : très réactif, repère les retournements de court terme.',
    compute: (d, p) => { const s = I.stochRsi(d.c, p.r, p.n, p.k, p.dd); return [{ key: 'k', label: 'K', values: s.k }, { key: 'd', label: 'D', values: s.d }]; } },
  cci: { name: 'CCI (Commodity Channel Index)', short: 'CCI', group: 'Oscillateurs', params: [P('n', 'Période', 20, 2, 200)], colors: [C.teal], levels: [-100, 0, 100],
    help: 'Écart du prix typique à sa moyenne, normalisé : au-delà de ±100 = mouvement inhabituel.',
    compute: (d, p) => [{ key: 'v', label: `CCI ${p.n}`, values: I.cci(d.h, d.l, d.c, p.n) }] },
  wr: { name: 'Williams %R', short: '%R', group: 'Oscillateurs', params: [P('n', 'Période', 14, 2, 200)], colors: [C.pink], range: [-100, 0], levels: [-80, -20],
    help: 'Proche du stochastique (échelle 0 à −100) : > −20 surachat, < −80 survente.',
    compute: (d, p) => [{ key: 'v', label: `%R ${p.n}`, values: I.williamsR(d.h, d.l, d.c, p.n) }] },
  roc: { name: 'Taux de variation (ROC)', short: 'ROC', group: 'Oscillateurs', params: [P('n', 'Période', 12, 1, 500)], colors: [C.navy], levels: [0],
    help: 'Variation en % sur n bougies : vitesse du mouvement.',
    compute: (d, p) => [{ key: 'v', label: `ROC ${p.n}`, values: I.roc(d.c, p.n) }] },
  mom: { name: 'Momentum', short: 'Mom.', group: 'Oscillateurs', params: [P('n', 'Période', 10, 1, 500)], colors: [C.brown], levels: [0],
    help: 'Différence entre la clôture et celle d\'il y a n bougies.',
    compute: (d, p) => [{ key: 'v', label: `Momentum ${p.n}`, values: I.momentum(d.c, p.n) }] },
  ao: { name: 'Awesome Oscillator', short: 'AO', group: 'Oscillateurs', params: [], colors: [C.green], levels: [0],
    help: 'Moyenne 5 − moyenne 34 du milieu des bougies ; barres vertes si l\'oscillateur monte, rouges s\'il baisse.',
    compute: (d) => [{ key: 'v', label: 'AO', values: I.awesome(d.h, d.l), type: 'hist', risingColor: true }] },
  uo: { name: 'Ultimate Oscillator', short: 'UO', group: 'Oscillateurs', params: [P('a', 'Court', 7, 1, 100), P('b', 'Moyen', 14, 2, 200), P('c', 'Long', 28, 3, 400)], colors: [C.violet], range: [0, 100], levels: [30, 70],
    help: 'Pression acheteuse sur trois horizons combinés (Williams) : moins de faux signaux.',
    compute: (d, p) => [{ key: 'v', label: 'UO', values: I.ultimate(d.h, d.l, d.c, p.a, p.b, p.c) }] },
  bbp: { name: 'Puissance acheteurs / vendeurs', short: 'Bull/Bear', group: 'Oscillateurs', params: [P('n', 'Période', 13, 2, 200)], colors: [C.green], levels: [0],
    help: 'Plus haut − MME (force des acheteurs) + plus bas − MME (force des vendeurs) — Elder.',
    compute: (d, p) => [{ key: 'v', label: 'Bull/Bear', values: I.bullBearPower(d.h, d.l, d.c, p.n), type: 'hist', signColor: true }] },
  zs: { name: 'Z-score', short: 'Z', group: 'Statistiques', params: [P('n', 'Période', 20, 3, 500)], colors: [C.navy], levels: [-2, 0, 2],
    help: 'Écart de la clôture à sa moyenne en écarts-types : au-delà de ±2 = excès statistique.',
    compute: (d, p) => [{ key: 'v', label: `Z ${p.n}`, values: I.zscore(d.c, p.n) }] },
  // ------------------------------------------------------------- tendance (panneaux)
  adx: { name: 'ADX / DMI (force de tendance)', short: 'ADX', group: 'Tendance', params: [P('n', 'Période', 14, 2, 200)], colors: [C.navy, C.green, C.red], range: [0, 100], levels: [20, 25, 40],
    help: 'ADX > 25 = tendance établie (quel que soit son sens) ; DI+ au-dessus de DI− = pression haussière.',
    compute: (d, p) => { const x = I.adx(d.h, d.l, d.c, p.n); return [{ key: 'adx', label: 'ADX', values: x.adx, width: 2 }, { key: 'p', label: 'DI+', values: x.pdi, width: 1 }, { key: 'm', label: 'DI−', values: x.mdi, width: 1 }]; } },
  aroon: { name: 'Aroon', short: 'Aroon', group: 'Tendance', params: [P('n', 'Période', 25, 2, 300)], colors: [C.green, C.red], range: [0, 100], levels: [30, 70],
    help: 'Temps écoulé depuis le plus haut / plus bas des n dernières bougies : quelle force domine.',
    compute: (d, p) => { const x = I.aroon(d.h, d.l, p.n); return [{ key: 'u', label: 'haussier', values: x.up }, { key: 'd', label: 'baissier', values: x.down }]; } },
  // ------------------------------------------------------------- volatilité
  atr: { name: 'ATR (amplitude moyenne)', short: 'ATR', group: 'Volatilité', params: [P('n', 'Période', 14, 1, 300)], colors: [C.red],
    help: 'Amplitude réelle moyenne (Wilder) : sert à placer les stops et dimensionner les positions.',
    compute: (d, p) => [{ key: 'v', label: `ATR ${p.n}`, values: I.atr(d.h, d.l, d.c, p.n) }] },
  hv: { name: 'Volatilité historique (annualisée %)', short: 'Vol.', group: 'Volatilité', params: [P('n', 'Période', 20, 2, 500)], colors: [C.orange],
    help: 'Écart-type des rendements logarithmiques, annualisé (252 séances ou équivalent intraday).',
    compute: (d, p) => [{ key: 'v', label: `Vol ${p.n}`, values: rollingVol(d.c, p.n, d.periodsPerYear ?? 252).map((x) => x * 100) }] },
  bbw: { name: 'Largeur et %B de Bollinger', short: 'BB %B', group: 'Volatilité', params: [P('n', 'Période', 20, 2, 500), P('k', 'Écarts-types', 2, 0.5, 5, 0.1)], colors: [C.blue, C.orange], levels: [0, 1],
    help: '%B : position du cours dans les bandes (0 = bande basse, 1 = haute) ; largeur : compression / expansion.',
    compute: (d, p) => { const b = I.bollinger(d.c, p.n, p.k); return [{ key: 'pb', label: '%B', values: b.pctB }, { key: 'w', label: 'largeur', values: b.width }]; } },
  // ------------------------------------------------------------- volumes
  obv: { name: 'On Balance Volume', short: 'OBV', group: 'Volumes', params: [], colors: [C.teal],
    help: 'Volume cumulé (ajouté les jours de hausse, retranché les jours de baisse) : confirme ou contredit la tendance.',
    compute: (d) => [{ key: 'v', label: 'OBV', values: I.obv(d.c, d.v) }] },
  ad: { name: 'Accumulation / distribution', short: 'A/D', group: 'Volumes', params: [], colors: [C.brown],
    help: 'Volume pondéré par la position de la clôture dans la bougie : accumulation (haut) ou distribution (bas).',
    compute: (d) => [{ key: 'v', label: 'A/D', values: I.adLine(d.h, d.l, d.c, d.v) }] },
  cmf: { name: 'Chaikin Money Flow', short: 'CMF', group: 'Volumes', params: [P('n', 'Période', 20, 2, 300)], colors: [C.green], levels: [0],
    help: 'Flux monétaire sur n bougies : > 0 pression acheteuse, < 0 pression vendeuse.',
    compute: (d, p) => [{ key: 'v', label: `CMF ${p.n}`, values: I.cmf(d.h, d.l, d.c, d.v, p.n), type: 'hist', signColor: true }] },
  mfi: { name: 'Money Flow Index', short: 'MFI', group: 'Volumes', params: [P('n', 'Période', 14, 2, 200)], colors: [C.violet], range: [0, 100], levels: [20, 80],
    help: '« RSI des volumes » : > 80 surachat, < 20 survente.',
    compute: (d, p) => [{ key: 'v', label: `MFI ${p.n}`, values: I.mfi(d.h, d.l, d.c, d.v, p.n) }] },
  fi: { name: 'Force Index', short: 'Force', group: 'Volumes', params: [P('n', 'Lissage', 13, 1, 200)], colors: [C.navy], levels: [0],
    help: 'Variation × volume, lissée (Elder) : intensité des acheteurs / vendeurs.',
    compute: (d, p) => [{ key: 'v', label: `Force ${p.n}`, values: I.forceIndex(d.c, d.v, p.n) }] },
};

export const GROUPS = ['Moyennes mobiles', 'Bandes et canaux', 'Tendance', 'Niveaux', 'Oscillateurs', 'Volatilité', 'Volumes', 'Statistiques'];

/** Instance d'indicateur avec ses paramètres par défaut. */
export function makeIndicator(type, params = {}) {
  const def = INDICATORS[type];
  if (!def) return null;
  return {
    id: `${type}-${Math.random().toString(36).slice(2, 8)}`, type,
    params: Object.fromEntries(def.params.map((p) => [p.k, params[p.k] ?? p.def])),
    colors: [...(params.colors ?? def.colors)], visible: true, height: def.overlay ? 0 : 0.18,
  };
}

/** Libellé court d'une instance (« MME 20 », « Bollinger 20 2 »…). */
export function labelOf(ind) {
  const def = INDICATORS[ind.type];
  const ps = def.params.map((p) => ind.params[p.k]).join(' ');
  return `${def.short}${ps ? ` ${ps}` : ''}`;
}

// ============================================================================
//  BOURSO :: chart/drawings.js — outils de tracé du graphique pro.
//
//  Points d'ancrage enregistrés en (clé de temps, prix) : les tracés restent accrochés au
//  marché à toutes les unités de temps et sont sauvegardés par valeur sur le serveur.
//  Aimant (faible : ≤ 14 px, fort : toujours) vers l'ouverture / le plus haut / le plus bas /
//  la clôture de la bougie. Sélection, poignées, déplacement, suppression (Suppr), annulation
//  (Ctrl+Z), verrouillage, masquage, propriétés (couleur, épaisseur, style, prolongements,
//  niveaux de Fibonacci modifiables, texte).
//
//  Familles : lignes et canaux, mesures, formes, positions longue/courte, Fibonacci
//  (retracement, extension, éventail, arcs, spirale, zones de temps, canal), Gann (éventail,
//  boîte, carré), fourchettes (Andrews, Schiff, Schiff modifiée), figures (XABCD avec
//  reconnaissance Gartley/Bat/Butterfly/Crab/Shark, ABCD, tête-épaules, triangle),
//  Elliott (impulsion 1-5 avec contrôle des règles, correction ABC, triangle ABCDE, WXY), texte.
// ============================================================================
import { HARMONICS } from '/src/core/quant/patterns.js';

const PHI = (1 + Math.sqrt(5)) / 2;
export const FIB_DEFAULT = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1, 1.272, 1.618, 2.618];
const FIB_EXT_DEFAULT = [0, 0.382, 0.618, 1, 1.272, 1.618, 2, 2.618];
const FIB_COLORS = ['#787b86', '#f23645', '#ff9800', '#4caf50', '#089981', '#00bcd4', '#787b86', '#2962ff', '#e91e63', '#9c27b0', '#f23645'];
const GANN = [[1, 8], [1, 4], [1, 3], [1, 2], [1, 1], [2, 1], [3, 1], [4, 1], [8, 1]];
const nfmt = (v, d = 1) => v.toLocaleString('fr-FR', { minimumFractionDigits: d, maximumFractionDigits: d });

// -------------------------------------------------------------------------- icônes (SVG 20×20)
const ic = (d) => `<svg viewBox="0 0 20 20"><path d="${d}"/></svg>`;
export const ICONS = {
  cursor: ic('M5 3l10 6-4.5 1.2L13 15l-2 1-2.4-4.6L5 14z'),
  trend: ic('M3 16L17 4M3 16h0M17 4h0'), ray: ic('M3 15L17 5M3 15m-1.5 0a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0'), xline: ic('M1 17L19 3'),
  arrow: ic('M3 16L16 5M16 5l-5 .5M16 5l-.5 5'), hline: ic('M2 10h16M10 10h0'), hray: ic('M6 10h12M6 10m-1.5 0a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0'),
  vline: ic('M10 2v16'), cross: ic('M10 2v16M2 10h16'), channel: ic('M2 12L14 4M6 17l12-8M4 14.5L16 6.5'), regch: ic('M2 14l16-8M2 10l16-8M2 18l16-8'),
  pricerange: ic('M4 4h12M4 16h12M10 4v12M8 6l2-2 2 2M8 14l2 2 2-2'), daterange: ic('M4 4v12M16 4v12M4 10h12M6 8l-2 2 2 2M14 8l2 2-2 2'),
  measure: ic('M3 17L17 3M3 17v-4M3 17h4M17 3v4M17 3h-4'), rect: ic('M3 5h14v10H3z'), ellipse: ic('M10 4c4.4 0 8 2.7 8 6s-3.6 6-8 6-8-2.7-8-6 3.6-6 8-6z'),
  triangle: ic('M10 3l8 14H2z'), text: ic('M4 5h12M10 5v11M7 16h6'), label: ic('M3 6h10l4 4-4 4H3z'),
  long: ic('M3 3h14v7H3zM3 10h14v7H3z M5 7h6'), short: ic('M3 3h14v7H3zM3 10h14v7H3z M5 13h6'),
  fib: ic('M2 4h16M2 8h16M2 12h16M2 16h16'), fibext: ic('M2 16l5-9 4 5M10 9h8M10 5h8M10 13h8'), fibfan: ic('M2 17L18 3M2 17l16-6M2 17l16-2'),
  fibarcs: ic('M2 17a12 12 0 0 1 12-12M2 17a8 8 0 0 1 8-8M2 17a4 4 0 0 1 4-4'), fibspiral: ic('M10 10a2 2 0 1 1 2 2a4 4 0 1 1-4-4a7 7 0 1 1 7 7'),
  fibtime: ic('M3 3v14M5 3v14M8 3v14M13 3v14'), fibchannel: ic('M2 14L14 4M4 17l12-10M6 19l12-10'),
  gannfan: ic('M2 18L18 2M2 18l16-8M2 18L10 2M2 18l16-3M2 18l3-16'), gannbox: ic('M2 2h16v16H2zM2 10h16M10 2v16M2 2l16 16'), gannsquare: ic('M3 3h14v14H3zM3 3l14 14M17 3L3 17M3 17a14 14 0 0 1 14-14'),
  pitchfork: ic('M2 12L9 4M9 4l9 4M9 4l7 13M5 9l13-1M12 17l6-9'), schiff: ic('M2 10L9 5l9 3M9 5l7 12M5 8l13 0M12 16l6-8'), mschiff: ic('M3 12l6-6 9 2M9 6l7 11'),
  xabcd: ic('M2 15L6 4l4 8 4-6 4 10M2 15L10 12M10 12L18 16'), abcd: ic('M2 15L7 4l5 8 6-9'), hs: ic('M1 15l3-5 3 3 3-9 3 9 3-3 3 5M3 13h14'), tri: ic('M2 16L10 3l8 13zM6 11l8-1'),
  elliott5: ic('M1 16l4-8 3 4 5-10 3 6 3-4'), elliott3: ic('M2 4l5 10 4-5 6 9'), elliottTri: ic('M1 6l4 10 3-8 3 6 3-4 3 3'), elliottWxy: ic('M2 4l5 9 4-4 6 9'),
  flagUp: ic('M10 16V4M10 4l-4 4M10 4l4 4'), flagDown: ic('M10 4v12M10 16l-4-4M10 16l4-4'),
};

// -------------------------------------------------------------------------- catalogue
export const TOOL_GROUPS = [
  { id: 'lines', name: 'Lignes', tools: ['trend', 'ray', 'xline', 'arrow', 'hline', 'hray', 'vline', 'cross', 'channel', 'regch'] },
  { id: 'measure', name: 'Mesures et positions', tools: ['measure', 'pricerange', 'daterange', 'long', 'short'] },
  { id: 'shapes', name: 'Formes et annotations', tools: ['rect', 'ellipse', 'triangle', 'text', 'label', 'flagUp', 'flagDown'] },
  { id: 'fib', name: 'Fibonacci', tools: ['fib', 'fibext', 'fibfan', 'fibarcs', 'fibspiral', 'fibtime', 'fibchannel'] },
  { id: 'gann', name: 'Gann', tools: ['gannfan', 'gannbox', 'gannsquare'] },
  { id: 'pitch', name: 'Fourchettes', tools: ['pitchfork', 'schiff', 'mschiff'] },
  { id: 'patterns', name: 'Figures harmoniques et chartistes', tools: ['xabcd', 'abcd', 'hs', 'tri'] },
  { id: 'elliott', name: "Vagues d'Elliott", tools: ['elliott5', 'elliott3', 'elliottTri', 'elliottWxy'] },
];

const LINE = { color: null, width: 1.5, dash: 'solid' };
export const TOOLS = {
  trend: { name: 'Ligne de tendance', n: 2, key: 'T', style: { ...LINE, showStats: true } },
  ray: { name: 'Demi-droite', n: 2, style: { ...LINE, extendRight: true } },
  xline: { name: 'Droite prolongée', n: 2, style: { ...LINE, extendLeft: true, extendRight: true } },
  arrow: { name: 'Flèche', n: 2, style: { ...LINE, width: 2 } },
  hline: { name: 'Ligne horizontale', n: 1, key: 'H', style: { ...LINE } },
  hray: { name: 'Rayon horizontal', n: 1, style: { ...LINE } },
  vline: { name: 'Ligne verticale', n: 1, key: 'V', style: { ...LINE } },
  cross: { name: 'Réticule fixe', n: 1, style: { ...LINE, width: 1 } },
  channel: { name: 'Canal parallèle', n: 3, key: 'C', style: { ...LINE, fill: true, fillAlpha: 0.08, extendRight: false, mid: true } },
  regch: { name: 'Canal de régression linéaire', n: 2, style: { ...LINE, fill: true, fillAlpha: 0.07, k: 2 } },
  measure: { name: 'Mesure (prix, %, durée)', n: 2, key: 'M', style: { ...LINE, width: 1 } },
  pricerange: { name: 'Plage de prix', n: 2, style: { ...LINE, width: 1 } },
  daterange: { name: 'Plage de dates', n: 2, style: { ...LINE, width: 1 } },
  long: { name: 'Position longue (entrée, stop, objectif)', n: 3, key: 'L', style: { width: 1, color: '#1e9e55', qty: 0 } },
  short: { name: 'Position courte (entrée, stop, objectif)', n: 3, style: { width: 1, color: '#d64541', qty: 0 } },
  rect: { name: 'Rectangle', n: 2, key: 'R', style: { ...LINE, fill: true, fillAlpha: 0.12 } },
  ellipse: { name: 'Ellipse', n: 2, style: { ...LINE, fill: true, fillAlpha: 0.1 } },
  triangle: { name: 'Triangle', n: 3, style: { ...LINE, fill: true, fillAlpha: 0.1 } },
  text: { name: 'Texte', n: 1, style: { color: null, text: 'Note', size: 12 } },
  label: { name: 'Étiquette de prix', n: 1, style: { color: null } },
  flagUp: { name: 'Repère haussier', n: 1, style: { color: '#1e9e55', text: '' } },
  flagDown: { name: 'Repère baissier', n: 1, style: { color: '#d64541', text: '' } },
  fib: { name: 'Retracement de Fibonacci', n: 2, key: 'F', style: { width: 1, levels: FIB_DEFAULT, fill: true, fillAlpha: 0.06, extendRight: false, showPrices: true, reverse: false } },
  fibext: { name: 'Extension de Fibonacci (tendance)', n: 3, style: { width: 1, levels: FIB_EXT_DEFAULT, fill: true, fillAlpha: 0.05, showPrices: true } },
  fibfan: { name: 'Éventail de Fibonacci', n: 2, style: { width: 1, levels: [0.236, 0.382, 0.5, 0.618, 0.786], fill: true, fillAlpha: 0.04 } },
  fibarcs: { name: 'Arcs de Fibonacci', n: 2, style: { width: 1, levels: [0.236, 0.382, 0.5, 0.618, 0.786, 1] } },
  fibspiral: { name: 'Spirale de Fibonacci', n: 2, style: { ...LINE, width: 1.2 } },
  fibtime: { name: 'Zones de temps de Fibonacci', n: 2, style: { width: 1, levels: [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89] } },
  fibchannel: { name: 'Canal de Fibonacci', n: 3, style: { width: 1, levels: [0, 0.618, 1, 1.618, 2.618], fill: true, fillAlpha: 0.04 } },
  gannfan: { name: 'Éventail de Gann', n: 2, key: 'G', style: { width: 1, fill: true, fillAlpha: 0.04 } },
  gannbox: { name: 'Boîte de Gann', n: 2, style: { width: 1, levels: [0, 0.25, 0.382, 0.5, 0.618, 0.75, 1], fill: true, fillAlpha: 0.04 } },
  gannsquare: { name: 'Carré de Gann', n: 2, style: { width: 1 } },
  pitchfork: { name: "Fourchette d'Andrews", n: 3, key: 'P', style: { width: 1.2, fill: true, fillAlpha: 0.06, levels: [0.5, 1, 1.5, 2] } },
  schiff: { name: 'Fourchette de Schiff', n: 3, style: { width: 1.2, fill: true, fillAlpha: 0.06, levels: [0.5, 1, 1.5, 2] } },
  mschiff: { name: 'Fourchette de Schiff modifiée', n: 3, style: { width: 1.2, fill: true, fillAlpha: 0.06, levels: [0.5, 1, 1.5, 2] } },
  xabcd: { name: 'Figure harmonique XABCD', n: 5, key: 'X', style: { width: 1.5, fill: true, fillAlpha: 0.12 } },
  abcd: { name: 'Figure ABCD', n: 4, style: { width: 1.5 } },
  hs: { name: 'Tête-épaules', n: 7, style: { width: 1.5, fill: true, fillAlpha: 0.1 } },
  tri: { name: 'Triangle (figure)', n: 4, style: { width: 1.5, fill: true, fillAlpha: 0.08 } },
  elliott5: { name: "Vague d'Elliott impulsive (1-2-3-4-5)", n: 6, key: 'E', style: { width: 1.5 } },
  elliott3: { name: 'Correction ABC', n: 4, style: { width: 1.5 } },
  elliottTri: { name: 'Triangle ABCDE', n: 6, style: { width: 1.5 } },
  elliottWxy: { name: 'Double correction WXY', n: 4, style: { width: 1.5 } },
};

// -------------------------------------------------------------------------- géométrie
const dist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);
function segDist(px, py, x1, y1, x2, y2) {
  const dx = x2 - x1, dy = y2 - y1, L = dx * dx + dy * dy;
  const t = L ? Math.max(0, Math.min(1, ((px - x1) * dx + (py - y1) * dy) / L)) : 0;
  return dist(px, py, x1 + t * dx, y1 + t * dy);
}
function inPoly(px, py, pts) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const [xi, yi] = pts[i], [xj, yj] = pts[j];
    if ((yi > py) !== (yj > py) && px < ((xj - xi) * (py - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
/** Prolonge le segment AB jusqu'aux bords du rectangle (gauche et/ou droite). */
function extend(x1, y1, x2, y2, box, left, right) {
  const dx = x2 - x1, dy = y2 - y1;
  if (Math.abs(dx) < 1e-9 && Math.abs(dy) < 1e-9) return [x1, y1, x2, y2];
  const ts = [];
  if (Math.abs(dx) > 1e-9) ts.push((box.x0 - x1) / dx, (box.x1 - x1) / dx);
  if (Math.abs(dy) > 1e-9) ts.push((box.y0 - y1) / dy, (box.y1 - y1) / dy);
  const valid = ts.filter((t) => {
    const x = x1 + t * dx, y = y1 + t * dy;
    return x >= box.x0 - 1 && x <= box.x1 + 1 && y >= box.y0 - 1 && y <= box.y1 + 1;
  });
  if (!valid.length) return [x1, y1, x2, y2];
  const a = left ? Math.min(0, ...valid) : 0, b = right ? Math.max(1, ...valid) : 1;
  return [x1 + a * dx, y1 + a * dy, x1 + b * dx, y1 + b * dy];
}

let MEASURE = null;
const measureCtx = () => (MEASURE ??= document.createElement('canvas').getContext('2d'));

/** Peintre : dessine sur le contexte 2D ET enregistre la géométrie pour la sélection. */
class Painter {
  constructor(ctx, hit, box, dpr, color) {
    this.ctx = ctx;
    this.hitMode = hit;
    this.box = box;
    this.dpr = dpr;
    this.shapes = [];
    this.color = color;
    this.width = 1.5;
    this.dash = 'solid';
  }
  style({ color, width, dash } = {}) {
    if (color) this.color = color;
    if (width) this.width = width;
    if (dash) this.dash = dash;
    return this;
  }
  #stroke(c = this.color, w = this.width, dash = this.dash) {
    const x = this.ctx, d = this.dpr;
    x.strokeStyle = c;
    x.lineWidth = Math.max(1, w * d);
    x.setLineDash(dash === 'dash' ? [6 * d, 4 * d] : dash === 'dot' ? [1.5 * d, 3 * d] : []);
  }
  line(x1, y1, x2, y2, o = {}) {
    if (o.extL || o.extR) [x1, y1, x2, y2] = extend(x1, y1, x2, y2, this.box, o.extL, o.extR);
    this.shapes.push({ k: 'seg', a: [x1, y1, x2, y2] });
    if (this.hitMode) return;
    this.#stroke(o.color, o.width, o.dash);
    const c = this.ctx;
    c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke();
    c.setLineDash([]);
  }
  poly(pts, o = {}) {
    if (pts.length < 2) return;
    for (let i = 1; i < pts.length; i++) this.shapes.push({ k: 'seg', a: [...pts[i - 1], ...pts[i]] });
    if (o.close) this.shapes.push({ k: 'seg', a: [...pts.at(-1), ...pts[0]] });
    if (o.fill) this.shapes.push({ k: 'poly', a: pts });
    if (this.hitMode) return;
    const c = this.ctx;
    c.beginPath();
    pts.forEach(([x, y], i) => (i ? c.lineTo(x, y) : c.moveTo(x, y)));
    if (o.close) c.closePath();
    if (o.fill) { c.fillStyle = o.fill; c.globalAlpha = o.fillAlpha ?? 0.1; c.fill(); c.globalAlpha = 1; }
    if (o.stroke !== false) { this.#stroke(o.color, o.width, o.dash); c.stroke(); c.setLineDash([]); }
  }
  rect(x0, y0, x1, y1, o = {}) {
    this.poly([[x0, y0], [x1, y0], [x1, y1], [x0, y1]], { ...o, close: true });
  }
  fillPoly(pts, color, alpha) {
    this.shapes.push({ k: 'poly', a: pts });
    if (this.hitMode) return;
    const c = this.ctx;
    c.beginPath();
    pts.forEach(([x, y], i) => (i ? c.lineTo(x, y) : c.moveTo(x, y)));
    c.closePath();
    c.fillStyle = color;
    c.globalAlpha = alpha;
    c.fill();
    c.globalAlpha = 1;
  }
  ellipse(cx, cy, rx, ry, o = {}) {
    const pts = [];
    const a0 = o.a0 ?? 0, a1 = o.a1 ?? Math.PI * 2, n = 64;
    for (let i = 0; i <= n; i++) { const a = a0 + ((a1 - a0) * i) / n; pts.push([cx + rx * Math.cos(a), cy + ry * Math.sin(a)]); }
    for (let i = 1; i < pts.length; i++) this.shapes.push({ k: 'seg', a: [...pts[i - 1], ...pts[i]] });
    if (o.fill) this.shapes.push({ k: 'poly', a: pts });
    if (this.hitMode) return;
    const c = this.ctx;
    c.beginPath();
    c.ellipse(cx, cy, Math.abs(rx), Math.abs(ry), 0, a0, a1);
    if (o.fill) { c.fillStyle = o.fill; c.globalAlpha = o.fillAlpha ?? 0.1; c.fill(); c.globalAlpha = 1; }
    this.#stroke(o.color, o.width, o.dash);
    c.stroke();
    c.setLineDash([]);
  }
  /** Texte (fond optionnel) ; renvoie sa largeur. */
  text(x, y, s, o = {}) {
    const c = this.ctx ?? measureCtx(), d = this.dpr, size = (o.size ?? 10.5) * d;
    c.font = `${o.bold ? 'bold ' : ''}${Math.round(size)}px Verdana, Tahoma, sans-serif`;
    const w = c.measureText(s).width, h = size * 1.35;
    const ax = o.align === 'right' ? x - w : o.align === 'center' ? x - w / 2 : x;
    const ay = o.base === 'bottom' ? y - h : o.base === 'top' ? y : y - h / 2;
    this.shapes.push({ k: 'box', a: [ax - 3 * d, ay, ax + w + 3 * d, ay + h] });
    if (this.hitMode) return w;
    if (o.bg) { c.fillStyle = o.bg; c.globalAlpha = o.bgAlpha ?? 0.92; c.fillRect(ax - 3 * d, ay, w + 6 * d, h); c.globalAlpha = 1; }
    c.fillStyle = o.color ?? this.color;
    c.textBaseline = 'middle';
    c.textAlign = 'left';
    c.fillText(s, ax, ay + h / 2);
    return w;
  }
  dist(px, py) {
    let best = Infinity;
    for (const s of this.shapes) {
      if (s.k === 'seg') best = Math.min(best, segDist(px, py, ...s.a));
      else if (s.k === 'poly' && inPoly(px, py, s.a)) best = Math.min(best, 3 * this.dpr);
      else if (s.k === 'box' && px >= s.a[0] && px <= s.a[2] && py >= s.a[1] && py <= s.a[3]) best = 0;
    }
    return best;
  }
}

// -------------------------------------------------------------------------- dessin de chaque outil
/**
 * @param {Painter} g @param {{x,y,t,p}[]} P points (pixels + données) @param {object} s style
 * @param {object} k contexte : chart, fmt(prix), dpr, box, color, complete (tous les points posés)
 */
function drawTool(type, g, P, s, k) {
  const [A, B, C] = P, box = k.box, d = k.dpr, col = g.color, fmt = k.fmt;
  const pct = (a, b) => ((b / a - 1) * 100);
  const sign = (x) => (x >= 0 ? '+' : '');
  const lbl = (x, y, t, o = {}) => g.text(x, y, t, { bg: k.th.legendBg, color: o.color ?? col, ...o });
  switch (type) {
    case 'trend': case 'ray': case 'xline': case 'arrow': {
      g.line(A.x, A.y, B.x, B.y, { extL: s.extendLeft, extR: s.extendRight });
      if (type === 'arrow') {
        const ang = Math.atan2(B.y - A.y, B.x - A.x), L = 11 * d;
        g.poly([[B.x - L * Math.cos(ang - 0.4), B.y - L * Math.sin(ang - 0.4)], [B.x, B.y], [B.x - L * Math.cos(ang + 0.4), B.y - L * Math.sin(ang + 0.4)]], { width: s.width });
      }
      if (s.showStats && k.selected) {
        const bars = Math.round(k.chart.indexOfTime(B.t) - k.chart.indexOfTime(A.t));
        lbl(B.x + 6 * d, B.y, `${sign(B.p - A.p)}${fmt(B.p - A.p)} (${sign(pct(A.p, B.p))}${nfmt(pct(A.p, B.p), 2)} %) · ${bars} bougies`);
      }
      break;
    }
    case 'hline': g.line(box.x0, A.y, box.x1, A.y); lbl(box.x1 - 4 * d, A.y - 9 * d, fmt(A.p), { align: 'right' }); break;
    case 'hray': g.line(A.x, A.y, box.x1, A.y); lbl(A.x + 4 * d, A.y - 9 * d, fmt(A.p)); break;
    case 'vline': g.line(A.x, box.y0, A.x, box.y1); lbl(A.x + 4 * d, box.y0 + 10 * d, k.chart.data.ts.label(Math.max(0, Math.min(k.chart.n - 1, Math.round(k.chart.indexOfTime(A.t)))))); break;
    case 'cross': g.line(box.x0, A.y, box.x1, A.y); g.line(A.x, box.y0, A.x, box.y1); lbl(A.x + 4 * d, A.y - 9 * d, fmt(A.p)); break;
    case 'channel': {
      if (!C) { g.line(A.x, A.y, B.x, B.y); break; }
      const dy = C.y - (A.y + ((B.y - A.y) * (C.x - A.x)) / ((B.x - A.x) || 1));
      const ext = { extL: s.extendLeft, extR: s.extendRight };
      g.line(A.x, A.y, B.x, B.y, ext);
      g.line(A.x, A.y + dy, B.x, B.y + dy, ext);
      if (s.mid) g.line(A.x, A.y + dy / 2, B.x, B.y + dy / 2, { ...ext, dash: 'dash', width: 1 });
      if (s.fill) g.fillPoly([[A.x, A.y], [B.x, B.y], [B.x, B.y + dy], [A.x, A.y + dy]], col, s.fillAlpha);
      break;
    }
    case 'regch': {
      const ch = k.chart, i0 = Math.round(Math.min(ch.indexOfTime(A.t), ch.indexOfTime(B.t))), i1 = Math.round(Math.max(ch.indexOfTime(A.t), ch.indexOfTime(B.t)));
      const a0 = Math.max(0, i0), a1 = Math.min(ch.n - 1, i1);
      if (a1 - a0 < 2) { g.line(A.x, A.y, B.x, B.y); break; }
      const c = ch.data.c;
      let sx = 0, sy = 0, sxx = 0, sxy = 0, m = 0;
      for (let i = a0; i <= a1; i++) { const x = i - a0; sx += x; sy += c[i]; sxx += x * x; sxy += x * c[i]; m++; }
      const b = (m * sxy - sx * sy) / (m * sxx - sx * sx), a = (sy - b * sx) / m;
      let ss = 0;
      for (let i = a0; i <= a1; i++) ss += (c[i] - (a + b * (i - a0))) ** 2;
      const sd = Math.sqrt(ss / Math.max(1, m - 2)), kk = s.k ?? 2;
      const X0 = ch.X(a0), X1 = ch.X(a1), y = (v) => ch.yOfPrice(v);
      const m0 = a, m1 = a + b * (a1 - a0);
      g.line(X0, y(m0), X1, y(m1), { dash: 'dash', extR: s.extendRight });
      g.line(X0, y(m0 + kk * sd), X1, y(m1 + kk * sd), { extR: s.extendRight });
      g.line(X0, y(m0 - kk * sd), X1, y(m1 - kk * sd), { extR: s.extendRight });
      if (s.fill) g.fillPoly([[X0, y(m0 + kk * sd)], [X1, y(m1 + kk * sd)], [X1, y(m1 - kk * sd)], [X0, y(m0 - kk * sd)]], col, s.fillAlpha);
      if (k.selected) lbl(X1 + 6 * d, y(m1), `pente ${sign(b)}${fmt(b)} / bougie · σ ${fmt(sd)} · ${m} bougies`);
      break;
    }
    case 'measure': case 'pricerange': case 'daterange': {
      const up = B.p >= A.p, c2 = type === 'measure' ? (up ? '#1e9e55' : '#d64541') : col;
      const ch = k.chart, ia = ch.indexOfTime(A.t), ib = ch.indexOfTime(B.t), bars = Math.round(ib - ia);
      const x0 = Math.min(A.x, B.x), x1 = Math.max(A.x, B.x), y0 = Math.min(A.y, B.y), y1 = Math.max(A.y, B.y);
      g.fillPoly([[x0, y0], [x1, y0], [x1, y1], [x0, y1]], c2, 0.12);
      if (type !== 'daterange') { g.line(x0, A.y, x1, A.y, { color: c2 }); g.line(x0, B.y, x1, B.y, { color: c2 }); g.line((x0 + x1) / 2, A.y, (x0 + x1) / 2, B.y, { color: c2 }); }
      if (type !== 'pricerange') { g.line(A.x, y0, A.x, y1, { color: c2 }); g.line(B.x, y0, B.x, y1, { color: c2 }); g.line(A.x, (y0 + y1) / 2, B.x, (y0 + y1) / 2, { color: c2 }); }
      let vol = 0;
      for (let i = Math.max(0, Math.round(Math.min(ia, ib))); i <= Math.min(ch.n - 1, Math.round(Math.max(ia, ib))); i++) vol += ch.data.v[i];
      const secs = ch.data.ts.intraday ? Math.abs(bars) * ch.data.ts.barSeconds : null;
      const dur = secs !== null ? (secs >= 3600 ? `${Math.floor(secs / 3600)} h ${String(Math.round((secs % 3600) / 60)).padStart(2, '0')}` : `${Math.round(secs / 60)} min`) : `${Math.abs(Math.round(B.t - A.t))} j`;
      const lines = [];
      if (type !== 'daterange') lines.push(`${sign(B.p - A.p)}${fmt(B.p - A.p)} (${sign(pct(A.p, B.p))}${nfmt(pct(A.p, B.p), 2)} %)`);
      if (type !== 'pricerange') lines.push(`${Math.abs(bars)} bougies · ${dur}`, `volume ${Math.round(vol).toLocaleString('fr-FR')}`);
      const ty = up ? y0 - 8 * d - lines.length * 15 * d : y1 + 8 * d;
      lines.forEach((t, i) => lbl((x0 + x1) / 2, ty + i * 15 * d + 7 * d, t, { align: 'center', color: '#fff', bg: c2, bgAlpha: 0.9 }));
      break;
    }
    case 'long': case 'short': {
      if (!C) { g.line(A.x, A.y, B.x, B.y); break; }
      const isLong = type === 'long', x0 = Math.min(A.x, C.x), x1 = Math.max(A.x, C.x, A.x + 40 * d);
      const entry = A.p, stop = B.p, tgt = C.p, risk = Math.abs(entry - stop), reward = Math.abs(tgt - entry);
      g.fillPoly([[x0, A.y], [x1, A.y], [x1, C.y], [x0, C.y]], '#1e9e55', 0.16);
      g.fillPoly([[x0, A.y], [x1, A.y], [x1, B.y], [x0, B.y]], '#d64541', 0.16);
      g.line(x0, A.y, x1, A.y, { color: k.th.legendText, width: 1 });
      g.line(x0, B.y, x1, B.y, { color: '#d64541', width: 1 });
      g.line(x0, C.y, x1, C.y, { color: '#1e9e55', width: 1 });
      const rr = risk > 0 ? reward / risk : NaN;
      lbl((x0 + x1) / 2, C.y + (isLong ? -10 : 10) * d, `Objectif ${fmt(tgt)} · ${sign(isLong ? tgt - entry : entry - tgt)}${nfmt(pct(entry, tgt) * (isLong ? 1 : -1), 2)} %`, { align: 'center', color: '#fff', bg: '#1e9e55' });
      lbl((x0 + x1) / 2, B.y + (isLong ? 10 : -10) * d, `Stop ${fmt(stop)} · ${nfmt(-Math.abs(pct(entry, stop)), 2)} %`, { align: 'center', color: '#fff', bg: '#d64541' });
      lbl(x1 + 5 * d, A.y, `Entrée ${fmt(entry)} · gain/risque ${Number.isFinite(rr) ? nfmt(rr, 2) : '—'}`, { color: k.th.legendText });
      break;
    }
    case 'rect': g.rect(A.x, A.y, B.x, B.y, { fill: s.fill ? col : null, fillAlpha: s.fillAlpha }); break;
    case 'ellipse': g.ellipse((A.x + B.x) / 2, (A.y + B.y) / 2, Math.abs(B.x - A.x) / 2, Math.abs(B.y - A.y) / 2, { fill: s.fill ? col : null, fillAlpha: s.fillAlpha }); break;
    case 'triangle': if (C) g.poly([[A.x, A.y], [B.x, B.y], [C.x, C.y]], { close: true, fill: s.fill ? col : null, fillAlpha: s.fillAlpha }); else g.line(A.x, A.y, B.x, B.y); break;
    case 'text': g.text(A.x, A.y, s.text || 'Texte', { size: s.size ?? 12, bold: true, color: col, base: 'middle' }); break;
    case 'label': g.text(A.x + 6 * d, A.y, fmt(A.p), { bg: col, color: '#fff', bold: true }); g.line(A.x - 4 * d, A.y, A.x + 4 * d, A.y); break;
    case 'flagUp': case 'flagDown': {
      const up = type === 'flagUp', L = 10 * d;
      g.poly([[A.x, A.y], [A.x - L * 0.7, A.y + (up ? L : -L)], [A.x + L * 0.7, A.y + (up ? L : -L)]], { close: true, fill: col, fillAlpha: 0.9 });
      if (s.text) g.text(A.x, A.y + (up ? 2.2 : -2.2) * L, s.text, { align: 'center', color: col, bold: true });
      break;
    }
    // ---------------------------------------------------------------- Fibonacci
    case 'fib': {
      const lv = [...(s.levels ?? FIB_DEFAULT)].sort((a, b) => a - b), x0 = Math.min(A.x, B.x), x1 = s.extendRight ? box.x1 : Math.max(A.x, B.x);
      const pOf = (r) => (s.reverse ? A.p + (B.p - A.p) * r : B.p + (A.p - B.p) * r);
      const yOf = (r) => k.chart.yOfPrice(pOf(r));
      lv.forEach((r, i) => {
        const c2 = FIB_COLORS[i % FIB_COLORS.length], y = yOf(r);
        if (s.fill && i > 0) g.fillPoly([[x0, yOf(lv[i - 1])], [x1, yOf(lv[i - 1])], [x1, y], [x0, y]], c2, s.fillAlpha);
        g.line(x0, y, x1, y, { color: c2, width: r === 0.5 || r === 0.618 ? 1.5 : 1 });
        g.text(x0 + 4 * d, y - 7 * d, `${nfmt(r * 100, r * 100 % 1 ? 1 : 0)} %${s.showPrices ? `  (${fmt(pOf(r))})` : ''}`, { color: c2 });
      });
      g.line(A.x, A.y, B.x, B.y, { dash: 'dash', width: 1, color: k.th.text });
      break;
    }
    case 'fibext': {
      if (!C) { g.line(A.x, A.y, B.x, B.y, { dash: 'dash' }); break; }
      g.poly([[A.x, A.y], [B.x, B.y], [C.x, C.y]], { dash: 'dash', width: 1, color: k.th.text });
      const lv = [...(s.levels ?? FIB_EXT_DEFAULT)].sort((a, b) => a - b), x0 = Math.min(C.x, B.x), x1 = Math.max(B.x, C.x) + (Math.abs(B.x - A.x) || 60 * d);
      lv.forEach((r, i) => {
        const pr = C.p + (B.p - A.p) * r, y = k.chart.yOfPrice(pr), c2 = FIB_COLORS[(i + 2) % FIB_COLORS.length];
        if (s.fill && i > 0) { const yp = k.chart.yOfPrice(C.p + (B.p - A.p) * lv[i - 1]); g.fillPoly([[x0, yp], [x1, yp], [x1, y], [x0, y]], c2, s.fillAlpha); }
        g.line(x0, y, x1, y, { color: c2, width: 1 });
        g.text(x1 + 4 * d, y, `${nfmt(r * 100, r * 100 % 1 ? 1 : 0)} %${s.showPrices ? ` (${fmt(pr)})` : ''}`, { color: c2 });
      });
      break;
    }
    case 'fibfan': {
      g.line(A.x, A.y, B.x, B.y, { color: k.th.text, width: 1 });
      const lv = s.levels ?? [0.236, 0.382, 0.5, 0.618, 0.786];
      const ends = lv.map((r) => [B.x, B.y + (A.y - B.y) * r]);
      ends.forEach(([x, y], i) => {
        const c2 = FIB_COLORS[(i + 1) % FIB_COLORS.length];
        g.line(A.x, A.y, x, y, { color: c2, extR: true, width: 1 });
        g.text(x + 3 * d, y, `${nfmt(lv[i] * 100, 1)} %`, { color: c2 });
      });
      g.line(B.x, A.y, B.x, B.y, { dash: 'dot', width: 1, color: k.th.text });
      break;
    }
    case 'fibarcs': {
      g.line(A.x, A.y, B.x, B.y, { dash: 'dash', width: 1, color: k.th.text });
      const R = dist(A.x, A.y, B.x, B.y), dir = A.y < B.y ? -1 : 1;
      (s.levels ?? [0.382, 0.5, 0.618, 1]).forEach((r, i) => {
        const c2 = FIB_COLORS[(i + 1) % FIB_COLORS.length];
        g.ellipse(B.x, B.y, R * r, R * r, { a0: dir < 0 ? Math.PI : 0, a1: dir < 0 ? 2 * Math.PI : Math.PI, color: c2, width: 1 });
        g.text(B.x + 3 * d, B.y + dir * R * r, `${nfmt(r * 100, 1)} %`, { color: c2 });
      });
      break;
    }
    case 'fibspiral': {
      // spirale d'or r(θ) = a·φ^(2θ/π), centrée en A, passant par B
      const R = dist(A.x, A.y, B.x, B.y), th0 = Math.atan2(B.y - A.y, B.x - A.x), pts = [];
      for (let q = -7 * Math.PI; q <= 0.0001; q += Math.PI / 48) { const r = R * PHI ** ((2 * q) / Math.PI); pts.push([A.x + r * Math.cos(th0 + q), A.y + r * Math.sin(th0 + q)]); }
      g.poly(pts);
      g.line(A.x, A.y, B.x, B.y, { dash: 'dot', width: 1 });
      break;
    }
    case 'fibtime': {
      const ia = k.chart.indexOfTime(A.t), unit = Math.max(1, Math.round(Math.abs(k.chart.indexOfTime(B.t) - ia)));
      (s.levels ?? [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]).forEach((f, i) => {
        const x = k.chart.X(ia + f * unit), c2 = FIB_COLORS[i % FIB_COLORS.length];
        if (x < box.x0 - 2 || x > box.x1 + 2) return;
        g.line(x, box.y0, x, box.y1, { color: c2, width: 1 });
        g.text(x + 3 * d, box.y1 - 10 * d, String(f), { color: c2 });
      });
      break;
    }
    case 'fibchannel': {
      if (!C) { g.line(A.x, A.y, B.x, B.y); break; }
      const dy = C.y - (A.y + ((B.y - A.y) * (C.x - A.x)) / ((B.x - A.x) || 1));
      const lv = s.levels ?? [0, 0.618, 1, 1.618, 2.618];
      lv.forEach((r, i) => {
        const c2 = FIB_COLORS[(i + 1) % FIB_COLORS.length];
        if (s.fill && i > 0) g.fillPoly([[A.x, A.y + dy * lv[i - 1]], [B.x, B.y + dy * lv[i - 1]], [B.x, B.y + dy * r], [A.x, A.y + dy * r]], c2, s.fillAlpha);
        g.line(A.x, A.y + dy * r, B.x, B.y + dy * r, { color: c2, width: 1, extR: true });
        g.text(B.x + 3 * d, B.y + dy * r, nfmt(r, 3), { color: c2 });
      });
      break;
    }
    // ---------------------------------------------------------------- Gann
    case 'gannfan': {
      const dx = B.x - A.x || 1, dy = B.y - A.y;
      GANN.forEach(([pr, tm], i) => {
        const slope = (dy / dx) * (pr / tm), c2 = FIB_COLORS[(i + 1) % FIB_COLORS.length];
        const x2 = A.x + dx, y2 = A.y + slope * dx;
        g.line(A.x, A.y, x2, y2, { color: c2, width: pr === tm ? 1.6 : 1, extR: true });
        const lx = Math.min(box.x1 - 30 * d, A.x + dx * 1.6), ly = A.y + slope * (lx - A.x);
        if (ly > box.y0 && ly < box.y1) g.text(lx, ly, `${pr}×${tm}`, { color: c2 });
      });
      break;
    }
    case 'gannbox': {
      const lv = s.levels ?? [0, 0.25, 0.382, 0.5, 0.618, 0.75, 1];
      if (s.fill) g.fillPoly([[A.x, A.y], [B.x, A.y], [B.x, B.y], [A.x, B.y]], col, s.fillAlpha);
      lv.forEach((r) => {
        const y = A.y + (B.y - A.y) * r, x = A.x + (B.x - A.x) * r;
        g.line(A.x, y, B.x, y, { width: r === 0 || r === 1 ? 1.4 : 0.8 });
        g.line(x, A.y, x, B.y, { width: r === 0 || r === 1 ? 1.4 : 0.8 });
        g.text(B.x + 3 * d, y, nfmt(r, 3), {});
      });
      g.line(A.x, A.y, B.x, B.y, { dash: 'dash', width: 1 });
      g.line(A.x, B.y, B.x, A.y, { dash: 'dash', width: 1 });
      break;
    }
    case 'gannsquare': {
      const side = Math.max(Math.abs(B.x - A.x), 10 * d), sx = Math.sign(B.x - A.x || 1), sy = Math.sign(B.y - A.y || 1);
      const X2 = A.x + sx * side, Y2 = B.y;
      g.rect(A.x, A.y, X2, Y2, {});
      g.line(A.x, A.y, X2, Y2, {}); g.line(A.x, Y2, X2, A.y, {});
      g.line((A.x + X2) / 2, A.y, (A.x + X2) / 2, Y2, { dash: 'dash', width: 1 }); g.line(A.x, (A.y + Y2) / 2, X2, (A.y + Y2) / 2, { dash: 'dash', width: 1 });
      const rx = side, ry = Math.abs(Y2 - A.y);
      for (const f of [0.5, 1]) g.ellipse(A.x, A.y, rx * f, ry * f, { a0: sy > 0 ? (sx > 0 ? 0 : Math.PI / 2) : sx > 0 ? -Math.PI / 2 : Math.PI, a1: sy > 0 ? (sx > 0 ? Math.PI / 2 : Math.PI) : sx > 0 ? 0 : Math.PI * 1.5, width: 1 });
      break;
    }
    // ---------------------------------------------------------------- fourchettes
    case 'pitchfork': case 'schiff': case 'mschiff': {
      if (!C) { g.line(A.x, A.y, B.x, B.y); break; }
      let P0 = [A.x, A.y];
      if (type === 'schiff') P0 = [A.x, (A.y + B.y) / 2];
      if (type === 'mschiff') P0 = [(A.x + B.x) / 2, (A.y + B.y) / 2];
      const M = [(B.x + C.x) / 2, (B.y + C.y) / 2], vx = M[0] - P0[0], vy = M[1] - P0[1];
      g.line(P0[0], P0[1], M[0], M[1], { extR: true, width: s.width });
      if (type !== 'pitchfork') g.line(A.x, A.y, P0[0], P0[1], { dash: 'dot', width: 1 });
      g.line(B.x, B.y, C.x, C.y, { dash: 'dash', width: 1 });
      const levels = s.levels ?? [0.5, 1, 1.5, 2], hx = (C.x - B.x) / 2, hy = (C.y - B.y) / 2;
      for (const r of levels) for (const sgn of [1, -1]) {
        const ox = M[0] + sgn * hx * r, oy = M[1] + sgn * hy * r, c2 = r === 1 ? col : FIB_COLORS[(levels.indexOf(r) + 2) % FIB_COLORS.length];
        g.line(ox, oy, ox + vx, oy + vy, { extR: true, color: c2, width: r === 1 ? s.width : 0.8 });
      }
      if (s.fill) {
        const far = 3;
        g.fillPoly([[B.x, B.y], [B.x + vx * far, B.y + vy * far], [C.x + vx * far, C.y + vy * far], [C.x, C.y]], col, s.fillAlpha);
      }
      break;
    }
    // ---------------------------------------------------------------- figures
    case 'xabcd': case 'abcd': {
      const names = type === 'xabcd' ? ['X', 'A', 'B', 'C', 'D'] : ['A', 'B', 'C', 'D'];
      const pts = P.map((q) => [q.x, q.y]);
      if (type === 'xabcd' && P.length >= 3 && s.fill) g.fillPoly(pts.slice(0, 3), col, s.fillAlpha);
      if (type === 'xabcd' && P.length >= 5 && s.fill) g.fillPoly(pts.slice(2, 5), col, s.fillAlpha);
      g.poly(pts, { width: s.width });
      P.forEach((q, i) => {
        const hi = i > 0 && q.p > P[i - 1].p || (i === 0 && P[1] && q.p > P[1].p);
        g.text(q.x, q.y + (hi ? -12 : 12) * d, names[i], { align: 'center', bold: true, color: col });
      });
      const ratio = (a, b, c) => Math.abs(c.p - b.p) / Math.abs(b.p - a.p || 1);
      const mid = (a, b) => [(a.x + b.x) / 2, (a.y + b.y) / 2];
      const tag = (a, c, r) => { g.line(a.x, a.y, c.x, c.y, { dash: 'dot', width: 1 }); const [mx, my] = mid(a, c); g.text(mx, my, nfmt(r, 3), { align: 'center', bg: k.th.legendBg, color: col }); };
      if (type === 'xabcd') {
        if (P.length >= 3) tag(P[0], P[2], ratio(P[0], P[1], P[2]));
        if (P.length >= 4) tag(P[1], P[3], ratio(P[1], P[2], P[3]));
        if (P.length >= 5) {
          tag(P[2], P[4], ratio(P[2], P[3], P[4]));
          tag(P[0], P[4], Math.abs(P[4].p - P[1].p) / Math.abs(P[1].p - P[0].p || 1));
          const match = matchHarmonic(P);
          g.text(P[4].x + 8 * d, P[4].y, match ? `${match.name} ${match.bull ? 'haussier' : 'baissier'} ✓ (écart ${nfmt(match.err * 100, 1)} %)` : 'ratios hors figures connues', { bg: match ? (match.bull ? '#1e9e55' : '#d64541') : k.th.legendBg, color: match ? '#fff' : col });
        }
      } else {
        if (P.length >= 3) tag(P[0], P[2], ratio(P[0], P[1], P[2]));
        if (P.length >= 4) {
          tag(P[1], P[3], ratio(P[1], P[2], P[3]));
          const ab = Math.abs(P[1].p - P[0].p), cd = Math.abs(P[3].p - P[2].p);
          g.text(P[3].x + 8 * d, P[3].y, `CD/AB = ${nfmt(cd / (ab || 1), 3)}${Math.abs(cd / (ab || 1) - 1) < 0.08 ? ' ✓ ABCD' : ''}`, { bg: k.th.legendBg, color: col });
        }
      }
      break;
    }
    case 'hs': {
      const pts = P.map((q) => [q.x, q.y]);
      g.poly(pts, { width: s.width });
      const names = ['', 'Épaule G', '', 'Tête', '', 'Épaule D', ''];
      P.forEach((q, i) => { if (names[i]) g.text(q.x, q.y + (q.p > (P[i - 1]?.p ?? 0) ? -12 : 12) * d, names[i], { align: 'center', bold: true }); });
      if (P.length >= 5) {
        const n1 = P[2], n2 = P[4];
        g.line(n1.x, n1.y, n2.x, n2.y, { extR: true, extL: true, color: '#d64541', width: 1.2, dash: 'dash' });
        if (P.length >= 4 && s.fill) g.fillPoly([[n1.x, n1.y], [P[3].x, P[3].y], [n2.x, n2.y]], col, s.fillAlpha);
        const head = P[3], neckAtHead = n1.p + ((n2.p - n1.p) * (k.chart.indexOfTime(head.t) - k.chart.indexOfTime(n1.t))) / ((k.chart.indexOfTime(n2.t) - k.chart.indexOfTime(n1.t)) || 1);
        const target = 2 * neckAtHead - head.p;
        if (P.length === 7) g.text(P[6].x + 6 * d, k.chart.yOfPrice(target), `objectif théorique ${fmt(target)}`, { bg: k.th.legendBg, color: '#d64541' });
      }
      break;
    }
    case 'tri': {
      if (P.length >= 3) g.line(P[0].x, P[0].y, P[2].x, P[2].y, { extR: true });
      if (P.length >= 4) {
        g.line(P[1].x, P[1].y, P[3].x, P[3].y, { extR: true });
        if (s.fill) g.fillPoly(P.map((q) => [q.x, q.y]), col, s.fillAlpha);
      }
      g.poly(P.map((q) => [q.x, q.y]), { dash: 'dot', width: 1 });
      break;
    }
    // ---------------------------------------------------------------- Elliott
    case 'elliott5': case 'elliott3': case 'elliottTri': case 'elliottWxy': {
      const names = { elliott5: ['0', '1', '2', '3', '4', '5'], elliott3: ['0', 'A', 'B', 'C'], elliottTri: ['0', 'A', 'B', 'C', 'D', 'E'], elliottWxy: ['0', 'W', 'X', 'Y'] }[type];
      g.poly(P.map((q) => [q.x, q.y]), { width: s.width });
      P.forEach((q, i) => {
        if (!i) return;
        const hi = q.p > P[i - 1].p;
        g.text(q.x, q.y + (hi ? -13 : 13) * d, `(${names[i]})`, { align: 'center', bold: true, color: col });
      });
      if (type === 'elliott5' && P.length === 6) {
        const r = elliottRules(P.map((q) => q.p));
        g.text(P[5].x + 8 * d, P[5].y, r.ok ? 'règles d\'Elliott respectées ✓' : `✗ ${r.broken.join(' ; ')}`, { bg: r.ok ? '#1e9e55' : '#d64541', color: '#fff' });
      }
      break;
    }
    default: if (B) g.line(A.x, A.y, B.x, B.y);
  }
}

/** Reconnaissance harmonique à partir des 5 points (mêmes règles que le moteur quant). */
function matchHarmonic(P) {
  const [X, A, B, C, D] = P.map((q) => q.p);
  const XA = Math.abs(A - X), AB = Math.abs(B - A), BC = Math.abs(C - B), CD = Math.abs(D - C);
  if (!XA || !AB || !BC) return null;
  const r = { ab: AB / XA, bc: BC / AB, cd: CD / BC, ad: Math.abs(D - A) / XA }, tol = 0.06;
  const err = (v, [lo, hi]) => (v < lo * (1 - tol) ? (lo - v) / lo : v > hi * (1 + tol) ? (v - hi) / hi : 0);
  let best = null;
  for (const pat of HARMONICS) {
    const e = [err(r.ab, pat.ab), err(r.bc, pat.bc), err(r.cd, pat.cd), err(r.ad, pat.ad)];
    if (e.some((x) => x > tol)) continue;
    const score = e.reduce((a, b) => a + b, 0) / 4;
    if (!best || score < best.err) best = { name: pat.name, err: score, bull: D < C };
  }
  return best;
}

/** Règles d'une impulsion : 2 ne retrace pas 100 % de 1, 3 n'est pas la plus courte, 4 ne recouvre pas 1. */
export function elliottRules([p0, p1, p2, p3, p4, p5]) {
  const up = p1 > p0, w1 = Math.abs(p1 - p0), w3 = Math.abs(p3 - p2), w5 = Math.abs(p5 - p4), broken = [];
  const alternance = up ? p2 < p1 && p3 > p2 && p4 < p3 && p5 > p4 : p2 > p1 && p3 < p2 && p4 > p3 && p5 < p4;
  if (!alternance) broken.push('alternance des vagues incohérente');
  if (up ? p2 <= p0 : p2 >= p0) broken.push('la vague 2 retrace plus de 100 % de la 1');
  if (w3 < w1 && w3 < w5) broken.push('la vague 3 est la plus courte');
  if (up ? p4 <= p1 : p4 >= p1) broken.push('la vague 4 chevauche la vague 1');
  return { ok: !broken.length, broken };
}

// -------------------------------------------------------------------------- gestionnaire
export class DrawingManager {
  /**
   * @param {import('./engine.js').ProChart} chart
   * @param {{ onChange?:(list)=>void, onStatus?:(text)=>void, onEdit?:(drawing)=>void, onSelect?:(drawing)=>void }} cb
   */
  constructor(chart, cb = {}) {
    this.chart = chart;
    this.cb = cb;
    this.items = [];
    this.tool = null;
    this.pending = null;
    this.selected = null;
    this.dragging = null;
    this.hoverId = null;
    this.history = [];
    this.future = [];
    this.stay = false;
    this.hideAll = false;
    chart.drawings = this;
  }

  get busy() { return Boolean(this.tool || this.dragging); }
  get list() { return this.items; }

  load(list) {
    this.items = (list ?? []).filter((x) => TOOLS[x.type]);
    this.selected = null;
    this.pending = null;
    this.history = [];
    this.chart.invalidate();
  }

  #snapshot() {
    this.history.push(JSON.stringify(this.items));
    if (this.history.length > 100) this.history.shift();
    this.future = [];
  }
  #changed() {
    this.cb.onChange?.(this.items);
    this.chart.invalidate();
  }
  undo() {
    if (!this.history.length) return;
    this.future.push(JSON.stringify(this.items));
    this.items = JSON.parse(this.history.pop());
    this.selected = null;
    this.#changed();
  }
  redo() {
    if (!this.future.length) return;
    this.history.push(JSON.stringify(this.items));
    this.items = JSON.parse(this.future.pop());
    this.#changed();
  }

  setTool(type, { stay = false } = {}) {
    this.tool = type && TOOLS[type] ? type : null;
    this.stay = stay;
    this.pending = null;
    if (this.tool) this.select(null);
    const t = this.tool ? TOOLS[this.tool] : null;
    this.cb.onStatus?.(t ? `${t.name} : ${t.n === 1 ? 'cliquez à l\'endroit voulu' : `posez ${t.n} points (clic à chaque point${t.n === 2 ? ', ou cliquer-glisser' : ''})`} — Échap pour annuler${this.chart.opt.magnet !== 'off' ? ' · aimant actif' : ''}` : '');
    this.cb.onTool?.(this.tool);
    this.chart.invalidate();
  }

  select(item) {
    this.selected = item;
    this.cb.onSelect?.(item);
    this.chart.invalidate();
  }

  remove(id) {
    this.#snapshot();
    this.items = this.items.filter((x) => x.id !== id);
    if (this.selected?.id === id) this.selected = null;
    this.#changed();
  }

  clear() {
    if (!this.items.length) return;
    this.#snapshot();
    this.items = [];
    this.selected = null;
    this.#changed();
  }

  clone(item) {
    this.#snapshot();
    const c = JSON.parse(JSON.stringify(item));
    c.id = `d${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`;
    const ch = this.chart, dIdx = Math.max(3, Math.round(ch.plotW / ch.view.ppb / 30));
    c.pts = c.pts.map((q) => ({ t: ch.timeOfIndex(ch.indexOfTime(q.t) + dIdx), p: q.p }));
    this.items.push(c);
    this.select(c);
    this.#changed();
    return c;
  }

  update(item, patch) {
    this.#snapshot();
    Object.assign(item, patch);
    if (patch.style) item.style = { ...item.style, ...patch.style };
    this.#changed();
  }

  /** Ajoute un tracé par programme (ex. ligne horizontale depuis le menu contextuel). */
  add(type, pts, style = {}) {
    this.#snapshot();
    const it = { id: `d${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`, type, pts, style: { ...TOOLS[type].style, ...style }, locked: false, hidden: false, created: Date.now() };
    this.items.push(it);
    this.#changed();
    return it;
  }

  // ------------------------------------------------------------------ rendu
  #box() {
    const p = this.chart.panes[0];
    return { x0: 0, y0: p.y0, x1: this.chart.plotW, y1: p.y0 + p.h };
  }
  #px(pts) {
    const ch = this.chart;
    return pts.map((q) => ({ x: ch.X(ch.indexOfTime(q.t)), y: ch.yOfPrice(q.p), t: q.t, p: q.p }));
  }
  #ctx(item, th, dpr) {
    return { chart: this.chart, fmt: (v) => this.chart.fmtPrice(v), dpr, box: this.#box(), th, selected: this.selected === item || this.hoverId === item.id || this.pending === item };
  }

  render(ctx, { dpr, th }) {
    if (this.hideAll) return;
    const draw = (item) => {
      if (item.hidden) return;
      const color = item.style.color || th.draw;
      const g = new Painter(ctx, false, this.#box(), dpr, color).style({ color, width: item.style.width ?? 1.5, dash: item.style.dash ?? 'solid' });
      ctx.save();
      if (this.selected === item || this.hoverId === item.id) {
        ctx.shadowColor = th.select;
        ctx.shadowBlur = this.selected === item ? 6 * dpr : 3 * dpr;
      }
      drawTool(item.type, g, this.#px(item.pts), item.style, this.#ctx(item, th, dpr));
      ctx.restore();
    };
    for (const it of this.items) draw(it);
    if (this.pending) draw(this.pending);
    // poignées du tracé sélectionné
    const sel = this.selected ?? this.pending;
    if (sel && !sel.hidden) {
      for (const q of this.#px(sel.pts)) {
        ctx.fillStyle = th.bg;
        ctx.strokeStyle = sel.locked ? th.text : th.select;
        ctx.lineWidth = 1.5 * dpr;
        ctx.beginPath();
        ctx.arc(q.x, q.y, 4.5 * dpr, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
    }
    if (this.tool && this.hoverPt?.snapped) {
      const ch = this.chart, x = ch.X(ch.indexOfTime(this.hoverPt.t)), y = ch.yOfPrice(this.hoverPt.p);
      ctx.strokeStyle = th.select;
      ctx.lineWidth = 1.5 * dpr;
      ctx.strokeRect(x - 5 * dpr, y - 5 * dpr, 10 * dpr, 10 * dpr);
    }
  }

  // ------------------------------------------------------------------ sélection
  hitTest(x, y) {
    if (this.hideAll) return null;
    const th = this.chart.th, dpr = this.chart.dpr, tol = 6 * dpr;
    let best = null, bd = tol;
    for (let k = this.items.length - 1; k >= 0; k--) {
      const it = this.items[k];
      if (it.hidden) continue;
      const g = new Painter(null, true, this.#box(), dpr, '#000');
      drawTool(it.type, g, this.#px(it.pts), it.style, this.#ctx(it, th, dpr));
      const dd = g.dist(x, y);
      if (dd < bd) { bd = dd; best = it; }
    }
    return best;
  }

  #handleAt(x, y) {
    const sel = this.selected;
    if (!sel || sel.locked || sel.hidden) return -1;
    const pts = this.#px(sel.pts), r = 8 * this.chart.dpr;
    return pts.findIndex((q) => dist(q.x, q.y, x, y) < r);
  }

  cursor(x, y) {
    if (this.tool) return 'crosshair';
    if (this.#handleAt(x, y) >= 0) return 'move';
    if (this.hoverId) return 'pointer';
    return null;
  }

  #point(x, y) {
    const s = this.chart.snap(x, y);
    return { t: s.t, p: s.p, snapped: s.snapped };
  }

  // ------------------------------------------------------------------ événements (appelés par le moteur)
  onDown(x, y, e) {
    if (this.tool) {
      const pt = this.#point(x, y), def = TOOLS[this.tool];
      if (!this.pending) {
        this.pending = { id: `d${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`, type: this.tool, pts: [pt], style: { ...def.style }, locked: false, hidden: false, created: Date.now() };
        if (def.n === 1) { this.#commit(e); return true; }
        this.pending.pts.push({ ...pt });
        this.downAt = { x, y };
      } else {
        this.pending.pts[this.pending.pts.length - 1] = pt;
        if (this.pending.pts.length >= def.n) this.#commit(e);
        else this.pending.pts.push({ ...pt });
      }
      this.chart.invalidate();
      return true;
    }
    const h = this.#handleAt(x, y);
    if (h >= 0) {
      this.#snapshot();
      this.dragging = { kind: 'handle', k: h, item: this.selected };
      return true;
    }
    const hit = this.hitTest(x, y);
    if (hit) {
      this.select(hit);
      if (!hit.locked) {
        this.#snapshot();
        this.dragging = { kind: 'move', item: hit, x, y, orig: hit.pts.map((q) => ({ ...q, idx: this.chart.indexOfTime(q.t), py: this.chart.yOfPrice(q.p) })) };
      }
      return true;
    }
    if (this.selected) this.select(null);
    return false;
  }

  onMove(x, y) {
    const dr = this.dragging, ch = this.chart;
    if (this.tool && this.pending) {
      this.pending.pts[this.pending.pts.length - 1] = this.#point(x, y);
      ch.invalidate();
      return;
    }
    if (!dr) return;
    if (dr.kind === 'handle') {
      dr.item.pts[dr.k] = this.#point(x, y);
      delete dr.item.pts[dr.k].snapped;
    } else {
      const dIdx = (x - dr.x) / ch.view.ppb, dy = y - dr.y;
      dr.item.pts = dr.orig.map((q) => ({ t: ch.timeOfIndex(q.idx + dIdx), p: ch.priceAt(q.py + dy) }));
    }
    ch.invalidate();
  }

  onUp(x, y) {
    const dr = this.dragging;
    this.dragging = null;
    if (this.tool && this.pending && this.downAt && TOOLS[this.tool].n === 2 && dist(x, y, this.downAt.x, this.downAt.y) > 6 * this.chart.dpr) {
      this.pending.pts[1] = this.#point(x, y);
      this.#commit();
    }
    this.downAt = null;
    if (dr) {
      if (dr.kind === 'move' && dist(x, y, dr.x, dr.y) < 2) this.history.pop();
      else this.#changed();
    }
  }

  onHover(x, y) {
    if (this.tool) {
      this.hoverPt = this.#point(x, y);
      this.chart.invalidate();
      return;
    }
    const hit = this.hitTest(x, y);
    const id = hit?.id ?? null;
    if (id !== this.hoverId) { this.hoverId = id; this.chart.invalidate(); }
  }

  onDblClick(x, y) {
    const hit = this.hitTest(x, y);
    if (hit) { this.select(hit); this.cb.onEdit?.(hit); return true; }
    return false;
  }

  onKey(e) {
    if (e.key === 'Escape') {
      if (this.pending || this.tool) { this.pending = null; this.setTool(null); return true; }
      if (this.selected) { this.select(null); return true; }
      return false;
    }
    if ((e.key === 'Delete' || e.key === 'Backspace') && this.selected) { this.remove(this.selected.id); return true; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { this.undo(); return true; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { this.redo(); return true; }
    if (e.altKey && !e.ctrlKey) {
      const t = Object.entries(TOOLS).find(([, v]) => v.key && v.key.toLowerCase() === e.key.toLowerCase());
      if (t) { this.setTool(t[0]); return true; }
    }
    return false;
  }

  #commit(e) {
    const p = this.pending;
    if (!p) return;
    for (const q of p.pts) delete q.snapped;
    this.#snapshot();
    this.items.push(p);
    this.pending = null;
    const keep = this.stay || e?.shiftKey;
    this.select(p);
    if (!keep) this.setTool(null);
    else this.setTool(p.type, { stay: this.stay });
    this.#changed();
    if (p.type === 'text') this.cb.onEdit?.(p);
  }
}

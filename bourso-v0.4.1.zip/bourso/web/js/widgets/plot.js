// ============================================================================
//  BOURSO :: widgets/plot.js — graphiques d'analyse (Canvas 2D, haute définition) :
//   Plot     courbes, aires, bandes (éventails), barres/histogrammes, nuages de points,
//            lignes de référence, axes gradués « ronds », légende, réticule avec valeurs ;
//   HeatGrid matrice colorée (corrélations, cartes de chaleur des balayages) avec infobulle ;
//   gauge()  jauge demi-cercle (résumé technique −1 … +1).
//  Couleurs lues dans le thème CSS (clair/sombre).
// ============================================================================
import { num, esc } from '../core/fmt.js';

const css = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
export const PALETTE = ['#1f6fd1', '#f28c18', '#1e9e55', '#d64541', '#7b4fc9', '#0f8f8f', '#c2185b', '#8d6e63', '#5c6bc0', '#9e9d24'];

/** Graduations « rondes » (1, 2, 2,5, 5 × 10^k) couvrant [lo, hi] avec ~n intervalles. */
export function niceTicks(lo, hi, n = 5) {
  if (!(hi > lo)) { const d = Math.abs(lo) * 0.1 || 1; lo -= d; hi += d; }
  const raw = (hi - lo) / Math.max(1, n), pow = 10 ** Math.floor(Math.log10(raw));
  const step = [1, 2, 2.5, 5, 10].map((s) => s * pow).find((s) => s >= raw) ?? 10 * pow;
  const out = [];
  for (let v = Math.ceil(lo / step - 1e-9) * step; v <= hi + step * 1e-9; v += step) out.push(Math.abs(v) < step * 1e-9 ? 0 : v);
  return { ticks: out, step, dec: Math.max(0, -Math.floor(Math.log10(step) + 1e-9)) };
}

export class Plot {
  /**
   * @param {HTMLCanvasElement} canvas
   * @param {{ height?:number, xs?:number[], xFormat?:(x)=>string, yFormat?:(y)=>string, yMin?:number, yMax?:number, zero?:boolean,
   *   log?:boolean, series?:object[], legend?:boolean, tooltip?:boolean, padding?:number[], xTicks?:number, yLabel?:string, xLabel?:string }} o
   */
  constructor(canvas, o = {}) {
    this.cv = canvas;
    this.o = { height: 240, legend: true, tooltip: true, padding: [10, 12, 26, 58], xTicks: 6, ...o };
    this.cv.style.height = `${this.o.height}px`;
    this.series = o.series ?? [];
    this.hover = null;
    this.ro = new ResizeObserver(() => this.render());
    this.ro.observe(canvas);
    canvas.addEventListener('mousemove', (e) => {
      const r = canvas.getBoundingClientRect();
      this.hover = { x: e.clientX - r.left, y: e.clientY - r.top };
      this.render();
    });
    canvas.addEventListener('mouseleave', () => { this.hover = null; this.render(); });
  }

  set(patch) {
    Object.assign(this.o, patch);
    if (patch.series) this.series = patch.series;
    if (patch.height) this.cv.style.height = `${patch.height}px`;
    this.render();
    return this;
  }

  destroy() {
    this.ro.disconnect();
  }

  #xs() {
    if (this.o.xs) return this.o.xs;
    const n = Math.max(0, ...this.series.map((s) => (s.data ?? s.hi ?? s.lo ?? []).length));
    return Array.from({ length: n }, (_, i) => i);
  }

  render() {
    const cv = this.cv, dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = this.o.height;
    if (!W) return;
    if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) {
      cv.width = Math.round(W * dpr);
      cv.height = Math.round(H * dpr);
    }
    const ctx = cv.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const th = { text: css('--c-text'), grid: css('--c-grid'), axis: css('--c-axis-line'), bg: css('--box'), legendBg: css('--c-legend-bg'), cross: css('--c-cross'), tag: css('--c-tag-bg'), tagFg: css('--c-tag-fg') };
    const [pt, pr, pb, pl] = this.o.padding, x0 = pl, x1 = W - pr, y0 = pt, y1 = H - pb;
    const xs = this.#xs(), n = xs.length;
    // bornes
    let lo = Infinity, hi = -Infinity, xlo = Infinity, xhi = -Infinity;
    const take = (v) => { if (Number.isFinite(v)) { if (v < lo) lo = v; if (v > hi) hi = v; } };
    for (const s of this.series) {
      if (s.hidden) continue;
      if (s.type === 'scatter') for (const [x, y] of s.data) { take(y); if (x < xlo) xlo = x; if (x > xhi) xhi = x; }
      else if (s.type === 'band') { s.lo.forEach(take); s.hi.forEach(take); }
      else if (s.type === 'hline') take(s.y);
      else if (s.type === 'vline') continue;
      else (s.data ?? []).forEach(take);
      if (s.type === 'bars') take(s.base ?? 0);
    }
    if (this.o.zero) take(0);
    if (Number.isFinite(this.o.yMin)) lo = this.o.yMin;
    if (Number.isFinite(this.o.yMax)) hi = this.o.yMax;
    if (!Number.isFinite(lo)) { lo = 0; hi = 1; }
    const log = this.o.log && lo > 0;
    const fy = log ? Math.log : (v) => v;
    let L = fy(lo), Hh = fy(hi);
    if (Hh === L) { L -= 1; Hh += 1; }
    const padY = (Hh - L) * 0.06;
    if (!Number.isFinite(this.o.yMin)) L -= padY;
    if (!Number.isFinite(this.o.yMax)) Hh += padY;
    if (n) { xlo = Math.min(xlo, xs[0]); xhi = Math.max(xhi, xs[n - 1]); }
    if (!Number.isFinite(xlo)) { xlo = 0; xhi = 1; }
    if (xhi === xlo) xhi = xlo + 1;
    const X = (x) => x0 + ((x - xlo) / (xhi - xlo)) * (x1 - x0), Y = (v) => y1 - ((fy(v) - L) / (Hh - L)) * (y1 - y0);
    this.map = { X, Y, xs, x0, x1, y0, y1, xlo, xhi };
    // grille + axes
    ctx.font = '10.5px Verdana, Tahoma, sans-serif';
    ctx.textBaseline = 'middle';
    const yt = log ? niceTicks(lo, hi, 5) : niceTicks(L, Hh, Math.max(2, Math.round((y1 - y0) / 42)));
    const yf = this.o.yFormat ?? ((v) => num(v, Math.min(4, yt.dec)));
    ctx.fillStyle = th.text;
    ctx.textAlign = 'right';
    for (const v of yt.ticks) {
      const y = Math.round(Y(v)) + 0.5;
      if (y < y0 - 1 || y > y1 + 1) continue;
      ctx.fillStyle = th.grid;
      ctx.fillRect(x0, y, x1 - x0, 1);
      ctx.fillStyle = th.text;
      ctx.fillText(yf(v), x0 - 5, y);
    }
    ctx.textAlign = 'center';
    const xf = this.o.xFormat ?? ((x) => num(x, 0));
    const xt = this.o.xTickValues ?? niceTicks(xlo, xhi, Math.max(2, Math.min(this.o.xTicks, Math.floor((x1 - x0) / 70)))).ticks;
    let lastX = -1e9;
    for (const v of xt) {
      const x = Math.round(X(v)) + 0.5;
      if (x < x0 - 1 || x > x1 + 1) continue;
      const t = xf(v), w = ctx.measureText(t).width;
      if (x - w / 2 < lastX + 8) continue;
      lastX = x + w / 2;
      ctx.fillStyle = th.grid;
      ctx.fillRect(x, y0, 1, y1 - y0);
      ctx.fillStyle = th.text;
      ctx.fillText(t, Math.min(W - w / 2 - 2, Math.max(w / 2 + 2, x)), y1 + 13);
    }
    ctx.fillStyle = th.axis;
    ctx.fillRect(x0, y1, x1 - x0, 1);
    ctx.fillRect(x0, y0, 1, y1 - y0);
    if (this.o.yLabel) { ctx.save(); ctx.translate(11, (y0 + y1) / 2); ctx.rotate(-Math.PI / 2); ctx.fillStyle = th.text; ctx.fillText(this.o.yLabel, 0, 0); ctx.restore(); }
    // séries
    ctx.save();
    ctx.beginPath();
    ctx.rect(x0, y0 - 2, x1 - x0, y1 - y0 + 4);
    ctx.clip();
    this.series.forEach((s, k) => {
      if (s.hidden) return;
      const col = s.color ?? PALETTE[k % PALETTE.length];
      if (s.type === 'band') {
        ctx.fillStyle = col;
        ctx.globalAlpha = s.alpha ?? 0.18;
        ctx.beginPath();
        let started = false;
        for (let i = 0; i < n; i++) if (Number.isFinite(s.hi[i])) { const x = X(xs[i]), y = Y(s.hi[i]); if (!started) { ctx.moveTo(x, y); started = true; } else ctx.lineTo(x, y); }
        for (let i = n - 1; i >= 0; i--) if (Number.isFinite(s.lo[i])) ctx.lineTo(X(xs[i]), Y(s.lo[i]));
        ctx.closePath();
        ctx.fill();
        ctx.globalAlpha = 1;
      } else if (s.type === 'bars') {
        const w = Math.max(1, ((x1 - x0) / Math.max(1, n)) * (s.widthRatio ?? 0.8)), base = Y(s.base ?? (log ? lo : 0));
        for (let i = 0; i < n; i++) {
          const v = s.data[i];
          if (!Number.isFinite(v)) continue;
          ctx.fillStyle = typeof s.colorOf === 'function' ? s.colorOf(v, i) : col;
          const y = Y(v);
          ctx.fillRect(X(xs[i]) - w / 2, Math.min(y, base), w, Math.max(1, Math.abs(base - y)));
        }
      } else if (s.type === 'scatter') {
        ctx.fillStyle = col;
        for (const [x, y, c] of s.data) {
          if (c) ctx.fillStyle = c;
          ctx.beginPath();
          ctx.arc(X(x), Y(y), s.r ?? 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      } else if (s.type === 'hline') {
        ctx.strokeStyle = col;
        ctx.lineWidth = s.width ?? 1;
        ctx.setLineDash(s.dash ?? [4, 3]);
        const y = Math.round(Y(s.y)) + 0.5;
        ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke();
        ctx.setLineDash([]);
        if (s.label) { ctx.fillStyle = col; ctx.textAlign = 'right'; ctx.fillText(s.label, x1 - 4, y - 7); }
      } else if (s.type === 'vline') {
        ctx.strokeStyle = col;
        ctx.setLineDash(s.dash ?? [4, 3]);
        const x = Math.round(X(s.x)) + 0.5;
        ctx.beginPath(); ctx.moveTo(x, y0); ctx.lineTo(x, y1); ctx.stroke();
        ctx.setLineDash([]);
        if (s.label) { ctx.fillStyle = col; ctx.textAlign = 'left'; ctx.fillText(s.label, x + 4, y0 + 8); }
      } else {
        ctx.strokeStyle = col;
        ctx.lineWidth = s.width ?? 1.6;
        ctx.globalAlpha = s.alpha ?? 1;
        ctx.setLineDash(s.dash ?? []);
        ctx.beginPath();
        let started = false, firstX = 0, lastXp = 0;
        for (let i = 0; i < n; i++) {
          const v = s.data[i];
          if (!Number.isFinite(v)) { started = false; continue; }
          const x = X(xs[i]), y = Y(v);
          if (!started) { ctx.moveTo(x, y); started = true; firstX = x; } else if (s.step) { ctx.lineTo(x, Y(s.data[i - 1])); ctx.lineTo(x, y); } else ctx.lineTo(x, y);
          lastXp = x;
        }
        ctx.stroke();
        ctx.globalAlpha = 1;
        ctx.setLineDash([]);
        if (s.area) {
          ctx.lineTo(lastXp, y1);
          ctx.lineTo(firstX, y1);
          ctx.closePath();
          ctx.globalAlpha = 0.12;
          ctx.fillStyle = col;
          ctx.fill();
          ctx.globalAlpha = 1;
        }
      }
    });
    ctx.restore();
    // légende
    const named = this.series.filter((s) => s.name && !s.hidden);
    if (this.o.legend && named.length) {
      ctx.textAlign = 'left';
      let lx = x0 + 6;
      const ly = y0 + 8;
      const total = named.reduce((a, s) => a + ctx.measureText(s.name).width + 22, 0);
      ctx.fillStyle = th.legendBg;
      ctx.fillRect(x0 + 2, y0 + 1, Math.min(total + 4, x1 - x0 - 4), 15);
      named.forEach((s) => {
        const col = s.color ?? PALETTE[this.series.indexOf(s) % PALETTE.length];
        ctx.fillStyle = col;
        ctx.fillRect(lx, ly - 3, 10, s.type === 'band' || s.type === 'bars' ? 7 : 2);
        ctx.fillStyle = th.text;
        ctx.fillText(s.name, lx + 13, ly);
        lx += ctx.measureText(s.name).width + 22;
      });
    }
    // réticule
    if (this.o.tooltip && this.hover && n && this.hover.x >= x0 && this.hover.x <= x1) {
      let best = 0, bd = Infinity;
      for (let i = 0; i < n; i++) { const d = Math.abs(X(xs[i]) - this.hover.x); if (d < bd) { bd = d; best = i; } }
      const x = Math.round(X(xs[best])) + 0.5;
      ctx.strokeStyle = th.cross;
      ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(x, y0); ctx.lineTo(x, y1); ctx.stroke();
      ctx.setLineDash([]);
      const lines = [this.o.tipX ? this.o.tipX(xs[best], best) : xf(xs[best])];
      for (const s of this.series) {
        if (s.hidden || !s.name || s.type === 'hline' || s.type === 'vline' || s.type === 'scatter') continue;
        const v = s.type === 'band' ? `${yf(s.lo[best])} … ${yf(s.hi[best])}` : Number.isFinite(s.data?.[best]) ? (s.tipFormat ?? yf)(s.data[best]) : '—';
        lines.push(`${s.name} : ${v}`);
      }
      const tw = Math.max(...lines.map((t) => ctx.measureText(t).width)) + 12, tH = lines.length * 14 + 6;
      const tx = x + 10 + tw > x1 ? x - 10 - tw : x + 10, ty = Math.min(y1 - tH, Math.max(y0, this.hover.y - tH / 2));
      ctx.fillStyle = th.tag;
      ctx.globalAlpha = 0.92;
      ctx.fillRect(tx, ty, tw, tH);
      ctx.globalAlpha = 1;
      ctx.fillStyle = th.tagFg;
      ctx.textAlign = 'left';
      lines.forEach((t, i) => ctx.fillText(t, tx + 6, ty + 10 + i * 14));
    }
  }
}

/** Histogramme : valeurs → classes (bornes régulières). */
export function histogram(values, bins = 40, lo, hi) {
  const v = values.filter((x) => Number.isFinite(x));
  if (!v.length) return { xs: [], counts: [] };
  lo ??= Math.min(...v);
  hi ??= Math.max(...v);
  if (hi === lo) hi = lo + 1;
  const w = (hi - lo) / bins, counts = new Array(bins).fill(0);
  for (const x of v) counts[Math.min(bins - 1, Math.max(0, Math.floor((x - lo) / w)))]++;
  return { xs: counts.map((_, i) => lo + (i + 0.5) * w), counts, width: w };
}

/** Couleur divergente (−1 rouge … 0 neutre … +1 vert) ou séquentielle. */
export function divColor(v, max = 1) {
  const t = Math.max(-1, Math.min(1, v / (max || 1)));
  const dark = document.documentElement.dataset.theme === 'dark';
  const n = dark ? [30, 38, 48] : [246, 247, 249];
  const pos = dark ? [35, 170, 95] : [24, 150, 80], neg = dark ? [225, 80, 72] : [205, 52, 48];
  const c = t >= 0 ? pos : neg, a = Math.abs(t) ** 0.8;
  return `rgb(${Math.round(n[0] + (c[0] - n[0]) * a)},${Math.round(n[1] + (c[1] - n[1]) * a)},${Math.round(n[2] + (c[2] - n[2]) * a)})`;
}

export class HeatGrid {
  /**
   * @param {HTMLCanvasElement} canvas
   * @param {{ rows:string[], cols:string[], values:(number|null)[][], max?:number, format?:(v)=>string, cell?:number, showValues?:boolean,
   *   color?:(v)=>string, rowTitle?:string, colTitle?:string, onClick?:(r,c)=>void, labelEvery?:number }} o
   */
  constructor(canvas, o) {
    this.cv = canvas;
    this.o = o;
    this.hover = null;
    canvas.addEventListener('mousemove', (e) => {
      const r = canvas.getBoundingClientRect();
      this.hover = { x: e.clientX - r.left, y: e.clientY - r.top };
      this.render();
    });
    canvas.addEventListener('mouseleave', () => { this.hover = null; this.render(); });
    canvas.addEventListener('click', () => { const c = this.#cellAt(); if (c && this.o.onClick) this.o.onClick(c.r, c.c); });
    this.ro = new ResizeObserver(() => this.render());
    this.ro.observe(canvas);
  }

  set(o) {
    Object.assign(this.o, o);
    this.render();
  }

  destroy() {
    this.ro.disconnect();
  }

  #geom() {
    const { rows, cols } = this.o, W = this.cv.clientWidth;
    const left = this.o.left ?? Math.min(170, 12 + Math.max(...rows.map((s) => s.length)) * 6.2);
    const top = this.o.top ?? (this.o.colsVertical ? Math.min(120, 12 + Math.max(...cols.map((s) => s.length)) * 6) : 18);
    const cw = Math.max(2, (W - left - 8) / cols.length), ch = this.o.cell ?? Math.max(4, Math.min(22, cw));
    return { left, top, cw, ch, W, H: top + ch * rows.length + 22 };
  }

  #cellAt() {
    if (!this.hover || !this.g) return null;
    const { left, top, cw, ch } = this.g, c = Math.floor((this.hover.x - left) / cw), r = Math.floor((this.hover.y - top) / ch);
    if (r < 0 || c < 0 || r >= this.o.rows.length || c >= this.o.cols.length) return null;
    return { r, c };
  }

  render() {
    const cv = this.cv, dpr = window.devicePixelRatio || 1;
    if (!cv.clientWidth || !this.o.rows.length) return;
    const g = (this.g = this.#geom());
    cv.style.height = `${g.H}px`;
    cv.width = Math.round(g.W * dpr);
    cv.height = Math.round(g.H * dpr);
    const ctx = cv.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.font = '10px Verdana, Tahoma, sans-serif';
    ctx.textBaseline = 'middle';
    const { rows, cols, values } = this.o, text = css('--c-text'), color = this.o.color ?? ((v) => divColor(v, this.o.max ?? 1));
    const every = this.o.labelEvery ?? Math.max(1, Math.ceil(11 / g.ch));
    rows.forEach((name, r) => {
      if (r % every === 0) { ctx.fillStyle = text; ctx.textAlign = 'right'; ctx.fillText(name, g.left - 4, g.top + r * g.ch + g.ch / 2); }
      cols.forEach((_, c) => {
        const v = values[r][c];
        ctx.fillStyle = v === null || !Number.isFinite(v) ? css('--zebra') : color(v);
        ctx.fillRect(g.left + c * g.cw, g.top + r * g.ch, Math.ceil(g.cw), Math.ceil(g.ch));
        if (this.o.showValues && g.cw > 30 && g.ch > 13 && Number.isFinite(v)) {
          ctx.fillStyle = Math.abs(v / (this.o.max ?? 1)) > 0.55 ? '#fff' : text;
          ctx.textAlign = 'center';
          ctx.fillText((this.o.format ?? ((x) => num(x, 2)))(v), g.left + c * g.cw + g.cw / 2, g.top + r * g.ch + g.ch / 2);
        }
      });
    });
    ctx.fillStyle = text;
    const everyC = Math.max(1, Math.ceil((this.o.colsVertical ? 11 : 42) / g.cw));
    cols.forEach((name, c) => {
      if (c % everyC) return;
      const x = g.left + c * g.cw + g.cw / 2;
      if (this.o.colsVertical) { ctx.save(); ctx.translate(x, g.top - 4); ctx.rotate(-Math.PI / 2.6); ctx.textAlign = 'left'; ctx.fillText(name, 0, 0); ctx.restore(); }
      else { ctx.textAlign = 'center'; ctx.fillText(name, x, g.top + rows.length * g.ch + 10); }
    });
    const cell = this.#cellAt();
    if (cell) {
      const v = values[cell.r][cell.c];
      ctx.strokeStyle = css('--accent');
      ctx.lineWidth = 2;
      ctx.strokeRect(g.left + cell.c * g.cw, g.top + cell.r * g.ch, g.cw, g.ch);
      const t = `${rows[cell.r]} × ${cols[cell.c]} : ${v === null || !Number.isFinite(v) ? '—' : (this.o.format ?? ((x) => num(x, 3)))(v)}`;
      ctx.font = '11px Verdana, Tahoma, sans-serif';
      const tw = ctx.measureText(t).width + 12;
      const tx = Math.min(g.W - tw - 2, this.hover.x + 12), ty = Math.max(2, this.hover.y - 24);
      ctx.fillStyle = css('--c-tag-bg');
      ctx.fillRect(tx, ty, tw, 18);
      ctx.fillStyle = css('--c-tag-fg');
      ctx.textAlign = 'left';
      ctx.fillText(t, tx + 6, ty + 9);
    }
  }
}

/** Jauge demi-cercle SVG : valeur −1 … +1, libellé. */
export function gauge(value, label, { w = 170, title = '' } = {}) {
  const v = Number.isFinite(value) ? Math.max(-1, Math.min(1, value)) : 0, h = w * 0.62, cx = w / 2, cy = h - 14, R = w * 0.4;
  const arc = (a0, a1, col) => {
    const p = (a) => [cx + R * Math.cos(Math.PI - a * Math.PI), cy - R * Math.sin(Math.PI - a * Math.PI)];
    const [ax, ay] = p(a0), [bx, by] = p(a1);
    return `<path d="M${ax.toFixed(1)},${ay.toFixed(1)} A${R},${R} 0 0 1 ${bx.toFixed(1)},${by.toFixed(1)}" stroke="${col}" stroke-width="${(w * 0.075).toFixed(1)}" fill="none"/>`;
  };
  const segs = [[0, 0.25, '#d64541'], [0.25, 0.45, '#f08a7e'], [0.45, 0.55, '#b9c2cd'], [0.55, 0.75, '#7fd19c'], [0.75, 1, '#1e9e55']];
  const a = (v + 1) / 2, nx = cx + (R - 6) * Math.cos(Math.PI - a * Math.PI), ny = cy - (R - 6) * Math.sin(Math.PI - a * Math.PI);
  return `<svg class="gauge" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${title ? `<text x="${cx}" y="11" text-anchor="middle" font-size="10.5" fill="var(--muted)">${esc(title)}</text>` : ''}${segs.map(([x, y, c]) => arc(x + 0.004, y - 0.004, c)).join('')}<line x1="${cx}" y1="${cy}" x2="${nx.toFixed(1)}" y2="${ny.toFixed(1)}" stroke="var(--text)" stroke-width="2.2"/><circle cx="${cx}" cy="${cy}" r="4" fill="var(--text)"/><text x="${cx}" y="${cy + 13}" text-anchor="middle" font-size="11" font-weight="bold" fill="var(--title)">${esc(label ?? '')}</text></svg>`;
}

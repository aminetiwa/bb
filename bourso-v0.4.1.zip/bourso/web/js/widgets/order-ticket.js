// ============================================================================
//  BOURSO :: widgets/order-ticket.js — bon d'ordre (négociation FICTIVE) : achat / vente,
//  au marché, à cours limité, à déclenchement, stop limite ; validité jour ou à révocation.
//  Estimation exacte des frais : courtage + taxe sur les transactions financières (0,4 % à
//  l'achat d'actions françaises de plus d'1 Md€ de capitalisation).
// ============================================================================
import { get, post } from '../core/api.js';
import { S } from '../core/store.js';
import { live } from '../core/live.js';
import { modal, toast, $ } from '../core/dom.js';
import { price, money, num, esc, eur, decOf } from '../core/fmt.js';

export function orderTicket(root, { sym, side = 'BUY', compact = false, onPlaced } = {}) {
  const info = S.info(sym), tick = info?.tick ?? 0.01, dec = decOf(tick);
  root.innerHTML = `
    <div class="form col" style="gap:7px">
      <div class="row wrap-ok"><b class="grow" style="color:var(--title)">${esc(info?.name ?? sym)} <small class="muted">${esc(info?.code ?? '')} · ${esc(info?.ex ?? '')}</small></b>
        <span class="small muted" ${S.real ? 'title="Fourchette ESTIMÉE : dernier cours différé ± 0,05 % (aucune source gratuite ne donne le carnet)"' : ''}>Achat ${S.real ? '≈ ' : ''}<b class="up" data-k="bid">—</b> / Vente ${S.real ? '≈ ' : ''}<b class="down" data-k="ask">—</b></span></div>
      <div class="row wrap-ok">
        <div class="seg" data-k="side"><button type="button" data-v="BUY">Achat (F1)</button><button type="button" data-v="SELL">Vente (F2)</button></div>
        <select data-k="type" title="Type d'ordre"><option value="MKT">Au marché</option><option value="LMT">À cours limité</option><option value="STP">À déclenchement (stop)</option><option value="STL">Stop limite</option></select>
        <select data-k="tif" title="Validité"><option value="DAY">Jour</option><option value="GTC">À révocation</option></select>
      </div>
      <div class="row wrap-ok">
        <label class="f">Quantité<input type="number" data-k="qty" min="1" step="1" value="10"></label>
        <label class="f" data-show="LMT STL">Limite<input type="number" data-k="limit" step="${tick}"></label>
        <label class="f" data-show="STP STL">Déclenchement<input type="number" data-k="stop" step="${tick}"></label>
        <label class="f">Montant visé (€)<input type="number" data-k="amount" min="0" step="100" placeholder="ex. 5000"></label>
      </div>
      <table class="kv small" data-k="est"></table>
      <div class="row"><button class="btn buy grow" type="button" data-k="send">Passer l'ordre</button></div>
      ${compact ? '' : `<div class="help-text">${S.real
        ? 'Ordre <b>fictif</b> : exécuté pendant la séance de la place, au dernier cours différé ± une demi-fourchette estimée (0,05 %). Hors séance, il attend l\'ouverture. Aucun ordre ne quitte la machine.'
        : 'Ordre exécuté sur la fourchette simulée (achat au prix vendeur, vente au prix acheteur). Aucun ordre ne quitte la machine.'}</div>`}
    </div>`;
  const q = (k) => root.querySelector(`[data-k="${k}"]`);
  let s = side, timer = null;
  const setSide = (v) => {
    s = v;
    for (const b of q('side').children) b.classList.toggle('on', b.dataset.v === v);
    const send = q('send');
    send.className = `btn ${v === 'BUY' ? 'buy' : 'sell'} grow`;
    send.textContent = v === 'BUY' ? 'Acheter' : 'Vendre';
    estimate();
  };
  const showFields = () => {
    const t = q('type').value;
    for (const l of root.querySelectorAll('[data-show]')) l.style.display = l.dataset.show.split(' ').includes(t) ? '' : 'none';
    const qt = S.quote(sym);
    if (qt && !q('limit').value) q('limit').value = qt.last.toFixed(dec);
    if (qt && !q('stop').value) q('stop').value = qt.last.toFixed(dec);
    estimate();
  };
  const refPx = () => {
    const qt = S.quote(sym), t = q('type').value;
    if (t === 'LMT' || t === 'STL') return Number(q('limit').value) || qt?.last;
    if (t === 'STP') return Number(q('stop').value) || qt?.last;
    return s === 'BUY' ? qt?.ask : qt?.bid;
  };
  const estimate = () => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const qty = Math.floor(Number(q('qty').value)), px = refPx();
      if (!(qty > 0) || !(px > 0)) { q('est').innerHTML = ''; return; }
      try {
        const f = await get(`/api/fees?sym=${encodeURIComponent(sym)}&side=${s}&qty=${qty}&px=${px}`);
        q('est').innerHTML = `<tr><th>Prix de référence</th><td>${price(px, tick)} ${esc(info?.ccy ?? '')}</td></tr>
          <tr><th>Montant</th><td>${eur(f.notionalEur, 2)}</td></tr>
          <tr><th>Courtage</th><td>${eur(f.commission, 2)}</td></tr>
          <tr><th title="${esc(f.ttfSource ?? '')}">TTF ${f.ttfEligible ? '(0,4 %)' : ''}</th><td>${f.ttf ? eur(f.ttf, 2) : `<span class="muted">${s === 'SELL' ? 'non (achats seulement)' : `non (${esc(f.ttfReason ?? 'non concernée')})`}</span>`}</td></tr>
          <tr><th>Total ${s === 'BUY' ? 'débité' : 'crédité'}</th><td>${eur(s === 'BUY' ? f.notionalEur + f.total : f.notionalEur - f.total, 2)}</td></tr>`;
      } catch (e) { q('est').innerHTML = `<tr><td class="err">${esc(e.message)}</td></tr>`; }
    }, 120);
  };
  q('side').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) setSide(b.dataset.v); });
  q('type').addEventListener('change', showFields);
  for (const k of ['qty', 'limit', 'stop']) q(k).addEventListener('input', estimate);
  q('amount').addEventListener('input', async () => {
    const amt = Number(q('amount').value), px = refPx();
    if (!(amt > 0) || !(px > 0)) return;
    const fx = await get(`/api/fees?sym=${encodeURIComponent(sym)}&side=${s}&qty=1&px=${px}`).catch(() => null);
    const unitEur = fx ? fx.notionalEur : px;
    q('qty').value = Math.max(1, Math.floor(amt / unitEur));
    estimate();
  });
  q('send').addEventListener('click', async () => {
    const body = { sym, side: s, type: q('type').value, qty: Math.floor(Number(q('qty').value)), tif: q('tif').value };
    if (body.type === 'LMT' || body.type === 'STL') body.limit = Number(q('limit').value);
    if (body.type === 'STP' || body.type === 'STL') body.stop = Number(q('stop').value);
    q('send').disabled = true;
    try {
      const o = await post('/api/orders', body);
      toast(o.status === 'FILLED' ? `Ordre ${S.real ? 'fictif ' : ''}exécuté` : `Ordre ${S.real ? 'fictif ' : ''}enregistré`, `${s === 'BUY' ? 'Achat' : 'Vente'} de ${num(o.qty, 0)} ${esc(o.name)}${o.status === 'FILLED' ? ` à ${price(o.avgPx, tick)} — frais ${money(o.fees, 'EUR')}` : ` — ${esc(o.waiting ?? 'en attente de déclenchement')}`}`, 'ok');
      onPlaced?.(o);
    } catch (e) {
      toast('Ordre refusé', esc(e.message), 'ko');
    } finally {
      q('send').disabled = false;
    }
  });
  const upd = () => {
    const qt = S.quote(sym);
    if (!qt) return;
    q('bid').textContent = price(qt.bid, tick);
    q('ask').textContent = price(qt.ask, tick);
  };
  const offQ = S.on('quotes', (ch) => { if (!ch || ch.some((x) => x.sym === sym)) upd(); });
  const unsub = live.sub(sym);
  setSide(side);
  showFields();
  upd();
  return { destroy() { offQ(); unsub(); clearTimeout(timer); }, setSide };
}

/** Bon d'ordre en fenêtre (raccourcis F1 / F2). */
export function openTicket(sym, side = 'BUY') {
  if (!S.info(sym)) return;
  const div = document.createElement('div');
  let t = null;
  modal({ title: `Passer un ordre — ${S.name(sym)}`, body: div, onClose: () => t?.destroy() });
  t = orderTicket(div, { sym, side, onPlaced: () => $('#modal-box [data-x]')?.click() });
}

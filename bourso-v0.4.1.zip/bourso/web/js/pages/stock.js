// ============================================================================
//  BOURSO :: pages/stock.js — GRAPHIQUE & FICHE VALEUR (#/valeur/SYM).
//
//  En-tête de cotation complet · graphique pro (13 unités de temps de 1 s à 1 mois, 6 types,
//  ~40 indicateurs, ~45 outils de tracé, profil de volume, plan de l'IA, ordres, alertes,
//  repères) · carnet d'ordres · transactions · bon d'ordre · dernière analyse de l'IA ·
//  niveaux clés · alertes · onglets : synthèse technique, statistiques, dossier de l'IA,
//  profil de marché (TPO), saisonnalité, performances, fondamentaux, actualités, historique.
// ============================================================================
import { S, prefs } from '../core/store.js';
import { get, post, put, del, history, download } from '../core/api.js';
import { live } from '../core/live.js';
import { $, el, on, modal, toast, flash, setHtml, setText, saveFile, tabs, meter, confirmBox } from '../core/dom.js';
import { esc, num, int, pct, price as fprice, cls, big, eur, money, ago, dur, decisionChip, ratingChip, DECISION, ymd, decOf, sci, dateTime } from '../core/fmt.js';
import { nameCell, chg, newsItem, symHref } from '../core/ui.js';
import { ProChart, CHART_TYPES } from '../chart/engine.js';
import { DrawingManager, TOOLS, TOOL_GROUPS, ICONS, FIB_DEFAULT } from '../chart/drawings.js';
import { INDICATORS, GROUPS, makeIndicator, labelOf } from '../chart/indicators.js';
import { buildTimescale, dayNum } from '../chart/timescale.js';
import { orderTicket } from '../widgets/order-ticket.js';
import { Plot, HeatGrid, gauge, histogram, divColor } from '../widgets/plot.js';
import { marketProfile } from '/src/core/quant/tpo.js';
import * as V from '/src/core/quant/volatility.js';
import { pivots as pivotCalc } from '/src/core/quant/indicators.js';

const TFS = ['1s', '5s', '15s', '1m', '2m', '5m', '15m', '30m', '1h', '4h', '1D', '1W', '1M'];
const TF_LABEL = { '1s': '1 s', '5s': '5 s', '15s': '15 s', '1m': '1 min', '2m': '2 min', '5m': '5 min', '15m': '15 min', '30m': '30 min', '1h': '1 h', '4h': '4 h', '1D': 'Jour', '1W': 'Semaine', '1M': 'Mois' };
const TF_BTN = { '1D': 'J', '1W': 'S', '1M': 'M' };
const RANGES = [['1j', 1], ['5j', 5], ['1m', 21], ['3m', 63], ['6m', 126], ['1a', 252], ['5a', 1260]];
const SWATCH = ['#1f6fd1', '#f28c18', '#1e9e55', '#d64541', '#7b4fc9', '#0f8f8f', '#c2185b', '#8d6e63', '#1a3d66', '#c49000', '#787b86', '#000000'];
const DEFAULT_LAYOUT = {
  tf: '15m', type: 'candles',
  indicators: [{ type: 'ema', params: { n: 20 } }, { type: 'sma', params: { n: 50 }, colors: ['#f28c18'] }, { type: 'sma', params: { n: 200 }, colors: ['#7b4fc9'] }, { type: 'vwap', params: { bands: 1 } }, { type: 'rsi', params: { n: 14 } }, { type: 'macd', params: {} }],
  opts: { volume: true, vp: false, log: false, magnet: 'weak', plan: true, orders: true, alerts: true, markers: true, sessions: true, hiLo: true, watermark: true },
};

export default {
  title: 'Graphique',
  async mount(root, ctx) {
    let sym = ctx.params[0] && S.info(ctx.params[0]) ? ctx.params[0] : S.lastSym;
    if (!S.info(sym)) sym = S.universe[0].sym;
    if (!ctx.params[0]) window.history.replaceState(null, '', `#/valeur/${encodeURIComponent(sym)}`);
    const page = new StockPage(root);
    await page.open(sym);
    return {
      get sym() { return page.sym; },
      update(c) {
        const s = c.params[0];
        if (s && S.info(s) && s !== page.sym) page.open(s);
      },
      unmount() { page.destroy(); },
    };
  },
};

class StockPage {
  constructor(root) {
    this.root = root;
    this.layout = prefs.get('chart.layout', DEFAULT_LAYOUT);
    this.layout.opts = { ...DEFAULT_LAYOUT.opts, ...(this.layout.opts ?? {}) };
    // données réelles : pas de bougies à la seconde avec les sources gratuites
    this.tfs = S.caps.seconds ? TFS : TFS.filter((t) => !t.endsWith('s'));
    if (!this.tfs.includes(this.layout.tf)) this.layout.tf = '15m';
    this.offs = [];
    this.tape = [];
    root.innerHTML = this.#html();
    this.$ = (s) => root.querySelector(s);
    this.chart = new ProChart(this.$('#c-wrap'), { type: this.layout.type, ...this.layout.opts });
    this.dm = new DrawingManager(this.chart, {
      onChange: (list) => this.#saveDrawings(list),
      onStatus: (t) => this.#hint(t),
      onEdit: (d) => this.#editDrawing(d),
      onTool: (t) => this.#syncTools(t),
    });
    this.#buildToolbar();
    this.#buildDrawBar();
    this.#bindChart();
    this.indicators = (this.layout.indicators ?? []).map((x) => ({ ...makeIndicator(x.type, x.params), ...(x.colors ? { colors: x.colors } : {}), height: x.height ?? 0.18, visible: x.visible !== false })).filter(Boolean);
    this.chart.setIndicators(this.indicators);
    this.offs.push(
      S.on('quotes', (ch) => { if (!ch || ch.some((q) => q.sym === this.sym)) this.#renderQuote(); }),
      S.on('screener', () => this.#renderQuote(true)),
      S.on('theme', () => setTimeout(() => this.chart.refreshTheme(), 30)),
      S.on('favorites', () => this.#renderQuote(true)),
      S.on('ai', (m) => this.#onAi(m)),
      S.on('news', (n) => { if (n.sym === this.sym) { this.#markers(); if (this.tab === 'news') this.#tabNews(); } }),
      live.on('live', (m) => this.#onLive(m)),
      live.on('pf', () => this.#loadOrders()),
      live.on('alerts', () => this.#loadAlerts()),
      live.on('rollover', (m) => { if (S.info(this.sym)?.mic === m.mic) setTimeout(() => this.#loadTf(this.tf, true), 500); }),
    );
    // données réelles : pas de carnet ; l'heure et la source du cours sont relues toutes les 30 s
    this.bookTimer = S.caps.book ? setInterval(() => this.#loadBook(), 900) : setInterval(() => this.#refreshMeta(), 30_000);
    this.tabsCtl = tabs(this.$('#s-tabs'), [
      { id: 'tech', label: 'Synthèse technique' }, { id: 'stats', label: 'Statistiques' }, { id: 'dossier', label: 'Dossier de l\'IA' },
      { id: 'tpo', label: 'Profil de marché' }, { id: 'season', label: 'Saisonnalité' }, { id: 'perf', label: 'Performances' },
      { id: 'fund', label: 'Fondamentaux' }, { id: 'news', label: 'Actualités' }, { id: 'hist', label: 'Historique' },
    ], (id) => this.#tab(id), prefs.get('stock.tab', 'tech'));
  }

  destroy() {
    this.dead = true;
    this.offs.forEach((f) => f());
    this.unsubLive?.();
    clearInterval(this.bookTimer);
    this.ticket?.destroy();
    this.plots?.forEach((p) => p.destroy?.());
    this.chart.destroy();
    this.ctxMenu?.remove();
  }

  #html() {
    return `
      <section class="box" id="s-quote"></section>
      <div class="layout l2">
        <div>
          <section class="box chart-box" id="s-chartbox">
            <div class="chart-toolbar" id="c-tb"></div>
            <div class="chart-area"><div class="draw-bar" id="c-draw"></div><div class="chart-wrap" id="c-wrap"><div class="chart-hint hidden" id="c-hint"></div></div></div>
            <div class="chart-status" id="c-status"></div>
          </section>
          <section class="box"><div id="s-tabs"></div><div id="s-tab"></div></section>
        </div>
        <aside>
          <section class="box"><h2 class="box-title"><span class="ico">◆</span>Analyse de l'IA <span class="tools"><button class="btn btn-xs primary" id="ai-run">Analyser maintenant</button></span></h2><div id="ai-box"></div></section>
          ${S.caps.book ? '<section class="box"><h2 class="box-title"><span class="ico">≣</span>Carnet d\'ordres <span class="title-note" id="book-note"></span></h2><table class="tbl compact book" id="book"></table></section>' : ''}
          ${S.caps.tape ? '<section class="box"><h2 class="box-title"><span class="ico">⇄</span>Transactions <span class="title-note" id="flow-note"></span></h2><div class="scroll" style="max-height:230px"><table class="tbl compact trades" id="tape"></table></div></section>' : ''}
          <section class="box"><h2 class="box-title"><span class="ico">✎</span>Passer un ordre <span class="title-note">${S.real ? 'fictif' : 'simulé'} · F1 / F2</span></h2><div id="ticket"></div></section>
          ${S.caps.book ? '' : '<section class="box"><h2 class="box-title"><span class="ico">ⓘ</span>Données de cette valeur</h2><div id="data-info" class="box-body small"></div></section>'}
          <section class="box"><h2 class="box-title"><span class="ico">⌖</span>Niveaux clés</h2><div id="levels"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">⏰</span>Alertes sur la valeur</h2><div id="alerts"></div></section>
        </aside>
      </div>`;
  }

  // ======================================================================= ouverture d'une valeur
  async open(sym) {
    this.sym = sym;
    this.info = S.info(sym);
    S.remember(sym);
    document.title = `${this.info.name} — Bourso`;
    this.tick = this.info.tick;
    this.meta = await get(`/api/quote/${encodeURIComponent(sym)}`);
    this.#renderQuote(true);
    this.tape = [];
    this.lastSeq = 0;
    this.ticket?.destroy();
    this.ticket = orderTicket(this.$('#ticket'), { sym, compact: true });
    const drawings = await get(`/api/drawings/${encodeURIComponent(sym)}`).catch(() => []);
    this.drawingsLoaded = false;
    await this.#loadTf(this.layout.tf);
    this.dm.load(drawings);
    this.drawingsLoaded = true;
    await Promise.all([this.#loadAi(), this.#loadOrders(), this.#loadAlerts(), this.#loadBook(), this.#levels()]);
    this.#tab(this.tab ?? prefs.get('stock.tab', 'tech'));
  }

  async #loadTf(tf, keepView = false) {
    const seq = (this.loadSeq = (this.loadSeq ?? 0) + 1);
    this.tf = tf;
    this.layout.tf = tf;
    this.#saveLayout();
    this.#syncToolbar();
    let h;
    try {
      h = await history(this.sym, tf);
    } catch (e) {
      toast('Historique indisponible', esc(e.message), 'ko');
      return;
    }
    if (seq !== this.loadSeq || this.dead) return;
    this.header = h.header;
    const ts = buildTimescale(h.header);
    this.chart.setData({ sym: this.sym, name: this.info.name, code: this.info.code, tf, tfLabel: TF_LABEL[tf], tick: this.tick, ccy: this.info.ccy, o: h.open, h: h.high, l: h.low, c: h.close, v: h.volume, ts }, { keepView });
    this.unsubLive?.();
    this.unsubLive = live.sub(this.sym, tf);
    this.#markers();
    this.#planLines();
    if (this.tab === 'tech') this.#tabTech();
  }

  // ======================================================================= en-tête de cotation
  #renderQuote(full = false) {
    const q = S.quote(this.sym), m = this.meta, r = S.row(this.sym), u = this.info;
    if (!m) return;
    const tk = this.tick, P = (v) => fprice(v, tk);
    if (full || !this.$('#q-last')) {
      const f = m.meta.fundamentals;
      setHtml(this.$('#s-quote'), `
        <div class="quote-head">
          <div class="quote-id">
            <h1>${esc(u.name)}</h1>
            <div class="quote-meta"><b>${esc(u.code)}</b> · ${esc(m.meta.exchange)} · ${u.isin ? `ISIN ${esc(u.isin)} · ` : ''}${esc(u.sector)} · ${esc(m.meta.countryName ?? u.country)} · ${esc(u.ccy)} · indice ${esc(m.meta.index)} · pas de cotation ${String(tk).replace('.', ',')}</div>
          </div>
          <div class="quote-actions">
            <button class="btn ${S.isFav(this.sym) ? 'fav-on' : ''}" id="q-fav">${S.isFav(this.sym) ? '★ Favori' : '☆ Ajouter aux favoris'}</button>
            <button class="btn primary" id="q-ai">◆ Analyser avec l'IA</button>
            <a class="btn" href="#/agent/new?sym=${encodeURIComponent(this.sym)}">✉ Demander à Bourso Pro</a>
            <button class="btn" id="q-alert">⏰ Alerte</button>
            <button class="btn buy" id="q-buy">Acheter <small>F1</small></button>
            <button class="btn sell" id="q-sell">Vendre <small>F2</small></button>
          </div>
          <div class="quote-price"><span id="q-last" class="big">—</span> <span class="ccy">${esc(u.ccy)}</span><div id="q-chg" class="chg">—</div><div class="small muted" id="q-time"></div></div>
        </div>
        <div class="quote-stats" id="q-stats"></div>`);
      this.$('#q-fav').onclick = async () => { await S.toggleFav(this.sym); toast(S.isFav(this.sym) ? 'Ajouté aux favoris' : 'Retiré des favoris', esc(u.name), 'ok', 2000); };
      this.$('#q-ai').onclick = () => this.#runAi();
      this.$('#q-alert').onclick = () => this.#newAlert();
      this.$('#q-buy').onclick = () => this.#focusTicket('BUY');
      this.$('#q-sell').onclick = () => this.#focusTicket('SELL');
      void f;
    }
    if (!q) return;
    const last = this.$('#q-last');
    if (last.textContent !== P(q.last)) { last.textContent = P(q.last); flash(last, q.dir); }
    setHtml(this.$('#q-chg'), `<span class="${cls(q.chgPct)}">${q.last - q.prev >= 0 ? '+' : ''}${P(q.last - q.prev)} (${pct(q.chgPct)})</span>`);
    const f = m.meta.fundamentals, spread = q.ask - q.bid, mid = (q.ask + q.bid) / 2, sim = S.real ? '' : ' (sim.)';
    if (S.real) {
      const at = m.meta.quoteAt;
      setHtml(this.$('#q-time'), `${at ? `cours du ${dateTime(at)} · ` : ''}différé · ${esc(m.meta.quoteSource ?? 'source en attente')}`);
    }
    const cells = [
      ['Ouverture', P(q.open)], ['Plus haut', P(q.high)], ['Plus bas', P(q.low)], ['Clôture veille', P(q.prev)],
      ['Volume', int(q.volume)], ['Capitaux', `${big(q.turnover)} ${esc(u.ccy)}`], ['VWAP', P(q.turnover / Math.max(1, q.volume))],
      ...(S.real ? [['Fourchette', '<span class="muted" title="Aucune source gratuite ne donne le carnet : la négociation fictive utilise le dernier cours ± 0,05 %">non disponible</span>']]
        : [['Achat / vente', `${P(q.bid)} / ${P(q.ask)}`], ['Écart', `${Math.round(spread / tk)} pas · ${num((spread / mid) * 1e4, 1)} pb`]]),
      ['+ haut 52 sem.', r?.hi52 ? `${P(r.hi52)} <small class="${cls(r.distHi52)}">${pct(r.distHi52, 1)}</small>` : '—'], ['+ bas 52 sem.', r?.lo52 ? `${P(r.lo52)} <small class="${cls(r.distLo52)}">${pct(r.distLo52, 1)}</small>` : '—'],
      ['Capitalisation', f.capitalisationMdEur ? `${num(f.capitalisationMdEur, 1)} Md€` : '—'], [`PER${sim}`, num(f.per, 1)], [`Rendement${sim}`, pct(f.rendementDividendePct, 2, false)], ['Bêta', num(m.meta.beta, 2)],
      ['Vol. moyen 20 j', r ? int(r.avgVol20) : '—'], ['Volume relatif', r?.relVol ? `× ${num(r.relVol, 2)}` : '—'], ['Volatilité 20 j', r ? pct(r.vol20, 1, false) : '—'], ['ATR 14', r ? pct(r.atrPct, 2, false) : '—'],
      ['RSI 14', r?.rsi14 ?? '—'], ['Perf. 1 mois', r ? chg(r.perf1m) : '—'], ['Perf. 1 an', r ? chg(r.perf1a) : '—'], ['Technique (J)', ratingChip(r?.rating, r?.ratingLabel)], ['Décision IA', this.lastSig ? decisionChip(this.lastSig.decision) : '<span class="chip none">—</span>'],
    ];
    setHtml(this.$('#q-stats'), cells.map(([k, v]) => `<div><span>${k}</span><b>${v}</b></div>`).join(''));
  }

  #focusTicket(side) {
    this.ticket?.setSide(side);
    this.$('#ticket').scrollIntoView({ behavior: 'smooth', block: 'center' });
    this.$('#ticket input[data-k="qty"]')?.focus();
  }

  // ======================================================================= barre d'outils du graphique
  #buildToolbar() {
    const tb = this.$('#c-tb');
    tb.innerHTML = `
      <div class="seg" id="tb-tf">${this.tfs.map((t) => `<button data-tf="${t}" title="${TF_LABEL[t]}">${TF_BTN[t] ?? t}</button>`).join('')}</div>
      <select id="tb-type" title="Type de graphique">${Object.entries(CHART_TYPES).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select>
      <button class="btn btn-small" id="tb-ind" title="Ajouter des indicateurs">ƒx Indicateurs</button>
      <span class="sep"></span>
      <div class="seg" id="tb-range" title="Période affichée">${RANGES.map(([l]) => `<button data-r="${l}">${l}</button>`).join('')}<button data-r="all">Tout</button></div>
      <label class="chk" title="Profil de volume de la zone visible (POC, zone de valeur 70 %)"><input type="checkbox" id="tb-vp"> Profil de volume</label>
      <button class="btn btn-small" id="tb-view" title="Volumes, échelle, plan de l'IA, ordres, repères…">Affichage ▾</button>
      <span class="sp"></span>
      <button class="btn btn-small" id="tb-reset" title="Recentrer (double-clic sur le graphique)">⟲</button>
      <button class="btn btn-small" id="tb-shot" title="Capture PNG">📷</button>
      <button class="btn btn-small" id="tb-csv" title="Exporter les bougies affichées (CSV)">CSV</button>
      <button class="btn btn-small" id="tb-full" title="Plein écran">⛶</button>`;
    on(tb, 'click', '[data-tf]', (e, b) => this.#loadTf(b.dataset.tf));
    on(tb, 'click', '[data-r]', (e, b) => {
      const r = b.dataset.r;
      if (r === 'all') { this.chart.showAll(); return; }
      const days = RANGES.find(([l]) => l === r)[1], H = this.header;
      const bars = H.intraday ? Math.round((days * H.ex.sessionSec) / H.barSeconds) : this.tf === '1W' ? Math.ceil(days / 5) : this.tf === '1M' ? Math.ceil(days / 21) : days;
      this.chart.showLast(Math.max(5, Math.min(this.chart.n, bars)));
    });
    this.$('#tb-type').onchange = (e) => { this.layout.type = e.target.value; this.chart.setOptions({ type: e.target.value }); this.#saveLayout(); };
    const opt = (id, key, after) => {
      const c = this.$(id);
      c.checked = Boolean(this.layout.opts[key]);
      c.onchange = () => { this.layout.opts[key] = c.checked; this.chart.setOptions({ [key]: c.checked }); this.#saveLayout(); after?.(); };
    };
    opt('#tb-vp', 'vp');
    const VIEW = [['volume', 'Volumes en bas du graphique'], ['log', 'Échelle logarithmique'], ['plan', 'Plan de l\'IA (zone d\'entrée, stop, objectifs)'], ['orders', 'Ordres en attente, prix de revient, alertes'],
      ['markers', 'Repères : décisions de l\'IA, exécutions, actualités'], ['sessions', 'Séparateurs de séances'], ['hiLo', 'Plus haut / plus bas visibles'], ['watermark', 'Filigrane (valeur et unité)']];
    this.$('#tb-view').onclick = (e) => {
      e.stopPropagation();
      this.viewPop?.remove();
      const b = this.$('#tb-view').getBoundingClientRect(), host = this.$('#s-chartbox').getBoundingClientRect();
      const pop = el(`<div class="tool-pop" style="left:${b.left - host.left}px;top:${b.bottom - host.top + 2}px;padding:4px 0">${VIEW.map(([k, l]) => `<label class="chk" style="display:flex;padding:4px 12px"><input type="checkbox" data-o="${k}" ${this.chart.opt[k] ? 'checked' : ''}> ${l}</label>`).join('')}</div>`);
      this.$('#s-chartbox').append(pop);
      this.viewPop = pop;
      pop.addEventListener('click', (ev) => ev.stopPropagation());
      pop.addEventListener('change', (ev) => {
        const k = ev.target.dataset.o, v = ev.target.checked;
        this.layout.opts[k] = v;
        this.chart.setOptions({ [k]: v });
        this.#saveLayout();
        if (k === 'plan' || k === 'orders') this.#planLines();
        if (k === 'markers') this.#markers();
      });
      setTimeout(() => document.addEventListener('click', () => pop.remove(), { once: true }), 0);
    };
    this.$('#tb-ind').onclick = () => this.#indicatorPicker();
    this.$('#tb-reset').onclick = () => this.chart.resetView();
    this.$('#tb-shot').onclick = () => {
      const url = this.chart.snapshot(`${this.info.name} (${this.info.code}) · ${TF_LABEL[this.tf]} · ${new Date().toLocaleString('fr-FR')} · Bourso (${S.real ? 'données Yahoo Finance, différées' : 'données simulées'})`);
      const a = Object.assign(document.createElement('a'), { href: url, download: `bourso_${this.info.code}_${this.tf}.png` });
      a.click();
    };
    this.$('#tb-csv').onclick = () => download(`/api/export/history.csv?sym=${encodeURIComponent(this.sym)}&tf=${this.tf}`);
    this.$('#tb-full').onclick = () => {
      const box = this.$('#s-chartbox');
      box.classList.toggle('full');
      this.$('#tb-full').textContent = box.classList.contains('full') ? '✕' : '⛶';
    };
    this.$('#tb-type').value = this.layout.type;
  }

  #syncToolbar() {
    for (const b of this.$('#tb-tf').children) b.classList.toggle('on', b.dataset.tf === this.tf);
  }

  #saveLayout() {
    this.layout.indicators = (this.indicators ?? this.layout.indicators).map((x) => ({ type: x.type, params: x.params, colors: x.colors, height: x.height, visible: x.visible }));
    prefs.set('chart.layout', this.layout);
  }

  // ======================================================================= barre des outils de tracé
  #buildDrawBar() {
    const bar = this.$('#c-draw'), last = prefs.get('chart.lastTools', {});
    this.groupTool = Object.fromEntries(TOOL_GROUPS.map((g) => [g.id, last[g.id] && g.tools.includes(last[g.id]) ? last[g.id] : g.tools[0]]));
    const btn = (g) => `<button class="more" data-group="${g.id}" title="${esc(g.name)} : ${esc(TOOLS[this.groupTool[g.id]].name)} (clic droit : liste)">${ICONS[this.groupTool[g.id]]}</button>`;
    bar.innerHTML = `<button data-cursor title="Curseur (Échap)" class="on">${ICONS.cursor}</button><hr>${TOOL_GROUPS.map(btn).join('')}<hr>
      <button data-mag title="Aimant OHLC : faible / fort / désactivé">🧲</button>
      <button data-hide title="Masquer / afficher les tracés">👁</button>
      <button data-undo title="Annuler (Ctrl+Z)">↶</button>
      <button data-redo title="Rétablir (Ctrl+Y)">↷</button>
      <button data-clear title="Effacer tous les tracés de la valeur">🗑</button>`;
    const pop = (g, b) => {
      this.toolPop?.remove();
      const r = b.getBoundingClientRect(), host = this.$('#s-chartbox').getBoundingClientRect();
      const p = el(`<div class="tool-pop" style="left:${r.right - host.left + 4}px;top:${Math.max(0, r.top - host.top - 4)}px"><div class="grp">${esc(g.name)}</div>${g.tools.map((t) => `<button data-t="${t}" class="${this.dm.tool === t ? 'on' : ''}">${ICONS[t]}<span>${esc(TOOLS[t].name)}</span>${TOOLS[t].key ? `<kbd>Alt+${TOOLS[t].key}</kbd>` : ''}</button>`).join('')}</div>`);
      this.$('#s-chartbox').append(p);
      this.toolPop = p;
      p.addEventListener('click', (e) => {
        const x = e.target.closest('[data-t]');
        if (!x) return;
        this.groupTool[g.id] = x.dataset.t;
        prefs.set('chart.lastTools', this.groupTool);
        b.outerHTML = btn(g);
        this.dm.setTool(x.dataset.t);
        p.remove();
      });
      setTimeout(() => document.addEventListener('click', () => p.remove(), { once: true }), 0);
    };
    bar.addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (!b) return;
      if (b.dataset.cursor !== undefined) this.dm.setTool(null);
      else if (b.dataset.group) {
        const g = TOOL_GROUPS.find((x) => x.id === b.dataset.group);
        if (this.dm.tool === this.groupTool[g.id] || e.offsetX > 20) pop(g, b);
        else this.dm.setTool(this.groupTool[g.id]);
      } else if (b.dataset.mag !== undefined) {
        const order = ['weak', 'strong', 'off'], cur = this.chart.opt.magnet, nx = order[(order.indexOf(cur) + 1) % 3];
        this.layout.opts.magnet = nx;
        this.chart.setOptions({ magnet: nx });
        this.#saveLayout();
        this.#syncTools(this.dm.tool);
        this.#hint(`Aimant : ${{ weak: 'faible (≤ 14 px)', strong: 'fort (toujours sur l\'OHLC)', off: 'désactivé' }[nx]}`, 1800);
      } else if (b.dataset.hide !== undefined) { this.dm.hideAll = !this.dm.hideAll; this.chart.invalidate(); this.#syncTools(this.dm.tool); }
      else if (b.dataset.undo !== undefined) this.dm.undo();
      else if (b.dataset.redo !== undefined) this.dm.redo();
      else if (b.dataset.clear !== undefined) confirmBox('Effacer tous les tracés de cette valeur ?', { danger: true, ok: 'Effacer' }).then((ok) => ok && this.dm.clear());
    });
    bar.addEventListener('contextmenu', (e) => {
      const b = e.target.closest('[data-group]');
      if (!b) return;
      e.preventDefault();
      pop(TOOL_GROUPS.find((x) => x.id === b.dataset.group), b);
    });
    this.#syncTools(null);
  }

  #syncTools(tool) {
    const bar = this.$('#c-draw');
    bar.querySelector('[data-cursor]').classList.toggle('on', !tool);
    for (const b of bar.querySelectorAll('[data-group]')) b.classList.toggle('on', tool && TOOL_GROUPS.find((g) => g.id === b.dataset.group).tools.includes(tool));
    const mag = bar.querySelector('[data-mag]');
    mag.classList.toggle('on', this.chart.opt.magnet !== 'off');
    mag.style.opacity = this.chart.opt.magnet === 'off' ? 0.45 : 1;
    mag.title = `Aimant OHLC : ${{ weak: 'faible', strong: 'fort', off: 'désactivé' }[this.chart.opt.magnet]} (clic pour changer)`;
    bar.querySelector('[data-hide]').style.opacity = this.dm.hideAll ? 0.45 : 1;
    if (!tool) this.#hint('');
  }

  #hint(text, ms = 0) {
    const h = this.$('#c-hint');
    h.textContent = text;
    h.classList.toggle('hidden', !text);
    clearTimeout(this.hintT);
    if (ms) this.hintT = setTimeout(() => h.classList.add('hidden'), ms);
  }

  #saveDrawings(list) {
    if (!this.drawingsLoaded) return;
    clearTimeout(this.saveT);
    const sym = this.sym;
    this.saveT = setTimeout(() => put(`/api/drawings/${encodeURIComponent(sym)}`, list).catch((e) => toast('Tracés non enregistrés', esc(e.message), 'ko')), 500);
  }

  // ======================================================================= graphique : événements
  #bindChart() {
    const ch = this.chart;
    ch.on('render', () => {
      const s = ch.stats;
      setHtml(this.$('#c-status'), `<span>GPU : <b>${esc(s.renderer ?? 'WebGL2')}</b></span><span>bougies : <b>${int(ch.n)}</b>${s.k > 1 ? ` (regroupées par ${s.k})` : ''}</span><span>sommets : <b>${int(s.verts)}</b></span><span>image : <b>${num(s.frameMs, 1)} ms</b></span>
        <span>tracés : <b>${this.dm.list.length}</b></span><span>indicateurs : <b>${this.indicators.length}</b></span>${ch.vp && ch.opt.vp ? `<span>POC <b>${ch.fmtPrice(ch.vp.poc)}</b> · zone de valeur <b>${ch.fmtPrice(ch.vp.val)} – ${ch.fmtPrice(ch.vp.vah)}</b></span>` : ''}<span class="sp"></span><span>molette : zoom · glisser : déplacer · axes : échelles · clic droit : menu</span>`);
    });
    ch.on('indicator', ({ id, act }) => {
      const ind = this.indicators.find((x) => x.id === id);
      if (!ind) return;
      if (act === 'del') this.indicators = this.indicators.filter((x) => x !== ind);
      else if (act === 'vis') ind.visible = ind.visible === false;
      else if (act === 'edit') { this.#editIndicator(ind); return; }
      else if (act === 'up' || act === 'down') {
        const panes = this.indicators.filter((x) => !INDICATORS[x.type].overlay), i = panes.indexOf(ind), j = act === 'up' ? i - 1 : i + 1;
        if (j < 0 || j >= panes.length) return;
        const a = this.indicators.indexOf(panes[i]), b = this.indicators.indexOf(panes[j]);
        [this.indicators[a], this.indicators[b]] = [this.indicators[b], this.indicators[a]];
      }
      this.chart.setIndicators(this.indicators);
      this.#saveLayout();
    });
    ch.on('layout', () => this.#saveLayout());
    ch.on('marker', (mk) => { if (mk.href) location.hash = mk.href; else if (mk.tip) toast(mk.title ?? 'Repère', mk.tip, '', 6000); });
    ch.on('context', (c) => this.#contextMenu(c));
  }

  #contextMenu(c) {
    this.ctxMenu?.remove();
    const items = [];
    const P = (v) => fprice(v, this.tick);
    if (c.drawing) {
      const d = c.drawing;
      items.push(['Paramètres du tracé…', () => this.#editDrawing(d)], ['Cloner', () => this.dm.clone(d)], [d.locked ? 'Déverrouiller' : 'Verrouiller', () => this.dm.update(d, { locked: !d.locked })], ['Masquer', () => this.dm.update(d, { hidden: true })], ['Supprimer', () => this.dm.remove(d.id)]);
    } else if (c.price !== null && c.price !== undefined) {
      const p = Number(c.price.toFixed(decOf(this.tick)));
      const q = S.quote(this.sym);
      items.push([`Alerte si le cours ${q && p > q.last ? 'atteint' : 'descend à'} ${P(p)}`, () => post('/api/alerts', { sym: this.sym, op: q && p > q.last ? 'above' : 'below', value: p }).then(() => toast('Alerte créée', `${esc(this.info.name)} ${P(p)}`, 'ok'))],
        [`Achat à cours limité à ${P(p)}`, () => post('/api/orders', { sym: this.sym, side: 'BUY', type: q && p > q.ask ? 'STP' : 'LMT', qty: 10, limit: p, stop: p, tif: 'GTC' }).then((o) => toast('Ordre enregistré', `Achat 10 ${esc(this.info.name)} ${o.type === 'LMT' ? 'limite' : 'stop'} ${P(p)}`, 'ok')).catch((e) => toast('Ordre refusé', esc(e.message), 'ko'))],
        [`Vente à cours limité à ${P(p)}`, () => post('/api/orders', { sym: this.sym, side: 'SELL', type: q && p < q.bid ? 'STP' : 'LMT', qty: 10, limit: p, stop: p, tif: 'GTC' }).then((o) => toast('Ordre enregistré', `Vente 10 ${esc(this.info.name)} ${o.type === 'LMT' ? 'limite' : 'stop'} ${P(p)}`, 'ok')).catch((e) => toast('Ordre refusé', esc(e.message), 'ko'))],
        [`Ligne horizontale à ${P(p)}`, () => this.dm.add('hline', [{ t: this.chart.timeOfIndex(c.index), p }])],
        ['Recentrer le graphique', () => this.chart.resetView()],
        ['Afficher les tracés masqués', () => { for (const d of this.dm.list) d.hidden = false; this.dm.hideAll = false; this.#saveDrawings(this.dm.list); this.chart.invalidate(); }]);
    }
    if (!items.length) return;
    const m = el(`<div class="tool-pop" style="position:fixed;left:${c.clientX}px;top:${c.clientY}px">${items.map(([t], i) => `<button data-i="${i}">${esc(t)}</button>`).join('')}</div>`);
    document.body.append(m);
    this.ctxMenu = m;
    m.addEventListener('click', (e) => { const b = e.target.closest('[data-i]'); if (b) { items[Number(b.dataset.i)][1](); m.remove(); } });
    setTimeout(() => document.addEventListener('click', () => m.remove(), { once: true }), 0);
  }

  // ======================================================================= indicateurs : choix et réglages
  #indicatorPicker() {
    const body = el(`<div><div class="form"><input type="search" placeholder="Rechercher un indicateur…" id="ind-q" style="width:280px"><span class="help-text">Clic : ajouter. Sur le graphique : ⚙ régler, ◉ masquer, ✕ retirer.</span></div><div class="ind-list" id="ind-list"></div></div>`);
    const render = (q = '') => {
      const f = q.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
      body.querySelector('#ind-list').innerHTML = GROUPS.map((g) => {
        const items = Object.entries(INDICATORS).filter(([, d]) => d.group === g && (!f || `${d.name} ${d.short} ${d.help}`.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().includes(f)));
        if (!items.length) return '';
        return `<div class="grp"><h4>${esc(g)}</h4>${items.map(([k, d]) => `<button data-k="${k}" title="${esc(d.help)}" class="${this.indicators.some((x) => x.type === k) ? 'on' : ''}">${esc(d.name)} <small>${d.overlay ? 'sur les cours' : 'panneau'}${d.intradayOnly ? ' · intraday' : ''}</small></button>`).join('')}</div>`;
      }).join('');
    };
    render();
    body.querySelector('#ind-q').addEventListener('input', (e) => render(e.target.value));
    body.addEventListener('click', (e) => {
      const b = e.target.closest('[data-k]');
      if (!b) return;
      const ind = makeIndicator(b.dataset.k);
      this.indicators.push(ind);
      this.chart.setIndicators(this.indicators);
      this.#saveLayout();
      b.classList.add('on');
      toast('Indicateur ajouté', esc(INDICATORS[ind.type].name), 'ok', 1500);
    });
    modal({ title: 'Indicateurs', body, wide: true });
    setTimeout(() => body.querySelector('#ind-q').focus(), 50);
  }

  #editIndicator(ind) {
    const def = INDICATORS[ind.type], outs = this.chart.outputs(ind.id).filter((o) => o.values && o.type !== 'band' && o.type !== 'cloud');
    const body = el(`<div class="box-body">
      <p class="help-text">${esc(def.help)}</p>
      <div class="form" style="padding:0">${def.params.map((p) => `<label class="f">${esc(p.label)}<input type="number" data-p="${p.k}" value="${ind.params[p.k]}" min="${p.min}" max="${p.max}" step="${p.step}"></label>`).join('') || '<span class="muted">Aucun paramètre.</span>'}</div>
      <h4 style="margin:10px 0 4px">Couleurs</h4>
      <div class="form" style="padding:0">${def.colors.map((c, k) => `<label class="f">${esc(outs[k]?.label ?? `série ${k + 1}`)}<input type="color" data-c="${k}" value="${ind.colors[k] ?? c}"></label>`).join('')}</div>
      ${def.overlay ? '' : `<label class="f" style="margin-top:8px">Hauteur du panneau (%)<input type="number" data-h value="${Math.round((ind.height ?? 0.18) * 100)}" min="8" max="60"></label>`}
    </div>`);
    modal({
      title: `Paramètres — ${def.name}`, body,
      buttons: [{ label: 'Retirer', cls: 'sell', onClick: (c) => { this.indicators = this.indicators.filter((x) => x !== ind); this.chart.setIndicators(this.indicators); this.#saveLayout(); c(); } },
        { label: 'Valider', cls: 'primary', onClick: (c) => {
          for (const i of body.querySelectorAll('[data-p]')) { const p = def.params.find((x) => x.k === i.dataset.p), v = Number(i.value); if (Number.isFinite(v)) ind.params[p.k] = Math.max(p.min, Math.min(p.max, v)); }
          for (const i of body.querySelectorAll('[data-c]')) ind.colors[Number(i.dataset.c)] = i.value;
          const hh = body.querySelector('[data-h]');
          if (hh) ind.height = Math.max(0.08, Math.min(0.6, Number(hh.value) / 100));
          this.chart.setIndicators(this.indicators);
          this.#saveLayout();
          c();
        } }],
    });
  }

  // ======================================================================= tracés : propriétés
  #editDrawing(d) {
    const def = TOOLS[d.type], s = d.style;
    const hasLevels = Array.isArray(def.style.levels), isText = d.type === 'text' || d.type.startsWith('flag'), isLine = ['trend', 'ray', 'xline', 'channel', 'regch', 'fib'].includes(d.type);
    const body = el(`<div class="box-body stack">
      <div><b>${esc(def.name)}</b> <span class="muted small">${d.pts.length} point(s) · ${d.locked ? 'verrouillé' : 'modifiable'}</span></div>
      <div class="row wrap-ok"><span class="muted">Couleur</span><div class="swatches">${SWATCH.map((c) => `<button data-col="${c}" style="background:${c}" class="${s.color === c ? 'on' : ''}"></button>`).join('')}</div><input type="color" data-k="color" value="${s.color || '#1f6fd1'}"></div>
      <div class="row wrap-ok"><label class="f">Épaisseur<select data-k="width">${[1, 1.5, 2, 3, 4].map((w) => `<option value="${w}" ${Number(s.width) === w ? 'selected' : ''}>${String(w).replace('.', ',')} px</option>`).join('')}</select></label>
        <label class="f">Style<select data-k="dash"><option value="solid">plein</option><option value="dash" ${s.dash === 'dash' ? 'selected' : ''}>tirets</option><option value="dot" ${s.dash === 'dot' ? 'selected' : ''}>points</option></select></label>
        ${'fill' in def.style ? `<label class="chk"><input type="checkbox" data-k="fill" ${s.fill ? 'checked' : ''}> remplissage</label><label class="f">Opacité<input type="range" data-k="fillAlpha" min="0.02" max="0.5" step="0.01" value="${s.fillAlpha ?? 0.1}"></label>` : ''}</div>
      ${isLine ? `<div class="row"><label class="chk"><input type="checkbox" data-k="extendLeft" ${s.extendLeft ? 'checked' : ''}> prolonger à gauche</label><label class="chk"><input type="checkbox" data-k="extendRight" ${s.extendRight ? 'checked' : ''}> prolonger à droite</label>${d.type === 'trend' ? `<label class="chk"><input type="checkbox" data-k="showStats" ${s.showStats ? 'checked' : ''}> statistiques</label>` : ''}</div>` : ''}
      ${isText ? `<label class="f">Texte<input type="text" data-k="text" value="${esc(s.text ?? '')}" style="width:100%"></label>` : ''}
      ${d.type === 'text' ? `<label class="f">Taille<input type="number" data-k="size" value="${s.size ?? 12}" min="8" max="40"></label>` : ''}
      ${d.type === 'regch' ? `<label class="f">Écarts-types<input type="number" data-k="k" value="${s.k ?? 2}" min="0.5" max="4" step="0.1"></label>` : ''}
      ${hasLevels ? `<label class="f">Niveaux (séparés par des points-virgules)<input type="text" data-k="levels" value="${(s.levels ?? def.style.levels).join(' ; ').replace(/\./g, ',')}" style="width:100%"></label>` : ''}
      ${'showPrices' in def.style ? `<label class="chk"><input type="checkbox" data-k="showPrices" ${s.showPrices ? 'checked' : ''}> afficher les prix</label>` : ''}
      ${d.type === 'fib' ? `<label class="chk"><input type="checkbox" data-k="reverse" ${s.reverse ? 'checked' : ''}> inverser (0 % au premier point)</label> <button class="btn btn-xs" data-fibreset>niveaux par défaut</button>` : ''}
      <div class="row"><label class="chk"><input type="checkbox" data-lock ${d.locked ? 'checked' : ''}> verrouiller</label><label class="chk"><input type="checkbox" data-hid ${d.hidden ? 'checked' : ''}> masquer</label></div>
    </div>`);
    body.addEventListener('click', (e) => {
      const b = e.target.closest('[data-col]');
      if (b) { body.querySelector('[data-k="color"]').value = b.dataset.col; for (const x of body.querySelectorAll('[data-col]')) x.classList.toggle('on', x === b); }
      if (e.target.closest('[data-fibreset]')) body.querySelector('[data-k="levels"]').value = FIB_DEFAULT.join(' ; ').replace(/\./g, ',');
    });
    modal({
      title: 'Propriétés du tracé', body,
      buttons: [
        { label: 'Supprimer', cls: 'sell', onClick: (c) => { this.dm.remove(d.id); c(); } },
        { label: 'Cloner', onClick: (c) => { this.dm.clone(d); c(); } },
        { label: 'Valider', cls: 'primary', onClick: (c) => {
          const st = {};
          for (const i of body.querySelectorAll('[data-k]')) {
            const k = i.dataset.k;
            if (i.type === 'checkbox') st[k] = i.checked;
            else if (k === 'levels') st.levels = i.value.split(/[;\s]+/).map((x) => Number(x.replace(',', '.'))).filter((x) => Number.isFinite(x));
            else if (['width', 'fillAlpha', 'size', 'k'].includes(k)) st[k] = Number(i.value);
            else st[k] = i.value;
          }
          this.dm.update(d, { style: st, locked: body.querySelector('[data-lock]').checked, hidden: body.querySelector('[data-hid]').checked });
          c();
        } },
      ],
    });
  }

  // ======================================================================= temps réel
  #onLive(m) {
    if (m.sym !== this.sym || this.dead) return;
    this.chart.setClock(m.sec);
    // transactions
    if (m.trades?.length) {
      const fresh = m.reset ? m.trades : m.trades.filter((t) => t[4] > this.lastSeq);
      this.lastSeq = Math.max(this.lastSeq, ...m.trades.map((t) => t[4]));
      this.tape = [...fresh.reverse(), ...this.tape].slice(0, 80);
      this.#renderTape(m);
    }
    if (m.tf !== this.tf || !m.bar || !this.header || !this.chart.data) return;
    const H = this.header, b = m.bar, ch = this.chart;
    if (H.intraday) {
      if (m.date !== H.dates.at(-1)) { if (Date.now() - (this.lastReload ?? 0) > 20_000) this.#reload(); return; }
      const idx = H.todayFrom + b.i, n = ch.n;
      if (idx === n - 1) ch.updateLast(b.o, b.h, b.l, b.c, b.v);
      else if (idx === n) {
        if (b.prev && H.todayFrom + b.prev.i === n - 1) ch.updateLast(b.prev.o, b.prev.h, b.prev.l, b.prev.c, b.prev.v);
        const t = dayNum(m.date) + (b.i * H.barSeconds) / H.ex.sessionSec;
        ch.append(b.o, b.h, b.l, b.c, b.v, t);
      } else if (idx > n || idx < n - 2) this.#reload();
    } else {
      const lastDate = H.dates.at(-1), key = this.tf === '1D' ? lastDate : this.tf === '1M' ? lastDate.slice(0, 7) : weekKey(lastDate);
      if (b.date !== key) { this.#reload(); return; }
      ch.updateLast(b.o, b.h, b.l, b.c, b.v);
    }
  }

  #reload() {
    if (this.reloading) return;
    this.reloading = true;
    this.lastReload = Date.now();
    setTimeout(() => this.#loadTf(this.tf, true).finally(() => { this.reloading = false; }), 300);
  }

  #renderTape(m) {
    if (!this.$('#tape')) return;
    const P = (v) => fprice(v, this.tick), avg = this.tape.length ? this.tape.reduce((a, t) => a + t[1], 0) / this.tape.length : 0;
    setHtml(this.$('#tape'), `<thead><tr><th>Heure</th><th class="r">Prix</th><th class="r">Qté</th><th>Sens</th></tr></thead><tbody>${this.tape.slice(0, 50).map((t) => `<tr class="${t[1] > avg * 4 ? 'big' : ''}"><td class="small muted">${esc(t[3])}</td><td class="r ${t[2] > 0 ? 'up' : 'down'}">${P(t[0])}</td><td class="r">${int(t[1])}</td><td class="${t[2] > 0 ? 'up' : 'down'}">${t[2] > 0 ? 'achat' : 'vente'}</td></tr>`).join('')}</tbody>`);
    if (m?.flow) {
      const f = m.flow, tot = f.buy + f.sell;
      setHtml(this.$('#flow-note'), `achats ${tot ? Math.round((f.buy / tot) * 100) : 50} % · gros ordres ${f.lb}/${f.ls}`);
    }
  }

  async #loadBook() {
    if (this.dead || !this.sym) return;
    if (!S.caps.book) { this.#dataInfo(); return; }
    try {
      const b = await get(`/api/book?sym=${encodeURIComponent(this.sym)}&depth=12`);
      if (b.sym !== this.sym) return;
      const P = (v) => fprice(v, this.tick), max = Math.max(...b.bids.map((x) => x[1]), ...b.asks.map((x) => x[1]));
      const avg = (b.bids.reduce((a, x) => a + x[1], 0) + b.asks.reduce((a, x) => a + x[1], 0)) / (b.bids.length + b.asks.length);
      const tb = b.bids.reduce((a, x) => a + x[1], 0), ta = b.asks.reduce((a, x) => a + x[1], 0);
      setHtml(this.$('#book'), `<thead><tr><th class="r">Qté</th><th class="r">Achat</th><th>Vente</th><th>Qté</th></tr></thead><tbody>${b.bids.map((bd, i) => {
        const a = b.asks[i];
        return `<tr class="${bd[1] > avg * 3 || a[1] > avg * 3 ? 'wall' : ''}"><td class="bq"><i style="width:${(bd[1] / max) * 100}%"></i><span>${int(bd[1])}</span></td><td class="bp">${P(bd[0])}</td><td class="ap">${P(a[0])}</td><td class="aq"><i style="width:${(a[1] / max) * 100}%"></i><span>${int(a[1])}</span></td></tr>`;
      }).join('')}<tr class="tot"><td class="r">${int(tb)}</td><td class="r">total</td><td>total</td><td>${int(ta)}</td></tr></tbody>`);
      setText(this.$('#book-note'), `déséquilibre ${tb + ta ? pct(((tb - ta) / (tb + ta)) * 100, 0) : '—'} · murs en gras`);
    } catch { /* passage de valeur */ }
  }

  // ======================================================================= IA
  async #loadAi() {
    const sigs = await get(`/api/ai/signals?sym=${encodeURIComponent(this.sym)}&limit=6`).catch(() => []);
    this.sigs = sigs;
    this.lastSig = sigs[0] ?? null;
    this.#renderAi();
    this.#renderQuote(true);
    this.#markers();
    this.#planLines();
    this.$('#ai-run').onclick = () => this.#runAi();
  }

  async #runAi() {
    try {
      const job = await post('/api/ai/analyze', { sym: this.sym });
      this.aiJob = job.id;
      this.aiStage = 'en file d\'attente';
      this.#renderAi();
      toast('Analyse demandée', `${esc(this.info.name)} passe en tête de file (avant les favoris).`, 'ok', 3000);
    } catch (e) { toast('Analyse impossible', esc(e.message), 'ko'); }
  }

  #onAi(m) {
    if (m.sym !== this.sym) return;
    if (m.ev === 'start') { this.aiJob = m.job; this.aiStage = 'démarrage'; this.#renderAi(); }
    else if (m.ev === 'stage') { this.aiStage = `${m.stage}${m.detail ? ` — ${m.detail}` : ''}`; this.#renderAi(); }
    else if (m.ev === 'result') { this.aiJob = null; this.aiStage = null; this.#loadAi(); }
    else if (m.ev === 'error') { this.aiJob = null; this.aiStage = null; toast(m.wait ? 'Analyse en attente' : 'Analyse en erreur', esc(m.error), m.wait ? '' : 'ko', m.wait ? 6000 : undefined); this.#renderAi(); }
  }

  #renderAi() {
    const g = this.lastSig, P = (v) => fprice(v, this.tick);
    const running = this.aiJob ? `<div class="info">Analyse en cours : <b>${esc(this.aiStage ?? '')}</b> · <a href="#/ia">suivre dans la console</a></div>` : '';
    if (!g) { setHtml(this.$('#ai-box'), `${running}<div class="empty">Pas encore d'analyse pour cette valeur.<br>Clique « Analyser maintenant » : calculs GPU/CPU + modèle Ollama.</div>`); return; }
    const d = DECISION[g.decision] ?? [g.decision, 'hold'];
    setHtml(this.$('#ai-box'), `${running}<div class="box-body stack">
      <div class="verdict"><span class="badge ${d[1]}">${d[0]}</span><div class="grow"><div class="small muted">confiance ${Math.round(g.confidence * 100)} % · ${esc(ago(g.at))} · horizon ${esc(g.horizon)}</div>${meter(g.confidence)}</div></div>
      ${g.simulated ? '<div class="small"><span class="chip sim">réponse simulée</span> Ollama n\'était pas joignable : décision dérivée des calculs.</div>' : ''}
      <div>${esc(g.summary)}</div>
      ${g.decision === 'HOLD' ? '<p class="small muted" style="margin:6px 0">Pas de position conseillée : attendre un signal plus clair.</p>' : g.entry ? `<table class="kv"><tr><th>Zone d'entrée</th><td>${P(g.entry.low)} – ${P(g.entry.high)}</td></tr><tr><th>Stop</th><td class="down">${P(g.stop)}</td></tr><tr><th>Objectifs</th><td class="up">${(g.targets ?? []).map(P).join(' · ') || '—'}</td></tr><tr><th>Gain / risque</th><td>${g.rewardRisk ? num(g.rewardRisk, 2) : '—'}</td></tr><tr><th>Taille conseillée</th><td>${g.sizeFraction ? pct(g.sizeFraction * 100, 0, false) : '—'} du risque max.</td></tr></table>` : ''}
      ${g.mc ? `<div class="small">Monte Carlo ${int(g.mc.paths)} trajectoires (${g.mc.horizon} séances) : objectif avant stop <b>${pct(g.mc.pTarget * 100, 1, false)}</b>, stop avant objectif <b>${pct(g.mc.pStop * 100, 1, false)}</b> (± ${num(g.mc.se * 100, 2)} pt)</div>` : ''}
      <div class="small">Calculs vs IA : <span class="chip ${g.quantVsAi === 'accord' ? 'ok' : g.quantVsAi === 'désaccord' ? 'ko' : 'warn'}">${esc(g.quantVsAi)}</span> (score quant ${num(g.quantScore, 2)})</div>
      ${g.guardrails?.length ? `<div class="notice"><b>Garde-fous</b><ul>${g.guardrails.map((x) => `<li>${esc(x)}</li>`).join('')}</ul></div>` : ''}
      <div class="small"><a href="#/ia/${encodeURIComponent(g.id)}">Détail complet de l'analyse →</a></div>
      ${(this.sigs ?? []).length > 1 ? `<table class="tbl compact"><thead><tr><th>Historique</th><th>Décision</th><th class="r">Conf.</th><th>Issue</th></tr></thead><tbody>${this.sigs.slice(1).map((x) => `<tr><td class="small">${esc(ago(x.at))}</td><td>${decisionChip(x.decision)}</td><td class="r">${Math.round(x.confidence * 100)} %</td><td>${x.outcome ? `<span class="chip ${x.outcome === 'objectif' ? 'ok' : x.outcome === 'stop' ? 'ko' : ''}">${esc(x.outcome)}</span>` : '<span class="muted small">en cours</span>'}</td></tr>`).join('')}</tbody></table>` : ''}
    </div>`);
  }

  // ======================================================================= lignes, zones, repères
  async #loadOrders() {
    const p = await get('/api/portfolio').catch(() => null);
    this.pf = p;
    this.#planLines();
    this.#markers();
  }
  async #loadAlerts() {
    this.alerts = await get('/api/alerts').catch(() => []);
    this.#planLines();
    this.#renderAlerts();
  }

  #planLines() {
    const lines = [], zones = [], o = this.layout.opts, g = this.lastSig;
    if (o.plan && g && g.entry && g.decision !== 'HOLD') {
      zones.push({ from: g.entry.low, to: g.entry.high, color: '#1f6fd1', alpha: 0.1 });
      if (g.stop) lines.push({ price: g.stop, color: '#d64541', label: 'Stop IA' });
      (g.targets ?? []).forEach((t, i) => lines.push({ price: t, color: '#1e9e55', label: `Objectif ${i + 1} IA` }));
    }
    if (o.orders && this.pf) {
      for (const od of this.pf.orders.filter((x) => x.sym === this.sym && x.status === 'WORKING')) {
        const px = od.type === 'LMT' ? od.limit : od.stop;
        lines.push({ price: px, color: od.side === 'BUY' ? '#0f8f8f' : '#c2185b', label: `${od.side === 'BUY' ? 'Achat' : 'Vente'} ${od.qty} ${od.type === 'LMT' ? 'limite' : od.type === 'STP' ? 'stop' : 'stop lim.'}` });
      }
      const pos = this.pf.positions.find((x) => x.sym === this.sym && x.qty);
      if (pos) lines.push({ price: pos.avg, color: '#7b4fc9', label: `PRU ${pos.qty > 0 ? '' : 'vente '}${int(Math.abs(pos.qty))} titres`, dash: false });
    }
    if (o.orders && this.alerts) for (const a of this.alerts.filter((x) => x.sym === this.sym && x.active && (x.op === 'above' || x.op === 'below'))) lines.push({ price: a.value, color: '#c49000', label: `Alerte ${a.op === 'above' ? '≥' : '≤'}` });
    this.chart.setPriceLines(lines);
    this.chart.setZones(zones);
  }

  #markers() {
    if (!this.header || !this.chart.data) return;
    const out = [], ex = this.header.ex, toT = (date, sec) => (date ? dayNum(date) + (this.header.intraday ? (sec ?? 0) / ex.sessionSec : 0) : null);
    if (this.layout.opts.markers) {
      for (const g of this.sigs ?? []) {
        const t = toT(g.simDate, g.simSec);
        if (t === null || g.decision === 'HOLD') continue;
        const buy = g.decision.includes('BUY');
        out.push({ t, pos: buy ? 'below' : 'above', shape: buy ? 'up' : 'down', color: buy ? '#1e9e55' : '#d64541', text: `IA ${Math.round(g.confidence * 100)} %`, href: `#/ia/${encodeURIComponent(g.id)}` });
      }
      for (const x of (this.pf?.executions ?? []).filter((e) => e.sym === this.sym)) {
        const t = toT(x.simDate, x.simSec);
        if (t !== null) out.push({ t, pos: x.side === 'BUY' ? 'below' : 'above', shape: 'circle', letter: x.side === 'BUY' ? 'A' : 'V', color: x.side === 'BUY' ? '#0f8f8f' : '#c2185b', title: 'Exécution', tip: `${x.side === 'BUY' ? 'Achat' : 'Vente'} ${x.qty} à ${fprice(x.px, this.tick)}` });
      }
      for (const n of S.news.filter((x) => x.sym === this.sym && x.simDate)) out.push({ t: toT(n.simDate, n.simSec), pos: 'above', shape: 'circle', letter: 'N', color: n.score >= 0 ? '#1f6fd1' : '#c49000', title: 'Actualité', tip: esc(n.title) });
    }
    this.chart.setMarkers(out);
  }

  // ======================================================================= niveaux clés, alertes
  async #levels() {
    const h = await history(this.sym, '1D').catch(() => null);
    if (!h) return;
    this.daily = h;
    const n = h.close.length, P = (v) => fprice(v, this.tick), q = S.quote(this.sym), last = q?.last ?? h.close[n - 1];
    const pv = pivotCalc(h.high[n - 2], h.low[n - 2], h.close[n - 2]).classic, r = S.row(this.sym);
    const rows = [['R3', pv.R3], ['R2', pv.R2], ['R1', pv.R1], ['Pivot', pv.P], ['S1', pv.S1], ['S2', pv.S2], ['S3', pv.S3]];
    const mas = [['MM 50 (J)', r?.ema50], ['MM 200 (J)', r?.sma200], ['+ haut 52 sem.', r?.hi52], ['+ bas 52 sem.', r?.lo52], ['Veille : + haut', h.high[n - 2]], ['Veille : + bas', h.low[n - 2]]];
    setHtml(this.$('#levels'), `<table class="kv">${[...rows, ...mas].filter(([, v]) => Number.isFinite(v)).sort((a, b) => b[1] - a[1]).map(([k, v]) => `<tr><th>${k}</th><td>${P(v)}</td><td class="r small ${cls(v - last)}">${pct((v / last - 1) * 100, 2)}</td></tr>`).join('')}</table><div class="box-foot">Pivots classiques de la séance précédente · écart au cours actuel</div>`);
  }

  #renderAlerts() {
    const list = (this.alerts ?? []).filter((a) => a.sym === this.sym), P = (v) => fprice(v, this.tick);
    const cond = (a) => (a.op === 'above' ? `≥ ${P(a.value)}` : a.op === 'below' ? `≤ ${P(a.value)}` : a.op === 'chg_above' ? `var. ≥ ${pct(a.value)}` : `var. ≤ ${pct(a.value)}`);
    setHtml(this.$('#alerts'), `${list.length ? `<table class="tbl compact"><tbody>${list.map((a) => `<tr><td>${cond(a)}${a.note ? `<small>${esc(a.note)}</small>` : ''}</td><td>${a.active ? '<span class="chip run">active</span>' : `<span class="chip warn">déclenchée</span><small>${ago(a.triggeredAt)}</small>`}</td><td class="r"><button class="mini" data-rearm="${a.id}" ${a.active ? 'disabled' : ''}>réarmer</button> <button class="mini" data-del="${a.id}">✕</button></td></tr>`).join('')}</tbody></table>` : '<div class="empty">Aucune alerte.</div>'}<div class="form"><button class="btn btn-small" id="al-new">+ Nouvelle alerte</button><span class="help-text">ou clic droit sur le graphique</span></div>`);
    this.$('#al-new').onclick = () => this.#newAlert();
    on(this.$('#alerts'), 'click', '[data-del]', (e, b) => del(`/api/alerts/${b.dataset.del}`).then(() => this.#loadAlerts()));
    on(this.$('#alerts'), 'click', '[data-rearm]', (e, b) => post(`/api/alerts/${b.dataset.rearm}/rearm`).then(() => this.#loadAlerts()));
  }

  #newAlert() {
    const q = S.quote(this.sym), dec = decOf(this.tick);
    const body = el(`<div class="form col"><label class="f">Condition<select data-k="op"><option value="above">cours ≥ seuil</option><option value="below">cours ≤ seuil</option><option value="chg_above">variation du jour ≥ (%)</option><option value="chg_below">variation du jour ≤ (%)</option></select></label>
      <label class="f">Seuil<input type="number" data-k="value" step="${this.tick}" value="${q ? (q.last * 1.02).toFixed(dec) : ''}"></label><label class="f">Note (facultatif)<input type="text" data-k="note" placeholder="ex. cassure de résistance"></label></div>`);
    const opSel = body.querySelector('[data-k="op"]'), val = body.querySelector('[data-k="value"]');
    opSel.onchange = () => { val.value = opSel.value === 'above' ? (q.last * 1.02).toFixed(dec) : opSel.value === 'below' ? (q.last * 0.98).toFixed(dec) : opSel.value === 'chg_above' ? 3 : -3; };
    modal({ title: `Nouvelle alerte — ${this.info.name}`, body, buttons: [{ label: 'Créer', cls: 'primary', onClick: async (c) => {
      try {
        await post('/api/alerts', { sym: this.sym, op: opSel.value, value: Number(val.value), note: body.querySelector('[data-k="note"]').value });
        toast('Alerte créée', esc(this.info.name), 'ok');
        this.#loadAlerts();
        c();
      } catch (e) { toast('Alerte refusée', esc(e.message), 'ko'); }
    } }] });
  }

  // ======================================================================= onglets
  #tab(id) {
    this.tab = id;
    prefs.set('stock.tab', id);
    this.plots?.forEach((p) => p.destroy?.());
    this.plots = [];
    const box = this.$('#s-tab');
    box.innerHTML = '<div class="empty">Calcul…</div>';
    const run = { tech: () => this.#tabTech(), stats: () => this.#tabStats(), dossier: () => this.#tabDossier(), tpo: () => this.#tabTpo(), season: () => this.#tabSeason(), perf: () => this.#tabPerf(), fund: () => this.#tabFund(), news: () => this.#tabNews(), hist: () => this.#tabHist() }[id];
    Promise.resolve(run?.()).catch((e) => { box.innerHTML = `<div class="box-body err">${esc(e.message)}</div>`; });
  }

  async #tabTech() {
    if (this.tab !== 'tech') return;
    const box = this.$('#s-tab'), tf = this.tf;
    const t = await post('/api/lab/technical', { sym: this.sym, tf });
    if (this.tab !== 'tech' || tf !== this.tf) return;
    const P = (v) => (Number.isFinite(v) ? num(v, Math.abs(v) < 10 ? 3 : 2) : '—');
    const vote = (v) => (v > 0 ? '<span class="chip buy">Achat</span>' : v < 0 ? '<span class="chip sell">Vente</span>' : '<span class="chip hold">Neutre</span>');
    const ma = t.details.filter((d) => d.group === 'ma'), osc = t.details.filter((d) => d.group !== 'ma');
    box.innerHTML = `<div class="box-body">
      <div class="row wrap-ok" style="justify-content:space-around">${gauge(t.osc, t.oscLabel, { title: 'Oscillateurs' })}${gauge(t.rating, t.label, { w: 210, title: `Résumé · ${TF_LABEL[tf]}` })}${gauge(t.ma, t.maLabel, { title: 'Moyennes mobiles' })}</div>
      <p class="c small muted">${t.counts.buy} achat · ${t.counts.neutral} neutre · ${t.counts.sell} vente — note ${num(t.rating, 3)} (−1 vente forte … +1 achat fort), même méthode que les plateformes de référence, calculée sur l'unité de temps affichée.</p>
      <div class="cols cols-2"><table class="tbl compact"><thead><tr><th>Oscillateur</th><th class="r">Valeur</th><th>Signal</th></tr></thead><tbody>${osc.map((d) => `<tr title="${esc(d.rule)}"><td>${esc(d.name)}</td><td class="r">${P(d.value)}</td><td>${vote(d.vote)}</td></tr>`).join('')}</tbody></table>
      <table class="tbl compact"><thead><tr><th>Moyenne mobile</th><th class="r">Valeur</th><th>Signal</th></tr></thead><tbody>${ma.map((d) => `<tr title="${esc(d.rule)}"><td>${esc(d.name)}</td><td class="r">${P(d.value)}</td><td>${vote(d.vote)}</td></tr>`).join('')}</tbody></table></div></div>`;
  }

  async #tabStats() {
    const box = this.$('#s-tab'), st = await post('/api/lab/stats', { sym: this.sym, window: 1260 }), h = this.daily ?? (await history(this.sym, '1D'));
    const c = h.close, o = h.open, hi = h.high, lo = h.low, n = c.length, ret = V.logReturns(c).subarray(1);
    const vols = [20, 60, 252].map((w) => ({ w, cc: V.closeToClose(c.subarray(n - w - 1), w), pk: V.parkinson(hi.subarray(n - w), lo.subarray(n - w), w), gk: V.garmanKlass(o.subarray(n - w), hi.subarray(n - w), lo.subarray(n - w), c.subarray(n - w), w), rs: V.rogersSatchell(o.subarray(n - w), hi.subarray(n - w), lo.subarray(n - w), c.subarray(n - w), w), yz: V.yangZhang(o.subarray(n - w - 1), hi.subarray(n - w - 1), lo.subarray(n - w - 1), c.subarray(n - w - 1), w) }));
    const g = V.garch11(ret.subarray(Math.max(0, ret.length - 756)));
    const m = st.moments, F = (x, d = 3) => (Number.isFinite(x) ? num(x, d) : '—'), lastV = (x) => (Array.isArray(x) || ArrayBuffer.isView(x) ? x.at(-1) : x);
    box.innerHTML = `<div class="box-body"><div class="cols cols-2">
      <div><h4>Distribution des rendements quotidiens (${st.window} séances)</h4><canvas class="plot" id="st-hist"></canvas>
        <table class="kv"><tr><th>Moyenne / jour</th><td>${pct(m.mean * 100, 3)}</td><th>Écart-type / jour</th><td>${pct(m.sd * 100, 2, false)}</td></tr><tr><th>Asymétrie</th><td>${F(m.skew)}</td><th>Kurtosis (excès)</th><td>${F(m.kurt)}</td></tr>
        <tr><th>Jarque-Bera</th><td>${F(st.jb.jb, 1)} (p ${F(st.jb.p, 4)})</td><th>Normalité</th><td>${st.jb.p < 0.05 ? '<span class="chip ko">rejetée</span>' : '<span class="chip ok">acceptée</span>'}</td></tr></table></div>
      <div><h4>Autocorrélation des rendements (20 retards)</h4><canvas class="plot" id="st-acf"></canvas>
        <table class="kv"><tr><th>Ljung-Box (10)</th><td>${F(st.ljung.q, 2)} (p ${F(st.ljung.p, 4)})</td></tr><tr><th>Hurst (R/S)</th><td>${F(st.hurst)} ${st.hurst > 0.55 ? '<small>persistant (tendance)</small>' : st.hurst < 0.45 ? '<small>anti-persistant (retour à la moyenne)</small>' : '<small>proche de la marche aléatoire</small>'}</td></tr>
        <tr><th>Ratio de variance (5)</th><td>${F(st.vr.vr)} (z* ${F(st.vr.zStar, 2)})</td></tr><tr><th>ADF (log-prix)</th><td>${st.adf ? `${F(st.adf.stat)} · seuil 5 % ${F(st.adf.crit[5])} → ${st.adf.stationary ? 'stationnaire' : 'racine unitaire (non stationnaire)'}` : '—'}</td></tr></table></div>
      </div>
      <h4 style="margin-top:10px">Volatilité annualisée selon l'estimateur</h4>
      <table class="tbl"><thead><tr><th>Fenêtre</th><th class="r">Clôture-clôture</th><th class="r">Parkinson</th><th class="r">Garman-Klass</th><th class="r">Rogers-Satchell</th><th class="r">Yang-Zhang</th></tr></thead><tbody>${vols.map((v) => `<tr><td>${v.w} séances</td>${[v.cc, v.pk, v.gk, v.rs, v.yz].map((x) => `<td class="r">${pct(lastV(x) * 100, 1, false)}</td>`).join('')}</tr>`).join('')}</tbody></table>
      ${g ? `<h4 style="margin-top:10px">GARCH(1,1) — maximum de vraisemblance (3 ans)</h4><table class="kv"><tr><th>ω</th><td>${sci(g.omega, 3)}</td><th>α (choc)</th><td>${F(g.alpha, 4)}</td><th>β (mémoire)</th><td>${F(g.beta, 4)}</td></tr><tr><th>Persistance α+β</th><td>${F(g.persistence, 4)}</td><th>Demi-vie des chocs</th><td>${F(g.halfLife, 1)} séances</td><th>Vol. prévue demain</th><td>${pct(Math.sqrt(g.nextVar * 252) * 100, 1, false)} /an</td></tr><tr><th>Vol. de long terme</th><td>${pct(Math.sqrt(g.uncondVar * 252) * 100, 1, false)} /an</td><th>Log-vraisemblance</th><td>${F(g.ll, 1)}</td><th>Observations</th><td>${g.n}</td></tr></table>` : ''}
    </div>`;
    const hgm = histogram(Array.from(ret.subarray(Math.max(0, ret.length - st.window)), (x) => x * 100), 50);
    const sd = m.sd * 100, mu = m.mean * 100, nobs = hgm.counts.reduce((a, b) => a + b, 0);
    const normal = hgm.xs.map((x) => (nobs * hgm.width) / (sd * Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * ((x - mu) / sd) ** 2));
    this.plots.push(new Plot(box.querySelector('#st-hist'), { height: 200, xs: hgm.xs, xFormat: (x) => `${num(x, 1)} %`, series: [{ type: 'bars', data: hgm.counts, name: 'observé', colorOf: (v, i) => (hgm.xs[i] >= 0 ? 'rgba(30,158,85,0.55)' : 'rgba(214,69,65,0.55)') }, { type: 'line', data: normal, name: 'loi normale', color: '#1f6fd1' }] }));
    const band = 1.96 / Math.sqrt(st.window);
    this.plots.push(new Plot(box.querySelector('#st-acf'), { height: 200, xs: st.acf.map((_, i) => i + 1), series: [{ type: 'bars', data: Array.from(st.acf), name: 'ACF', colorOf: (v) => (Math.abs(v) > band ? '#f28c18' : '#7fa6d6') }, { type: 'hline', y: band, color: '#d64541', label: 'IC 95 %' }, { type: 'hline', y: -band, color: '#d64541' }], zero: true }));
  }

  async #tabDossier() {
    const box = this.$('#s-tab');
    box.innerHTML = '<div class="empty">Construction du dossier sur un worker (≈ 60 indicateurs, régimes, cycles, niveaux)…</div>';
    const r = await get(`/api/ai/dossier?sym=${encodeURIComponent(this.sym)}`), d = r.dossier;
    const sc = d.scores;
    box.innerHTML = `<div class="box-body">
      <div class="info">Ce dossier est <b>exactement ce que l'IA reçoit</b> (avec en plus Monte Carlo et backtests lors d'une analyse). Calculé en ${dur(r.ms)} sur un worker · ${int(r.text.length)} caractères ≈ ${int(r.tokens)} jetons.</div>
      <div class="cols cols-2" style="margin-top:8px">
        <div><h4>Faits saillants (classés par importance)</h4><ul class="factors" style="padding-left:0">${d.faits.map((f) => `<li class="${f.sens > 0 ? 'pos' : f.sens < 0 ? 'neg' : 'neu'}">${esc(f.texte)} <small class="muted">· ${esc(f.theme)} · poids ${f.poids}</small></li>`).join('')}</ul></div>
        <div><h4>Scores (−1 … +1)</h4><table class="kv">${Object.entries(sc).map(([k, v]) => `<tr><th>${esc(k)}</th><td style="width:60%"><div class="meter center"><i style="left:${v >= 0 ? 50 : 50 + v * 50}%;width:${Math.abs(v) * 50}%;background:${v >= 0 ? 'var(--up)' : 'var(--down)'}"></i></div></td><td class="r ${cls(v)}">${num(v, 2)}</td></tr>`).join('')}</table>
          <h4 style="margin-top:8px">Sections</h4><div class="small">${Object.keys(d.sections).map((k) => `<details><summary><b>${esc(k)}</b></summary><pre class="mono small" style="white-space:pre-wrap;max-height:260px;overflow:auto">${esc(JSON.stringify(d.sections[k], null, 1))}</pre></details>`).join('')}</div></div>
      </div>
      <h4 style="margin-top:10px">Texte transmis au modèle <button class="btn btn-xs" id="dz-copy">copier</button> <button class="btn btn-xs" id="dz-save">enregistrer</button></h4>
      <pre class="console" style="max-height:420px">${esc(r.text)}</pre></div>`;
    box.querySelector('#dz-copy').onclick = () => navigator.clipboard?.writeText(r.text).then(() => toast('Copié', '', 'ok', 1200));
    box.querySelector('#dz-save').onclick = () => saveFile(`dossier_${this.info.code}.txt`, r.text);
  }

  async #tabTpo() {
    const box = this.$('#s-tab'), h = await history(this.sym, '1m'), H = h.header, P = H.perSession, days = H.dates.length;
    box.innerHTML = `<div class="box-body"><div class="form" style="padding:0 0 8px"><label class="f">Séance<select id="tpo-day">${H.dates.map((d, i) => `<option value="${i}" ${i === days - 1 ? 'selected' : ''}>${ymd(d)}${i === days - 1 ? ' (en cours)' : ''}</option>`).join('')}</select></label>
      <label class="f">Période par lettre<select id="tpo-per"><option value="30">30 min</option><option value="15">15 min</option><option value="60">60 min</option></select></label><span class="help-text">Chaque lettre = une période où le prix a coté à ce niveau. POC = niveau le plus coté ; zone de valeur = 70 % du temps ; IB = range de la première heure.</span></div>
      <canvas id="tpo-cv" style="width:100%;display:block"></canvas><div id="tpo-kv"></div></div>`;
    const draw = () => {
      const day = Number(box.querySelector('#tpo-day').value), per = Number(box.querySelector('#tpo-per').value);
      const from = day * P, to = Math.min(h.close.length, from + P);
      const mp = marketProfile({ high: h.high, low: h.low, from, to, periodBars: per, tick: this.tick, maxRows: 70 });
      const cv = box.querySelector('#tpo-cv'), dpr = window.devicePixelRatio || 1, W = cv.clientWidth, rowH = 14, Hh = mp.rows.length * rowH + 30;
      cv.style.height = `${Hh}px`;
      cv.width = W * dpr;
      cv.height = Hh * dpr;
      const x = cv.getContext('2d');
      x.setTransform(dpr, 0, 0, dpr, 0, 0);
      const css = (k) => getComputedStyle(document.documentElement).getPropertyValue(k).trim();
      x.font = '11px "DejaVu Sans Mono", monospace';
      x.textBaseline = 'middle';
      const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
      [...mp.rows].reverse().forEach((r, i) => {
        const y = 10 + i * rowH + rowH / 2, inVa = r.price <= mp.vah && r.price >= mp.val, isPoc = Math.abs(r.price - mp.poc) < this.tick / 2;
        if (isPoc) { x.fillStyle = css('--c-poc'); x.globalAlpha = 0.25; x.fillRect(0, y - rowH / 2, W, rowH); x.globalAlpha = 1; }
        else if (inVa) { x.fillStyle = css('--c-line'); x.globalAlpha = 0.06; x.fillRect(0, y - rowH / 2, W, rowH); x.globalAlpha = 1; }
        x.fillStyle = css('--c-text');
        x.textAlign = 'right';
        x.fillText(fprice(r.price, this.tick), 74, y);
        x.textAlign = 'left';
        let cx = 84;
        for (const ch of r.letters) {
          x.fillStyle = ch === letters[0] || ch === letters[1] ? '#c49000' : inVa ? css('--c-line') : css('--c-text');
          x.fillText(ch, cx, y);
          cx += 9;
        }
        if (r.count === 1 && i > 0 && i < mp.rows.length - 1) { x.fillStyle = '#d64541'; x.fillText('◂ unique', cx + 4, y); }
      });
      setHtml(box.querySelector('#tpo-kv'), `<table class="kv"><tr><th>POC</th><td>${fprice(mp.poc, this.tick)}</td><th>Haut de zone de valeur (VAH)</th><td>${fprice(mp.vah, this.tick)}</td><th>Bas (VAL)</th><td>${fprice(mp.val, this.tick)}</td></tr>
        <tr><th>Initial balance (A+B)</th><td>${mp.ib ? `${fprice(mp.ib.lo, this.tick)} – ${fprice(mp.ib.hi, this.tick)}` : '—'}</td><th>Impressions uniques</th><td>${mp.singlePrints?.length ?? 0}</td><th>Plus haut / bas « pauvres »</th><td>${mp.poorHigh ? 'haut pauvre' : '—'} / ${mp.poorLow ? 'bas pauvre' : '—'}</td></tr></table>`);
    };
    box.querySelector('#tpo-day').onchange = draw;
    box.querySelector('#tpo-per').onchange = draw;
    draw();
  }

  async #tabSeason() {
    const box = this.$('#s-tab'), h = this.daily ?? (await history(this.sym, '1D')), dates = h.header.dates, c = h.close;
    const months = new Map();
    let prevKey = null, startC = null, lastC = null;
    for (let i = 0; i < c.length; i++) {
      const k = dates[i].slice(0, 7);
      if (k !== prevKey) { if (prevKey) months.set(prevKey, (lastC / startC - 1) * 100); startC = i ? c[i - 1] : h.open[0]; prevKey = k; }
      lastC = c[i];
    }
    if (prevKey) months.set(prevKey, (lastC / startC - 1) * 100);
    const years = [...new Set([...months.keys()].map((k) => k.slice(0, 4)))].sort();
    const MN = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
    const vals = years.map((y) => MN.map((_, m) => months.get(`${y}-${String(m + 1).padStart(2, '0')}`) ?? null));
    const avg = MN.map((_, m) => { const v = vals.map((r) => r[m]).filter((x) => x !== null); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null; });
    const pos = MN.map((_, m) => { const v = vals.map((r) => r[m]).filter((x) => x !== null); return v.length ? v.filter((x) => x > 0).length / v.length : null; });
    const dow = [0, 0, 0, 0, 0], dn = [0, 0, 0, 0, 0];
    for (let i = 1; i < c.length; i++) { const wd = new Date(`${dates[i]}T12:00:00Z`).getUTCDay() - 1; if (wd >= 0 && wd < 5) { dow[wd] += (c[i] / c[i - 1] - 1) * 100; dn[wd]++; } }
    // rendement de chaque année civile (dernière clôture de l'année / dernière clôture de l'année précédente)
    const yearRet = years.map((y) => {
      let first = -1, last = -1;
      for (let i = 0; i < c.length; i++) if (dates[i].startsWith(y)) { if (first < 0) first = i; last = i; }
      const base = first > 0 ? c[first - 1] : h.open[0];
      return first >= 0 ? (c[last] / base - 1) * 100 : null;
    });
    const valsY = vals.map((row, i) => [...row, yearRet[i]]);
    box.innerHTML = `<div class="box-body"><h4>Rendement mensuel (%) — ${years[0]} à ${years.at(-1)}</h4><canvas id="se-grid" style="width:100%;max-width:920px"></canvas>
      <div class="cols cols-2" style="margin-top:8px"><div><h4>Moyenne par mois et % de mois positifs</h4><canvas class="plot" id="se-avg"></canvas></div><div><h4>Rendement moyen par jour de semaine</h4><canvas class="plot" id="se-dow"></canvas></div></div>
      <p class="help-text">Dernière colonne : rendement de l'année civile (année en cours : depuis le 1er janvier). ${S.real ? 'Données quotidiennes réelles sur 5 ans' : 'Données quotidiennes simulées sur 5 ans'} : 5 observations par mois ne font pas un signal fiable.</p></div>`;
    const maxAbs = Math.max(2, ...vals.flat().filter((x) => x !== null).map(Math.abs));
    this.plots.push(new HeatGrid(box.querySelector('#se-grid'), { rows: years, cols: [...MN, 'Année'], values: valsY, max: maxAbs, showValues: true, format: (v) => num(v, 1), cell: 24 }));
    this.plots.push(new Plot(box.querySelector('#se-avg'), { height: 190, xs: MN.map((_, i) => i), xTickValues: MN.map((_, i) => i), xFormat: (i) => MN[i] ?? '', series: [{ type: 'bars', data: avg, name: 'moyenne %', colorOf: (v) => (v >= 0 ? '#1e9e55' : '#d64541') }], zero: true, tipX: (x, i) => `${MN[i]} : ${pct(avg[i])} · positifs ${pct01(pos[i])}` }));
    this.plots.push(new Plot(box.querySelector('#se-dow'), { height: 190, xs: [0, 1, 2, 3, 4], xTickValues: [0, 1, 2, 3, 4], xFormat: (i) => ['lun.', 'mar.', 'mer.', 'jeu.', 'ven.'][i] ?? '', series: [{ type: 'bars', data: dow.map((s, i) => s / (dn[i] || 1)), name: 'moyenne %', colorOf: (v) => (v >= 0 ? '#1e9e55' : '#d64541') }], zero: true, yFormat: (v) => num(v, 3) }));
  }

  async #tabPerf() {
    const box = this.$('#s-tab'), h = this.daily ?? (await history(this.sym, '1D')), mic = this.info.mic;
    const idx = await get(`/api/index/${mic}`), c = h.close, n = c.length, dates = h.header.dates;
    const imap = new Map(idx.dates.map((d, i) => [d, idx.close[i]]));
    const per = [['1 séance', 1], ['1 semaine', 5], ['1 mois', 21], ['3 mois', 63], ['6 mois', 126], ['1 an', 252], ['3 ans', 756], ['5 ans', n - 1]];
    const sector = S.screen.rows.filter((r) => r.sectorKey === this.info.sectorKey);
    const rowsHtml = per.filter(([, k]) => k < n).map(([l, k]) => {
      const p = (c[n - 1] / c[n - 1 - k] - 1) * 100, i0 = imap.get(dates[n - 1 - k]), i1 = imap.get(dates[n - 1]) ?? idx.close.at(-1);
      const pi = i0 ? (i1 / i0 - 1) * 100 : NaN;
      return `<tr><td>${l}</td><td class="r">${chg(p)}</td><td class="r">${chg(pi)}</td><td class="r">${chg(p - pi)}</td></tr>`;
    }).join('');
    const ytdI = dates.findIndex((d) => d.slice(0, 4) === dates[n - 1].slice(0, 4));
    box.innerHTML = `<div class="box-body"><div class="cols cols-2"><div><table class="tbl"><thead><tr><th>Période</th><th class="r">${esc(this.info.code)}</th><th class="r">Indice (${esc(this.meta.meta.index)})</th><th class="r">Écart</th></tr></thead><tbody>${rowsHtml}<tr><td>Depuis le 1er janvier</td><td class="r">${chg((c[n - 1] / c[Math.max(0, ytdI - 1)] - 1) * 100)}</td><td></td><td></td></tr></tbody></table>
      <h4 style="margin-top:8px">Dans son secteur (${esc(this.info.sector)}, ${sector.length} valeurs)</h4><table class="tbl compact"><thead><tr><th>Valeur</th><th class="r">1 mois</th><th class="r">1 an</th></tr></thead><tbody>${[...sector].sort((a, b) => (b.perf1a ?? -1e9) - (a.perf1a ?? -1e9)).slice(0, 12).map((r) => `<tr class="${r.sym === this.sym ? 'sel' : ''}"><td>${nameCell(r.sym, { sub: false })}</td><td class="r">${chg(r.perf1m)}</td><td class="r">${chg(r.perf1a)}</td></tr>`).join('')}</tbody></table></div>
      <div><h4>Base 100 sur un an : valeur vs indice</h4><canvas class="plot" id="pf-plot"></canvas><h4 style="margin-top:8px">Base 100 sur 5 ans</h4><canvas class="plot" id="pf-plot5"></canvas></div></div></div>`;
    const mk = (k, el2) => {
      const from = n - 1 - k, xs = [], a = [], b = [];
      const i0 = imap.get(dates[from]);
      for (let i = from; i < n; i++) { xs.push(i - from); a.push((c[i] / c[from]) * 100); const iv = imap.get(dates[i]); b.push(iv && i0 ? (iv / i0) * 100 : null); }
      this.plots.push(new Plot(box.querySelector(el2), { height: 200, xs, xFormat: (x) => ymd(dates[from + Math.round(x)] ?? '', true), series: [{ type: 'line', data: a, name: this.info.code, color: '#1f6fd1' }, { type: 'line', data: b, name: 'indice', color: '#f28c18' }, { type: 'hline', y: 100, color: '#8a95a3' }] }));
    };
    mk(Math.min(252, n - 1), '#pf-plot');
    mk(n - 1, '#pf-plot5');
  }

  async #refreshMeta() {
    if (this.dead || !this.sym || document.hidden) return;
    const sym = this.sym, m = await get(`/api/quote/${encodeURIComponent(sym)}`).catch(() => null);
    if (!m || sym !== this.sym || this.dead) return;
    this.meta = m;
    this.#renderQuote();
    this.#dataInfo();
  }

  /** Données réelles : d'où viennent les chiffres de la valeur, et ce qui manque. */
  #dataInfo() {
    const box = this.$('#data-info'), m = this.meta?.meta;
    if (!box || !m) return;
    setHtml(box, `<table class="kv"><tr><th>Cours</th><td>${esc(m.quoteSource ?? 'en attente')}${m.quoteAt ? ` · ${dateTime(m.quoteAt)} (heure de Paris)` : ''}</td></tr>
      <tr><th>Historique</th><td>${m.historyDays ? `${int(m.historyDays)} séances · ${esc(m.historySource ?? '')}` : 'en cours de chargement'}</td></tr>
      <tr><th>Séance</th><td>${esc(this.meta.clock?.label ?? this.meta.clock?.state ?? '—')}</td></tr>
      ${m.dataError ? `<tr><th>Problème</th><td class="down">${esc(m.dataError)}</td></tr>` : ''}</table>
      <p class="help-text">Carnet d'ordres et bande des transactions : non disponibles avec les sources gratuites (il faudrait un flux de niveau 2 payant). Cours différés (≈ 15 min en Europe).</p>
      <button class="btn btn-xs" id="di-refresh">Recharger les données de la valeur</button>`);
    this.$('#di-refresh').onclick = async () => {
      try {
        const r = await post('/api/data/refresh', { sym: this.sym });
        toast('Données rechargées', `${int(r.days)} séances · ${esc(r.source ?? '')}`, 'ok', 2500);
        this.meta = await get(`/api/quote/${encodeURIComponent(this.sym)}`);
        this.#loadTf(this.tf, true);
        this.#dataInfo();
      } catch (e) { toast('Rechargement impossible', esc(e.message), 'ko'); }
    };
  }

  async #tabFund() {
    if (S.real) return this.#tabFundReal();
    const f = this.meta.meta.fundamentals, q = S.quote(this.sym), up = (f.objectifCoursMoyen / q.last - 1) * 100, tot = f.consensus.achat + f.consensus.neutre + f.consensus.vente;
    const rows = [['Capitalisation', `${num(f.capitalisationMdEur, 1)} Md€`], ['Nombre d\'actions', `${num(f.nombreActionsM, 1)} M`], ['Flottant', pct(f.flottantPct, 0, false)], ['PER', num(f.per, 1)], ['PER année prochaine', num(f.perAnneeProchaine, 1)], ['BPA', fprice(f.bpa, 0.001)],
      ['Rendement', pct(f.rendementDividendePct, 2, false)], ['Dividende par action', fprice(f.dividendeParAction, 0.001)], ['Taux de distribution', pct(f.tauxDistributionPct, 0, false)], ['Croissance du CA', pct(f.croissanceCaPct, 1)], ['Marge nette', pct(f.margeNettePct, 1, false)],
      ['Dette nette / EBITDA', f.detteNetteSurEbitda === null ? '<span class="muted">non pertinent (secteur financier)</span>' : f.detteNetteSurEbitda < 0 ? `${num(f.detteNetteSurEbitda, 2)} <small class="muted">(trésorerie nette)</small>` : num(f.detteNetteSurEbitda, 2)], ['ROE', pct(f.roePct, 1, false)], ['Cours / valeur comptable', num(f.prixSurValeurComptable, 2)], ['Prochaine publication', ymd(f.prochainePublication)]];
    this.$('#s-tab').innerHTML = `<div class="box-body"><div class="notice">Fondamentaux <b>simulés</b> (ordres de grandeur réalistes par secteur) : utiles pour tester l'interface et l'IA, pas pour investir.</div>
      <div class="cols cols-2" style="margin-top:8px"><table class="kv">${rows.map(([k, v]) => `<tr><th>${k}</th><td>${v}</td></tr>`).join('')}</table>
      <div><h4>Consensus des analystes (simulé)</h4><div class="row"><span class="up">Achat ${f.consensus.achat}</span><div class="grow meter" style="height:12px"><i style="width:${(f.consensus.achat / tot) * 100}%;background:var(--up)"></i></div></div>
        <div class="row"><span class="muted">Neutre ${f.consensus.neutre}</span><div class="grow meter" style="height:12px"><i style="width:${(f.consensus.neutre / tot) * 100}%;background:var(--muted)"></i></div></div>
        <div class="row"><span class="down">Vente ${f.consensus.vente}</span><div class="grow meter" style="height:12px"><i style="width:${(f.consensus.vente / tot) * 100}%;background:var(--down)"></i></div></div>
        <table class="kv" style="margin-top:8px"><tr><th>Objectif de cours moyen</th><td>${fprice(f.objectifCoursMoyen, this.tick)} ${esc(this.info.ccy)}</td></tr><tr><th>Potentiel</th><td class="${cls(up)}">${pct(up, 1)}</td></tr><tr><th>Rendement du bénéfice (1/PER)</th><td>${pct(100 / f.per, 2, false)}</td></tr></table></div></div></div>`;
  }

  /** Fondamentaux réels : ce que donnent les sources gratuites (et les sources à clé si configurées). */
  async #tabFundReal() {
    this.$('#s-tab').innerHTML = '<div class="empty">Chargement des fondamentaux…</div>';
    const r = await get(`/api/fundamentals/${encodeURIComponent(this.sym)}`).catch(() => null);
    if (!r || this.tab !== 'fund') return;
    const f = r.fundamentals ?? {}, q = S.quote(this.sym), P = (v) => fprice(v, this.tick);
    const rows = [['Capitalisation', f.capitalisationMdEur ? `${num(f.capitalisationMdEur, 1)} Md€` : '—'], ['Nombre d\'actions', f.nombreActionsM ? `${num(f.nombreActionsM, 1)} M` : '—'], ['PER', num(f.per, 1)], ['BPA', num(f.bpa, 3)],
      ['Rendement (12 mois)', pct(f.rendementDividendePct, 2, false)], ['Dividendes des 12 derniers mois', f.dividendeParAction ? `${P(f.dividendeParAction)} ${esc(this.info.ccy)}` : '—'], ['Taux de distribution', pct(f.tauxDistributionPct, 0, false)],
      ['Croissance du CA', pct(f.croissanceCaPct, 1)], ['Marge nette', pct(f.margeNettePct, 1, false)], ['ROE', pct(f.roePct, 1, false)], ['Cours / valeur comptable', num(f.prixSurValeurComptable, 2)], ['Bêta', num(f.beta, 2)],
      ['Plus haut 52 semaines', P(f.plusHaut52s)], ['Plus bas 52 semaines', P(f.plusBas52s)], ['Prochaine publication', f.prochainePublication ? ymd(f.prochainePublication) : '—']];
    const c = f.consensus, tot = c ? c.achat + c.neutre + c.vente : 0;
    this.$('#s-tab').innerHTML = `<div class="box-body"><div class="info">Sources : ${esc(f.source ?? 'cours et dividendes (Yahoo)')}. Les sources gratuites sans clé ne donnent ni PER, ni BPA, ni consensus : ajoute une clé gratuite <b>Finnhub</b> ou <b>FMP</b> dans <a href="#/reglages">Réglages → Données</a> pour les obtenir (couverture variable selon la place).</div>
      <div class="cols cols-2" style="margin-top:8px"><table class="kv">${rows.map(([k, v]) => `<tr><th>${k}</th><td>${v}</td></tr>`).join('')}</table>
      <div>${tot ? `<h4>Consensus des analystes${c.periode ? ` (${esc(c.periode)})` : ''}</h4><div class="row"><span class="up">Achat ${c.achat}</span><div class="grow meter" style="height:12px"><i style="width:${(c.achat / tot) * 100}%;background:var(--up)"></i></div></div>
        <div class="row"><span class="muted">Neutre ${c.neutre}</span><div class="grow meter" style="height:12px"><i style="width:${(c.neutre / tot) * 100}%;background:var(--muted)"></i></div></div>
        <div class="row"><span class="down">Vente ${c.vente}</span><div class="grow meter" style="height:12px"><i style="width:${(c.vente / tot) * 100}%;background:var(--down)"></i></div></div>` : '<h4>Consensus des analystes</h4><p class="muted small">Non disponible sans clé Finnhub.</p>'}
        <h4 style="margin-top:8px">Dividendes versés</h4>${r.dividends?.length ? `<table class="tbl compact"><thead><tr><th>Date</th><th class="r">Montant</th><th class="r">Rendement au cours actuel</th></tr></thead><tbody>${r.dividends.slice().reverse().map((d) => `<tr><td>${ymd(d.date)}</td><td class="r">${P(d.amount)}</td><td class="r">${q?.last ? pct((d.amount / q.last) * 100, 2, false) : '—'}</td></tr>`).join('')}</tbody></table>` : '<p class="muted small">Aucun dividende sur la période.</p>'}
        ${f.description ? `<h4 style="margin-top:8px">Activité</h4><p class="small">${esc(f.description)}</p>` : ''}</div></div></div>`;
    return undefined;
  }

  async #tabNews() {
    const items = await get(`/api/news?sym=${encodeURIComponent(this.sym)}&limit=40`);
    this.$('#s-tab').innerHTML = items.length ? `<ul class="news">${items.map((n) => newsItem(n)).join('')}</ul>` : '<div class="empty">Aucune actualité pour cette valeur, son secteur ou sa région.</div>';
  }

  async #tabHist() {
    const h = this.daily ?? (await history(this.sym, '1D')), d = h.header.dates, n = h.close.length, P = (v) => fprice(v, this.tick);
    const rows = [];
    for (let i = n - 1; i >= Math.max(1, n - 120); i--) {
      const ch = (h.close[i] / h.close[i - 1] - 1) * 100;
      rows.push(`<tr><td>${ymd(d[i])}</td><td class="r">${P(h.open[i])}</td><td class="r">${P(h.high[i])}</td><td class="r">${P(h.low[i])}</td><td class="r"><b>${P(h.close[i])}</b></td><td class="r">${chg(ch)}</td><td class="r">${int(h.volume[i])}</td><td class="r">${pct(((h.high[i] - h.low[i]) / h.close[i - 1]) * 100, 2, false)}</td></tr>`);
    }
    this.$('#s-tab').innerHTML = `<div class="form"><button class="btn btn-small" id="hx-d">Exporter le quotidien (CSV)</button><button class="btn btn-small" id="hx-tf">Exporter l'unité affichée (${TF_LABEL[this.tf]})</button><span class="help-text">${n} séances disponibles · 120 dernières affichées</span></div>
      <div class="scroll tall"><table class="tbl"><thead><tr><th>Date</th><th class="r">Ouv.</th><th class="r">+ haut</th><th class="r">+ bas</th><th class="r">Clôture</th><th class="r">Var.</th><th class="r">Volume</th><th class="r">Amplitude</th></tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
    this.$('#hx-d').onclick = () => download(`/api/export/history.csv?sym=${encodeURIComponent(this.sym)}&tf=1D`);
    this.$('#hx-tf').onclick = () => download(`/api/export/history.csv?sym=${encodeURIComponent(this.sym)}&tf=${this.tf}`);
  }
}

function weekKey(s) {
  const t = new Date(`${s}T12:00:00Z`), wd = (t.getUTCDay() + 6) % 7;
  return new Date(t.getTime() - wd * 86_400_000).toISOString().slice(0, 10);
}
const pct01 = (x) => (Number.isFinite(x) ? `${Math.round(x * 100)} %` : '—');
void [money, eur, divColor, symHref, ratingChip, cls];

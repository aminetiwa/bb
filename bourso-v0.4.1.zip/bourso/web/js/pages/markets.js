// ============================================================================
//  BOURSO :: pages/markets.js — MARCHÉS : toutes les actions (Europe en premier),
//  screener (préréglages + règles libres), carte du marché (treemap par secteur, taille =
//  capitalisation), secteurs, places boursières, matrice de corrélation, devises.
// ============================================================================
import { S, prefs } from '../core/store.js';
import { get, post, download } from '../core/api.js';
import { $, el, on, setHtml, tabs, flash, toast } from '../core/dom.js';
import { esc, num, int, pct, price, cls, big, ratingChip, ymd } from '../core/fmt.js';
import { nameCell, star, chg, bindStars, symHref, clockRow } from '../core/ui.js';
import { HeatGrid, divColor } from '../widgets/plot.js';

const REG_ORDER = ['Europe', 'Amérique du Nord', 'Asie-Pacifique', 'Amérique latine', 'Afrique & Moyen-Orient'];
const COLS = {
  cours: { label: 'Cotation', cols: [
    ['last', 'Cours', (r) => r.last, (r) => `<b>${price(r.last, S.tick(r.sym))}</b>${r.ccy !== 'EUR' ? ` <span class="muted small">${esc(r.ccy)}</span>` : ''}`, 'r'],
    ['chgPct', 'Var.', (r) => r.chgPct, (r) => chg(r.chgPct), 'r'],
    ['volume', 'Volume', (r) => r.volume, (r) => big(r.volume), 'r'],
    ['turnoverEur', 'Capitaux €', (r) => r.turnover * fx(r.ccy), (r) => big(r.turnover * fx(r.ccy)), 'r'],
    ['vwapDist', 'Écart VWAP', (r) => r.vwapDist, (r) => chg(r.vwapDist), 'r'],
  ] },
  perf: { label: 'Performances', cols: [
    ['perf1s', '1 sem.', (r) => r.perf1s, (r) => chg(r.perf1s, 1), 'r'], ['perf1m', '1 mois', (r) => r.perf1m, (r) => chg(r.perf1m, 1), 'r'],
    ['perf3m', '3 mois', (r) => r.perf3m, (r) => chg(r.perf3m, 1), 'r'], ['perf6m', '6 mois', (r) => r.perf6m, (r) => chg(r.perf6m, 1), 'r'],
    ['ytd', '1er janv.', (r) => r.ytd, (r) => chg(r.ytd, 1), 'r'], ['perf1a', '1 an', (r) => r.perf1a, (r) => chg(r.perf1a, 1), 'r'], ['perf5a', '5 ans', (r) => r.perf5a, (r) => chg(r.perf5a, 0), 'r'],
  ] },
  tech: { label: 'Technique', cols: [
    ['rating', 'Note', (r) => r.rating, (r) => ratingChip(r.rating, r.ratingLabel), ''], ['rsi14', 'RSI', (r) => r.rsi14, (r) => `<span class="${r.rsi14 > 70 ? 'down' : r.rsi14 < 30 ? 'up' : ''}">${num(r.rsi14, 1)}</span>`, 'r'],
    ['adx', 'ADX', (r) => r.adx, (r) => num(r.adx, 1), 'r'], ['macdHist', 'MACD hist.', (r) => r.macdHist, (r) => `<span class="${cls(r.macdHist)}">${num(r.macdHist, 3)}</span>`, 'r'],
    ['trendScore', 'Tendance', (r) => r.trendScore, (r) => (r.trendScore > 0.3 ? '<span class="up">▲ haussière</span>' : r.trendScore < -0.3 ? '<span class="down">▼ baissière</span>' : '<span class="muted">◆ neutre</span>'), ''],
    ['aboveSma200', '> MM200', (r) => (r.aboveSma200 ? 1 : 0), (r) => (r.aboveSma200 ? '<span class="up">oui</span>' : '<span class="down">non</span>'), 'c'],
    ['bollPctB', '%B Boll.', (r) => r.bollPctB, (r) => num(r.bollPctB, 2), 'r'], ['relVol', 'Vol. relatif', (r) => r.relVol, (r) => (r.relVol ? `× ${num(r.relVol, 2)}` : '—'), 'r'],
    ['distHi52', 'Dist. haut 52 s.', (r) => r.distHi52, (r) => chg(r.distHi52, 1), 'r'],
  ] },
  risk: { label: 'Risque', cols: [
    ['vol20', 'Vol. 20 j', (r) => r.vol20, (r) => pct(r.vol20, 1, false), 'r'], ['atrPct', 'ATR %', (r) => r.atrPct, (r) => pct(r.atrPct, 2, false), 'r'],
    ['maxDD1a', 'Perte max 1 an', (r) => r.maxDD1a, (r) => `<span class="down">${pct(r.maxDD1a, 1)}</span>`, 'r'], ['sharpe1a', 'Sharpe 1 an', (r) => r.sharpe1a, (r) => num(r.sharpe1a, 2), 'r'],
    ['var95', 'VaR 95 % (1 j)', (r) => r.var95, (r) => pct(r.var95, 2, false), 'r'], ['hurst', 'Hurst', (r) => r.hurst, (r) => num(r.hurst, 2), 'r'],
  ] },
  // données réelles : la capitalisation n'est connue qu'avec une clé (Finnhub, FMP) ; la taille
  // affichée par défaut est alors les capitaux moyens échangés par jour (mesure réelle)
  get fund() {
    const cap = ['capEur', 'Capitalisation', (r) => r.capEur, (r) => (Number.isFinite(r.capEur) ? `${num(r.capEur / 1000, 1)} Md€` : '—'), 'r'];
    const per = ['per', 'PER', (r) => r.per, (r) => num(r.per, 1), 'r'], dy = ['dy', 'Rendement', (r) => r.dy, (r) => pct(r.dy, 2, false), 'r'];
    return S.real
      ? { label: 'Taille & fondamentaux', cols: [['size', 'Capitaux / jour (20 j)', (r) => r.size, (r) => (r.size ? `${big(r.size * 1e6)} €` : '—'), 'r'], cap, per, dy] }
      : { label: 'Fondamentaux (sim.)', cols: [cap, per, dy] };
  },
};
const fx = (ccy) => {
  const r = S.overview?.fx?.find((f) => f.pair === `EUR/${ccy === 'GBX' ? 'GBP' : ccy === 'ZAC' ? 'ZAR' : ccy}`);
  const k = ccy === 'GBX' || ccy === 'ZAC' ? 100 : 1;
  return ccy === 'EUR' ? 1 : r ? 1 / r.rate / k : 1;
};

/** Champs disponibles pour les règles du screener. */
const FIELDS_ALL = () => [
  ['chgPct', 'Variation du jour (%)'], ['perf1s', 'Perf. 1 semaine (%)'], ['perf1m', 'Perf. 1 mois (%)'], ['perf3m', 'Perf. 3 mois (%)'], ['perf6m', 'Perf. 6 mois (%)'], ['perf1a', 'Perf. 1 an (%)'], ['ytd', 'Perf. depuis le 1er janv. (%)'],
  ['rsi14', 'RSI 14'], ['adx', 'ADX 14'], ['diPlus', 'DI+'], ['diMinus', 'DI−'], ['macdHist', 'Histogramme MACD'], ['rating', 'Note technique (−1…+1)'], ['trendScore', 'Score de tendance (−1…+1)'],
  ['bollPctB', '%B de Bollinger'], ['bollWidth', 'Largeur de Bollinger (%)'], ['relVol', 'Volume relatif (×)'], ['distHi52', 'Distance au plus haut 52 s. (%)'], ['distLo52', 'Distance au plus bas 52 s. (%)'],
  ['vol20', 'Volatilité 20 j (%)'], ['atrPct', 'ATR (% du cours)'], ['maxDD1a', 'Perte maximale 1 an (%)'], ['sharpe1a', 'Sharpe 1 an'], ['var95', 'VaR 95 % 1 jour (%)'], ['hurst', 'Exposant de Hurst'],
  ['per', `PER${S.real ? ' (avec clé Finnhub / FMP)' : ' (sim.)'}`], ['dy', `Rendement du dividende %${S.real ? '' : ' (sim.)'}`], ['capEur', `Capitalisation (M€)${S.real ? ' (avec clé)' : ''}`],
  ...(S.real ? [['size', 'Capitaux moyens / jour, 20 j (M€)']] : []), ['vwapDist', 'Écart au VWAP (%)'],
];
const PRESETS = [
  { id: 'oversold', name: 'Survente (RSI < 30)', rules: [['rsi14', '<', 30]], sort: 'rsi14', dir: 1 },
  { id: 'overbought', name: 'Surachat (RSI > 70)', rules: [['rsi14', '>', 70]], sort: 'rsi14', dir: -1 },
  { id: 'strongtrend', name: 'Tendance haussière forte', rules: [['trendScore', '>=', 0.8], ['adx', '>', 25], ['diPlus', '>', 'diMinus']], sort: 'adx', dir: -1 },
  { id: 'downtrend', name: 'Tendance baissière forte', rules: [['trendScore', '<=', -0.8], ['adx', '>', 25], ['diMinus', '>', 'diPlus']], sort: 'adx', dir: -1 },
  { id: 'hi52', name: 'Près du plus haut 52 semaines', rules: [['distHi52', '>', -2]], sort: 'distHi52', dir: -1 },
  { id: 'lo52', name: 'Près du plus bas 52 semaines', rules: [['distLo52', '<', 3]], sort: 'distLo52', dir: 1 },
  { id: 'volume', name: 'Volume inhabituel (× 2)', rules: [['relVol', '>', 2]], sort: 'relVol', dir: -1 },
  { id: 'momentum', name: 'Momentum 3 mois > 15 %', rules: [['perf3m', '>', 15], ['rsi14', '<', 75]], sort: 'perf3m', dir: -1 },
  { id: 'squeeze', name: 'Compression de Bollinger', rules: [['bollWidth', '<', 6]], sort: 'bollWidth', dir: 1 },
  { id: 'value', name: 'Décote (PER < 10, rendement > 3 %)', rules: [['per', '<', 10], ['dy', '>', 3]], sort: 'per', dir: 1 },
  { id: 'yield', name: 'Rendement élevé (> 4 %)', rules: [['dy', '>', 4]], sort: 'dy', dir: -1 },
  { id: 'lowvol', name: 'Faible volatilité (< 18 %)', rules: [['vol20', '<', 18], ['aboveSma200', '=', 1]], sort: 'vol20', dir: 1 },
  { id: 'buy', name: 'Note technique : achat fort', rules: [['rating', '>=', 0.5]], sort: 'rating', dir: -1 },
  { id: 'sell', name: 'Note technique : vente forte', rules: [['rating', '<=', -0.5]], sort: 'rating', dir: 1 },
  { id: 'meanrev', name: 'Retour à la moyenne (Hurst < 0,45)', rules: [['hurst', '<', 0.45]], sort: 'hurst', dir: 1 },
];

export default {
  title: 'Marchés',
  async mount(root, ctx) {
    root.innerHTML = `<div class="page-title"><h1>Marchés</h1><span class="sub">${S.universe.length} actions sur ${S.meta.exchanges.length} places${S.real ? ' · cours réels différés' : ''} · indicateurs recalculés en continu sur tous les cœurs · Europe en premier</span></div>
      <section class="box ov"><div id="m-tabs"></div><div id="m-body"></div></section>`;
    const body = $('#m-body', root);
    let cur = null;
    const offStars = bindStars(root);
    const show = (id) => {
      cur?.destroy?.();
      body.innerHTML = '';
      cur = { table: tableTab, screener: screenerTab, carte: mapTab, secteurs: sectorTab, places: placesTab, correlations: corrTab, devises: fxTab }[id](body);
      prefs.set('markets.tab', id);
      window.history.replaceState(null, '', `#/marches/${id}`);
    };
    const first = ctx.params[0] ?? prefs.get('markets.tab', 'table');
    const tc = tabs($('#m-tabs', root), [{ id: 'table', label: 'Toutes les actions' }, { id: 'screener', label: 'Screener' }, { id: 'carte', label: 'Carte du marché' }, { id: 'secteurs', label: 'Secteurs' }, { id: 'places', label: 'Places boursières' }, { id: 'correlations', label: 'Corrélations' }, { id: 'devises', label: 'Devises' }], show, first);
    show(first);
    return {
      // lien direct vers un onglet (#/marches/carte…) : l'onglet actif suit
      update(c) { if (c.params[0] && c.params[0] !== prefs.get('markets.tab')) { tc.set(c.params[0], true); show(c.params[0]); } },
      unmount() { cur?.destroy?.(); offStars(); },
    };
  },
};

// ======================================================================= tableau générique (cotations en direct)
function liveTable(container, { rows, groups, sortKey = S.real ? 'size' : 'capEur', dir = -1, pageSize = 100, extraCols = [] }) {
  let page = 0, key = sortKey, sdir = dir, data = rows;
  const colsOf = () => [
    ['fav', '', null, (r) => star(r.sym), ''], ['name', 'Valeur', (r) => r.name, (r) => nameCell(r.sym), ''],
    ...extraCols, ...groups.flatMap((g) => COLS[g].cols),
  ];
  const render = () => {
    const cols = colsOf(), c = cols.find((x) => x[0] === key);
    // tri possible sur un champ dont la colonne n'est pas affichée (taille par défaut)
    const getter = c ? c[2] : (r) => r[key];
    const sorted = getter ? [...data].sort((a, b) => {
      const x = getter(a), y = getter(b);
      if (x === y) return 0;
      if (x === null || x === undefined || Number.isNaN(x)) return 1;
      if (y === null || y === undefined || Number.isNaN(y)) return -1;
      return (typeof x === 'string' ? x.localeCompare(y, 'fr') : x - y) * sdir;
    }) : data;
    const pages = Math.max(1, Math.ceil(sorted.length / pageSize));
    page = Math.min(page, pages - 1);
    const slice = sorted.slice(page * pageSize, (page + 1) * pageSize);
    container.innerHTML = `<div class="scroll xtall"><table class="tbl sortable"><thead><tr>${cols.map(([k, l, f, , c2]) => `<th class="${c2} ${k === key ? `sorted ${sdir > 0 ? 'asc' : ''}` : ''}" data-k="${k}" ${f ? '' : 'style="cursor:default"'}>${l}</th>`).join('')}</tr></thead>
      <tbody>${slice.map((r) => `<tr data-sym="${esc(r.sym)}">${cols.map(([k, , , h, c2]) => `<td class="${c2}" data-c="${k}">${h(r)}</td>`).join('')}</tr>`).join('') || `<tr class="empty"><td colspan="${cols.length}">Aucune valeur</td></tr>`}</tbody></table></div>
      <div class="box-foot row">${sorted.length} valeurs · page <b>${page + 1}</b> / ${pages} <button class="mini" data-pg="-1" ${page ? '' : 'disabled'}>◂ précédente</button><button class="mini" data-pg="1" ${page < pages - 1 ? '' : 'disabled'}>suivante ▸</button><span class="sp"></span>cours et variations en direct · indicateurs du ${S.screen.at ? new Date(S.screen.at).toLocaleTimeString('fr-FR') : '—'}</div>`;
  };
  container.addEventListener('click', (e) => {
    const th = e.target.closest('th[data-k]');
    if (th) {
      const c = colsOf().find((x) => x[0] === th.dataset.k);
      if (!c?.[2]) return;
      if (key === th.dataset.k) sdir = -sdir; else { key = th.dataset.k; sdir = typeof c[2](data[0] ?? {}) === 'string' ? 1 : -1; }
      render();
      return;
    }
    const pg = e.target.closest('[data-pg]');
    if (pg) { page += Number(pg.dataset.pg); render(); container.querySelector('.scroll').scrollTop = 0; }
  });
  render();
  let last = 0;
  const off = S.on('quotes', (ch) => {
    const t = performance.now();
    if (t - last < 700 || !ch) return;
    last = t;
    for (const q of ch) {
      const tr = container.querySelector(`tr[data-sym="${CSS.escape(q.sym)}"]`);
      if (!tr) continue;
      const r = data.find((x) => x.sym === q.sym);
      if (r) Object.assign(r, { last: q.last, chgPct: q.chgPct, volume: q.volume, turnover: q.turnover });
      const c1 = tr.querySelector('[data-c="last"]'), c2 = tr.querySelector('[data-c="chgPct"]');
      if (c1 && r) { const h = colsOf().find((x) => x[0] === 'last')[3](r); if (c1.innerHTML !== h) { c1.innerHTML = h; flash(c1, q.dir); } }
      if (c2 && r) c2.innerHTML = chg(r.chgPct);
    }
  });
  return { set(rows2) { data = rows2; page = 0; render(); }, render, destroy: off };
}

// ======================================================================= onglet : toutes les actions
function tableTab(body) {
  const st = prefs.get('markets.filters', { region: 'Europe', ex: '', sector: '', q: '', groups: ['cours', 'perf', 'tech'], favs: false });
  body.innerHTML = `<div class="form" id="t-f">
      <label class="f">Région<select data-k="region"><option value="">Toutes</option>${REG_ORDER.map((r) => `<option ${st.region === r ? 'selected' : ''}>${esc(r)}</option>`).join('')}</select></label>
      <label class="f">Place<select data-k="ex"><option value="">Toutes</option>${S.meta.exchanges.map((e) => `<option value="${e.mic}" ${st.ex === e.mic ? 'selected' : ''}>${esc(e.short)} (${e.n})</option>`).join('')}</select></label>
      <label class="f">Secteur<select data-k="sector"><option value="">Tous</option>${Object.entries(S.meta.sectors).sort((a, b) => a[1].localeCompare(b[1], 'fr')).map(([k, v]) => `<option value="${k}" ${st.sector === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></label>
      <label class="f">Filtrer<input type="search" data-k="q" value="${esc(st.q)}" placeholder="nom, code, ISIN…"></label>
      <label class="chk"><input type="checkbox" data-k="favs" ${st.favs ? 'checked' : ''}> favoris seulement</label>
      <span class="sp"></span><span class="muted small">Colonnes :</span>${Object.entries(COLS).map(([k, g]) => `<label class="chk"><input type="checkbox" data-g="${k}" ${st.groups.includes(k) ? 'checked' : ''}> ${g.label}</label>`).join('')}
      <button class="btn btn-small" id="t-csv">Exporter (CSV)</button></div><div id="t-table"></div>`;
  const rows = () => {
    const q = st.q.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    return S.screen.rows.filter((r) => (!st.region || r.region === st.region) && (!st.ex || r.mic === st.ex) && (!st.sector || r.sectorKey === st.sector) && (!st.favs || S.isFav(r.sym))
      && (!q || `${r.name} ${r.code} ${S.info(r.sym)?.isin ?? ''}`.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().includes(q)));
  };
  let t = liveTable($('#t-table', body), { rows: rows(), groups: st.groups });
  const refresh = () => {
    prefs.set('markets.filters', st);
    t.destroy();
    t = liveTable($('#t-table', body), { rows: rows(), groups: st.groups });
  };
  $('#t-f', body).addEventListener('input', (e) => {
    const k = e.target.dataset.k, g = e.target.dataset.g;
    if (k) st[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    if (g) st.groups = [...body.querySelectorAll('[data-g]')].filter((x) => x.checked).map((x) => x.dataset.g);
    if (k === 'region' && st.ex && S.exchanges.get(st.ex)?.region !== st.region) { st.ex = ''; body.querySelector('[data-k="ex"]').value = ''; }
    refresh();
  });
  $('#t-csv', body).onclick = () => download('/api/export/screener.csv');
  const off = S.on('screener', () => t.set(rows()));
  return { destroy() { t.destroy(); off(); } };
}

// ======================================================================= onglet : screener
function screenerTab(body) {
  const st = prefs.get('markets.screener', { rules: PRESETS[0].rules, region: 'Europe', preset: 'oversold', sort: 'rsi14', dir: 1 });
  body.innerHTML = `<div class="layout l2l" style="padding:10px">
      <div><h4>Préréglages</h4><div class="stack" id="sc-presets" style="margin-top:6px">${PRESETS.map((p) => `<button class="btn btn-small ${st.preset === p.id ? 'on' : ''}" data-p="${p.id}" style="width:100%;justify-content:flex-start">${esc(p.name)}</button>`).join('')}</div></div>
      <div><div class="row wrap-ok"><label class="f">Région<select id="sc-region"><option value="">Monde</option>${REG_ORDER.map((r) => `<option ${st.region === r ? 'selected' : ''}>${esc(r)}</option>`).join('')}</select></label><span class="sp"></span><span class="help-text">Une valeur doit remplir <b>toutes</b> les règles. La comparaison peut porter sur un nombre ou un autre champ.</span></div>
        <div id="sc-rules" class="stack" style="margin:8px 0"></div>
        <div class="row"><button class="btn btn-small" id="sc-add">+ Ajouter une règle</button><button class="btn btn-small primary" id="sc-run">Appliquer</button><span class="muted small" id="sc-count"></span></div>
        <div id="sc-table" style="margin-top:8px"></div></div></div>`;
  const FIELDS = FIELDS_ALL();
  const opt = (sel) => FIELDS.map(([k, l]) => `<option value="${k}" ${sel === k ? 'selected' : ''}>${esc(l)}</option>`).join('');
  const renderRules = () => {
    $('#sc-rules', body).innerHTML = st.rules.map(([f, op, v], i) => `<div class="row" data-i="${i}"><select data-r="f">${opt(f)}</select><select data-r="op">${['<', '<=', '>', '>=', '='].map((o) => `<option ${o === op ? 'selected' : ''}>${o}</option>`).join('')}</select>
      ${typeof v === 'string' ? `<select data-r="v">${opt(v)}</select>` : `<input type="number" data-r="v" value="${v}" step="any" style="width:110px">`}<button class="mini" data-swap="${i}" title="comparer à un nombre / à un champ">⇄</button><button class="mini" data-del="${i}">✕</button></div>`).join('');
  };
  const read = () => {
    st.rules = [...body.querySelectorAll('#sc-rules [data-i]')].map((row) => {
      const v = row.querySelector('[data-r="v"]');
      return [row.querySelector('[data-r="f"]').value, row.querySelector('[data-r="op"]').value, v.tagName === 'SELECT' ? v.value : Number(v.value)];
    });
    st.region = $('#sc-region', body).value;
  };
  let table = null;
  const run = () => {
    read();
    prefs.set('markets.screener', st);
    const test = (r) => st.rules.every(([f, op, v]) => {
      const a = f === 'aboveSma200' ? (r[f] ? 1 : 0) : r[f], b = typeof v === 'string' ? r[v] : v;
      if (!Number.isFinite(a) || !Number.isFinite(b)) return false;
      return op === '<' ? a < b : op === '<=' ? a <= b : op === '>' ? a > b : op === '>=' ? a >= b : Math.abs(a - b) < 1e-9;
    });
    const res = S.screen.rows.filter((r) => (!st.region || r.region === st.region) && test(r));
    const pool = S.screen.rows.filter((r) => !st.region || r.region === st.region);
    // données réelles : PER / capitalisation inconnus sans clé → le dire plutôt que « 0 résultat » muet
    const keyed = st.rules.some(([f, , v]) => ['per', 'capEur'].includes(f) || ['per', 'capEur'].includes(v));
    const known = keyed ? pool.filter((r) => st.rules.every(([f, , v]) => (!['per', 'capEur'].includes(f) || Number.isFinite(r[f])) && (typeof v !== 'string' || !['per', 'capEur'].includes(v) || Number.isFinite(r[v])))).length : pool.length;
    $('#sc-count', body).innerHTML = `${res.length} valeur(s) sur ${pool.length}${S.real && keyed ? ` · <span class="warn">PER / capitalisation connus pour ${known} valeur(s) seulement : ajoute une clé Finnhub ou FMP dans <a href="#/reglages">Réglages → Données</a></span>` : ''}`;
    table?.destroy();
    const extra = [...new Set(st.rules.flatMap(([f, , v]) => [f, typeof v === 'string' ? v : null]).filter(Boolean))].filter((k) => !['rsi14', 'chgPct', 'last'].includes(k))
      .map((k) => [k, (FIELDS.find((x) => x[0] === k)?.[1] ?? k).replace(/ \(.*\)/, ''), (r) => r[k], (r) => (typeof r[k] === 'boolean' ? (r[k] ? 'oui' : 'non') : num(r[k], Math.abs(r[k]) < 10 ? 2 : 1)), 'r']);
    table = liveTable($('#sc-table', body), { rows: res, groups: ['cours'], sortKey: st.sort ?? 'chgPct', dir: st.dir ?? -1, extraCols: [['rsi14', 'RSI', (r) => r.rsi14, (r) => num(r.rsi14, 1), 'r'], ...extra, ['rating', 'Note', (r) => r.rating, (r) => ratingChip(r.rating, r.ratingLabel), '']] });
  };
  body.addEventListener('click', (e) => {
    const p = e.target.closest('[data-p]');
    if (p) {
      const pr = PRESETS.find((x) => x.id === p.dataset.p);
      Object.assign(st, { rules: JSON.parse(JSON.stringify(pr.rules)), preset: pr.id, sort: pr.sort, dir: pr.dir });
      for (const b of body.querySelectorAll('[data-p]')) b.classList.toggle('on', b === p);
      renderRules();
      run();
    }
    const d = e.target.closest('[data-del]');
    if (d) { read(); st.rules.splice(Number(d.dataset.del), 1); renderRules(); }
    const sw = e.target.closest('[data-swap]');
    if (sw) { read(); const r = st.rules[Number(sw.dataset.swap)]; r[2] = typeof r[2] === 'string' ? 0 : 'rsi14'; renderRules(); }
  });
  $('#sc-add', body).onclick = () => { read(); st.rules.push(['perf1m', '>', 0]); renderRules(); };
  $('#sc-run', body).onclick = run;
  renderRules();
  run();
  const off = S.on('screener', run);
  return { destroy() { table?.destroy(); off(); } };
}

// ======================================================================= onglet : carte du marché (treemap)
function squarify(items, x, y, w, h) {
  const out = [], total = items.reduce((a, b) => a + b.v, 0);
  if (!total || !items.length) return out;
  const scale = (w * h) / total;
  let rest = items.map((it) => ({ ...it, a: it.v * scale }));
  let X = x, Y = y, W = w, H = h;
  const worst = (row, len) => {
    const s = row.reduce((a, b) => a + b.a, 0), mx = Math.max(...row.map((r) => r.a)), mn = Math.min(...row.map((r) => r.a));
    return Math.max((len * len * mx) / (s * s), (s * s) / (len * len * mn));
  };
  while (rest.length) {
    const len = Math.min(W, H), row = [rest[0]];
    let k = 1;
    while (k < rest.length && worst([...row, rest[k]], len) <= worst(row, len)) row.push(rest[k++]);
    rest = rest.slice(k);
    const s = row.reduce((a, b) => a + b.a, 0);
    if (W >= H) {
      const cw = s / H;
      let cy = Y;
      for (const r of row) { const ch = r.a / cw; out.push({ ...r, x: X, y: cy, w: cw, h: ch }); cy += ch; }
      X += cw; W -= cw;
    } else {
      const ch = s / W;
      let cx = X;
      for (const r of row) { const cw = r.a / ch; out.push({ ...r, x: cx, y: Y, w: cw, h: ch }); cx += cw; }
      Y += ch; H -= ch;
    }
  }
  return out;
}

function mapTab(body) {
  const st = prefs.get('markets.map', { region: 'Europe', metric: 'chgPct' });
  body.innerHTML = `<div class="form"><label class="f">Région<select id="mp-r"><option value="">Monde</option>${REG_ORDER.map((r) => `<option ${st.region === r ? 'selected' : ''}>${esc(r)}</option>`).join('')}</select></label>
    <label class="f">Couleur<select id="mp-m"><option value="chgPct">variation du jour</option><option value="perf1s">1 semaine</option><option value="perf1m">1 mois</option><option value="perf3m">3 mois</option><option value="perf1a">1 an</option><option value="rsi14">RSI 14</option><option value="relVol">volume relatif</option></select></label>
    <span class="help-text">Surface = ${S.real ? 'capitaux moyens échangés par jour (20 séances)' : 'capitalisation'} · regroupement par secteur · clic : ouvrir le graphique</span></div><div class="treemap" id="mp"></div>`;
  $('#mp-m', body).value = st.metric;
  const draw = () => {
    st.region = $('#mp-r', body).value;
    st.metric = $('#mp-m', body).value;
    prefs.set('markets.map', st);
    const box = $('#mp', body), W = box.clientWidth, H = box.clientHeight;
    const rows = S.screen.rows.filter((r) => (!st.region || r.region === st.region) && Number.isFinite(r.chgPct) && (r.size ?? r.capEur) > 0);
    const bySec = new Map();
    for (const r of rows) { if (!bySec.has(r.sector)) bySec.set(r.sector, []); bySec.get(r.sector).push(r); }
    const area = (r) => Math.max(1e-3, r.size ?? r.capEur ?? 0);
    const secs = [...bySec.entries()].map(([name, list]) => ({ name, list, v: list.reduce((a, r) => a + area(r), 0) })).sort((a, b) => b.v - a.v);
    const m = st.metric, val = (r) => (m === 'rsi14' ? (r.rsi14 - 50) / 10 : m === 'relVol' ? ((r.relVol ?? 1) - 1) * 2 : r[m] ?? 0);
    const scale = m === 'chgPct' ? 3 : m === 'perf1s' ? 6 : m === 'perf1m' ? 12 : m === 'perf3m' ? 20 : m === 'perf1a' ? 35 : 3;
    let html = '';
    for (const sb of squarify(secs, 0, 0, W, H)) {
      html += `<div class="sector" style="left:${sb.x}px;top:${sb.y}px;width:${sb.w}px;height:${sb.h}px"><span>${esc(sb.name)}</span></div>`;
      const tiles = squarify(sb.list.map((r) => ({ r, v: area(r) })).sort((a, b) => b.v - a.v), sb.x + 1, sb.y + 14, Math.max(1, sb.w - 2), Math.max(1, sb.h - 15));
      for (const t of tiles) {
        const r = t.r, v = val(r), lab = m === 'rsi14' ? num(r.rsi14, 0) : m === 'relVol' ? `× ${num(r.relVol, 1)}` : pct(r[m], 1);
        html += `<a class="tile" href="${symHref(r.sym)}" title="${esc(r.name)} · ${esc(r.ex)} · ${pct(r.chgPct)} · RSI ${num(r.rsi14, 0)}" style="left:${t.x}px;top:${t.y}px;width:${t.w}px;height:${t.h}px;background:${divColor(v, scale)}">${t.w > 46 && t.h > 24 ? `<b>${esc(r.code)}</b>${lab}` : ''}</a>`;
      }
    }
    box.innerHTML = html || `<div class="empty">${S.real ? 'Historiques en cours de chargement : la carte se remplit au fil des valeurs chargées.' : 'Aucune valeur'}</div>`;
  };
  body.addEventListener('change', draw);
  draw();
  const ro = new ResizeObserver(() => draw());
  ro.observe($('#mp', body));
  let last = 0;
  const off = S.on('quotes', () => { if (Date.now() - last > 3000 && st.metric === 'chgPct') { last = Date.now(); for (const r of S.screen.rows) { const q = S.quote(r.sym); if (q) r.chgPct = q.chgPct; } draw(); } });
  return { destroy() { ro.disconnect(); off(); } };
}

// ======================================================================= onglet : secteurs
function sectorTab(body) {
  body.innerHTML = '<div class="empty">Chargement…</div>';
  const draw = async () => {
    const list = await get('/api/sectors');
    const maxAbs = Math.max(0.5, ...list.map((s) => Math.abs(s.chg)));
    body.innerHTML = `<table class="tbl big"><thead><tr><th>Secteur</th><th class="r">Valeurs</th><th>Variation moyenne du jour</th><th class="r">Var.</th><th class="r">Hausses / baisses</th><th class="r">Perf. 1 mois</th><th class="r">${S.real ? 'Capitaux / jour (20 j)' : 'Capitalisation'}</th><th>Meilleure</th><th>Moins bonne</th></tr></thead><tbody>${list.map((s) => `<tr>
      <td><b>${esc(s.name)}</b></td><td class="r">${s.n}</td><td style="width:22%"><div class="meter center"><i style="left:${s.chg >= 0 ? 50 : 50 + (s.chg / maxAbs) * 50}%;width:${(Math.abs(s.chg) / maxAbs) * 50}%;background:${s.chg >= 0 ? 'var(--up)' : 'var(--down)'}"></i></div></td>
      <td class="r">${chg(s.chg)}</td><td class="r"><span class="up">${s.up}</span> / <span class="down">${s.down}</span></td><td class="r">${chg(s.perf1m, 1)}</td><td class="r">${S.real ? `${big((s.size ?? 0) * 1e6)} €` : `${num(s.cap / 1000, 0)} Md€`}</td>
      <td>${s.best ? `<a href="${symHref(s.best.sym)}">${esc(s.best.name)}</a> ${chg(s.best.chgPct)}` : ''}</td><td>${s.worst ? `<a href="${symHref(s.worst.sym)}">${esc(s.worst.name)}</a> ${chg(s.worst.chgPct)}` : ''}</td></tr>`).join('')}</tbody></table>`;
  };
  draw();
  const t = setInterval(draw, 15_000);
  return { destroy() { clearInterval(t); } };
}

// ======================================================================= onglet : places
function placesTab(body) {
  const draw = () => {
    const o = S.overview;
    if (!o) return;
    const idx = new Map(o.indices.map((i) => [i.key, i]));
    body.innerHTML = `<table class="tbl big"><thead><tr><th>Place</th><th>Pays</th><th>Région</th><th>Horaires (local)</th><th class="r">Heure locale</th><th>État</th><th>Séance</th><th class="r">Valeurs</th><th>${S.real ? 'Indice de référence' : 'Indice (panier simulé)'}</th><th class="r">Niveau</th><th class="r">Var.</th><th class="r">▲ / ▼</th></tr></thead><tbody>${S.meta.exchanges.map((e) => {
      const c = o.clocks.find((x) => x.mic === e.mic), i = idx.get(e.mic);
      return `<tr><td><b>${esc(e.name)}</b><small>${esc(e.mic)} · ${esc(e.ccy)}</small></td><td>${esc(e.countryName)}</td><td>${esc(e.region)}</td><td>${esc(e.open)} – ${esc(e.close)}${e.breaks.length ? ' <small>(pause midi)</small>' : ''}</td><td class="r num">${esc(c?.time ?? '—')}</td>
        <td>${c?.live ? '<span class="chip ok">ouverte</span>' : '<span class="chip">fermée</span>'}${S.real ? `<small>${esc(c?.realLabel ?? '')}</small>` : `<small>réel : ${esc(c?.realLabel ?? '')}</small>`}</td><td style="width:90px"><div class="meter blue"><i style="width:${((c?.progress ?? 0) * 100).toFixed(1)}%"></i></div></td>
        <td class="r">${e.n}</td><td>${esc(S.real ? i?.name ?? e.index : e.index)}</td><td class="r">${i ? num(i.level, 2) : '—'}</td><td class="r">${i ? chg(i.chgPct) : '—'}</td><td class="r small">${i ? `<span class="up">${i.up}</span>/<span class="down">${i.down}</span>` : ''}</td></tr>`;
    }).join('')}</tbody></table><div class="box-foot">${S.real
      ? 'Heures et états réels des places (week-ends, fériés et pauses de midi compris). Indices : niveaux réels différés ; ▲ / ▼ compte les valeurs suivies par Bourso sur cette place.'
      : 'En mode démonstration toutes les places sont « ouvertes » en continu (séances simulées) ; la colonne « réel » indique l\'état réel de la place à cette heure.'}</div>`;
  };
  draw();
  const off = S.on('overview', draw);
  return { destroy: off };
}

// ======================================================================= onglet : corrélations
function corrTab(body) {
  const st = prefs.get('markets.corr', { region: 'Europe', n: 30, window: 252 });
  body.innerHTML = `<div class="form"><label class="f">Région<select id="co-r"><option value="">Monde</option>${REG_ORDER.map((r) => `<option ${st.region === r ? 'selected' : ''}>${esc(r)}</option>`).join('')}</select></label>
    <label class="f">Plus grosses capitalisations<input type="number" id="co-n" value="${st.n}" min="5" max="80"></label><label class="f">Fenêtre (séances)<input type="number" id="co-w" value="${st.window}" min="30" max="1259"></label>
    <button class="btn btn-small primary" id="co-go">Calculer</button><span class="help-text" id="co-info">Corrélation des rendements quotidiens, ordre par regroupement hiérarchique (les valeurs qui évoluent ensemble sont voisines).</span></div><div class="box-body"><canvas id="co-cv" style="width:100%"></canvas></div>`;
  let grid = null;
  const go = async () => {
    Object.assign(st, { region: $('#co-r', body).value, n: Number($('#co-n', body).value), window: Number($('#co-w', body).value) });
    prefs.set('markets.corr', st);
    const t0 = performance.now(), r = await post('/api/lab/correlation', { region: st.region || undefined, n: st.n, window: st.window });
    const ord = r.order, names = ord.map((i) => S.info(r.syms[i])?.code ?? r.syms[i]);
    const vals = ord.map((i) => ord.map((j) => r.matrix[i][j]));
    grid?.destroy();
    grid = new HeatGrid($('#co-cv', body), { rows: names, cols: names, values: vals, max: 1, colsVertical: true, format: (v) => num(v, 2), showValues: st.n <= 20, onClick: (a, b) => { location.hash = symHref(r.syms[ord[a]]); void b; } });
    grid.render();
    let s = 0, k = 0;
    for (let i = 0; i < vals.length; i++) for (let j = i + 1; j < vals.length; j++) { s += vals[i][j]; k++; }
    $('#co-info', body).textContent = `${r.syms.length} valeurs · ${r.window} séances · corrélation moyenne ${num(s / k, 3)} · calcul ${Math.round(performance.now() - t0)} ms (worker)`;
  };
  $('#co-go', body).onclick = go;
  go().catch((e) => toast('Corrélations', esc(e.message), 'ko'));
  return { destroy() { grid?.destroy(); } };
}

// ======================================================================= onglet : devises
function fxTab(body) {
  const draw = () => {
    const f = S.overview?.fx;
    if (!f) return;
    const cc = ['EUR', ...f.map((x) => x.pair.slice(4))], rate = (c) => (c === 'EUR' ? 1 : f.find((x) => x.pair === `EUR/${c}`)?.rate ?? NaN);
    const main = ['EUR', 'USD', 'GBP', 'CHF', 'JPY', 'SEK', 'NOK', 'DKK', 'CAD', 'AUD', 'HKD', 'CNY'];
    body.innerHTML = `<div class="cols cols-2" style="padding:10px"><table class="tbl"><thead><tr><th>Paire</th><th class="r">Cours</th><th class="r">Inverse</th><th class="r">${S.real ? 'Var. / veille' : 'Var. depuis l\'ouverture'}</th>${S.real ? '<th>Source</th>' : ''}</tr></thead><tbody>${f.map((x) => `<tr><td><b>${esc(x.pair)}</b></td><td class="r num">${num(x.rate, x.rate > 50 ? 2 : 5)}</td><td class="r num">${num(1 / x.rate, 1 / x.rate > 50 ? 2 : 5)}</td><td class="r">${chg(x.chgPct, 3)}</td>${S.real ? `<td class="small muted">${esc(x.source ?? '')}</td>` : ''}</tr>`).join('')}</tbody></table>
      <div><h4>Taux croisés (1 unité de la ligne en devise de la colonne)</h4><div class="scroll tall"><table class="tbl compact"><thead><tr><th></th>${main.map((c) => `<th class="r">${c}</th>`).join('')}</tr></thead><tbody>${main.map((a) => `<tr><td><b>${a}</b></td>${main.map((b) => `<td class="r num">${a === b ? '—' : num(rate(b) / rate(a), rate(b) / rate(a) > 50 ? 2 : 4)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>
      <p class="help-text">${S.real
        ? 'Taux réels : référence quotidienne de la Banque centrale européenne (publiée vers 16 h les jours ouvrés), affinée en séance par Yahoo Finance (différé). Ils valorisent le portefeuille en euros.'
        : 'Taux SIMULÉS (ordres de grandeur réalistes, faible volatilité) servant à valoriser le portefeuille en euros.'}</p></div></div>`;
    void cc;
  };
  draw();
  const off = S.on('overview', draw);
  return { destroy: off };
}
void [el, on, setHtml, int, ymd, clockRow];

// ============================================================================
//  BOURSO :: pages/settings.js — RÉGLAGES.
//
//  ▸ Modèle d'IA (Ollama) : choix du serveur, du modèle des analyses et de celui de l'agent,
//    liste des modèles installés avec leurs capacités réelles (outils, réflexion et ses niveaux,
//    vision), contexte maximal, place en mémoire ; test de vitesse ; téléchargement d'un modèle
//    (progression en direct) ; création du modèle optimisé « bourso » ; suppression.
//  ▸ Génération (température, réflexion, contexte, longueur, maintien en mémoire), analyse
//    automatique des favoris, calcul (niveau, répartition GPU/CPU), négociation fictive,
//    affichage.
//  ▸ Données de marché : réelles (sources publiques gratuites) ou démonstration, intensité des
//    rafraîchissements, clés gratuites facultatives (Finnhub, FMP, Twelve Data, Stooq), flux
//    d'actualités, test des sources depuis cette machine.
// ============================================================================
import { S, prefs } from '../core/store.js';
import { get, post, del } from '../core/api.js';
import { live } from '../core/live.js';
import { $, on, setHtml, setText, toast, confirmBox, meter, saveFile } from '../core/dom.js';
import { esc, num, int, pct, big, bytes, dur, ago, dateTime } from '../core/fmt.js';

/** Sources gratuites à clé (facultatives) : ce qu'elles apportent et où obtenir la clé. */
const KEYED = [
  { k: 'finnhub', name: 'Finnhub', url: 'https://finnhub.io/register', gives: 'PER, BPA, ROE, marges, capitalisation, consensus des analystes, prochaine publication, actualités par société (60 requêtes/min ; couverture surtout américaine en offre gratuite)' },
  { k: 'fmp', name: 'Financial Modeling Prep', url: 'https://site.financialmodelingprep.com/developer/docs', gives: 'profil, capitalisation, PER, rendement, marges (≈ 250 requêtes/jour)' },
  { k: 'twelvedata', name: 'Twelve Data', url: 'https://twelvedata.com/pricing', gives: 'historiques quotidiens de secours — offre gratuite : actions américaines seulement (8 requêtes/min, 800/jour)' },
  { k: 'stooq', name: 'Stooq', url: 'https://stooq.com/q/d/?s=aapl.us&get_apikey', gives: 'historiques de secours ; la clé s\'obtient sur leur page de téléchargement CSV après un captcha que TU résous dans ton navigateur' },
];
const INTENSITY_HELP = {
  econome: 'cours toutes les 10 min (favoris et valeur affichée : 5 min) — le moins de requêtes, utile si Yahoo te limite',
  normale: 'cours toutes les 3 min (favoris et valeur affichée : 90 s) — conseillé',
  soutenue: 'cours toutes les 90 s (favoris et valeur affichée : 45 s) — plus de risque d\'être limité par Yahoo',
};

/** Modèles conseillés (Ollama) pour une machine capable de faire tourner un modèle ~30B. */
const RECOMMENDED = [
  { name: 'qwen3:30b', size: '19 Go', vram: '24 Go (ou 12-16 Go + RAM)', note: 'Choix par défaut : 30B « mixture of experts » (≈ 3B actifs par mot), rapide, outils + réflexion, bon en français.' },
  { name: 'qwen3.5:35b', size: '22 Go', vram: '24 Go', note: '35B « mixture of experts » (≈ 3B actifs, alias 35b-a3b) : outils, réflexion, images, contexte 256k ; aussi rapide que le 30B.' },
  { name: 'qwen3.8:27b', size: '18 Go', vram: '24 Go', note: 'Le plus récent (août 2026) : 27B dense, images, contexte 256k ; Ollama à jour requis ; plus lent qu\'un modèle MoE.' },
  { name: 'qwen3.5:27b', size: '17 Go', vram: '20-24 Go', note: '27B dense : outils, réflexion, images, contexte 256k.' },
  { name: 'qwen3.6:27b', size: '17 Go', vram: '20-24 Go', note: '27B, images, contexte 256k, orienté agents.' },
  { name: 'gemma4:26b', size: '18 Go', vram: '20-24 Go', note: 'Google, multimodal avec réflexion ; vérifie la capacité « outils » ci-dessus une fois installé (sinon l\'agent passe en mode données pré-calculées).' },
  { name: 'qwen3:32b', size: '20 Go', vram: '24 Go', note: 'Version « dense » de Qwen3 : plus lente que le 30B MoE, raisonnement un peu plus solide.' },
  { name: 'gpt-oss:20b', size: '14 Go', vram: '16 Go', note: 'Modèle ouvert d\'OpenAI : raisonnement à niveaux (faible / moyen / élevé), outils.' },
  { name: 'mistral-small3.2:24b', size: '15 Go', vram: '16-24 Go', note: 'Français excellent, appels d\'outils fiables, pas de mode réflexion.' },
  { name: 'deepseek-r1:32b', size: '20 Go', vram: '24 Go', note: 'Spécialiste du raisonnement : lent mais approfondi.' },
  { name: 'qwen3:14b', size: '9 Go', vram: '12 Go', note: 'Pour une carte 12 Go : bon compromis.' },
  { name: 'qwen3:8b', size: '5 Go', vram: '8 Go', note: 'Petite carte ou portable : rapide, moins précis.' },
];
const CAP = { tools: ['outils', 'ok'], thinking: ['réflexion', 'run'], vision: ['images', ''], embedding: ['embeddings', 'hold'], completion: ['texte', ''] };
const KEEP = [['5m', '5 minutes'], ['30m', '30 minutes'], ['1h', '1 heure'], ['4h', '4 heures'], ['-1', 'toujours (jamais déchargé)'], ['0', 'décharger après chaque appel']];

export default {
  title: 'Réglages',
  async mount(root) {
    root.innerHTML = `<div class="page-title"><h1>Réglages</h1><span class="sub">données de marché, modèle d'IA, génération, analyse automatique, calcul, négociation, affichage · enregistrés sur le serveur local</span></div>
      <section class="box" id="st-data-box"><h2 class="box-title"><span class="ico">⇅</span>Données de marché <span class="title-note" id="st-data-note"></span></h2>
        <div class="cols cols-2" style="padding:10px" id="st-data"></div>
        <div id="st-check" style="padding:0 10px 10px"></div></section>
      <section class="box"><h2 class="box-title"><span class="ico">◆</span>Modèle d'IA (Ollama) <span class="tools"><button class="btn btn-xs" id="st-refresh">actualiser</button></span></h2>
        <div class="form" id="st-host"></div>
        <div class="cols cols-2" style="padding:0 10px 6px" id="st-choose"></div>
        <div class="scroll tall"><table class="tbl" id="st-models"></table></div>
        <div id="st-test"></div>
        <div class="cols cols-2" style="padding:10px">
          <div><h4>Télécharger un modèle</h4><div class="form" style="padding:6px 0"><input type="text" id="st-pull-name" placeholder="nom Ollama, ex. qwen3:30b" style="width:240px"><button class="btn btn-small primary" id="st-pull">Télécharger</button><span class="help-text">depuis la bibliothèque d'Ollama</span></div>
            <div id="st-ops"></div><table class="tbl compact" id="st-reco"></table></div>
          <div><h4>Créer le modèle « bourso » <small class="muted">(facultatif)</small></h4><p class="small">Copie d'un modèle installé avec des consignes et paramètres par défaut (température 0,1, top-p 0,9, top-k 20, pénalité de répétition 1,05, contexte des réglages). <b>Facultatif</b> : Bourso envoie déjà ses consignes et ses réglages à chaque analyse, donc choisir directement le modèle de base dans « Modèle des analyses » donne le même résultat.</p>
            <div class="form" style="padding:4px 0"><label class="f">Modèle de base<select id="st-base"></select></label><label class="f">Nom<input type="text" id="st-newname" value="bourso" style="width:120px"></label><button class="btn btn-small" id="st-create">Créer</button></div>
            <div id="st-create-help"></div>
            <div class="info small">Conseil : un seul modèle pour les analyses ET l'agent. Deux modèles différents = deux modèles en mémoire, ou des rechargements de plusieurs secondes à chaque changement.</div></div>
        </div></section>
      <div class="cols cols-2">
        <section class="box"><h2 class="box-title"><span class="ico">⚙</span>Génération — analyses</h2><div class="form col" id="st-gen"></div></section>
        <section class="box"><h2 class="box-title"><span class="ico">✉</span>Génération — agent Bourso Pro</h2><div class="form col" id="st-agent"></div></section>
        <section class="box"><h2 class="box-title"><span class="ico">★</span>Analyse automatique des favoris</h2><div class="form col" id="st-policy"></div></section>
        <section class="box"><h2 class="box-title"><span class="ico">⚡</span>Calcul (GPU / CPU)</h2><div class="form col" id="st-compute"></div></section>
        <section class="box"><h2 class="box-title"><span class="ico">₪</span>Négociation fictive</h2><div class="form col" id="st-trade"></div></section>
        <section class="box"><h2 class="box-title"><span class="ico">▣</span>Affichage et données</h2><div class="form col" id="st-ui"></div></section>
      </div>`;
    const R = (s) => root.querySelector(s);
    let info = null;
    const ops = new Map();

    // ================================================================= modèles
    const capChips = (m) => (m.capabilities ? m.capabilities.filter((c) => CAP[c] && c !== 'completion').map((c) => `<span class="chip ${CAP[c][1]}">${CAP[c][0]}${c === 'thinking' && m.thinking?.values?.some((v) => typeof v === 'string') ? ` : ${m.thinking.values.filter((v) => typeof v === 'string').join('/')}` : ''}</span>`).join(' ') : '<span class="small muted">capacités inconnues (Ollama ancien)</span>');
    const isChat = (m) => !m.capabilities || m.capabilities.includes('completion');
    const renderModels = () => {
      if (!info) return;
      const a = S.settings.ai, ag = S.settings.agent;
      setHtml(R('#st-host'), `<label class="f">Serveur Ollama<input type="text" id="st-h" value="${esc(info.host)}" style="width:260px"></label><button class="btn btn-small" id="st-h-go">Appliquer</button>
        <span>${info.up ? `<span class="chip ok">joignable</span> version ${esc(info.version)}` : '<span class="chip ko">injoignable</span>'} · ${info.models.length} modèle(s) installé(s)</span>
        <span class="help-text">Par défaut http://127.0.0.1:11434 (variable OLLAMA_HOST). Un autre ordinateur du réseau peut servir le modèle.</span>`);
      R('#st-h-go').onclick = async () => {
        const r = await post('/api/ollama/host', { host: R('#st-h').value });
        toast(r.up ? 'Ollama joignable' : 'Ollama injoignable', esc(r.up ? `version ${r.version}` : r.error ?? ''), r.up ? 'ok' : 'ko');
        load();
      };
      const chat = info.models.filter(isChat);
      const warn = (st, kind) => (st.installed === false ? `<div class="notice small">« ${esc(st.wanted)} » n'est pas installé : <b>${esc(st.used)}</b> (le meilleur modèle installé) est utilisé à la place. Choisis-le ci-dessus pour faire disparaître ce message${/^bourso(:|$)/.test(st.wanted ?? '') ? ' : « bourso » est facultatif' : ''}.</div>` : '') + (kind === 'agent' && (info.models.find((m) => m.name === st.used)?.capabilities ?? ['tools']).includes('tools') === false ? '<div class="notice small">Ce modèle ne sait pas appeler d\'outils : l\'agent lui donnera des données pré-calculées (moins précis qu\'un modèle avec outils).</div>' : '');
      const opt = (m, sel) => `<option value="${esc(m.name)}" ${m.name === sel ? 'selected' : ''}>${esc(m.name)} — ${esc(m.params ?? '?')} ${esc(m.quant ?? '')} · ${bytes(m.size)}${m.capabilities?.includes('tools') ? ' · outils' : ''}${m.capabilities?.includes('thinking') ? ' · réflexion' : ''}</option>`;
      const aSel = a.model ? info.analysis.used : '', gSel = ag.model || '';
      const autoOpt = `<option value="" ${a.model ? '' : 'selected'}>automatique — meilleur modèle installé${info.analysis.auto && info.analysis.used ? ` (${esc(info.analysis.used)})` : ''}</option>`;
      setHtml(R('#st-choose'), `<div><h4>Modèle des analyses <small class="muted">(favoris et demandes)</small></h4><select id="st-ai-model" style="width:100%">${autoOpt}${chat.map((m) => opt(m, aSel)).join('')}${!a.model || chat.some((m) => m.name === a.model || m.name === `${a.model}:latest`) ? '' : `<option value="${esc(a.model)}" selected>${esc(a.model)} (non installé)</option>`}</select>${warn(info.analysis, 'ai')}</div>
        <div><h4>Modèle de l'agent Bourso Pro</h4><select id="st-ag-model" style="width:100%"><option value="">même modèle que les analyses (recommandé)</option>${chat.map((m) => opt(m, gSel)).join('')}</select>${warn(info.agent, 'agent')}</div>`);
      R('#st-ai-model').onchange = async (e) => { await S.saveSettings({ ai: { model: e.target.value || null } }); toast('Modèle des analyses', esc(e.target.value || 'automatique'), 'ok', 2000); load(); };
      R('#st-ag-model').onchange = async (e) => { await S.saveSettings({ agent: { model: e.target.value || null } }); toast('Modèle de l\'agent', esc(e.target.value || 'même modèle que les analyses'), 'ok', 2000); load(); };
      setHtml(R('#st-models'), `<thead><tr><th>Modèle installé</th><th>Famille</th><th class="r">Paramètres</th><th>Quantif.</th><th class="r">Taille</th><th class="r">Contexte max</th><th>Capacités</th><th>En mémoire</th><th>Utilisé pour</th><th></th></tr></thead><tbody>${info.models.map((m) => {
        const usedA = m.name === info.analysis.used, usedG = m.name === info.agent.used;
        return `<tr class="${usedA || usedG ? 'sel' : ''}"><td><b>${esc(m.name)}</b>${m.parent ? `<small>basé sur ${esc(m.parent)}</small>` : ''}<small>modifié ${ago(Date.parse(m.modifiedAt))}</small></td><td>${esc(m.family ?? '—')}</td><td class="r">${esc(m.params ?? '—')}</td><td>${esc(m.quant ?? '—')}</td><td class="r">${bytes(m.size)}</td>
          <td class="r">${m.contextLength ? `${int(m.contextLength / 1024)} k` : '—'}</td><td>${capChips(m)}</td><td>${m.loaded ? `<span class="chip ok">chargé</span><small>${bytes(m.loaded.vram)} en VRAM${m.loaded.contextLength ? ` · ctx ${int(m.loaded.contextLength)}` : ''}</small>` : '<span class="small muted">—</span>'}</td>
          <td>${usedA ? '<span class="chip run">analyses</span> ' : ''}${usedG ? '<span class="chip run">agent</span>' : ''}</td>
          <td class="r nowrap">${isChat(m) ? `<button class="mini" data-use-a="${esc(m.name)}" ${usedA ? 'disabled' : ''}>analyses</button> <button class="mini" data-use-g="${esc(m.name)}">agent</button> <button class="mini" data-test="${esc(m.name)}">tester</button> <button class="mini" data-base="${esc(m.name)}" title="créer « bourso » à partir de ce modèle">→ bourso</button> ` : ''}<button class="mini" data-del="${esc(m.name)}" title="supprimer du disque">✕</button></td></tr>`;
      }).join('') || '<tr class="empty"><td colspan="10">Aucun modèle installé : télécharges-en un ci-dessous (qwen3:30b conseillé).</td></tr>'}</tbody>`);
      setHtml(R('#st-reco'), `<thead><tr><th>Conseillés</th><th class="r">Taille</th><th>Mémoire GPU conseillée</th><th></th></tr></thead><tbody>${RECOMMENDED.map((r) => {
        const inst = info.models.some((m) => m.name === r.name || m.name === `${r.name}:latest`);
        return `<tr><td><b>${esc(r.name)}</b><small style="white-space:normal">${esc(r.note)}</small></td><td class="r">${r.size}</td><td>${r.vram}</td><td>${inst ? '<span class="chip ok">installé</span>' : `<button class="mini" data-pull="${esc(r.name)}">télécharger</button>`}</td></tr>`;
      }).join('')}</tbody>`);
      R('#st-base').innerHTML = chat.filter((m) => !/^bourso(:|$)/.test(m.name)).map((m) => `<option ${m.name.startsWith('qwen3:30b') ? 'selected' : ''}>${esc(m.name)}</option>`).join('');
      renderGen();
    };
    const renderOps = () => setHtml(R('#st-ops'), [...ops.values()].map((o) => `<div class="row" style="margin:4px 0"><b>${esc(o.model)}</b><span class="small">${o.op === 'pull' ? 'téléchargement' : o.op === 'create' ? 'création' : o.op}</span>
      <div class="grow">${o.total ? meter(o.completed / o.total, 'blue') : ''}</div><span class="small">${o.total ? `${bytes(o.completed)} / ${bytes(o.total)}` : ''} ${esc(o.status ?? '')}</span>${o.done ? '' : `<button class="mini" data-cancel="${esc(o.model)}">annuler</button>`}</div>`).join(''));

    on(root, 'click', '[data-use-a]', async (e, b) => { await S.saveSettings({ ai: { model: b.dataset.useA } }); toast('Modèle des analyses', esc(b.dataset.useA), 'ok', 2000); load(); });
    on(root, 'click', '[data-use-g]', async (e, b) => { await S.saveSettings({ agent: { model: b.dataset.useG } }); toast('Modèle de l\'agent', esc(b.dataset.useG), 'ok', 2000); load(); });
    on(root, 'click', '[data-base]', (e, b) => { R('#st-base').value = b.dataset.base; R('#st-create').scrollIntoView({ behavior: 'smooth', block: 'center' }); });
    on(root, 'click', '[data-test]', async (e, b) => {
      const m = b.dataset.test;
      b.disabled = true;
      setHtml(R('#st-test'), `<div class="info" style="margin:8px 10px">Test de ${esc(m)} : chargement du modèle (contexte ${int(S.settings.ai.numCtx)} jetons) puis génération…</div>`);
      const r = await post('/api/ollama/test', { model: m });
      b.disabled = false;
      setHtml(R('#st-test'), r.ok ? `<div class="info" style="margin:8px 10px"><b>${esc(m)}</b> : ${r.tokPerSec ? `<b>${num(r.tokPerSec, 1)} jetons/s</b> en génération` : ''} · chargement ${dur(r.loadMs)} · total ${dur(r.wallMs)} · ${int(r.promptTokens)} jetons lus, ${int(r.outputTokens)} écrits<br><i>« ${esc(r.content)} »</i></div>` : `<div class="notice" style="margin:8px 10px">Échec du test de ${esc(m)} : ${esc(r.error)}</div>`);
    });
    on(root, 'click', '[data-pull]', (e, b) => pull(b.dataset.pull));
    on(root, 'click', '[data-cancel]', (e, b) => post('/api/ollama/cancel', { model: b.dataset.cancel }));
    on(root, 'click', '[data-del]', async (e, b) => {
      const m = b.dataset.del;
      if (!(await confirmBox(`Supprimer <b>${esc(m)}</b> du disque ? Il faudra le retélécharger pour l'utiliser.`, { danger: true, ok: 'Supprimer' }))) return;
      try { await del(`/api/ollama/models/${encodeURIComponent(m)}`); toast('Modèle supprimé', esc(m), 'ok'); load(); } catch (err) { toast('Suppression impossible', esc(err.message), 'ko'); }
    });
    const pull = async (name) => {
      const m = String(name ?? '').trim();
      if (!m) return;
      try {
        await post('/api/ollama/pull', { model: m });
        ops.set(m, { op: 'pull', model: m, status: 'démarrage' });
        renderOps();
      } catch (err) { toast('Téléchargement impossible', esc(err.message), 'ko'); }
    };
    R('#st-pull').onclick = () => pull(R('#st-pull-name').value);
    R('#st-create').onclick = async () => {
      try {
        await post('/api/ollama/create', { from: R('#st-base').value, name: R('#st-newname').value || 'bourso' });
        ops.set(R('#st-newname').value || 'bourso', { op: 'create', model: R('#st-newname').value || 'bourso', status: 'démarrage' });
        renderOps();
      } catch (err) { toast('Création impossible', esc(err.message), 'ko'); }
    };
    const showHelp = (e) => {
      const h = e.help;
      if (!h) { setHtml(R('#st-create-help'), ''); return; }
      setHtml(R('#st-create-help'), `<div class="notice small" style="margin:6px 0"><b>${esc(h.title)}</b>${h.lines.map((l) => `<p style="margin:4px 0">${esc(l).replace(/`([^`]+)`/g, '<code>$1</code>')}</p>`).join('')}
        ${h.commands.map((c) => `<div style="margin-top:6px"><b>${esc(c.label).replace(/`([^`]+)`/g, '<code>$1</code>')}</b><pre class="mono small" style="white-space:pre-wrap;margin:3px 0;padding:6px;background:var(--panel-2, rgba(0,0,0,0.05))">${esc(c.code)}</pre><button class="mini" data-copy="${esc(c.code)}">copier</button></div>`).join('')}
        ${h.useBase ? `<div style="margin-top:8px"><button class="btn btn-small primary" data-use-a="${esc(h.useBase)}">Utiliser ${esc(h.useBase)} directement (sans « bourso »)</button></div>` : ''}</div>`);
    };
    on(root, 'click', '[data-copy]', async (e, b) => {
      try { await navigator.clipboard.writeText(b.dataset.copy); toast('Copié', 'commande copiée dans le presse-papiers', 'ok', 1200); } catch { toast('Copie impossible', 'sélectionne le texte et copie-le à la main', 'warn', 2500); }
    });
    const offOl = live.on('ollama', (e) => {
      if (e.done && (e.op === 'create' || e.op === 'pull')) showHelp(e.ok ? {} : e);
      const o = ops.get(e.model) ?? { op: e.op, model: e.model };
      Object.assign(o, { status: e.status, total: e.total ?? o.total, completed: e.completed ?? o.completed, done: e.done });
      ops.set(e.model, o);
      renderOps();
      if (e.done) {
        toast(e.ok ? `${e.op === 'pull' ? 'Téléchargement' : e.op === 'create' ? 'Création' : 'Opération'} terminé(e)` : 'Échec', `${esc(e.model)}${e.ok ? '' : ` : ${esc(e.status)}`}`, e.ok ? 'ok' : 'ko', 6000);
        setTimeout(() => { ops.delete(e.model); renderOps(); }, 8000);
        load();
      }
    });

    // ================================================================= génération
    const renderGen = () => {
      const a = S.settings.ai, ag = S.settings.agent, cur = info?.models.find((m) => m.name === info.analysis.used), curG = info?.models.find((m) => m.name === info.agent.used);
      const thinkOpts = (m, v) => {
        const levels = m?.thinking?.values?.filter((x) => typeof x === 'string') ?? [], can = !m?.capabilities || m.capabilities.includes('thinking');
        const o = [['false', 'désactivée (réponse directe, rapide)'], ...(can ? [['true', 'activée']] : []), ...levels.map((l) => [l, `niveau « ${l} »`])];
        return o.map(([k, l]) => `<option value="${k}" ${String(v) === k ? 'selected' : ''}>${l}</option>`).join('') + (can ? '' : '<option disabled>ce modèle n\'a pas de mode réflexion</option>');
      };
      const maxCtx = cur?.contextLength ?? 131072;
      R('#st-gen').innerHTML = `<label class="f">Température (0 = déterministe ; conseillé 0,1 – 0,2)<input type="number" data-a="temperature" value="${a.temperature}" min="0" max="1.5" step="0.05"></label>
        <label class="f">Réflexion du modèle avant de répondre<select data-a="think">${thinkOpts(cur, a.think)}</select></label>
        <label class="f">Contexte (jetons) — maximum du modèle : ${cur?.contextLength ? int(cur.contextLength) : 'inconnu'}<input type="number" data-a="numCtx" value="${a.numCtx}" min="4096" max="${maxCtx}" step="1024"></label>
        <label class="f">Longueur maximale d'une réponse (jetons)<input type="number" data-a="numPredict" value="${a.numPredict ?? 2500}" min="256" max="16384" step="256"></label>
        <label class="f">Garder le modèle en mémoire<select data-a="keepAlive">${KEEP.map(([k, l]) => `<option value="${k}" ${String(a.keepAlive) === k ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
        <label class="f">Horizon du Monte Carlo (séances)<input type="number" data-a="horizonDays" value="${a.horizonDays}" min="1" max="120"></label>
        <label class="f">Trajectoires Monte Carlo (vide = selon le niveau de calcul)<input type="number" data-a="mcPaths" value="${a.mcPaths ?? ''}" min="1000" step="1000"></label>
        <button class="btn btn-small primary" id="st-gen-save">Enregistrer</button><div class="help-text">Le contexte de 32 768 jetons couvre largement un dossier (≈ 3 000 jetons) et une longue discussion. Plus de contexte = plus de mémoire GPU.</div>`;
      R('#st-gen-save').onclick = async () => {
        const g = (k) => R(`#st-gen [data-a="${k}"]`), th = g('think').value;
        await S.saveSettings({ ai: { temperature: Number(g('temperature').value), think: th === 'true' ? true : th === 'false' ? false : th, numCtx: Math.min(maxCtx, Number(g('numCtx').value)), numPredict: Number(g('numPredict').value), keepAlive: g('keepAlive').value, horizonDays: Number(g('horizonDays').value), mcPaths: g('mcPaths').value ? Number(g('mcPaths').value) : null } });
        toast('Réglages des analyses enregistrés', '', 'ok', 1500);
      };
      R('#st-agent').innerHTML = `<label class="f">Température (conseillé 0,3)<input type="number" data-g="temperature" value="${ag.temperature}" min="0" max="1.5" step="0.05"></label>
        <label class="f">Réflexion avant de répondre<select data-g="think">${thinkOpts(curG, ag.think)}</select></label><button class="btn btn-small primary" id="st-ag-save">Enregistrer</button>
        <div class="help-text">L'agent utilise le même contexte que les analyses : le modèle n'est jamais rechargé entre une question et une analyse. Ses questions passent avant les analyses de fond.</div>`;
      R('#st-ag-save').onclick = async () => {
        const th = R('#st-agent [data-g="think"]').value;
        await S.saveSettings({ agent: { temperature: Number(R('#st-agent [data-g="temperature"]').value), think: th === 'true' ? true : th === 'false' ? false : th } });
        toast('Réglages de l\'agent enregistrés', '', 'ok', 1500);
      };
    };

    // ================================================================= politique, calcul, négociation, affichage
    const renderPolicy = () => {
      const a = S.settings.ai, p = a.policy;
      R('#st-policy').innerHTML = `<label class="chk"><input type="checkbox" data-p="auto" ${a.auto ? 'checked' : ''}> analyser automatiquement les favoris, dans l'ordre</label>
        <label class="f">Réanalyser si le cours a bougé de plus de (%)<input type="number" data-p="movePct" value="${p.movePct}" step="0.1" min="0.05"></label>
        <label class="f">Réanalyser au plus tard après (minutes)<input type="number" data-p="maxAge" value="${Math.round(p.maxAgeMs / 60000)}" min="1"></label>
        <label class="f">Jamais deux fois en moins de (minutes)<input type="number" data-p="minGap" value="${Math.round(p.minGapMs / 60000)}" min="0"></label>
        <label class="chk"><input type="checkbox" data-p="onlyDuringSession" ${p.onlyDuringSession ? 'checked' : ''}> seulement pendant la séance de la valeur</label><button class="btn btn-small primary" id="st-pol-save">Enregistrer</button>`;
      R('#st-pol-save').onclick = async () => {
        const g = (k) => R(`#st-policy [data-p="${k}"]`);
        await S.saveSettings({ ai: { auto: g('auto').checked, policy: { movePct: Number(g('movePct').value), maxAgeMs: Number(g('maxAge').value) * 60000, minGapMs: Number(g('minGap').value) * 60000, onlyDuringSession: g('onlyDuringSession').checked } } });
        toast('Règle enregistrée', '', 'ok', 1500);
      };
    };
    const renderCompute = async () => {
      const s = await get('/api/system'), c = s.compute;
      R('#st-compute').innerHTML = `${Object.entries(c.levels).map(([k, l]) => `<label class="chk"><input type="radio" name="st-lvl" value="${k}" ${c.level === k ? 'checked' : ''}> ${esc(l)}</label>`).join('')}
        <label class="f">Répartition<select id="st-mode"><option value="auto" ${c.mode === 'auto' ? 'selected' : ''}>dosée GPU + CPU selon les débits mesurés</option><option value="gpu" ${c.mode === 'gpu' ? 'selected' : ''}>GPU seul</option><option value="cpu" ${c.mode === 'cpu' ? 'selected' : ''}>CPU seul</option></select></label>
        <div class="help-text">GPU : ${c.gpu.ok ? esc(`${c.gpu.vendor} ${c.gpu.description}`) : `non utilisé (${esc(c.gpu.reason ?? '')})`} · CPU natif : ${c.native.ok ? `${c.cpu.cores} cœurs` : 'non compilé'} · <a href="#/systeme">détails</a></div>`;
      R('#st-compute').onchange = async (e) => {
        if (e.target.name === 'st-lvl') await post('/api/system/level', { level: e.target.value });
        if (e.target.id === 'st-mode') await post('/api/system/mode', { mode: e.target.value });
        toast('Calcul', 'réglage appliqué', 'ok', 1200);
      };
    };
    const renderTrade = () => {
      const t = S.settings.trading;
      R('#st-trade').innerHTML = `<label class="f">Courtage (% du montant)<input type="number" data-t="commissionPct" value="${t.commissionPct}" step="0.01" min="0"></label><label class="f">Minimum par ordre (€)<input type="number" data-t="commissionMin" value="${t.commissionMin}" step="0.5" min="0"></label>
        <label class="f">Taxe sur les transactions financières (%)<input type="number" data-t="ttfPct" value="${t.ttfPct}" step="0.05" min="0"></label><label class="chk"><input type="checkbox" data-t="allowShort" ${t.allowShort ? 'checked' : ''}> autoriser la vente à découvert</label>
        <label class="f">Capital de départ (€, appliqué à la prochaine réinitialisation)<input type="number" data-t="initialCash" value="${t.initialCash}" step="1000" min="1000"></label><button class="btn btn-small primary" id="st-tr-save">Enregistrer</button>`;
      R('#st-tr-save').onclick = async () => {
        const g = (k) => R(`#st-trade [data-t="${k}"]`);
        await S.saveSettings({ trading: { commissionPct: Number(g('commissionPct').value), commissionMin: Number(g('commissionMin').value), ttfPct: Number(g('ttfPct').value), allowShort: g('allowShort').checked, initialCash: Number(g('initialCash').value) } });
        toast('Négociation', 'réglages enregistrés', 'ok', 1500);
      };
    };
    const renderUi = () => {
      const dark = document.documentElement.dataset.theme === 'dark';
      R('#st-ui').innerHTML = `<label class="f">Thème<select id="st-theme"><option value="light" ${dark ? '' : 'selected'}>clair</option><option value="dark" ${dark ? 'selected' : ''}>sombre</option></select></label>
        <div class="row wrap-ok"><button class="btn btn-small" id="st-reset-chart">Réinitialiser la disposition du graphique</button><button class="btn btn-small" id="st-reset-ui">Effacer toutes les préférences d'affichage</button></div>
        <div class="row wrap-ok"><button class="btn btn-small" id="st-exp-sig">Exporter les décisions de l'IA (CSV)</button><button class="btn btn-small" id="st-exp-conv">Exporter les discussions (JSON)</button></div>
        <div class="help-text">Toutes les données (réglages, favoris, signaux, discussions, tracés, portefeuille) sont dans le dossier « data » du projet, sur ta machine.</div>`;
      R('#st-theme').onchange = (e) => { document.documentElement.dataset.theme = e.target.value; try { localStorage.setItem('bourso.theme', e.target.value); } catch { /* indisponible */ } S.emit('theme', e.target.value); };
      R('#st-reset-chart').onclick = () => { prefs.set('chart.layout', null); try { localStorage.removeItem('bourso.chart.layout'); } catch { /* indisponible */ } toast('Graphique', 'disposition par défaut rétablie', 'ok', 1500); };
      R('#st-reset-ui').onclick = async () => {
        if (!(await confirmBox('Effacer les préférences d\'affichage de ce navigateur (onglets, filtres, disposition) ?', { ok: 'Effacer' }))) return;
        try { Object.keys(localStorage).filter((k) => k.startsWith('bourso.') && k !== 'bourso.theme').forEach((k) => localStorage.removeItem(k)); } catch { /* indisponible */ }
        toast('Préférences effacées', '', 'ok', 1500);
      };
      R('#st-exp-sig').onclick = async () => {
        const list = await get('/api/ai/signals?limit=1000'), cols = ['at', 'sym', 'name', 'decision', 'confidence', 'price', 'stop', 'targets', 'horizon', 'quantScore', 'quantVsAi', 'simulated', 'outcome', 'outcomeReturn', 'summary'];
        const cell = (v) => { const x = Array.isArray(v) ? v.join(' ') : v ?? ''; return /[;"\n]/.test(String(x)) ? `"${String(x).replace(/"/g, '""')}"` : String(x); };
        saveFile('bourso_decisions_ia.csv', `﻿${cols.join(';')}\n${list.map((g) => cols.map((c) => cell(c === 'at' ? dateTime(g.at) : g[c])).join(';')).join('\n')}`, 'text/csv');
      };
      R('#st-exp-conv').onclick = async () => {
        const list = await get('/api/agent/conversations'), full = await Promise.all(list.map((c) => get(`/api/agent/conversations/${encodeURIComponent(c.id)}`)));
        saveFile('bourso_discussions.json', JSON.stringify(full, null, 1), 'application/json');
      };
    };

    // ================================================================= données de marché
    let feedList = [];
    on(R('#st-data'), 'click', '[data-fdel]', (e, b) => { feedList[Number(b.dataset.fdel)] = null; b.closest('tr').remove(); });
    const renderCheck = (r, running = false) => {
      if (running) { setHtml(R('#st-check'), '<div class="info">Test en cours : une requête par source, au rythme normal de Bourso (≈ 20 à 40 s)…</div>'); return; }
      if (!r?.results?.length) { setHtml(R('#st-check'), ''); return; }
      const groups = [...new Set(r.results.map((x) => x.group))];
      setHtml(R('#st-check'), `<div class="${r.summary?.essentialOk ? 'info' : 'notice'}" style="margin-bottom:6px">${esc(r.summary?.verdict ?? '')} <small class="muted">(test du ${dateTime(r.at)})</small></div>
        <table class="tbl compact"><thead><tr><th>Source</th><th>État</th><th>Résultat</th><th class="r">Durée</th></tr></thead><tbody>${groups.map((g) => `<tr class="grp"><td colspan="4"><b>${esc(g)}</b></td></tr>${r.results.filter((x) => x.group === g).map((x) => `<tr>
          <td>${esc(x.name)}${x.essential ? ' <small class="muted">(essentiel)</small>' : ''}</td><td>${x.ok ? '<span class="chip ok">joignable</span>' : `<span class="chip ${x.essential ? 'ko' : 'warn'}">échec</span>`}</td>
          <td class="small">${x.ok ? esc(x.detail ?? '') : `${esc(x.error ?? '')}${x.hint ? `<br><span class="muted">→ ${esc(x.hint)}</span>` : ''}`}</td><td class="r small">${dur(x.ms)}</td></tr>`).join('')}`).join('')}</tbody></table>`);
    };
    const renderData = async () => {
      const d = S.settings.data ?? {}, st = await get('/api/data/status').catch(() => null);
      const keyInfo = st?.keys ?? {};
      setText(R('#st-data-note'), S.real ? `réelles · intensité ${st?.intensityLabel ?? d.intensity ?? 'normale'} · ${st ? `${int(st.quotesLive)} / ${int(st.instruments)} cours reçus, ${int(st.histories)} historiques` : ''}` : 'démonstration (simulées)');
      const feeds = st?.news?.feeds ?? (d.feeds?.length ? d.feeds : st?.defaultFeeds ?? []), defaults = new Set((st?.defaultFeeds ?? []).map((f) => f.url));
      setHtml(R('#st-data'), `<div>
          <h4>Source des cours</h4>
          <label class="chk wrap"><input type="radio" name="st-dmode" value="real" ${S.real ? 'checked' : ''}> <span><b>Données réelles</b> — cours <b>différés</b> (≈ 15 min en Europe), 5 ans d'historique, bougies intraday, actualités et change de sources publiques gratuites. Portefeuille et ordres <b>fictifs</b>.</span></label>
          <label class="chk wrap"><input type="radio" name="st-dmode" value="demo" ${S.real ? '' : 'checked'}> <span><b>Démonstration</b> — marché simulé (carnet d'ordres, bande des transactions, secondes) ; fonctionne hors connexion. Portefeuille séparé.</span></label>
          <label class="f" style="margin-top:8px;display:flex">Intensité des rafraîchissements<select id="st-int" style="max-width:100%">${Object.entries(INTENSITY_HELP).map(([k, h]) => `<option value="${k}" ${(d.intensity ?? 'normale') === k ? 'selected' : ''}>${k === 'econome' ? 'économe' : k} — ${esc(h)}</option>`).join('')}</select></label>
          <div class="help-text">Bourso est poli avec les sources : débit limité par site, cache sur disque (data/cache), pause automatique quand un site refuse, aucun contournement (captcha, connexion, paywall, consentement).</div>
          <h4 style="margin-top:10px">Clés gratuites <small class="muted">(facultatives — elles restent sur ta machine)</small></h4>
          <table class="kv keys">${KEYED.map((x) => `<tr><th>${esc(x.name)}</th><td><input type="text" data-key="${x.k}" value="${esc(d.keys?.[x.k] ?? '')}" placeholder="clé ${esc(x.name)}" autocomplete="off" spellcheck="false" style="width:200px">
            ${keyInfo[x.k]?.configured ? `<span class="chip ok">renseignée</span>${keyInfo[x.k].notCovered ? ` <small class="muted">${int(keyInfo[x.k].notCovered)} valeur(s) non couverte(s)</small>` : ''}` : '<span class="muted small">aucune</span>'} · <a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer" class="small">obtenir une clé ↗</a>
            <div class="small muted" style="font-weight:normal">${esc(x.gives)}</div></td></tr>`).join('')}</table>
          <div class="row"><button class="btn btn-small primary" id="st-keys-save">Enregistrer les clés</button><span class="help-text">Pour effacer une clé : vide le champ puis enregistre.</span></div>
        </div>
        <div>
          <h4>Flux d'actualités</h4>
          <div class="scroll" style="max-height:330px"><table class="tbl compact feeds"><thead><tr><th></th><th>Flux</th><th>Langue</th><th></th></tr></thead><tbody id="st-feeds">${feeds.map((f, i) => `<tr data-i="${i}"><td><input type="checkbox" data-fe="${i}" ${f.enabled !== false ? 'checked' : ''}></td><td>${esc(f.name)}<small>${esc(f.url)}</small></td><td>${esc(f.lang ?? '')}</td><td>${defaults.has(f.url) ? '<span class="muted small">par défaut</span>' : `<button class="mini" data-fdel="${i}">✕</button>`}</td></tr>`).join('') || '<tr class="empty"><td colspan="4">Aucun flux</td></tr>'}</tbody></table></div>
          <div class="form" style="padding:6px 0"><input type="text" id="st-f-name" placeholder="nom" style="width:120px"><input type="url" id="st-f-url" placeholder="https://…/rss.xml" style="width:220px"><select id="st-f-lang"><option value="fr">fr</option><option value="en">en</option></select><button class="btn btn-small" id="st-f-add">Ajouter</button></div>
          <div class="row"><button class="btn btn-small primary" id="st-feeds-save">Enregistrer les flux</button><button class="btn btn-small" id="st-feeds-reset">Flux par défaut</button></div>
          <div class="help-text">Flux RSS ou Atom publics uniquement. Les titres sont classés par valeur, secteur ou région et transmis à l'IA comme données non fiables.</div>
          <h4 style="margin-top:10px">Tester les sources depuis cette machine</h4>
          <div class="row"><button class="btn btn-small" id="st-check-go">Lancer le test</button><span class="help-text">Équivaut à <code>npm run data:check</code> : une requête par source, avec une piste en cas d'échec.</span></div>
        </div>`);
      feedList = feeds.map((f) => ({ name: f.name, url: f.url, lang: f.lang, enabled: f.enabled !== false }));
      R('#st-data').onchange = async (e) => {
        if (e.target.name === 'st-dmode') {
          const mode = e.target.value;
          toast('Bascule des données', mode === 'real' ? 'passage aux données réelles : la page va se recharger…' : 'passage à la démonstration : la page va se recharger…', '', 4000);
          try { await post('/api/data/mode', { mode }); } catch (err) { toast('Bascule impossible', esc(err.message), 'ko'); }
        } else if (e.target.id === 'st-int') {
          await S.saveSettings({ data: { intensity: e.target.value } });
          toast('Intensité', esc(INTENSITY_HELP[e.target.value]), 'ok', 2500);
        } else if (e.target.dataset.fe !== undefined && feedList[Number(e.target.dataset.fe)]) feedList[Number(e.target.dataset.fe)].enabled = e.target.checked;
      };
      R('#st-keys-save').onclick = async () => {
        const keys = Object.fromEntries([...root.querySelectorAll('[data-key]')].map((i) => [i.dataset.key, i.value.trim()]));
        try {
          await S.saveSettings({ data: { keys } });
          toast('Clés enregistrées', 'elles servent dès les prochains chargements', 'ok', 2500);
          renderData();
        } catch (err) { toast('Clés refusées', esc(err.message), 'ko'); }
      };
      R('#st-f-add').onclick = () => {
        const url = R('#st-f-url').value.trim();
        if (!/^https?:\/\//i.test(url)) { toast('Flux', 'adresse http(s) attendue', 'ko', 2500); return; }
        let host = url;
        try { host = new URL(url).host; } catch { toast('Flux', 'adresse invalide', 'ko', 2500); return; }
        feedList.push({ name: R('#st-f-name').value.trim() || host, url, lang: R('#st-f-lang').value, enabled: true });
        R('#st-feeds').insertAdjacentHTML('beforeend', `<tr><td>＋</td><td>${esc(feedList.at(-1).name)}<small>${esc(url)}</small></td><td>${esc(feedList.at(-1).lang)}</td><td><span class="muted small">à enregistrer</span></td></tr>`);
        R('#st-f-url').value = '';
        R('#st-f-name').value = '';
      };
      R('#st-feeds-save').onclick = async () => {
        const list = feedList.filter(Boolean);
        try { await S.saveSettings({ data: { feeds: list } }); toast('Flux enregistrés', `${list.filter((f) => f.enabled).length} flux actif(s)`, 'ok', 2000); renderData(); } catch (err) { toast('Flux refusés', esc(err.message), 'ko'); }
      };
      R('#st-feeds-reset').onclick = async () => { await S.saveSettings({ data: { feeds: [] } }); toast('Flux par défaut rétablis', '', 'ok', 1500); renderData(); };
      R('#st-check-go').onclick = async () => {
        R('#st-check-go').disabled = true;
        renderCheck(null, true);
        try { renderCheck(await post('/api/data/check')); } catch (err) { setHtml(R('#st-check'), `<div class="notice">${esc(err.message)}</div>`); }
        R('#st-check-go').disabled = false;
      };
    };

    const load = async () => {
      try {
        info = await get('/api/ollama/models');
      } catch (e) {
        info = { host: S.ai.ollama?.host ?? '', up: false, version: null, models: [], analysis: { wanted: S.settings.ai.model, used: S.settings.ai.model ?? '—', installed: null, auto: !S.settings.ai.model }, agent: { wanted: S.settings.agent.model || S.settings.ai.model, used: S.settings.agent.model || S.settings.ai.model || '—', installed: null } };
        setHtml(R('#st-test'), `<div class="notice" style="margin:8px 10px">Ollama ne répond pas (${esc(e.message)}). Vérifie qu'il tourne (<kbd>ollama serve</kbd>) ou change l'adresse du serveur ci-dessus. En attendant, les analyses sont simulées.</div>`);
      }
      renderModels();
    };
    R('#st-refresh').onclick = load;
    renderData();
    get('/api/data/check').then((r) => renderCheck(r)).catch(() => {});
    await load();
    renderPolicy();
    renderCompute();
    renderTrade();
    renderUi();
    const offS = S.on('settings', () => { renderPolicy(); renderTrade(); });
    return { unmount() { offOl(); offS(); } };
  },
};
void [$, pct];

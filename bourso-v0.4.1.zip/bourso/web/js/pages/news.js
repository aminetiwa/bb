// ============================================================================
//  BOURSO :: pages/news.js — ACTUALITÉS : fil en direct (valeurs, secteurs, régions, macro),
//  filtres, tonalité, et la réaction des cours concernés. Données réelles : titres de presse
//  (flux RSS, Google Actualités, GDELT), liens vers les articles ; démonstration : actualités
//  SIMULÉES (étiquetées) qui font bouger le marché simulé. L'IA les intègre à ses dossiers.
// ============================================================================
import { S, prefs } from '../core/store.js';
import { get } from '../core/api.js';
import { $, setHtml } from '../core/dom.js';
import { esc, num, pct, ago, cls } from '../core/fmt.js';
import { newsItem, chg, symHref } from '../core/ui.js';

export default {
  title: 'Actualités',
  async mount(root) {
    const st = prefs.get('news.filters', { scope: '', tone: '', region: '', q: '', favs: false });
    root.innerHTML = `<div class="page-title"><h1>Actualités</h1><span class="sub">${S.real
      ? 'titres réels : presse (flux RSS), Google Actualités, GDELT · clic sur un titre : l\'article (site externe) · tonalité estimée par lexique, indicative · transmis à l\'IA comme données non fiables'
      : 'fil en direct · actualités simulées qui font bouger le marché simulé · intégrées aux dossiers de l\'IA'}</span></div>
      <div class="layout l2">
        <div><section class="box"><div class="form" id="n-f">
          <label class="f">Portée<select data-k="scope"><option value="">Toutes</option><option value="valeur">Valeurs</option><option value="secteur">Secteurs</option><option value="région">Régions</option><option value="monde">Monde</option>${S.real ? '<option value="marché">Marché (général)</option>' : ''}</select></label>
          <label class="f">Tonalité<select data-k="tone"><option value="">Toutes</option><option value="pos">Positives</option><option value="neg">Négatives</option></select></label>
          <label class="f">Région<select data-k="region"><option value="">Toutes</option>${['Europe', 'Amérique du Nord', 'Asie-Pacifique', 'Amérique latine', 'Afrique & Moyen-Orient'].map((r) => `<option>${r}</option>`).join('')}</select></label>
          <label class="f">Rechercher<input type="search" data-k="q" placeholder="mot, valeur…"></label><label class="chk"><input type="checkbox" data-k="favs"> mes favoris</label><span class="sp"></span><span class="small muted" id="n-count"></span></div>
          <ul class="news" id="n-list"></ul></section></div>
        <aside>
          <section class="box"><h2 class="box-title"><span class="ico">☊</span>Tonalité par secteur <span class="title-note">300 dernières</span></h2><div id="n-sec"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">⌖</span>Valeurs les plus citées</h2><table class="tbl compact" id="n-top"></table></section>
          <section class="box"><h2 class="box-title"><span class="ico">≋</span>Par région</h2><div id="n-reg"></div></section>
        </aside></div>`;
    for (const [k, v] of Object.entries(st)) { const i = root.querySelector(`[data-k="${k}"]`); if (i) { if (i.type === 'checkbox') i.checked = v; else i.value = v; } }
    let items = await get('/api/news?limit=300');
    const regionOf = (n) => n.region ?? (n.sym ? S.info(n.sym)?.region : null);
    const render = (fresh = null) => {
      const q = st.q.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
      const list = items.filter((n) => (!st.scope || n.scope === st.scope) && (!st.tone || (st.tone === 'pos' ? n.score > 0 : n.score < 0)) && (!st.region || regionOf(n) === st.region || n.scope === 'monde')
        && (!st.favs || (n.sym && S.isFav(n.sym))) && (!q || `${n.title} ${n.name ?? ''} ${n.sector ?? ''}`.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().includes(q)));
      setHtml($('#n-list', root), list.slice(0, 150).map((n) => {
        const qq = n.sym ? S.quote(n.sym) : null;
        return newsItem(n, { fresh: n === fresh }).replace('</li>', qq ? `<div class="meta">réaction : <a href="${symHref(n.sym)}">${esc(n.name ?? S.name(n.sym))}</a> ${chg(qq.chgPct)} aujourd'hui</div></li>` : '</li>');
      }).join('') || '<li class="empty">Aucune actualité</li>');
      $('#n-count', root).textContent = `${list.length} actualité(s)`;
      // statistiques
      const bySec = new Map(), byReg = new Map(), bySym = new Map();
      for (const n of items) {
        const sec = n.sector ?? (n.sym ? S.info(n.sym)?.sector : null), reg = regionOf(n) ?? 'Monde';
        if (sec) { const a = bySec.get(sec) ?? [0, 0]; a[0] += n.score; a[1]++; bySec.set(sec, a); }
        const b = byReg.get(reg) ?? [0, 0]; b[0] += n.score; b[1]++; byReg.set(reg, b);
        if (n.sym) bySym.set(n.sym, (bySym.get(n.sym) ?? 0) + 1);
      }
      const bars = (m) => `<table class="tbl compact"><tbody>${[...m.entries()].sort((a, b) => b[1][0] / b[1][1] - a[1][0] / a[1][1]).map(([k, [s, n]]) => `<tr><td>${esc(k)}</td><td style="width:40%"><div class="meter center"><i style="left:${s / n >= 0 ? 50 : 50 + Math.max(-1, s / n) * 50}%;width:${Math.min(1, Math.abs(s / n)) * 50}%;background:${s >= 0 ? 'var(--up)' : 'var(--down)'}"></i></div></td><td class="r ${cls(s)}">${num(s / n, 2)}</td><td class="r small muted">${n}</td></tr>`).join('')}</tbody></table>`;
      setHtml($('#n-sec', root), bars(bySec));
      setHtml($('#n-reg', root), bars(byReg));
      setHtml($('#n-top', root), `<tbody>${[...bySym.entries()].sort((a, b) => b[1] - a[1]).slice(0, 12).map(([s, n]) => `<tr><td><a href="${symHref(s)}">${esc(S.name(s))}</a></td><td class="r">${n}</td><td class="r">${chg(S.quote(s)?.chgPct)}</td></tr>`).join('')}</tbody>`);
    };
    $('#n-f', root).addEventListener('input', (e) => {
      const k = e.target.dataset.k;
      if (!k) return;
      st[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
      prefs.set('news.filters', st);
      render();
    });
    render();
    const off = S.on('news', (n) => { items = [n, ...items].slice(0, 400); render(n); });
    return { unmount: off };
  },
};
void pct; void ago;

// ============================================================================
//  BOURSO :: pages/agent.js — AGENT PRO : discuter avec « Bourso Pro », un expert boursier.
//  Réponses en direct (jeton par jeton), appels d'outils visibles (cotation, analyse technique,
//  dossier complet, Monte Carlo GPU/CPU, backtests, screener, actualités, portefeuille,
//  corrélations, calcul de position…), valeur affichée en contexte, discussions enregistrées.
// ============================================================================
import { S } from '../core/store.js';
import { get, post, del } from '../core/api.js';
import { live } from '../core/live.js';
import { $, el, on, setHtml, toast, confirmBox } from '../core/dom.js';
import { esc, num, ago, dur, int, price } from '../core/fmt.js';
import { markdown } from '../core/md.js';
import { symHref } from '../core/ui.js';

const SUGGEST = [
  'Comment va le marché européen aujourd\'hui ?',
  'Analyse complète de LVMH : faut-il acheter ?',
  'Quelle est la probabilité que ASML gagne 5 % avant de perdre 3 % ?',
  'Trouve-moi des valeurs européennes en survente avec une tendance de fond haussière',
  'Compare SAP, ASML et Schneider Electric',
  'Que penses-tu de mon portefeuille ? Est-il bien diversifié ?',
  'Calcule ma taille de position : capital 50 000 €, risque 1 %, entrée 617, stop 598',
  'Quelles stratégies ont le mieux marché sur TotalEnergies en hors échantillon ?',
];
const TOOL_LABEL = {
  rechercher_valeur: 'Recherche de valeur', cotation: 'Cotation', analyse_technique: 'Analyse technique', dossier_complet: 'Dossier complet', monte_carlo: 'Monte Carlo GPU/CPU',
  backtest_strategies: 'Backtests walk-forward', screener: 'Screener', vue_marche: 'Vue du marché', actualites: 'Actualités', portefeuille: 'Portefeuille', signaux_ia: 'Décisions de l\'IA',
  lancer_analyse_ia: 'Analyse IA complète', comparer: 'Comparaison', correlations: 'Corrélations', calcul_position: 'Calcul de position',
};

export default {
  title: 'Agent Pro',
  async mount(root, ctx) {
    root.innerHTML = `<div class="page-title"><h1>Bourso Pro</h1><span class="sub">ton expert boursier : il appelle les outils de calcul de la machine avant de répondre, et cite leurs chiffres${S.real ? ' · données réelles (cours différés), recherche et ajout de n\'importe quelle action du monde · il ne passe jamais d\'ordre' : ' · marché de démonstration (simulé)'}</span></div>
      <div class="layout">
        <aside>
          <section class="box"><h2 class="box-title"><span class="ico">✉</span>Discussions <span class="tools"><button class="btn btn-xs primary" id="ag-new">+ nouvelle</button></span></h2><div class="conv-list scroll xtall" id="ag-list"></div></section>
        </aside>
        <div>
          <section class="box ov chat">
            <h2 class="box-title"><span class="ico">◆</span><span id="ag-title">Nouvelle discussion</span>
              <span class="tools"><span class="small muted">valeur en contexte :</span><span id="ag-ctx"></span><input type="search" id="ag-ctx-q" placeholder="joindre une valeur…" style="width:150px;height:21px"><button class="btn btn-xs" id="ag-del" title="Supprimer la discussion">🗑</button></span></h2>
            <div class="suggest hidden" id="ag-ctx-sug" style="position:absolute;right:40px;top:30px;width:420px;left:auto"></div>
            <div class="chat-log" id="ag-log"></div>
            <div class="chat-input"><textarea id="ag-in" rows="2" placeholder="Pose ta question (Entrée pour envoyer, Maj+Entrée pour aller à la ligne)…"></textarea><button class="btn primary" id="ag-send">Envoyer</button><button class="btn sell hidden" id="ag-stop">Arrêter</button></div>
          </section>
        </div>
        <aside class="col-right">
          <section class="box"><h2 class="box-title"><span class="ico">⚙</span>Modèle</h2><div id="ag-model"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">🔧</span>Outils de l'agent</h2><div class="scroll tall" id="ag-tools"></div></section>
        </aside>
      </div>`;
    const R = (s) => root.querySelector(s);
    let conv = null, streaming = null;

    // ---------------------------------------------------------------- liste des discussions
    const loadList = async () => {
      const list = await get('/api/agent/conversations');
      setHtml(R('#ag-list'), list.map((c) => `<a href="#/agent/${esc(c.id)}" class="${conv?.id === c.id ? 'on' : ''}">${esc(c.title)}<small>${ago(c.updatedAt)} · ${c.messages} message(s)${c.sym ? ` · ${esc(S.info(c.sym)?.code ?? c.sym)}` : ''}</small></a>`).join('') || '<div class="empty">Aucune discussion</div>');
      return list;
    };
    const newConv = async (sym = null) => {
      conv = await post('/api/agent/conversations', { sym });
      window.history.replaceState(null, '', `#/agent/${conv.id}`);
      renderConv();
      loadList();
      R('#ag-in').focus();
    };
    const open = async (id) => {
      const c = await get(`/api/agent/conversations/${encodeURIComponent(id)}`).catch(() => null);
      if (!c) { await newConv(); return; }
      conv = c;
      renderConv();
      loadList();
      if (c.busy) setBusy(true);
    };

    // ---------------------------------------------------------------- rendu
    const toolCard = (name, args, result, ms, ok = true, pending = false) => `<details class="tool-call"${pending ? ' open' : ''}><summary>🔧 <b>${esc(TOOL_LABEL[name] ?? name)}</b> <span class="mono small">${esc(name)}(${esc(argsText(args))})</span>${pending ? ' <span class="chip run">calcul…</span>' : ` · ${ok ? `${dur(ms)}` : '<span class="chip ko">erreur</span>'}`}</summary>${result !== undefined ? `<pre>${esc(typeof result === 'string' ? prettyJson(result) : JSON.stringify(result, null, 1))}</pre>` : ''}</details>`;
    const argsText = (a) => {
      if (!a) return '';
      const o = typeof a === 'string' ? (() => { try { return JSON.parse(a); } catch { return {}; } })() : a;
      return Object.entries(o).map(([k, v]) => `${k}=${Array.isArray(v) ? v.join(',') : v}`).join(', ');
    };
    const prettyJson = (s) => { try { return JSON.stringify(JSON.parse(s), null, 1); } catch { return s; } };
    const assistantBubble = (m) => `<div class="msg"><div class="who">Bourso Pro${m.simulated ? ' · <span class="chip sim">simulé</span>' : ''}${m.stats?.model ? ` · ${esc(m.stats.model)}` : ''}${m.stats?.tokPerSec ? ` · ${num(m.stats.tokPerSec, 1)} jetons/s` : ''}${m.ms ? ` · ${dur(m.ms)}` : ''}</div>
      ${m.thinking ? `<details class="tool-call"><summary>💭 réflexion du modèle (${int(m.thinking.length)} car.)</summary><pre>${esc(m.thinking)}</pre></details>` : ''}<div class="bubble md ${m.error ? 'err' : ''}">${markdown(m.content)}</div></div>`;
    const renderConv = () => {
      R('#ag-title').textContent = conv.title;
      renderCtx();
      const out = [], msgs = conv.messages;
      for (let i = 0; i < msgs.length; i++) {
        const m = msgs[i];
        if (m.role === 'user' && m.prefetch) { out.push(`<div class="msg">${toolCard('données pré-calculées', {}, m.content.slice(0, 4000), 0)}</div>`); continue; }
        if (m.role === 'user') out.push(`<div class="msg user"><div class="who">Toi · ${ago(m.at)}</div><div class="bubble">${esc(m.content).replace(/\n/g, '<br>')}</div></div>`);
        else if (m.role === 'assistant' && m.tool_calls?.length) {
          const cards = m.tool_calls.map((c, k) => {
            const r = msgs[i + 1 + k];
            return toolCard(c.name, c.arguments, r?.role === 'tool' ? r.content : undefined, r?.ms, r?.ok !== false);
          });
          out.push(`<div class="msg">${m.content ? `<div class="bubble md">${markdown(m.content)}</div>` : ''}${cards.join('')}</div>`);
        } else if (m.role === 'assistant') out.push(assistantBubble(m));
      }
      if (!msgs.length) out.push(`<div class="empty">Pose une question à Bourso Pro. Il appelle les outils (calculs GPU/CPU, dossier, backtests…) puis te répond avec les chiffres.</div><div class="suggestions">${SUGGEST.map((s) => `<button data-sug="${esc(s)}">${esc(s)}</button>`).join('')}</div>`);
      setHtml(R('#ag-log'), out.join(''));
      R('#ag-log').scrollTop = R('#ag-log').scrollHeight;
    };
    const renderCtx = () => {
      setHtml(R('#ag-ctx'), conv?.sym ? `<a class="chip run" href="${symHref(conv.sym)}">${esc(S.name(conv.sym))}</a> <button class="mini" id="ag-ctx-x" title="retirer">✕</button>` : '<span class="small muted">aucune</span>');
      const x = R('#ag-ctx-x');
      if (x) x.onclick = () => { conv.sym = null; pendingSym = null; renderCtx(); };
    };
    let pendingSym;

    // ---------------------------------------------------------------- envoi et flux
    const setBusy = (b) => {
      R('#ag-send').classList.toggle('hidden', b);
      R('#ag-stop').classList.toggle('hidden', !b);
      R('#ag-in').disabled = b;
    };
    const send = async (text) => {
      const t = (text ?? R('#ag-in').value).trim();
      if (!t || streaming) return;
      if (!conv) await newConv();
      R('#ag-in').value = '';
      conv.messages.push({ role: 'user', content: t, at: Date.now() });
      renderConv();
      streaming = { text: '', thinking: '', el: null, tools: [] };
      setBusy(true);
      R('#ag-log').insertAdjacentHTML('beforeend', '<div class="msg" id="ag-live"><div class="who">Bourso Pro · en train de répondre…</div><div id="ag-live-tools"></div><details class="tool-call hidden" id="ag-live-think"><summary>💭 réflexion du modèle</summary><pre></pre></details><div class="bubble md"><span class="cur"></span></div></div>');
      R('#ag-log').scrollTop = R('#ag-log').scrollHeight;
      try {
        await post(`/api/agent/conversations/${encodeURIComponent(conv.id)}/messages`, { text: t, sym: pendingSym !== undefined ? pendingSym : conv.sym ?? undefined });
      } catch (e) {
        toast('Envoi impossible', esc(e.message), 'ko');
        streaming = null;
        setBusy(false);
      }
    };
    const onAgent = (m) => {
      if (!conv || m.conv !== conv.id) { if (m.type === 'done') loadList(); return; }
      const liveEl = R('#ag-live');
      if (!streaming) streaming = { text: '', thinking: '', tools: [] };
      if (m.type === 'start') { if (m.title) R('#ag-title').textContent = m.title; return; }
      if (!liveEl) return;
      const bubble = liveEl.querySelector('.bubble');
      if (m.type === 'token') {
        streaming.text += m.text;
        bubble.innerHTML = `${markdown(streaming.text)}<span class="cur"></span>`;
      } else if (m.type === 'thinking') {
        streaming.thinking += m.text;
        const th = liveEl.querySelector('#ag-live-think');
        th.classList.remove('hidden');
        th.querySelector('pre').textContent = streaming.thinking;
      } else if (m.type === 'tool') {
        streaming.tools.push({ name: m.name, args: m.arguments });
        liveEl.querySelector('#ag-live-tools').insertAdjacentHTML('beforeend', `<div data-tool="${streaming.tools.length - 1}">${toolCard(m.name, m.arguments, undefined, 0, true, true)}</div>`);
        if (streaming.text) { streaming.text = ''; bubble.innerHTML = '<span class="cur"></span>'; }
      } else if (m.type === 'tool_result') {
        const k = streaming.tools.findIndex((t) => t.name === m.name && !t.done);
        if (k >= 0) {
          streaming.tools[k].done = true;
          const slot = liveEl.querySelector(`[data-tool="${k}"]`);
          if (slot) slot.innerHTML = toolCard(m.name, streaming.tools[k].args, m.result, m.ms, m.ok);
        }
      } else if (m.type === 'notice') {
        liveEl.querySelector('#ag-live-tools').insertAdjacentHTML('beforeend', `<div class="notice small">${esc(m.text)}</div>`);
      } else if (m.type === 'done' || m.type === 'error') {
        streaming = null;
        setBusy(false);
        open(conv.id);
        return;
      }
      const log = R('#ag-log');
      if (log.scrollTop + log.clientHeight >= log.scrollHeight - 140) log.scrollTop = log.scrollHeight;
    };

    R('#ag-send').onclick = () => send();
    R('#ag-stop').onclick = () => conv && post(`/api/agent/conversations/${encodeURIComponent(conv.id)}/abort`);
    R('#ag-in').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
    on(R('#ag-log'), 'click', '[data-sug]', (e, b) => send(b.dataset.sug));
    R('#ag-new').onclick = () => newConv(pendingSym ?? null);
    R('#ag-del').onclick = async () => {
      if (!conv || !(await confirmBox('Supprimer cette discussion ?', { danger: true, ok: 'Supprimer' }))) return;
      await del(`/api/agent/conversations/${encodeURIComponent(conv.id)}`);
      conv = null;
      const list = await loadList();
      if (list[0]) open(list[0].id); else newConv();
    };
    // valeur en contexte
    const cq = R('#ag-ctx-q'), csug = R('#ag-ctx-sug');
    let tm = null;
    cq.addEventListener('input', () => {
      clearTimeout(tm);
      tm = setTimeout(async () => {
        const v = cq.value.trim();
        if (!v) { csug.classList.add('hidden'); return; }
        const r = await get(`/api/search?q=${encodeURIComponent(v)}&limit=8`);
        csug.innerHTML = r.map((x) => `<a href="#" data-cs="${esc(x.sym)}"><span class="code">${esc(x.code)}</span><span>${esc(x.name)} <span class="where">${esc(x.ex)}</span></span><span>${price(x.last, S.tick(x.sym))}</span><span></span></a>`).join('');
        csug.classList.remove('hidden');
      }, 120);
    });
    on(csug, 'click', '[data-cs]', (e, a) => { e.preventDefault(); pendingSym = a.dataset.cs; if (conv) conv.sym = pendingSym; cq.value = ''; csug.classList.add('hidden'); renderCtx(); });

    // ---------------------------------------------------------------- panneau de droite
    const tools = await get('/api/agent/tools');
    setHtml(R('#ag-tools'), `<table class="tbl compact"><tbody>${tools.map((t) => `<tr><td><b>${esc(TOOL_LABEL[t.name] ?? t.name)}</b><small style="white-space:normal">${esc(t.description)}</small></td></tr>`).join('')}</tbody></table>`);
    const renderModel = () => {
      const o = S.ai.ollama, a = S.settings.agent, models = (o?.models ?? []).filter((m) => !/embed|bge|nomic|minilm/i.test(m.name)).map((m) => m.name);
      const used = S.sys?.modelStatus?.agent?.used ?? a.model ?? S.ai.model;
      const thinkTxt = a.think === true ? 'activée' : a.think ? `niveau « ${a.think} »` : 'désactivée';
      setHtml(R('#ag-model'), `<table class="kv"><tr><th>Ollama</th><td>${o?.up ? `<span class="chip ok">joignable</span> v${esc(o.version)}` : '<span class="chip ko">injoignable</span>'}</td></tr><tr><th>Modèle utilisé</th><td>${esc(used ?? '—')}</td></tr><tr><th>Température</th><td>${num(a.temperature, 2)}</td></tr><tr><th>Réflexion</th><td>${esc(thinkTxt)}</td></tr></table>
        <div class="form col"><label class="f">Modèle de l'agent<select id="ag-msel"><option value="">même modèle que les analyses (recommandé)</option>${models.map((m) => `<option ${m === a.model ? 'selected' : ''}>${esc(m)}</option>`).join('')}</select></label>
        <a class="btn btn-small" href="#/reglages">Réglages du modèle →</a>
        <div class="help-text">${o?.up ? 'Priorité maximale : une question passe avant les analyses des favoris.' : 'Sans Ollama, les réponses sont simulées à partir des outils (étiquetées).'}</div></div>`);
      R('#ag-msel').onchange = async (e) => { await S.saveSettings({ agent: { model: e.target.value || null } }); toast('Modèle de l\'agent', esc(e.target.value || 'même modèle que les analyses'), 'ok', 1500); };
    };
    renderModel();

    const offs = [live.on('agent', onAgent), S.on('settings', renderModel), S.on('system', renderModel)];
    const list = await loadList();
    const want = ctx.params[0];
    if (want === 'new') {
      pendingSym = ctx.query.get('sym') ?? null;
      await newConv(pendingSym);
    } else if (want) await open(want);
    else if (list[0]) await open(list[0].id);
    else await newConv();
    return {
      async update(c) {
        if (c.params[0] === 'new') { pendingSym = c.query.get('sym') ?? null; await newConv(pendingSym); }
        else if (c.params[0] && c.params[0] !== conv?.id) await open(c.params[0]);
      },
      unmount() { offs.forEach((f) => f()); },
    };
  },
};
void [el, $];

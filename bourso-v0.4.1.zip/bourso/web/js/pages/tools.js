// ============================================================================
//  BOURSO :: pages/tools.js — OUTILS : calculatrices du trader, calcul exact en double
//  précision (mêmes fonctions numériques que le moteur : loi normale exacte à 1e-15 près…).
//  Taille de position · gain/risque · frais et TTF · pivots · Fibonacci · Kelly · options
//  Black-Scholes (+ grecques, volatilité implicite) · volatilité · intérêts composés · perte →
//  gain nécessaire · seuil de rentabilité · devises · rendement du dividende.
// ============================================================================
import { S } from '../core/store.js';
import { get, history } from '../core/api.js';
import { $, el, on, setHtml, toast } from '../core/dom.js';
import { esc, num, int, pct, eur, price, cls } from '../core/fmt.js';
import { normCdf, normPdf } from '/src/core/quant/numeric.js';
import { pivots } from '/src/core/quant/indicators.js';

const card = (id, title, form, help = '') => `<section class="box" id="${id}"><h2 class="box-title"><span class="ico">∑</span>${title}</h2><div class="form" data-form>${form}</div><div class="box-body" data-out style="padding-top:0"></div>${help ? `<div class="box-foot">${help}</div>` : ''}</section>`;
const inp = (k, label, v, step = 'any', w = 100) => `<label class="f">${label}<input type="number" data-k="${k}" value="${v}" step="${step}" style="width:${w}px"></label>`;

/** Black-Scholes-Merton (dividende continu q) : prix et grecques. */
function bs({ S0, K, T, r, q, sigma, call }) {
  if (!(T > 0) || !(sigma > 0)) return null;
  const sq = Math.sqrt(T), d1 = (Math.log(S0 / K) + (r - q + (sigma * sigma) / 2) * T) / (sigma * sq), d2 = d1 - sigma * sq;
  const dfq = Math.exp(-q * T), dfr = Math.exp(-r * T);
  const price2 = call ? S0 * dfq * normCdf(d1) - K * dfr * normCdf(d2) : K * dfr * normCdf(-d2) - S0 * dfq * normCdf(-d1);
  const delta = call ? dfq * normCdf(d1) : dfq * (normCdf(d1) - 1);
  const gamma = (dfq * normPdf(d1)) / (S0 * sigma * sq), vega = (S0 * dfq * normPdf(d1) * sq) / 100;
  const theta = (call ? -(S0 * dfq * normPdf(d1) * sigma) / (2 * sq) - r * K * dfr * normCdf(d2) + q * S0 * dfq * normCdf(d1) : -(S0 * dfq * normPdf(d1) * sigma) / (2 * sq) + r * K * dfr * normCdf(-d2) - q * S0 * dfq * normCdf(-d1)) / 365;
  const rho = (call ? K * T * dfr * normCdf(d2) : -K * T * dfr * normCdf(-d2)) / 100;
  return { price: price2, delta, gamma, vega, theta, rho, d1, d2, probITM: call ? normCdf(d2) : normCdf(-d2) };
}
/** Volatilité implicite : Newton-Raphson protégé par dichotomie. */
function impliedVol(p, o) {
  let lo = 1e-6, hi = 5, s = 0.3;
  for (let i = 0; i < 100; i++) {
    const v = bs({ ...o, sigma: s });
    if (!v) return NaN;
    const d = v.price - p;
    if (Math.abs(d) < 1e-10) return s;
    if (d > 0) hi = s; else lo = s;
    const vega = v.vega * 100;
    let ns = vega > 1e-12 ? s - d / vega : (lo + hi) / 2;
    if (!(ns > lo && ns < hi)) ns = (lo + hi) / 2;
    s = ns;
  }
  return s;
}

export default {
  title: 'Outils',
  async mount(root) {
    const sym = S.lastSym, q = S.quote(sym), last = Number.isFinite(q?.last) ? q.last : 100;
    root.innerHTML = `<div class="page-title"><h1>Outils</h1><span class="sub">calculatrices exactes (double précision) · valeur de référence : <a href="#/valeur/${encodeURIComponent(sym)}">${esc(S.name(sym))}</a> à ${price(last, S.tick(sym))}</span></div>
      <div class="cols cols-3">
        <div>${card('t-pos', 'Taille de position', inp('cap', 'Capital (€)', 50000, 1000, 110) + inp('risk', 'Risque (% du capital)', 1, 0.1, 80) + inp('entry', 'Entrée', last.toFixed(2)) + inp('stop', 'Stop', (last * 0.97).toFixed(2)) + inp('target', 'Objectif', (last * 1.06).toFixed(2)), 'Quantité telle que la perte au stop = risque choisi. Règle des pros : 0,5 à 2 % par position.')}
          ${card('t-fees', 'Frais et taxe sur les transactions (TTF)', `<label class="f">Valeur<input type="text" data-k="sym" value="${esc(sym)}" style="width:110px"></label>` + inp('qty', 'Quantité', 100, 1, 80) + inp('px', 'Prix', last.toFixed(2)), 'TTF française : 0,4 % à l\'achat d\'actions de sociétés françaises de plus d\'1 Md€ de capitalisation (depuis le 1er avril 2025).')}
          ${card('t-kelly', 'Critère de Kelly', inp('win', 'Taux de réussite (%)', 55, 1, 80) + inp('payoff', 'Gain moyen / perte moyenne', 1.5, 0.1, 80), 'Fraction optimale théorique du capital à risquer. En pratique : ½ ou ¼ de Kelly.')}
          ${card('t-loss', 'Perte → gain nécessaire', inp('loss', 'Perte (%)', 20, 1, 80), 'Après −50 %, il faut +100 % pour revenir à l\'équilibre.')}</div>
        <div>${card('t-rr', 'Gain / risque et seuil de réussite', inp('entry', 'Entrée', last.toFixed(2)) + inp('stop', 'Stop', (last * 0.97).toFixed(2)) + inp('t1', 'Objectif 1', (last * 1.04).toFixed(2)) + inp('t2', 'Objectif 2', (last * 1.08).toFixed(2)) + inp('fee', 'Frais aller-retour (%)', 0.2, 0.05, 70), 'Taux de réussite minimal pour être gagnant = risque / (risque + gain).')}
          ${card('t-piv', 'Points pivots', inp('H', 'Plus haut', (last * 1.012).toFixed(2)) + inp('L', 'Plus bas', (last * 0.99).toFixed(2)) + inp('C', 'Clôture', last.toFixed(2)) + '<button class="btn btn-small" data-load>séance précédente de la valeur</button>', 'Classiques, Fibonacci, Camarilla et Woodie, calculés sur la séance précédente.')}
          ${card('t-fib', 'Niveaux de Fibonacci', inp('A', 'Départ du mouvement', (last * 0.9).toFixed(2)) + inp('B', 'Fin du mouvement', last.toFixed(2)), 'Retracements (vers le départ) et extensions (au-delà de la fin).')}
          ${card('t-be', 'Seuil de rentabilité', inp('px', 'Prix d\'achat', last.toFixed(2)) + inp('qty', 'Quantité', 100, 1, 80) + inp('fees', 'Frais totaux (€)', 12, 0.5, 80) + inp('tax', 'Impôt sur la plus-value (%)', 30, 0.5, 70), 'Prix de revente pour rentrer dans ses frais (avant / après prélèvement forfaitaire unique de 30 %).')}</div>
        <div>${card('t-bs', 'Options : Black-Scholes', inp('S0', 'Sous-jacent', last.toFixed(2)) + inp('K', 'Prix d\'exercice', (Math.round(last / 10) * 10).toFixed(2)) + inp('days', 'Jours restants', 30, 1, 70) + inp('vol', 'Volatilité (%)', 25, 0.5, 70) + inp('r', 'Taux sans risque (%)', 2.5, 0.05, 70) + inp('q', 'Dividende (%)', 1.5, 0.05, 70) + inp('mkt', 'Prix observé (vol. implicite)', '', 'any', 90), 'Modèle de Black-Scholes-Merton (dividende continu), loi normale exacte. Thêta par jour calendaire, véga et rhô pour 1 point.')}
          ${card('t-vol', 'Convertisseur de volatilité', inp('ann', 'Volatilité annuelle (%)', 25, 0.5, 80) + inp('px', 'Prix', last.toFixed(2)), 'σ(période) = σ(an) × √(durée / 252 séances). Fourchette à 1 écart-type ≈ 68 % des cas.')}
          ${card('t-cagr', 'Intérêts composés / CAGR', inp('start', 'Capital initial (€)', 10000, 100, 100) + inp('rate', 'Rendement annuel (%)', 7, 0.1, 70) + inp('years', 'Années', 10, 1, 60) + inp('add', 'Versement mensuel (€)', 200, 10, 80) + inp('end', 'Capital final visé (€)', 25000, 100, 100), '')}
          ${card('t-fx', `Convertisseur de devises (${S.real ? 'taux BCE / séance' : 'taux simulés'})`, inp('amt', 'Montant', 1000, 1, 100) + '<label class="f">De<select data-k="from"></select></label><label class="f">Vers<select data-k="to"></select></label>', '')}
          ${card('t-div', 'Rendement du dividende', inp('dps', 'Dividende par action', 2.5, 0.01, 80) + inp('px', 'Cours', last.toFixed(2)) + inp('tax', 'Fiscalité (%)', 30, 0.5, 70), '')}</div>
      </div>`;
    const R = (s) => root.querySelector(s);
    const vals = (id) => Object.fromEntries([...R(`#${id}`).querySelectorAll('[data-k]')].map((i) => [i.dataset.k, i.type === 'number' ? Number(i.value) : i.value]));
    const out = (id, html) => setHtml(R(`#${id} [data-out]`), html);
    const kv = (rows) => `<table class="kv">${rows.map(([k, v]) => `<tr><th>${k}</th><td>${v}</td></tr>`).join('')}</table>`;
    const N = (x, d = 2) => num(x, d);

    const calc = {
      't-pos': () => {
        const v = vals('t-pos'), per = Math.abs(v.entry - v.stop), risk = (v.cap * v.risk) / 100, qty = per > 0 ? Math.floor(risk / per) : 0;
        out('t-pos', kv([['Quantité', `<b>${int(qty)}</b> titres`], ['Montant investi', `${eur(qty * v.entry, 2)} (${pct(((qty * v.entry) / v.cap) * 100, 1, false)} du capital)`], ['Perte au stop', `<span class="down">${eur(qty * per, 2)}</span>`], ['Gain à l\'objectif', `<span class="up">${eur(qty * Math.abs(v.target - v.entry), 2)}</span>`], ['Gain / risque', N(Math.abs(v.target - v.entry) / (per || 1))], ['Distance du stop', pct((per / v.entry) * 100, 2, false)]]));
      },
      't-rr': () => {
        const v = vals('t-rr'), risk = Math.abs(v.entry - v.stop) + (v.entry * v.fee) / 100, g1 = Math.abs(v.t1 - v.entry) - (v.entry * v.fee) / 100, g2 = Math.abs(v.t2 - v.entry) - (v.entry * v.fee) / 100;
        out('t-rr', kv([['Risque (frais inclus)', `${N(risk, 3)} (${pct((risk / v.entry) * 100, 2, false)})`], ['Gain / risque objectif 1', `<b>${N(g1 / risk)}</b>`], ['Gain / risque objectif 2', `<b>${N(g2 / risk)}</b>`], ['Réussite minimale (obj. 1)', pct((risk / (risk + g1)) * 100, 1, false)], ['Réussite minimale (obj. 2)', pct((risk / (risk + g2)) * 100, 1, false)], ['Gain si ½ à obj. 1 et ½ à obj. 2', `${N((g1 + g2) / 2 / risk)} R`]]));
      },
      't-fees': async () => {
        const v = vals('t-fees'), s2 = S.info(v.sym) ? v.sym : (await get(`/api/search?q=${encodeURIComponent(v.sym)}&limit=1`))[0]?.sym;
        if (!s2) { out('t-fees', '<span class="err">valeur inconnue</span>'); return; }
        const [b, s3] = await Promise.all([get(`/api/fees?sym=${encodeURIComponent(s2)}&side=BUY&qty=${v.qty}&px=${v.px}`), get(`/api/fees?sym=${encodeURIComponent(s2)}&side=SELL&qty=${v.qty}&px=${v.px}`)]);
        out('t-fees', kv([['Valeur', `${esc(S.name(s2))} ${b.isin ? `<small>${esc(b.isin)}</small>` : ''}`], ['Montant', eur(b.notionalEur, 2)], ['Courtage achat / vente', `${eur(b.commission, 2)} / ${eur(s3.commission, 2)}`], ['TTF à l\'achat', b.ttf ? `<b>${eur(b.ttf, 2)}</b>` : `non (${b.isin?.startsWith('FR') ? 'capitalisation < 1 Md€' : 'société non française'})`], ['Coût aller-retour', `${eur(b.total + s3.total, 2)} (${pct(((b.total + s3.total) / b.notionalEur) * 100, 3, false)})`], ['Hausse nécessaire pour couvrir les frais', pct(((b.total + s3.total) / b.notionalEur) * 100, 3, false)]]));
      },
      't-kelly': () => {
        const v = vals('t-kelly'), p = v.win / 100, b = v.payoff, k = p - (1 - p) / b;
        out('t-kelly', kv([['Kelly complet', `<b class="${cls(k)}">${pct(k * 100, 1)}</b> du capital`], ['½ Kelly (conseillé)', pct((k / 2) * 100, 1)], ['¼ Kelly (prudent)', pct((k / 4) * 100, 1)], ['Espérance par trade', `${N(p * b - (1 - p), 3)} R`], ['Verdict', k > 0 ? '<span class="up">avantage positif</span>' : '<span class="down">pas d\'avantage : ne pas jouer</span>']]));
      },
      't-loss': () => {
        const v = vals('t-loss'), need = (1 / (1 - v.loss / 100) - 1) * 100;
        out('t-loss', kv([['Gain nécessaire', `<b>${pct(need, 2, false)}</b>`], ['Exemples', [10, 20, 30, 50, 75].map((x) => `−${x} % → +${num((1 / (1 - x / 100) - 1) * 100, 1)} %`).join('<br>')]]));
      },
      't-piv': () => {
        const v = vals('t-piv'), p = pivots(v.H, v.L, v.C), keys = ['R4', 'R3', 'R2', 'R1', 'P', 'S1', 'S2', 'S3', 'S4'];
        out('t-piv', `<table class="tbl compact"><thead><tr><th></th><th class="r">Classique</th><th class="r">Fibonacci</th><th class="r">Camarilla</th><th class="r">Woodie</th></tr></thead><tbody>${keys.map((k) => `<tr><td><b>${k}</b></td>${['classic', 'fibonacci', 'camarilla', 'woodie'].map((t) => `<td class="r ${k.startsWith('R') ? 'down' : k.startsWith('S') ? 'up' : ''}">${p[t][k] !== undefined ? N(p[t][k], 3) : ''}</td>`).join('')}</tr>`).join('')}</tbody></table>`);
      },
      't-fib': () => {
        const v = vals('t-fib'), d = v.B - v.A;
        const ret = [0.236, 0.382, 0.5, 0.618, 0.786].map((r) => [`Retracement ${num(r * 100, 1)} %`, N(v.B - d * r, 3)]);
        const ext = [1.272, 1.414, 1.618, 2, 2.618].map((r) => [`Extension ${num(r * 100, 1)} %`, N(v.A + d * r, 3)]);
        out('t-fib', kv([...ret, ...ext]));
      },
      't-be': () => {
        const v = vals('t-be'), cost = v.px * v.qty + v.fees, be = cost / v.qty;
        out('t-be', kv([['Prix de revient frais inclus', `<b>${N(be, 4)}</b>`], ['Hausse nécessaire', pct((be / v.px - 1) * 100, 3, false)], [`Pour gagner 1 000 € nets (après ${v.tax} %)`, `revendre à ${N(be + 1000 / (1 - v.tax / 100) / v.qty, 3)}`]]));
      },
      't-bs': () => {
        const v = vals('t-bs'), o = { S0: v.S0, K: v.K, T: v.days / 365, r: v.r / 100, q: v.q / 100, sigma: v.vol / 100 };
        const c = bs({ ...o, call: true }), p = bs({ ...o, call: false });
        if (!c) { out('t-bs', '<span class="err">paramètres invalides</span>'); return; }
        const iv = v.mkt ? impliedVol(v.mkt, { ...o, call: v.K >= v.S0 }) : null;
        out('t-bs', `<table class="tbl compact"><thead><tr><th></th><th class="r">Call</th><th class="r">Put</th></tr></thead><tbody>${[['Prix', c.price, p.price, 4], ['Delta', c.delta, p.delta, 4], ['Gamma', c.gamma, p.gamma, 5], ['Véga (1 pt)', c.vega, p.vega, 4], ['Thêta (1 jour)', c.theta, p.theta, 4], ['Rhô (1 pt)', c.rho, p.rho, 4], ['Proba. dans la monnaie', c.probITM * 100, p.probITM * 100, 2]].map(([k, a, b, d]) => `<tr><th>${k}</th><td class="r">${N(a, d)}</td><td class="r">${N(b, d)}</td></tr>`).join('')}</tbody></table>
          ${kv([['Parité call-put (contrôle)', `C − P = ${N(c.price - p.price, 6)} · S·e^(−qT) − K·e^(−rT) = ${N(v.S0 * Math.exp(-o.q * o.T) - v.K * Math.exp(-o.r * o.T), 6)}`], ['d1 · d2', `${N(c.d1, 4)} · ${N(c.d2, 4)}`], ...(iv !== null ? [[`Vol. implicite (${v.K >= v.S0 ? 'call' : 'put'} à ${v.mkt})`, `<b>${pct(iv * 100, 2, false)}</b>`]] : [])])}`);
      },
      't-vol': () => {
        const v = vals('t-vol'), s = v.ann / 100;
        out('t-vol', `<table class="tbl compact"><thead><tr><th>Période</th><th class="r">σ</th><th class="r">Fourchette 68 %</th><th class="r">Fourchette 95 %</th></tr></thead><tbody>${[['1 jour', 1], ['1 semaine', 5], ['1 mois', 21], ['3 mois', 63], ['1 an', 252]].map(([l, d]) => { const sd = s * Math.sqrt(d / 252); return `<tr><td>${l}</td><td class="r">${pct(sd * 100, 2, false)}</td><td class="r">${N(v.px * Math.exp(-sd), 2)} – ${N(v.px * Math.exp(sd), 2)}</td><td class="r">${N(v.px * Math.exp(-1.96 * sd), 2)} – ${N(v.px * Math.exp(1.96 * sd), 2)}</td></tr>`; }).join('')}</tbody></table>`);
      },
      't-cagr': () => {
        const v = vals('t-cagr'), r = v.rate / 100, m = (1 + r) ** (1 / 12) - 1, n = v.years * 12;
        const fv = v.start * (1 + r) ** v.years + (m > 0 ? v.add * (((1 + m) ** n - 1) / m) : v.add * n), paid = v.start + v.add * n;
        const cagr = ((v.end / v.start) ** (1 / v.years) - 1) * 100;
        out('t-cagr', kv([['Capital final', `<b>${eur(fv)}</b>`], ['Versé au total', eur(paid)], ['Gains composés', `<span class="up">${eur(fv - paid)}</span>`], [`CAGR pour atteindre ${eur(v.end)} (sans versement)`, pct(cagr, 2, false)], ['Règle de 72 : doublement en', `${N(72 / v.rate, 1)} ans`]]));
      },
      't-fx': () => {
        const v = vals('t-fx'), f = S.overview?.fx ?? [], rate = (c) => (c === 'EUR' ? 1 : f.find((x) => x.pair === `EUR/${c}`)?.rate ?? NaN);
        out('t-fx', kv([['Résultat', `<b>${N((v.amt / rate(v.from)) * rate(v.to), 4)} ${esc(v.to)}</b>`], ['Taux', `1 ${esc(v.from)} = ${N(rate(v.to) / rate(v.from), 6)} ${esc(v.to)}`]]));
      },
      't-div': () => {
        const v = vals('t-div'), y = (v.dps / v.px) * 100;
        out('t-div', kv([['Rendement brut', `<b>${pct(y, 2, false)}</b>`], ['Rendement net', pct(y * (1 - v.tax / 100), 2, false)], ['Pour 10 000 € investis', `${eur((10000 * y) / 100, 2)} brut · ${eur(((10000 * y) / 100) * (1 - v.tax / 100), 2)} net`]]));
      },
    };
    // devises
    const fxs = ['EUR', ...(S.overview?.fx ?? []).map((x) => x.pair.slice(4))];
    R('#t-fx [data-k="from"]').innerHTML = fxs.map((c) => `<option ${c === 'EUR' ? 'selected' : ''}>${c}</option>`).join('');
    R('#t-fx [data-k="to"]').innerHTML = fxs.map((c) => `<option ${c === 'USD' ? 'selected' : ''}>${c}</option>`).join('');
    // pivots de la séance précédente
    R('#t-piv [data-load]').onclick = async () => {
      const h = await history(sym, '1D'), n = h.close.length;
      const set = (k, v) => { R(`#t-piv [data-k="${k}"]`).value = v.toFixed(4); };
      set('H', h.high[n - 2]); set('L', h.low[n - 2]); set('C', h.close[n - 2]);
      calc['t-piv']();
      toast('Pivots', `séance précédente de ${esc(S.name(sym))}`, 'ok', 1500);
    };
    for (const id of Object.keys(calc)) {
      const box = R(`#${id}`);
      box.addEventListener('input', () => calc[id]());
      box.addEventListener('change', () => calc[id]());
      Promise.resolve(calc[id]()).catch((e) => out(id, `<span class="err">${esc(e.message)}</span>`));
    }
  },
};
void [el, on, $];

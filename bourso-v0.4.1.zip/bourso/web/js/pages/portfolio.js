// ============================================================================
//  BOURSO :: pages/portfolio.js — PORTEFEUILLE & ORDRES (négociation fictive : simulée en
//  démonstration, sur cours réels différés en mode données réelles ; aucun ordre ne sort).
//  Synthèse, courbe de valeur, positions (P&L latent, du jour, poids), répartition, RISQUE
//  (volatilité, VaR/ES historiques en €, bêta Europe, contributions, corrélations), passage
//  d'ordres sur n'importe quelle valeur, ordres en attente, exécutions, alertes.
// ============================================================================
import { S, prefs } from '../core/store.js';
import { get, post, del } from '../core/api.js';
import { live } from '../core/live.js';
import { $, el, on, setHtml, tabs, toast, confirmBox, meter } from '../core/dom.js';
import { esc, num, int, pct, eur, money, price, ago, dateTime, cls } from '../core/fmt.js';
import { nameCell, chg, symHref } from '../core/ui.js';
import { orderTicket } from '../widgets/order-ticket.js';
import { Plot, HeatGrid } from '../widgets/plot.js';

const TYPE = { MKT: 'marché', LMT: 'limite', STP: 'stop', STL: 'stop limite' };
const STATUS = { WORKING: ['en attente', 'run'], FILLED: ['exécuté', 'ok'], CANCELLED: ['annulé', ''], EXPIRED: ['expiré', ''] };

export default {
  title: 'Portefeuille',
  async mount(root, ctx) {
    root.innerHTML = `<div class="page-title"><h1>Portefeuille &amp; ordres</h1><span class="sub">${S.real ? 'compte <b>fictif</b> sur cours réels différés (aucun ordre ne quitte ta machine)' : 'compte de négociation simulé'} · frais de courtage et taxe sur les transactions financières (0,4 %) appliqués</span></div>
      <div class="kpis" id="p-kpi" style="margin-bottom:12px"></div>
      <div class="layout l2">
        <div>
          <section class="box"><h2 class="box-title"><span class="ico">₪</span>Positions</h2><div class="scroll tall"><table class="tbl" id="p-pos"></table></div></section>
          <div class="cols cols-2">
            <section class="box"><h2 class="box-title"><span class="ico">∿</span>Valeur du portefeuille</h2><div class="box-body"><canvas class="plot" id="p-eq"></canvas></div></section>
            <section class="box"><h2 class="box-title"><span class="ico">◔</span>Répartition</h2><div class="box-body" id="p-alloc"></div></section>
          </div>
          <section class="box"><h2 class="box-title"><span class="ico">⚠</span>Risque du portefeuille <span class="title-note">1 an de séances communes, hors change</span></h2><div id="p-risk"></div></section>
          <section class="box"><div id="p-tabs"></div><div id="p-tab"></div></section>
        </div>
        <aside>
          <section class="box ov"><h2 class="box-title"><span class="ico">✎</span>Passer un ordre</h2>
            <div class="form" style="position:relative"><input type="search" id="p-q" placeholder="Valeur : nom, code ou ISIN…" style="width:100%" autocomplete="off"><div class="suggest hidden" id="p-sug" style="top:36px;left:10px;right:10px"></div></div><div id="p-ticket"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">⚙</span>Compte</h2><div class="form col" id="p-acct"></div></section>
        </aside>
      </div>`;
    const R = (s) => root.querySelector(s);
    let pf = null, eqPlot = null, ticket = null, grid = null, tab = ctx.params[0] === 'alertes' ? 'alerts' : prefs.get('pf.tab', 'orders');

    const setSym = (sym) => {
      ticket?.destroy();
      ticket = orderTicket(R('#p-ticket'), { sym });
    };
    setSym(S.lastSym);
    // recherche de valeur pour le bon d'ordre
    const q = R('#p-q'), sug = R('#p-sug');
    let tm = null;
    q.addEventListener('input', () => {
      clearTimeout(tm);
      tm = setTimeout(async () => {
        const v = q.value.trim();
        if (!v) { sug.classList.add('hidden'); return; }
        const r = await get(`/api/search?q=${encodeURIComponent(v)}&limit=10`).catch(() => []);
        if (v !== q.value.trim()) return;
        found = r;
        sug.innerHTML = r.map((x, i) => (x.external
          ? `<a href="#" class="ext" data-x="${i}" title="Valeur pas encore suivie : un clic l'ajoute à Bourso"><span class="code">${esc(x.code)}</span><span>${esc(x.name)} <span class="where">${esc(x.ex ?? '')}</span></span><span class="chip ok">+ ajouter</span><span></span></a>`
          : `<a href="#" data-s="${esc(x.sym)}"><span class="code">${esc(x.code)}</span><span>${esc(x.name)} <span class="where">${esc(x.ex)}</span></span><span>${price(x.last, S.tick(x.sym))}</span><span></span></a>`)).join('') || '<div class="empty">Aucune valeur trouvée</div>';
        sug.classList.remove('hidden');
      }, 160);
    });
    let found = [];
    on(sug, 'click', '[data-s]', (e, a) => { e.preventDefault(); setSym(a.dataset.s); q.value = ''; sug.classList.add('hidden'); });
    on(sug, 'click', '[data-x]', async (e, a) => {
      e.preventDefault();
      const x = found[Number(a.dataset.x)];
      q.value = '';
      sug.classList.add('hidden');
      if (!x) return;
      toast('Ajout de la valeur', `${esc(x.name)} : cours et historique en cours de chargement…`, '', 2500);
      try { setSym(await S.addExternal({ ...x, exchangeCode: null })); } catch (err) { toast('Ajout impossible', esc(err.message), 'ko', 6000); }
    });

    const render = () => {
      if (!pf) return;
      const invested = pf.marketValueEur;
      setHtml(R('#p-kpi'), [
        ['Valeur totale', eur(pf.totalEur, 2), `départ ${eur(pf.initial)}`], ['Performance', `<span class="${cls(pf.perfPct)}">${pct(pf.perfPct)}</span>`, `${eur(pf.totalEur - pf.initial, 2)}`],
        ['Liquidités', eur(pf.cashEur, 2), `${pct((pf.cashEur / pf.totalEur) * 100, 1, false)} du total`], ['Investi', eur(invested, 2), `${pf.positions.length} position(s)`],
        ['Plus-value latente', `<span class="${cls(pf.unrealizedEur)}">${eur(pf.unrealizedEur, 2)}</span>`, ''], ['Réalisé (net de frais)', `<span class="${cls(pf.realizedEur)}">${eur(pf.realizedEur, 2)}</span>`, ''],
        ['Frais payés', eur(pf.feesEur, 2), 'courtage + TTF'], ['Variation du jour', `<span class="${cls(pf.positions.reduce((a, p) => a + p.dayPnlEur, 0))}">${eur(pf.positions.reduce((a, p) => a + p.dayPnlEur, 0), 2)}</span>`, ''],
      ].map(([k, v, s2]) => `<div class="kpi"><span>${k}</span><b>${v}</b><small>${s2}</small></div>`).join(''));
      setHtml(R('#p-pos'), `<thead><tr><th>Valeur</th><th class="r">Quantité</th><th class="r">PRU</th><th class="r">Cours</th><th class="r">Var. jour</th><th class="r">Valeur €</th><th class="r">+/- value latente</th><th class="r">P&amp;L jour</th><th class="r">Poids</th><th></th></tr></thead><tbody>${pf.positions.map((p) => `<tr>
        <td>${nameCell(p.sym)}</td><td class="r">${int(p.qty)}</td><td class="r">${price(p.avg, S.tick(p.sym))}</td><td class="r"><b>${price(p.last, S.tick(p.sym))}</b> <span class="small muted">${p.ccy !== 'EUR' ? esc(p.ccy) : ''}</span></td><td class="r">${chg(p.chgPct)}</td>
        <td class="r">${eur(p.valueEur, 2)}</td><td class="r ${cls(p.upnlEur)}">${eur(p.upnlEur, 2)}<small>${pct(p.upnlPct, 2)}</small></td><td class="r ${cls(p.dayPnlEur)}">${eur(p.dayPnlEur, 2)}</td><td class="r">${pct(p.weight * 100, 1, false)}</td>
        <td class="r nowrap">${p.qty ? `<button class="mini" data-close="${esc(p.sym)}" data-qty="${p.qty}">clôturer</button>` : ''} <button class="mini" data-trade="${esc(p.sym)}">ordre</button></td></tr>`).join('') || '<tr class="empty"><td colspan="10">Aucune position. Passe un ordre à droite (ou F1 / F2 depuis un graphique).</td></tr>'}</tbody>`);
      // répartition
      const part = (obj) => {
        const tot = Object.values(obj).reduce((a, b) => a + Math.abs(b), 0) || 1;
        return Object.entries(obj).sort((a, b) => b[1] - a[1]).map(([k, v]) => `<tr><td>${esc(k)}</td><td style="width:45%">${meter(Math.abs(v) / tot, 'blue')}</td><td class="r">${pct((v / pf.totalEur) * 100, 1, false)}</td></tr>`).join('');
      };
      setHtml(R('#p-alloc'), `<table class="tbl compact"><thead><tr><th>Secteur</th><th></th><th class="r">% total</th></tr></thead><tbody>${part(pf.bySector) || '<tr class="empty"><td colspan="3">—</td></tr>'}</tbody></table>
        <table class="tbl compact" style="margin-top:6px"><thead><tr><th>Région</th><th></th><th class="r">% total</th></tr></thead><tbody>${part({ ...pf.byRegion, Liquidités: pf.cashEur })}</tbody></table>`);
      // courbe de valeur
      const eq = pf.equity.length > 1 ? pf.equity : [[Date.now() - 60_000, pf.initial], [Date.now(), pf.totalEur]];
      const xs = eq.map((e) => e[0]), ys = eq.map((e) => e[1]);
      if (!eqPlot) eqPlot = new Plot(R('#p-eq'), { height: 200, xs, xFormat: (x) => new Date(x).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }), yFormat: (v) => eur(v), series: [] });
      eqPlot.set({ xs, series: [{ type: 'line', data: ys, name: 'valeur', area: true, color: '#1f6fd1' }, { type: 'hline', y: pf.initial, color: '#8a95a3', label: 'départ' }] });
      renderTab();
    };

    const loadRisk = async () => {
      const r = await get('/api/portfolio/risk').catch(() => null);
      if (!r || !r.positions) { setHtml(R('#p-risk'), '<div class="empty">Pas de position : rien à mesurer.</div>'); return; }
      if (r.error) { setHtml(R('#p-risk'), `<div class="empty">${esc(r.error)}</div>`); return; }
      setHtml(R('#p-risk'), `<div class="box-body"><div class="cols cols-2"><table class="kv">
        <tr><th>Volatilité annualisée</th><td>${pct(r.volAnnPct, 1, false)}</td></tr><tr><th>VaR 95 % (1 jour)</th><td class="down">${eur(r.var95Eur)} <small>${pct(r.var95Pct, 2, false)}</small></td></tr><tr><th>VaR 99 % (1 jour)</th><td class="down">${eur(r.var99Eur)}</td></tr>
        <tr><th>Perte moyenne au-delà (ES 95 %)</th><td class="down">${eur(r.es95Eur)}</td></tr><tr><th>Bêta vs panier Europe</th><td>${num(r.betaEurope, 2)}</td></tr><tr><th>Perte maximale (1 an, poids actuels)</th><td class="down">${pct(r.maxDrawdown1aPct, 1)}</td></tr>
        <tr><th>Rendement 1 an (poids actuels)</th><td class="${cls(r.return1aPct)}">${pct(r.return1aPct, 1)}</td></tr><tr><th>Ratio de diversification</th><td>${num(r.diversificationRatio, 2)} <small class="muted">(1 = aucune diversification)</small></td></tr><tr><th>Séances communes</th><td>${r.days}</td></tr></table>
        <div><table class="tbl compact"><thead><tr><th>Valeur</th><th class="r">Poids</th><th class="r">Vol.</th><th>Contribution au risque</th></tr></thead><tbody>${r.rows.map((x) => `<tr><td>${esc(x.name)}</td><td class="r">${pct(x.weightPct, 1, false)}</td><td class="r">${pct(x.volAnnPct, 0, false)}</td><td>${meter((x.riskContribPct ?? 0) / 100, 'red')} <small>${pct(x.riskContribPct, 1, false)}</small></td></tr>`).join('')}</tbody></table>
        ${r.rows.length > 1 ? '<canvas id="p-corr" style="width:100%;margin-top:8px"></canvas>' : ''}</div></div></div>`);
      if (r.rows.length > 1) {
        grid?.destroy();
        const names = r.rows.map((x) => S.info(x.sym)?.code ?? x.sym);
        grid = new HeatGrid(R('#p-corr'), { rows: names, cols: names, values: r.corr, max: 1, showValues: r.rows.length <= 10, format: (v) => num(v, 2) });
        grid.render();
      }
    };

    const renderTab = () => {
      if (!pf) return;
      const box = R('#p-tab');
      if (tab === 'orders') {
        setHtml(box, `<table class="tbl"><thead><tr><th>Créé</th><th>Valeur</th><th>Sens</th><th>Type</th><th class="r">Qté</th><th class="r">Limite</th><th class="r">Déclenchement</th><th>Validité</th><th>État</th><th class="r">Prix exécuté</th><th class="r">Frais</th><th>Origine</th><th></th></tr></thead><tbody>${pf.orders.map((o) => `<tr>
          <td class="small">${dateTime(o.created)}</td><td><a href="${symHref(o.sym)}">${esc(o.name)}</a></td><td class="${o.side === 'BUY' ? 'up' : 'down'}">${o.side === 'BUY' ? 'achat' : 'vente'}</td><td>${TYPE[o.type]}</td><td class="r">${int(o.qty)}</td>
          <td class="r">${o.limit ? price(o.limit, S.tick(o.sym)) : '—'}</td><td class="r">${o.stop ? price(o.stop, S.tick(o.sym)) : '—'}</td><td>${o.tif === 'GTC' ? 'révocation' : 'jour'}</td><td><span class="chip ${STATUS[o.status]?.[1] ?? ''}">${STATUS[o.status]?.[0] ?? esc(o.status)}</span>${o.status === 'WORKING' && o.waiting ? `<small>${esc(o.waiting)}</small>` : o.note && o.status === 'EXPIRED' ? `<small>${esc(o.note)}</small>` : ''}</td>
          <td class="r">${o.avgPx ? price(o.avgPx, S.tick(o.sym)) : '—'}</td><td class="r">${o.fees ? eur(o.fees, 2) : '—'}</td><td class="small">${esc(o.source)}</td><td>${o.status === 'WORKING' ? `<button class="mini" data-cancel="${esc(o.id)}">annuler</button>` : ''}</td></tr>`).join('') || '<tr class="empty"><td colspan="13">Aucun ordre</td></tr>'}</tbody></table>`);
      } else if (tab === 'execs') {
        setHtml(box, `<table class="tbl"><thead><tr><th>Date</th><th>Valeur</th><th>Sens</th><th class="r">Qté</th><th class="r">Prix</th><th class="r">Montant €</th><th class="r">Courtage</th><th class="r">TTF</th><th class="r">Réalisé €</th></tr></thead><tbody>${pf.executions.map((x) => `<tr${x.note ? ` title="${esc(x.note)}"` : ''}>
          <td class="small">${dateTime(x.at)}</td><td><a href="${symHref(x.sym)}">${esc(x.name)}</a></td><td class="${x.side === 'BUY' ? 'up' : 'down'}">${x.side === 'BUY' ? 'achat' : 'vente'}</td><td class="r">${int(x.qty)}</td><td class="r">${price(x.px, S.tick(x.sym))} ${x.ccy !== 'EUR' ? esc(x.ccy) : ''}</td>
          <td class="r">${eur(x.fees.notionalEur, 2)}</td><td class="r">${eur(x.fees.commission, 2)}</td><td class="r">${x.fees.ttf ? eur(x.fees.ttf, 2) : '—'}</td><td class="r ${cls(x.realizedEur)}">${x.realizedEur ? eur(x.realizedEur, 2) : '—'}</td></tr>`).join('') || '<tr class="empty"><td colspan="9">Aucune exécution</td></tr>'}</tbody></table>`);
      } else if (tab === 'alerts') renderAlerts(box);
    };
    const renderAlerts = async (box) => {
      const al = await get('/api/alerts');
      const cond = (a) => (a.op === 'above' ? `cours ≥ ${price(a.value, S.tick(a.sym))}` : a.op === 'below' ? `cours ≤ ${price(a.value, S.tick(a.sym))}` : a.op === 'chg_above' ? `variation ≥ ${pct(a.value)}` : `variation ≤ ${pct(a.value)}`);
      setHtml(box, `<table class="tbl"><thead><tr><th>Créée</th><th>Valeur</th><th>Condition</th><th>Note</th><th class="r">Cours actuel</th><th>État</th><th></th></tr></thead><tbody>${al.map((a) => `<tr>
        <td class="small">${dateTime(a.created)}</td><td><a href="${symHref(a.sym)}">${esc(a.name)}</a></td><td>${cond(a)}</td><td class="small">${esc(a.note)}</td><td class="r">${price(S.quote(a.sym)?.last, S.tick(a.sym))}</td>
        <td>${a.active ? '<span class="chip run">active</span>' : `<span class="chip warn">déclenchée</span><small>${ago(a.triggeredAt)} à ${price(a.triggerPrice, S.tick(a.sym))}</small>`}</td>
        <td class="r nowrap"><button class="mini" data-rearm="${a.id}" ${a.active ? 'disabled' : ''}>réarmer</button> <button class="mini" data-delal="${a.id}">✕</button></td></tr>`).join('') || '<tr class="empty"><td colspan="7">Aucune alerte — crée-en depuis la fiche d\'une valeur (bouton « Alerte » ou clic droit sur le graphique).</td></tr>'}</tbody></table>`);
    };
    tabs(R('#p-tabs'), [{ id: 'orders', label: 'Ordres' }, { id: 'execs', label: 'Exécutions' }, { id: 'alerts', label: 'Alertes de cours' }], (id) => { tab = id; prefs.set('pf.tab', id); renderTab(); }, tab);

    on(root, 'click', '[data-cancel]', async (e, b) => { await del(`/api/orders/${b.dataset.cancel}`); toast('Ordre annulé', '', 'ok', 1500); });
    on(root, 'click', '[data-close]', async (e, b) => {
      const qty = Number(b.dataset.qty), sym = b.dataset.close;
      if (!(await confirmBox(`Clôturer la position ${esc(S.name(sym))} (${int(Math.abs(qty))} titres) au marché ?`, { ok: 'Clôturer' }))) return;
      try { await post('/api/orders', { sym, side: qty > 0 ? 'SELL' : 'BUY', type: 'MKT', qty: Math.abs(qty) }); } catch (err) { toast('Ordre refusé', esc(err.message), 'ko'); }
    });
    on(root, 'click', '[data-trade]', (e, b) => { setSym(b.dataset.trade); R('#p-ticket').scrollIntoView({ behavior: 'smooth', block: 'center' }); });
    on(root, 'click', '[data-delal]', async (e, b) => { await del(`/api/alerts/${b.dataset.delal}`); renderTab(); });
    on(root, 'click', '[data-rearm]', async (e, b) => { await post(`/api/alerts/${b.dataset.rearm}/rearm`); renderTab(); });

    const renderAcct = () => {
      const t = S.settings.trading;
      R('#p-acct').innerHTML = `<table class="kv"><tr><th>Courtage</th><td>${num(t.commissionPct, 2)} % (min. ${eur(t.commissionMin, 2)})</td></tr><tr><th title="Sociétés françaises de plus d'1 Md€ de capitalisation au 1er décembre précédent : liste officielle (BOFiP)">TTF (achats, liste officielle)</th><td>${num(t.ttfPct, 1)} %</td></tr><tr><th>Vente à découvert</th><td>${t.allowShort ? 'autorisée' : 'interdite'}</td></tr></table>
        <label class="f">Courtage (%)<input type="number" id="a-com" value="${t.commissionPct}" step="0.01" min="0"></label><label class="f">Minimum par ordre (€)<input type="number" id="a-min" value="${t.commissionMin}" step="0.5" min="0"></label>
        <label class="chk"><input type="checkbox" id="a-short" ${t.allowShort ? 'checked' : ''}> autoriser la vente à découvert</label><button class="btn btn-small" id="a-save">Enregistrer</button>
        <hr style="width:100%;border:0;border-top:1px solid var(--border-soft)"><label class="f">Capital de départ (€)<input type="number" id="a-cash" value="${t.initialCash}" step="1000" min="1000"></label><button class="btn btn-small sell" id="a-reset">Réinitialiser le compte</button>`;
      R('#a-save').onclick = async () => { await S.saveSettings({ trading: { commissionPct: Number(R('#a-com').value), commissionMin: Number(R('#a-min').value), allowShort: R('#a-short').checked } }); toast('Enregistré', '', 'ok', 1200); renderAcct(); };
      R('#a-reset').onclick = async () => {
        if (!(await confirmBox(`Réinitialiser le portefeuille ${S.real ? 'fictif (données réelles)' : 'de démonstration'} : positions, ordres et historique effacés ?`, { danger: true, ok: 'Réinitialiser' }))) return;
        const cash = Number(R('#a-cash').value);
        await S.saveSettings({ trading: { initialCash: cash } });
        pf = await post('/api/portfolio/reset', { cash });
        render();
        loadRisk();
      };
    };
    renderAcct();

    const load = async () => { pf = await get('/api/portfolio'); render(); };
    await load();
    loadRisk();
    let t = 0, riskT = null;
    const offs = [
      live.on('pf', () => { load(); clearTimeout(riskT); riskT = setTimeout(loadRisk, 1500); }),
      live.on('alerts', () => { if (tab === 'alerts') renderTab(); }),
      S.on('quotes', () => { if (performance.now() - t > 2000) { t = performance.now(); load(); } }),
    ];
    return { unmount() { offs.forEach((f) => f()); ticket?.destroy(); eqPlot?.destroy(); grid?.destroy(); } };
  },
};
void [el, $, money];

// ============================================================================
//  BOURSO :: pages/ai.js — ANALYSE IA : la console de l'IA.
//
//  Lancer l'analyse de n'importe quelle action · suivre en direct chaque étape (calculs GPU/CPU,
//  dossier, réponse du modèle Ollama jeton par jeton, réflexion, garde-fous) · lire la décision
//  complète (plan, scénarios, facteurs, Monte Carlo en éventail, backtests, temps, jetons) ·
//  historique · fiabilité mesurée · réglages du modèle · prompt et schéma de réponse.
// ============================================================================
import { S } from '../core/store.js';
import { get, post } from '../core/api.js';
import { $, el, on, setHtml, toast, meter, tabs } from '../core/dom.js';
import { esc, num, int, pct, ago, until, dur, dateTime, decisionChip, DECISION, price, cls, big, bytes } from '../core/fmt.js';
import { nameCell, symHref } from '../core/ui.js';
import { Plot } from '../widgets/plot.js';

/** Bloc « lecture de la réponse du modèle » : anti-boucle, corrections, compléments, valeurs par défaut. */
function readingNotes(g) {
  const p = g.parsing ?? {}, items = [];
  for (const x of g.antiLoop ?? []) items.push(`<li>⟲ anti-boucle — ${esc(x)}</li>`);
  for (const x of p.notes ?? []) items.push(`<li>${esc(x)}</li>`);
  if (p.completed?.length) items.push(`<li>complété par un appel court : ${esc(p.completed.join(', '))}</li>`);
  if (p.defaulted?.length) items.push(`<li>valeurs par défaut : ${esc(p.defaulted.join(' · '))}</li>`);
  return items.length ? `<div class="info small"><b>Lecture de la réponse du modèle</b>${p.calls ? ` <span class="muted">(${p.calls} appel${p.calls > 1 ? 's' : ''} supplémentaire${p.calls > 1 ? 's' : ''})</span>` : ''}<ul style="margin:4px 0 0 16px;padding:0">${items.join('')}</ul></div>` : '';
}

const STAGES = [['données', 'Données'], ['calculs', 'Calculs GPU/CPU'], ['dossier', 'Dossier'], ['ia', 'Modèle IA'], ['garde-fous', 'Garde-fous'], ['décision', 'Décision']];

export default {
  title: 'Analyse IA',
  async mount(root, ctx) {
    root.innerHTML = `<div class="page-title"><h1>Analyse IA</h1><span class="sub" id="ai-sub"></span></div>
      <div class="layout">
        <aside>
          <section class="box ov"><h2 class="box-title"><span class="ico">▶</span>Analyser une action</h2>
            <div class="form col" style="position:relative"><input type="search" id="ai-q" placeholder="Nom, code ou ISIN (toutes places)…" autocomplete="off"><div class="suggest hidden" id="ai-sug" style="top:36px;left:10px;right:10px"></div>
              <label class="chk" style="white-space:normal"><input type="checkbox" id="ai-think"> réflexion du modèle (plus lent, plus approfondi)</label>
              <button class="btn primary" id="ai-go" disabled>Lancer l'analyse</button>
              <div class="help-text">Passe devant la boucle des favoris. Favoris : <span id="ai-favs"></span></div></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">≡</span>File de l'IA <span class="title-note" id="ai-qnote"></span></h2><ul class="queue" id="ai-queue"></ul></section>
          <section class="box"><h2 class="box-title"><span class="ico">⚙</span>Ollama <span class="tools"><button class="btn btn-xs" id="ai-check">revérifier</button></span></h2><div id="ai-ollama"></div></section>
        </aside>
        <div>
          <section class="box"><h2 class="box-title"><span class="ico">◉</span>Analyse en direct <span class="title-note" id="live-note">en attente d'une analyse</span></h2>
            <div class="box-body"><div class="pipeline" id="pipe"></div><pre class="console" id="console"><span class="d">La console affiche chaque étape : calculs GPU/CPU, dossier, puis la réponse du modèle jeton par jeton.</span></pre></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">◆</span>Décision <span class="title-note" id="res-note"></span></h2><div id="result"><div class="empty">Choisis une décision dans l'historique ou lance une analyse.</div></div></section>
        </div>
        <aside class="col-right">
          <section class="box"><h2 class="box-title"><span class="ico">☰</span>Historique des décisions</h2><div class="scroll tall"><table class="tbl compact" id="ai-hist"></table></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">✓</span>Fiabilité mesurée</h2><div id="ai-rel"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">⚙</span>Réglages du modèle</h2><div class="form col" id="ai-set"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">✎</span>Consignes du modèle</h2><div class="box-body small"><details><summary>Prompt système de l'analyste</summary><pre class="mono small" id="ai-prompt" style="white-space:pre-wrap;max-height:320px;overflow:auto"></pre></details><details><summary>Schéma JSON imposé (structured outputs)</summary><pre class="mono small" id="ai-schema" style="white-space:pre-wrap;max-height:320px;overflow:auto"></pre></details></div></section>
        </aside>
      </div>`;
    const R = (s) => root.querySelector(s);
    const state = { job: null, sym: null, stage: null, content: '', thinking: '', t0: 0, stageTimes: {}, plots: [] };
    let selSym = null;

    // ---------------------------------------------------------------- lancer une analyse
    const q = R('#ai-q'), sug = R('#ai-sug');
    let tm = null;
    q.addEventListener('input', () => {
      clearTimeout(tm);
      R('#ai-go').disabled = true;
      tm = setTimeout(async () => {
        const v = q.value.trim();
        if (!v) { sug.classList.add('hidden'); return; }
        const r = await get(`/api/search?q=${encodeURIComponent(v)}&limit=10`);
        sug.innerHTML = r.map((x) => `<a href="#" data-s="${esc(x.sym)}"><span class="code">${esc(x.code)}</span><span>${esc(x.name)} <span class="where">${esc(x.ex)}</span></span><span>${price(x.last, S.tick(x.sym))}</span><span></span></a>`).join('') || '<div class="empty">Aucune valeur</div>';
        sug.classList.remove('hidden');
      }, 120);
    });
    on(sug, 'click', '[data-s]', (e, a) => {
      e.preventDefault();
      selSym = a.dataset.s;
      q.value = S.name(selSym);
      sug.classList.add('hidden');
      R('#ai-go').disabled = false;
    });
    const launch = async (sym) => {
      try {
        const j = await post('/api/ai/analyze', { sym, think: R('#ai-think').checked || undefined });
        if (j.duplicate) toast('Déjà dans la file', `${esc(S.name(sym))} attend déjà son analyse (job ${esc(j.id)})`, 'warn', 3000);
        else toast('Analyse lancée', `${esc(S.name(sym))} — job ${esc(j.id)}`, 'ok', 2500);
      } catch (e) { toast('Analyse impossible', esc(e.message), 'ko'); }
    };
    R('#ai-go').onclick = () => selSym && launch(selSym);
    R('#ai-favs').innerHTML = S.favorites.map((s) => `<a href="#" data-fav-run="${esc(s)}">${esc(S.info(s)?.code ?? s)}</a>`).join(' · ');
    on(root, 'click', '[data-fav-run]', (e, a) => { e.preventDefault(); launch(a.dataset.favRun); });

    // ---------------------------------------------------------------- file, Ollama
    const renderQueue = () => {
      const qq = S.ai.queue;
      if (!qq) return;
      const rows = [];
      if (qq.running) rows.push(`<li class="running"><span class="rk">▶</span><span class="nm"><b>${esc(qq.running.name)}</b><div class="st">${esc(qq.running.stage ?? '')} · ${ago(qq.running.startedAt)}</div></span><span class="chip run">en cours</span></li>`);
      for (const m of qq.manual) rows.push(`<li><span class="rk">⚑</span><span class="nm">${esc(m.name)}<div class="st">demande manuelle</div></span><span class="chip warn">prioritaire</span></li>`);
      for (const f of qq.favorites) {
        const st = { waiting: ['en attente', ''], running: ['en cours', 'run'], done: ['faite', 'ok'], skipped: ['rien de nouveau', 'hold'], error: ['erreur', 'ko'], paused: ['en pause', 'warn'] }[f.state] ?? ['en attente', ''];
        rows.push(`<li class="${f.state === 'skipped' ? 'skipped' : ''}"><span class="rk">${f.rank}</span><span class="nm"><a href="${symHref(f.sym)}">${esc(f.name ?? f.sym)}</a><div class="st">${esc(f.reason ?? '')}${f.at ? ` · ${ago(f.at)}` : ''}</div></span><span>${f.decision ? decisionChip(f.decision) : `<span class="chip ${st[1]}">${st[0]}</span>`}</span></li>`);
      }
      if (qq.pausedUntil) rows.unshift(`<li class="paused"><span class="rk">⏸</span><span class="nm"><b>Boucle des favoris en pause</b><div class="st">anti-boucle : plusieurs analyses ont échoué d'affilée (${esc(qq.pauseReason ?? '')}) · reprise ${until(qq.pausedUntil)}</div></span><button class="btn btn-xs" id="ai-resume">reprendre</button></li>`);
      setHtml(R('#ai-queue'), rows.join('') || '<li class="empty">File vide</li>');
      const rs = R('#ai-resume');
      if (rs) rs.onclick = async () => { S.ai.queue = await post('/api/ai/resume'); renderQueue(); toast('Boucle des favoris', 'reprise', 'ok', 1500); };
      setHtml(R('#ai-qnote'), `${qq.pausedUntil ? 'pause anti-boucle' : qq.auto ? 'boucle active' : 'boucle en pause'} · ${int(qq.stats.analyzed)} analyses${qq.stats.loops ? ` · ${int(qq.stats.loops)} boucle(s) évitée(s)` : ''}`);
    };
    const renderOllama = () => {
      const o = S.ai.ollama;
      if (!o) return;
      setHtml(R('#ai-ollama'), `<table class="kv"><tr><th>Serveur</th><td>${esc(o.host ?? '')}</td></tr><tr><th>État</th><td>${o.up ? `<span class="chip ok">joignable</span> v${esc(o.version)}` : `<span class="chip ko">injoignable</span><small>${esc(o.error ?? '')}</small>`}</td></tr>
        <tr><th>Modèle utilisé</th><td>${esc(S.ai.model ?? '—')}</td></tr></table>
        ${o.models?.length ? `<table class="tbl compact"><thead><tr><th>Modèle installé</th><th class="r">Taille</th><th>Param.</th></tr></thead><tbody>${o.models.map((m) => `<tr><td>${esc(m.name)}</td><td class="r">${bytes(m.size)}</td><td>${esc(m.params ?? '')} ${esc(m.quant ?? '')}</td></tr>`).join('')}</tbody></table>` : ''}
        ${o.loaded?.length ? `<div class="box-foot">En mémoire : ${o.loaded.map((m) => `${esc(m.name)} (${bytes(m.vram)} en VRAM)`).join(', ')}</div>` : ''}
        ${o.up ? '' : '<div class="notice small">Sans Ollama, les décisions sont <b>simulées</b> à partir des calculs (étiquetées). Lance <kbd>ollama serve</kbd> puis <kbd>npm run ollama:setup</kbd>.</div>'}`);
      R('#ai-sub').textContent = `un seul modèle (${S.ai.model ?? '—'}) via Ollama ${o.up ? `v${o.version}` : '(injoignable : réponses simulées)'} · analyses manuelles prioritaires, puis les favoris dans l'ordre`;
    };
    R('#ai-check').onclick = async () => { S.ai.ollama = await post('/api/ai/check'); renderOllama(); };

    // ---------------------------------------------------------------- pipeline et console en direct
    const pipe = () => {
      const cur = STAGES.findIndex(([k]) => k === state.stage);
      setHtml(R('#pipe'), STAGES.map(([k, l], i) => `<div class="st ${i < cur || state.stage === 'décision' ? 'done' : i === cur ? 'on' : ''}">${l}<small>${state.stageTimes[k] ? dur(state.stageTimes[k]) : ''}</small></div>`).join(''));
    };
    const cons = R('#console');
    const put = (html) => {
      const atBottom = cons.scrollTop + cons.clientHeight >= cons.scrollHeight - 30;
      cons.insertAdjacentHTML('beforeend', html);
      if (atBottom) cons.scrollTop = cons.scrollHeight;
    };
    const colorJson = (s) => esc(s).replace(/(&quot;[^&]*?&quot;)(\s*:)/g, '<span class="k">$1</span>$2').replace(/: (&quot;.*?&quot;)/g, ': <span class="s">$1</span>').replace(/: (-?\d+(\.\d+)?)/g, ': <span class="n">$1</span>');
    let tokenEl = null, thinkEl = null, lastStageAt = 0;
    const onAi = (m) => {
      if (m.ev === 'queue') { renderQueue(); return; }
      if (m.ev === 'start') {
        Object.assign(state, { job: m.job, sym: m.sym, stage: 'données', content: '', thinking: '', t0: Date.now(), stageTimes: {} });
        lastStageAt = Date.now();
        cons.innerHTML = '';
        tokenEl = thinkEl = null;
        put(`<span class="stage">▶ ${esc(m.name)} (${esc(m.sym)}) — ${esc(m.reason ?? '')} · ${m.manual ? 'demande manuelle' : 'boucle des favoris'}</span>\n`);
        R('#live-note').innerHTML = `<a href="${symHref(m.sym)}">${esc(m.name)}</a> · job ${esc(m.job)}`;
        pipe();
        return;
      }
      if (m.job !== state.job) { if (!state.job && m.ev !== 'result') return; }
      if (m.ev === 'stage') {
        if (state.stage && state.stage !== m.stage) state.stageTimes[state.stage] = Date.now() - lastStageAt;
        if (state.stage !== m.stage) lastStageAt = Date.now();
        state.stage = m.stage;
        put(`<span class="stage">■ ${esc(m.stage)}</span>${m.detail ? ` <span class="d">${esc(m.detail)}</span>` : ''}\n`);
        if (m.stage === 'ia') { tokenEl = null; thinkEl = null; }
        pipe();
      } else if (m.ev === 'dossier') {
        put(`<span class="d">  dossier : ${int(m.chars)} caractères ≈ ${int(m.tokens)} jetons · scores : ${Object.entries(m.scores).map(([k, v]) => `${k} ${num(v, 2)}`).join(' · ')}</span>\n`);
        for (const f of m.faits.slice(0, 8)) put(`<span class="${f.sens > 0 ? 's' : f.sens < 0 ? 'n' : 'd'}">  ${f.sens > 0 ? '+' : f.sens < 0 ? '−' : '='} ${esc(f.texte)}</span>\n`);
      } else if (m.ev === 'thinking') {
        if (!thinkEl) { put('<span class="think"></span>'); thinkEl = cons.lastElementChild; }
        state.thinking += m.text;
        thinkEl.textContent = state.thinking;
      } else if (m.ev === 'token') {
        if (!tokenEl) { put('<span class="cur"></span>'); tokenEl = cons.lastElementChild; }
        state.content += m.text;
        tokenEl.innerHTML = colorJson(state.content);
        const atBottom = cons.scrollTop + cons.clientHeight >= cons.scrollHeight - 60;
        if (atBottom) cons.scrollTop = cons.scrollHeight;
      } else if (m.ev === 'result') {
        if (state.stage) state.stageTimes[state.stage] = Date.now() - lastStageAt;
        state.stage = 'décision';
        tokenEl?.classList.remove('cur');
        const g = m.signal;
        put(`\n<span class="stage">✔ ${esc(DECISION[g.decision]?.[0] ?? g.decision)} · confiance ${Math.round(g.confidence * 100)} % · ${dur(g.timings.totalMs)}${g.simulated ? ' · réponse simulée' : ''}</span>\n`);
        pipe();
        showSignal(g);
        loadHist();
        loadRel();
        state.job = null;
      } else if (m.ev === 'loop') {
        tokenEl = null;
        thinkEl = null;
        put(`\n<span class="n">⟲ anti-boucle (${m.kind === 'thinking' ? 'réflexion' : 'réponse'}) : ${esc(m.reason)} → ${esc(m.action)}</span>\n`);
      } else if (m.ev === 'error') {
        put(m.wait ? `<span class="n">⏳ ${esc(m.error)} — l'analyse se fera dès que les données seront là</span>\n` : `<span class="n">✖ erreur : ${esc(m.error)}</span>\n`);
        state.job = null;
      }
    };

    // ---------------------------------------------------------------- résultat
    const showSignal = (g) => {
      state.plots.forEach((p) => p.destroy());
      state.plots = [];
      const tk = S.tick(g.sym), P = (v) => price(v, tk), d = DECISION[g.decision] ?? [g.decision, 'hold'];
      R('#res-note').innerHTML = `<a href="${symHref(g.sym)}">${esc(g.name)}</a> · ${dateTime(g.at)} · ${esc(g.id)}`;
      const box = R('#result');
      box.innerHTML = `<div class="box-body stack">
        <div class="verdict"><span class="badge ${d[1]}">${d[0]}</span>
          <div class="grow"><div class="row small muted">confiance ${Math.round(g.confidence * 100)} % · horizon ${esc(g.horizon)} · cours à l'analyse ${P(g.price)} ${esc(g.ccy)} · ${g.manual ? 'demande manuelle' : 'favori'} (${esc(g.reason)})</div>${meter(g.confidence)}</div>
          ${g.simulated ? '<span class="chip sim">réponse simulée</span>' : `<span class="chip ok">${esc(g.llm?.model ?? '')}</span>`}
          ${g.llmDecision && g.llmDecision !== g.decision ? `<span class="chip warn">modèle : ${esc(DECISION[g.llmDecision]?.[0] ?? g.llmDecision)} → ajusté par les garde-fous</span>` : ''}</div>
        ${g.summary ? `<p style="font-size:12.5px">${esc(g.summary)}</p>` : ''}
        <div class="cols cols-2">
          <div><h4>Plan</h4><table class="kv">${g.entry && g.decision !== 'HOLD' ? `<tr><th>Zone d'entrée</th><td>${P(g.entry.low)} – ${P(g.entry.high)}</td></tr><tr><th>Stop (invalidation)</th><td class="down">${P(g.stop)}</td></tr><tr><th>Objectifs</th><td class="up">${(g.targets ?? []).map(P).join(' · ')}</td></tr><tr><th>Gain / risque</th><td>${g.rewardRisk ? num(g.rewardRisk, 2) : '—'}</td></tr><tr><th>Taille</th><td>${g.sizeFraction ? `${Math.round(g.sizeFraction * 100)} % du risque maximal` : '—'}</td></tr>` : '<tr><td class="muted" colspan="2" style="font-weight:normal">Pas de position conseillée (attente).</td></tr>'}
            <tr><th>Invalidation</th><td class="help">${esc(g.invalidation)}</td></tr></table>
            <h4 style="margin-top:8px">Scénarios</h4>${(g.scenarios ?? []).map((s) => `<div class="scen"><b class="${s.name === 'HAUSSIER' ? 'up' : s.name === 'BAISSIER' ? 'down' : ''}">${esc(s.name.toLowerCase())}</b>${meter(s.probability, s.name === 'BAISSIER' ? 'red' : s.name === 'HAUSSIER' ? '' : 'blue')}<span class="r">${Math.round(s.probability * 100)} %</span><span class="r">${P(s.target)}</span></div>${s.description ? `<div class="small muted" style="margin:-2px 0 4px 96px">${esc(s.description)}</div>` : ''}`).join('') || '<div class="small muted">Scénarios non fournis par le modèle.</div>'}
          </div>
          <div><h4>Facteurs clés</h4><ul class="factors" style="padding-left:0">${(g.keyFactors ?? []).map((k) => `<li class="${k.impact === 'POSITIF' ? 'pos' : k.impact === 'NEGATIF' ? 'neg' : 'neu'}">${esc(k.factor)} <small class="muted">poids ${k.weight}</small></li>`).join('')}</ul>
            <h4>Risques</h4><ul class="why">${(g.risks ?? []).map((r) => `<li>${esc(r)}</li>`).join('')}</ul>
            <table class="kv"><tr><th>Actualités</th><td>${g.news ? `${num(g.news.score, 2)} (conf. ${num(g.news.confidence, 2)})` : '—'}</td></tr><tr><td colspan="2" class="help">${esc(g.news?.summary ?? '')}</td></tr>
              <tr><th>Marché</th><td>${g.market ? `biais ${num(g.market.bias, 2)} · ${esc(g.market.regime)}` : '—'}</td></tr><tr><td colspan="2" class="help">${esc(g.market?.summary ?? '')}</td></tr>
              <tr><th>Calculs vs IA</th><td><span class="chip ${g.quantVsAi === 'accord' ? 'ok' : g.quantVsAi === 'désaccord' ? 'ko' : 'warn'}">${esc(g.quantVsAi)}</span> score quant ${num(g.quantScore, 2)}</td></tr></table></div>
        </div>
        ${g.guardrails?.length ? `<div class="notice"><b>Garde-fous appliqués</b><ul>${g.guardrails.map((x) => `<li>${esc(x)}</li>`).join('')}</ul></div>` : ''}
        ${readingNotes(g)}
        ${g.mc ? `<div class="cols cols-2"><div><h4>Monte Carlo (${int(g.mc.paths)} trajectoires, ${g.mc.horizon} séances, GARCH)</h4><canvas class="plot" id="res-fan"></canvas></div>
          <div><h4>&nbsp;</h4><table class="kv"><tr><th>Objectif ${P(g.mc.up)} avant stop</th><td class="up">${pct(g.mc.pTarget * 100, 2, false)} <small class="muted">± ${num(g.mc.se * 100, 2)}</small></td></tr><tr><th>Stop ${P(g.mc.down)} avant objectif</th><td class="down">${pct(g.mc.pStop * 100, 2, false)}</td></tr><tr><th>Hausse à l'horizon</th><td>${pct(g.mc.pUp * 100, 2, false)}</td></tr>
            <tr><th>Moteurs</th><td>${(g.mc.split ?? []).map((s) => `${esc(s.backend)} ${int(s.paths)} (${s.ms} ms)`).join(' + ')}</td></tr><tr><th>Durée</th><td>${dur(g.mc.ms)}</td></tr>
            ${g.mc.q ? Object.entries(g.mc.q).filter(([k]) => ['0.01', '0.05', '0.5', '0.95', '0.99'].includes(k)).map(([k, v]) => `<tr><th>Quantile ${Math.round(Number(k) * 100)} %</th><td>${P(v.price)} <small class="${cls(v.ret)}">${pct(v.ret * 100, 2)}</small></td></tr>`).join('') : ''}</table></div></div>` : ''}
        ${g.backtests?.length ? `<h4>Backtests walk-forward (hors échantillon)</h4><table class="tbl compact"><thead><tr><th>Stratégie</th><th class="r">Sharpe</th><th class="r">Rendement</th><th class="r">Perte max</th><th class="r">Transactions</th><th class="r">Robustesse</th></tr></thead><tbody>${g.backtests.map((b) => `<tr><td>${esc(b.name)}</td><td class="r ${cls(b.sharpe)}">${num(b.sharpe, 2)}</td><td class="r ${cls(b.ret)}">${pct(b.ret * 100, 1)}</td><td class="r down">${pct(b.maxDD * 100, 1)}</td><td class="r">${b.trades}</td><td class="r">${num(b.robustness, 2)}</td></tr>`).join('')}</tbody></table>` : ''}
        <h4>Temps et ressources</h4><div class="row wrap-ok small">${[['Monte Carlo', g.timings.mcMs], ['backtests', g.timings.backtestMs], ['dossier', g.timings.dossierMs], ['modèle', g.timings.llmMs], ...(g.timings.fixMs > 50 ? [['lecture et complément', g.timings.fixMs]] : []), ['total', g.timings.totalMs]].map(([k, v]) => `<span class="chip">${k} ${dur(v)}</span>`).join(' ')}
          ${g.llm ? `<span class="chip">jetons : ${int(g.llm.promptTokens)} lus · ${int(g.llm.outputTokens)} écrits${g.llm.tokPerSec ? ` · ${num(g.llm.tokPerSec, 1)} jetons/s` : ''}</span>` : ''}<span class="chip">dossier ${int(g.dossierChars)} car.</span></div>
        <details><summary>Faits saillants transmis (${(g.faits ?? []).length})</summary><ul class="factors" style="padding-left:0">${(g.faits ?? []).map((f) => `<li class="${f.sens > 0 ? 'pos' : f.sens < 0 ? 'neg' : 'neu'}">${esc(f.texte)}</li>`).join('')}</ul></details>
        <details><summary>Réponse brute du modèle (JSON)</summary><pre class="console" id="res-raw"></pre></details>
      </div>`;
      if (g.mc?.fan) {
        const f = g.mc.fan, xs = [0, ...f.map((x) => x.step)];
        const at = (k) => [g.price, ...f.map((x) => x[k])];
        state.plots.push(new Plot(box.querySelector('#res-fan'), { height: 210, xs, xFormat: (x) => `J+${num(x, 0)}`, yFormat: (v) => price(v, tk),
          series: [{ type: 'band', lo: at('q5'), hi: at('q95'), name: '5-95 %', color: '#1f6fd1', alpha: 0.12 }, { type: 'band', lo: at('q25'), hi: at('q75'), name: '25-75 %', color: '#1f6fd1', alpha: 0.25 }, { type: 'line', data: at('q50'), name: 'médiane', color: '#1f6fd1' },
            { type: 'hline', y: g.mc.up, color: '#1e9e55', label: 'objectif' }, { type: 'hline', y: g.mc.down, color: '#d64541', label: 'stop' }, { type: 'hline', y: g.price, color: '#8a95a3' }] }));
      }
      get(`/api/ai/signal/${encodeURIComponent(g.id)}`).then((full) => { const r = box.querySelector('#res-raw'); if (r) r.innerHTML = colorJson(full.raw ?? ''); }).catch(() => {});
    };

    // ---------------------------------------------------------------- historique, fiabilité, réglages
    const loadHist = async () => {
      const list = await get('/api/ai/signals?limit=200');
      setHtml(R('#ai-hist'), `<thead><tr><th>Quand</th><th>Valeur</th><th>Décision</th><th class="r">Conf.</th><th>Issue</th></tr></thead><tbody>${list.map((g) => `<tr data-id="${esc(g.id)}" style="cursor:pointer"><td class="small">${ago(g.at)}</td><td><b>${esc(S.info(g.sym)?.code ?? g.sym)}</b>${g.simulated ? ' <span class="chip sim">sim.</span>' : ''}</td><td>${decisionChip(g.decision)}</td><td class="r">${Math.round(g.confidence * 100)} %</td><td>${g.outcome ? `<span class="chip ${g.outcome === 'objectif' ? 'ok' : g.outcome === 'stop' ? 'ko' : ''}">${esc(g.outcome)}</span>` : '<span class="small muted">suivi</span>'}</td></tr>`).join('') || '<tr class="empty"><td colspan="5">Aucune décision</td></tr>'}</tbody>`);
      return list;
    };
    on(R('#ai-hist'), 'click', 'tr[data-id]', async (e, tr) => { showSignal(await get(`/api/ai/signal/${encodeURIComponent(tr.dataset.id)}`)); window.history.replaceState(null, '', `#/ia/${encodeURIComponent(tr.dataset.id)}`); });
    const loadRel = async () => {
      const r = await get('/api/ai/reliability'), hit = (s) => (s.n ? `${Math.round((s.objectif / s.n) * 100)} %` : '—');
      setHtml(R('#ai-rel'), `<table class="kv"><tr><th>Décisions</th><td>${r.total}</td></tr><tr><th>Avec plan suivi</th><td>${r.suivis}</td></tr><tr><th>Clôturées</th><td>${r.clos} <small class="muted">(objectif ${r.global.objectif} · stop ${r.global.stop} · expirées ${r.global.expire})</small></td></tr>
        <tr><th>Taux de réussite</th><td>${hit(r.global)}</td></tr><tr><th>Rendement moyen</th><td>${r.global.avgReturn !== null ? pct(r.global.avgReturn * 100, 2) : '—'}</td></tr></table>
        <table class="tbl compact"><thead><tr><th>Confiance</th><th class="r">Clos</th><th>Réussite</th></tr></thead><tbody>${r.parConfiance.map((b) => `<tr><td>${Math.round(b.de * 100)}–${Math.round(b.a * 100)} %</td><td class="r">${b.n}</td><td>${b.n ? `${meter(b.objectif / b.n)} ${hit(b)}` : '<span class="muted small">pas encore</span>'}</td></tr>`).join('')}</tbody></table>
        <div class="box-foot">${r.dataMode === 'real'
          ? 'Données réelles : chaque décision d\'achat/vente est suivie sur les vrais cours (plus hauts / plus bas des séances suivantes) jusqu\'à son 1er objectif, son stop, ou la fin de son horizon (intraday 8 h, swing ≈ horizon × 1,45 jour, position 30 jours). Seules les décisions prises sur données réelles comptent ici.'
          : 'Démonstration : une décision d\'achat/vente est suivie jusqu\'à son 1er objectif, son stop, ou 3 h de marché simulé.'}
          Réponses du modèle : ${hit(r.reelsVsSimules.reels)} · réponses simulées (sans Ollama) : ${hit(r.reelsVsSimules.simules)}. Aucune IA ne prédit le marché à 100 % : ces chiffres mesurent la fiabilité réelle.</div>`);
    };
    const renderSettings = () => {
      const a = S.settings.ai, models = (S.ai.ollama?.models ?? []).filter((m) => !/embed|bge|nomic|minilm/i.test(m.name)).map((m) => m.name);
      const thinkTxt = a.think === true ? 'activée' : a.think ? `niveau « ${a.think} »` : 'désactivée';
      R('#ai-set').innerHTML = `<label class="f">Modèle des analyses<select id="ai-model"><option value="" ${a.model ? '' : 'selected'}>automatique${!a.model && S.ai.model ? ` (${esc(S.ai.model)})` : ''}</option>${[...new Set([...(a.model ? [a.model] : []), ...models])].map((m) => `<option value="${esc(m)}" ${m === a.model ? 'selected' : ''}>${esc(m)}</option>`).join('')}</select></label>
        <table class="kv"><tr><th>Température</th><td>${num(a.temperature, 2)}</td></tr><tr><th>Réflexion</th><td>${esc(thinkTxt)}</td></tr><tr><th>Contexte</th><td>${int(a.numCtx)} jetons</td></tr><tr><th>Réponse max.</th><td>${int(a.numPredict ?? 2500)} jetons</td></tr>
          <tr><th>Maintien en mémoire</th><td>${esc(String(a.keepAlive ?? '30m'))}</td></tr><tr><th>Horizon Monte Carlo</th><td>${a.horizonDays} séances</td></tr><tr><th>Trajectoires</th><td>${a.mcPaths ? int(a.mcPaths) : 'selon le niveau de calcul'}</td></tr></table>
        <a class="btn btn-small" href="#/reglages">Tous les réglages du modèle →</a><div class="help-text">Capacités de chaque modèle, test de vitesse, téléchargement et création du modèle « bourso » : page Réglages.</div>`;
      R('#ai-model').onchange = async (e) => { await S.saveSettings({ ai: { model: e.target.value || null } }); toast('Modèle des analyses', esc(e.target.value || 'automatique'), 'ok', 1500); };
    };
    get('/api/ai/prompts').then((p) => { R('#ai-prompt').textContent = p.analyste; R('#ai-schema').textContent = JSON.stringify(p.schema, null, 1); });

    renderQueue();
    renderOllama();
    renderSettings();
    pipe();
    const list = await loadHist();
    loadRel();
    const want = ctx.params[0];
    const first = want ? await get(`/api/ai/signal/${encodeURIComponent(want)}`).catch(() => null) : list[0] ? await get(`/api/ai/signal/${encodeURIComponent(list[0].id)}`) : null;
    if (first) showSignal(first);
    if (S.ai.queue?.running) R('#live-note').textContent = `${S.ai.queue.running.name} en cours (${S.ai.queue.running.stage}) — la suite s'affiche ici`;
    const offs = [S.on('ai', onAi), S.on('settings', renderSettings)];
    const t = setInterval(() => { renderOllama(); renderQueue(); }, 5000);
    return {
      async update(c) { if (c.params[0]) { const g = await get(`/api/ai/signal/${encodeURIComponent(c.params[0])}`).catch(() => null); if (g) showSignal(g); } },
      unmount() { offs.forEach((f) => f()); clearInterval(t); state.plots.forEach((p) => p.destroy()); },
    };
  },
};
void [el, tabs, nameCell];

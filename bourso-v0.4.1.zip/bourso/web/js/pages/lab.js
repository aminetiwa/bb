// ============================================================================
//  BOURSO :: pages/lab.js — LABO QUANT : les calculs lourds, à la demande, sur n'importe quelle
//  valeur. Monte Carlo GPU + CPU natif (avec contrôle croisé des mêmes trajectoires), balayages
//  massifs de stratégies (vérification exacte en double précision), walk-forward hors
//  échantillon, régimes de Markov (HMM), cycles (FFT), statistiques, corrélations et test de
//  charge « Fondre les serveurs » (GPU + CPU + workers simultanément).
// ============================================================================
import { S, prefs } from '../core/store.js';
import { get, post } from '../core/api.js';
import { live } from '../core/live.js';
import { $, el, on, setHtml, tabs, toast, meter } from '../core/dom.js';
import { esc, num, int, pct, price, dur, rate, cls, ymd, big, sci } from '../core/fmt.js';
import { symHref } from '../core/ui.js';
import { Plot, HeatGrid, histogram, PALETTE } from '../widgets/plot.js';

const TABS = [['mc', 'Monte Carlo'], ['sweep', 'Balayage de stratégies'], ['wf', 'Walk-forward'], ['hmm', 'Régimes (Markov)'], ['fft', 'Cycles (FFT)'], ['analog', 'Analogues historiques'], ['stats', 'Statistiques'], ['corr', 'Corrélations'], ['stress', 'Fondre les serveurs']];

export default {
  title: 'Labo quant',
  async mount(root, ctx) {
    root.innerHTML = `<div class="page-title"><h1>Labo quant</h1><span class="sub">calculs exacts, dosés entre GPU, CPU natif multi-cœurs et workers · lance n'importe quelle étude sur n'importe quelle valeur</span></div>
      <section class="box ov"><div class="form" style="position:relative;border-bottom:1px solid var(--border-soft)"><b>Valeur étudiée :</b> <a id="lab-sym" class="bold"></a>
        <input type="search" id="lab-q" placeholder="changer de valeur…" style="width:260px" autocomplete="off"><div class="suggest hidden" id="lab-sug" style="top:36px;left:120px;width:460px"></div><span class="sp"></span><span class="small muted" id="lab-engines"></span></div>
        <div id="lab-tabs"></div><div id="lab-body"></div></section>`;
    const R = (s) => root.querySelector(s);
    const ctxLab = { sym: S.lastSym, plots: [] };
    let cur = prefs.get('lab.tab', 'mc');
    if (TABS.some(([k]) => k === ctx.params[0])) cur = ctx.params[0];
    if (ctx.query.get('sym') && S.info(ctx.query.get('sym'))) ctxLab.sym = ctx.query.get('sym');

    const setSym = (sym) => {
      ctxLab.sym = sym;
      const a = R('#lab-sym');
      a.textContent = `${S.name(sym)} (${S.info(sym)?.code} · ${S.info(sym)?.ex})`;
      a.href = symHref(sym);
    };
    setSym(ctxLab.sym);
    const q = R('#lab-q'), sug = R('#lab-sug');
    let tm = null;
    q.addEventListener('input', () => {
      clearTimeout(tm);
      tm = setTimeout(async () => {
        const v = q.value.trim();
        if (!v) { sug.classList.add('hidden'); return; }
        const r = await get(`/api/search?q=${encodeURIComponent(v)}&limit=10`);
        sug.innerHTML = r.map((x) => `<a href="#" data-s="${esc(x.sym)}"><span class="code">${esc(x.code)}</span><span>${esc(x.name)} <span class="where">${esc(x.ex)}</span></span><span>${price(x.last, S.tick(x.sym))}</span><span></span></a>`).join('');
        sug.classList.remove('hidden');
      }, 120);
    });
    on(sug, 'click', '[data-s]', (e, a) => { e.preventDefault(); setSym(a.dataset.s); q.value = ''; sug.classList.add('hidden'); show(cur); });

    get('/api/system').then((s) => {
      const c = s.compute;
      R('#lab-engines').innerHTML = `GPU : <b>${c.gpu.ok ? esc(`${c.gpu.vendor} ${c.gpu.description}`) : 'non utilisé'}</b> · CPU natif : <b>${c.native.ok ? `${c.cpu.cores} cœurs` : 'absent (workers JS)'}</b> · ${c.pool.size} workers · niveau <b>${esc(c.levels[c.level])}</b> · <a href="#/systeme">régler</a>`;
    });

    let inst = null;
    const show = (id) => {
      cur = id;
      prefs.set('lab.tab', id);
      inst?.destroy?.();
      ctxLab.plots.forEach((p) => p.destroy());
      ctxLab.plots = [];
      const body = R('#lab-body');
      body.innerHTML = '';
      inst = { mc: tabMc, sweep: tabSweep, wf: tabWf, hmm: tabHmm, fft: tabFft, analog: tabAnalog, stats: tabStats, corr: tabCorr, stress: tabStress }[id](body, ctxLab);
      window.history.replaceState(null, '', `#/labo/${id}`);
    };
    tabs(R('#lab-tabs'), TABS.map(([id, label]) => ({ id, label })), show, cur);
    show(cur);
    return { unmount() { inst?.destroy?.(); ctxLab.plots.forEach((p) => p.destroy()); } };
  },
};

const busy = (btn, on2, label = 'Calcul…') => {
  btn.disabled = on2;
  if (on2) { btn.dataset.l = btn.textContent; btn.textContent = label; } else if (btn.dataset.l) btn.textContent = btn.dataset.l;
};
const field = (form, k) => form.querySelector(`[data-k="${k}"]`);

// ======================================================================= Monte Carlo
function tabMc(body, L) {
  const st = prefs.get('lab.mc', { model: 'garch', steps: 20, paths: 1000000, upPct: 5, downPct: 3, verify: true, mode: 'auto', window: 756, nu: 5, block: 5 });
  body.innerHTML = `<div class="form" id="mc-f">
    <label class="f">Modèle<select data-k="model"><option value="garch">GARCH(1,1) gaussien</option><option value="garch_t">GARCH(1,1) Student-t</option><option value="bootstrap">Bootstrap par blocs (historique)</option></select></label>
    <label class="f">Horizon (séances)<input type="number" data-k="steps" min="1" max="750"></label><label class="f">Trajectoires<input type="number" data-k="paths" min="1000" step="100000" style="width:120px"></label>
    <label class="f">Objectif (+ %)<input type="number" data-k="upPct" step="0.5" min="0"></label><label class="f">Stop (− %)<input type="number" data-k="downPct" step="0.5" min="0"></label>
    <label class="f">Historique (séances)<input type="number" data-k="window" min="60" max="1259"></label><label class="f" data-for="garch_t">ν (Student)<input type="number" data-k="nu" min="2.5" max="60" step="0.5" style="width:70px"></label><label class="f" data-for="bootstrap">Bloc (bootstrap)<input type="number" data-k="block" min="1" max="60" style="width:70px"></label>
    <label class="f">Moteur<select data-k="mode"><option value="auto">dosé GPU + CPU</option><option value="gpu">GPU seul</option><option value="cpu">CPU seul</option></select></label>
    <label class="chk"><input type="checkbox" data-k="verify"> contrôle croisé GPU/CPU</label><button class="btn primary" id="mc-go">Simuler</button></div><div id="mc-out"><div class="empty">Paramètre la simulation puis « Simuler ».</div></div>`;
  const f = $('#mc-f', body);
  for (const [k, v] of Object.entries(st)) { const i = field(f, k); if (i) { if (i.type === 'checkbox') i.checked = v; else i.value = v; } }
  const showModel = () => { for (const l of f.querySelectorAll('[data-for]')) l.style.display = l.dataset.for === field(f, 'model').value ? '' : 'none'; };
  field(f, 'model').addEventListener('change', showModel);
  showModel();
  $('#mc-go', body).onclick = async () => {
    for (const k of Object.keys(st)) { const i = field(f, k); if (i) st[k] = i.type === 'checkbox' ? i.checked : i.type === 'number' ? Number(i.value) : i.value; }
    prefs.set('lab.mc', st);
    const btn = $('#mc-go', body);
    busy(btn, true, 'Simulation…');
    try {
      const r = await post('/api/lab/montecarlo', { sym: L.sym, ...st });
      renderMc(body, L, r);
    } catch (e) { toast('Monte Carlo', esc(e.message), 'ko'); } finally { busy(btn, false); }
  };
}

function renderMc(body, L, r) {
  L.plots.forEach((p) => p.destroy());
  L.plots = [];
  const s = r.summary, tk = S.tick(r.sym), P = (v) => price(v, tk), ci = (x) => `${pct((x.p - 1.96 * x.se) * 100, 2, false)} – ${pct((x.p + 1.96 * x.se) * 100, 2, false)}`;
  const v = r.verify, steps = s.steps;
  $('#mc-out', body).innerHTML = `<div class="box-body"><div class="kpis">
      <div class="kpi"><span>Trajectoires × pas</span><b>${big(r.pathSteps)}</b><small>${int(s.paths)} × ${steps}</small></div><div class="kpi"><span>Durée</span><b>${dur(r.wallMs)}</b><small>${rate(r.pathSteps / (r.wallMs / 1000), ' pas/s')}</small></div>
      <div class="kpi"><span>Objectif ${P(r.up)} avant stop</span><b class="up">${pct(s.pTarget.p * 100, 2, false)}</b><small>IC 95 % ${ci(s.pTarget)}</small></div><div class="kpi"><span>Stop ${P(r.down)} avant objectif</span><b class="down">${pct(s.pStop.p * 100, 2, false)}</b><small>IC 95 % ${ci(s.pStop)}</small></div>
      <div class="kpi"><span>Ni l'un ni l'autre</span><b>${pct(s.pNone.p * 100, 2, false)}</b><small>à J+${steps}</small></div><div class="kpi"><span>Hausse à l'horizon</span><b>${pct(s.pUp.p * 100, 2, false)}</b><small>± ${num(s.pUp.se * 100, 3)} pt</small></div>
      <div class="kpi"><span>VaR 95 % (horizon)</span><b class="down">${pct(s.var95 * 100, 2, false)}</b><small>ES 95 % ${pct(s.es95 * 100, 2, false)}</small></div><div class="kpi"><span>Prix espéré</span><b>${P(s.expectedPrice)}</b><small>rendement moyen ${pct(s.meanReturn * 100, 2)}</small></div></div>
    <div class="cols cols-2" style="margin-top:10px"><div><h4>Éventail des prix (quantiles 5–95 %)</h4><canvas class="plot" id="mc-fan"></canvas></div><div><h4>Distribution du prix à J+${steps}</h4><canvas class="plot" id="mc-hist"></canvas></div></div>
    <div class="cols cols-2" style="margin-top:8px"><div><h4>Quantiles du prix final</h4><table class="tbl compact"><thead><tr><th>Quantile</th><th class="r">Prix</th><th class="r">Rendement</th></tr></thead><tbody>${Object.entries(s.quantiles).map(([k, x]) => `<tr><td>${num(Number(k) * 100, Number(k) * 100 % 1 ? 1 : 0)} %</td><td class="r">${P(x.price)}</td><td class="r ${cls(x.ret)}">${pct(x.ret * 100, 2)}</td></tr>`).join('')}</tbody></table>
      <p class="help-text">Résolution de l'histogramme : ${num(s.resolution * 1e4, 2)} pb de rendement log. Erreur standard d'une probabilité : √(p(1−p)/N).</p></div>
      <div><h4>Moteurs de calcul</h4><table class="tbl compact"><thead><tr><th>Moteur</th><th class="r">Trajectoires</th><th class="r">Durée</th><th class="r">Débit</th><th class="r">Fils</th></tr></thead><tbody>${r.split.map((x) => `<tr><td><b>${esc(x.backend)}</b></td><td class="r">${int(x.paths)}</td><td class="r">${dur(x.ms)}</td><td class="r">${rate((x.paths * steps) / (x.ms / 1000), ' pas/s')}</td><td class="r">${x.threads ?? '—'}</td></tr>`).join('')}</tbody></table>
      <h4 style="margin-top:8px">Modèle</h4><table class="kv">${r.model.kind === 'bootstrap' ? `<tr><th>Bootstrap</th><td>blocs de ${r.model.block} séances sur ${r.model.window} séances</td></tr>` : `<tr><th>ω · α · β</th><td>${sci(r.model.omega, 3)} · ${num(r.model.alpha, 4)} · ${num(r.model.beta, 4)}</td></tr><tr><th>Vol. de départ (annualisée)</th><td>${pct(Math.sqrt(r.model.h0 * 252) * 100, 1, false)}</td></tr><tr><th>Vol. de long terme</th><td>${pct(Math.sqrt(r.model.uncondVar * 252) * 100, 1, false)}</td></tr>${r.model.nu ? `<tr><th>ν (Student)</th><td>${r.model.nu}</td></tr>` : ''}`}<tr><th>Graine</th><td>${r.seed}</td></tr></table>
      ${v ? (v.available ? `<h4 style="margin-top:8px">Contrôle croisé GPU / CPU (mêmes ${int(v.paths)} trajectoires)</h4><table class="kv"><tr><th>Objectif touché</th><td>GPU ${int(v.gpu.hitUp)} · CPU ${int(v.cpu.hitUp)}</td></tr><tr><th>Stop touché</th><td>GPU ${int(v.gpu.hitDown)} · CPU ${int(v.cpu.hitDown)}</td></tr><tr><th>Écart max (trajectoires)</th><td>${int(v.maxDiffPaths)} ${v.maxDiffPaths === 0 ? '<span class="chip ok">identiques</span>' : '<span class="chip warn">écart float32</span>'}</td></tr><tr><th>Écart d'histogramme (L1)</th><td>${int(v.histogramL1)}</td></tr><tr><th>Écart moyen de rendement</th><td>${sci(v.meanDiff, 2)}</td></tr></table>` : '<div class="notice small">Contrôle croisé indisponible : pas de GPU actif (tout a été calculé en double précision sur le CPU).</div>') : ''}</div></div></div>`;
  const fan = s.fan, xs = [0, ...fan.map((x) => x.step)], at = (k) => [r.s0, ...fan.map((x) => x[k])];
  L.plots.push(new Plot($('#mc-fan', body), { height: 240, xs, xFormat: (x) => `J+${num(x, 0)}`, yFormat: P, series: [{ type: 'band', lo: at('q5'), hi: at('q95'), name: '5–95 %', color: '#1f6fd1', alpha: 0.12 }, { type: 'band', lo: at('q25'), hi: at('q75'), name: '25–75 %', color: '#1f6fd1', alpha: 0.26 }, { type: 'line', data: at('q50'), name: 'médiane', color: '#1f6fd1' }, ...(r.up ? [{ type: 'hline', y: r.up, color: '#1e9e55', label: 'objectif' }] : []), ...(r.down ? [{ type: 'hline', y: r.down, color: '#d64541', label: 'stop' }] : []), { type: 'hline', y: r.s0, color: '#8a95a3' }] }));
  const h = s.histogram, w = (h.hi - h.lo) / h.counts.length;
  const px = h.counts.map((_, i) => r.s0 * Math.exp(h.lo + (i + 0.5) * w));
  const nz = h.counts.map((c, i) => [c, i]).filter(([c]) => c > 0), a = nz[0]?.[1] ?? 0, b = nz.at(-1)?.[1] ?? h.counts.length - 1;
  L.plots.push(new Plot($('#mc-hist', body), { height: 240, xs: px.slice(a, b + 1), xFormat: P, series: [{ type: 'bars', data: h.counts.slice(a, b + 1).map((c) => (c / s.paths) * 100), name: '% des trajectoires', colorOf: (vv, i) => (px[a + i] >= r.s0 ? 'rgba(30,158,85,0.6)' : 'rgba(214,69,65,0.6)'), widthRatio: 0.95 }, { type: 'vline', x: r.s0, color: '#8a95a3', label: 'cours' }], yFormat: (vv) => `${num(vv, 2)} %` }));
}

// ======================================================================= balayage massif
function tabSweep(body, L) {
  const st = prefs.get('lab.sweep', { strategy: 'ema_cross', scale: 1, years: 5, costBps: 5, short: false, mode: 'auto' });
  const strategies = S.meta.strategies.filter((x) => x.sweep);
  body.innerHTML = `<div class="form" id="sw-f"><label class="f">Stratégie<select data-k="strategy">${strategies.map((x) => `<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select></label>
    <label class="f">Taille de la grille (×)<input type="number" data-k="scale" min="0.5" max="8" step="0.5"></label><label class="f">Historique (années)<input type="number" data-k="years" min="1" max="5"></label>
    <label class="f">Coûts (pb par transaction)<input type="number" data-k="costBps" min="0" max="200"></label><label class="chk"><input type="checkbox" data-k="short"> vente à découvert</label>
    <label class="f">Moteur<select data-k="mode"><option value="auto">dosé GPU + CPU</option><option value="gpu">GPU seul</option><option value="cpu">CPU seul</option></select></label><button class="btn primary" id="sw-go">Lancer le balayage</button><span class="help-text" id="sw-grid"></span></div><div id="sw-out"><div class="empty">Teste des milliers de jeux de paramètres d'un coup.</div></div>`;
  const f = $('#sw-f', body);
  for (const [k, v] of Object.entries(st)) { const i = field(f, k); if (i) { if (i.type === 'checkbox') i.checked = v; else i.value = v; } }
  const gridInfo = async () => {
    const g = await get(`/api/lab/grid?strategy=${field(f, 'strategy').value}&scale=${field(f, 'scale').value}`);
    $('#sw-grid', body).textContent = `${int(g.combos)} combinaisons (${g.keys.join(' × ')})`;
  };
  f.addEventListener('change', gridInfo);
  gridInfo();
  $('#sw-go', body).onclick = async () => {
    for (const k of Object.keys(st)) { const i = field(f, k); st[k] = i.type === 'checkbox' ? i.checked : i.type === 'number' ? Number(i.value) : i.value; }
    prefs.set('lab.sweep', st);
    const btn = $('#sw-go', body);
    busy(btn, true, 'Balayage…');
    try {
      const r = await post('/api/lab/sweep', { sym: L.sym, ...st });
      L.plots.forEach((p) => p.destroy());
      L.plots = [];
      const best = r.top[0];
      $('#sw-out', body).innerHTML = `<div class="box-body"><div class="kpis"><div class="kpi"><span>Combinaisons</span><b>${int(r.combos)}</b><small>× ${int(r.bars)} séances</small></div>
        <div class="kpi"><span>Durée</span><b>${dur(r.wallMs)}</b><small>${rate((r.combos * r.bars) / (r.wallMs / 1000), ' bougies/s')}</small></div>
        <div class="kpi"><span>Meilleur Sharpe</span><b class="${cls(best.sharpe)}">${num(best.sharpe, 3)}</b><small>${esc(Object.entries(best.params).map(([k, v]) => `${k} ${v}`).join(' · '))}</small></div>
        <div class="kpi"><span>Vérification exacte</span><b>${r.verification.verified} meilleures</b><small>écart max ${sci(r.verification.maxSharpeDiff, 1)} (double précision)</small></div>
        <div class="kpi"><span>Moteurs</span><b>${r.split.map((x) => esc(x.backend)).join(' + ')}</b><small>${r.split.map((x) => `${int(x.combos)} en ${dur(x.ms)}`).join(' · ')}</small></div></div>
        ${r.heat ? `<h4 style="margin-top:10px">Carte du ratio de Sharpe : ${esc(r.heat.y)} (lignes) × ${esc(r.heat.x)} (colonnes) — meilleur Sharpe par case</h4><canvas id="sw-heat" style="width:100%"></canvas>` : ''}
        <div class="notice small" style="margin-top:8px">Attention au sur-apprentissage : le meilleur paramètre sur le passé n'est pas une prévision. Préfère une <b>zone</b> stable (couleur homogène) et vérifie avec le walk-forward hors échantillon.</div>
        <h4 style="margin-top:8px">100 meilleures combinaisons</h4><div class="scroll tall"><table class="tbl compact"><thead><tr><th>#</th>${r.keys.map((k) => `<th class="r">${esc(k)}</th>`).join('')}<th class="r">Sharpe</th><th class="r">Sortino</th><th class="r">Rendement</th><th class="r">Annuel</th><th class="r">Perte max</th><th class="r">Transactions</th><th class="r">Réussite</th><th class="r">Profit factor</th><th class="r">Exposition</th><th>Calcul</th></tr></thead><tbody>${r.top.map((x, i) => `<tr><td class="muted">${i + 1}</td>${r.keys.map((k) => `<td class="r">${x.params[k]}</td>`).join('')}<td class="r ${cls(x.sharpe)}"><b>${num(x.sharpe, 3)}</b></td><td class="r">${num(x.sortino, 2)}</td><td class="r ${cls(x.totalReturn)}">${pct(x.totalReturn * 100, 1)}</td><td class="r">${pct(x.annReturn * 100, 1)}</td><td class="r down">${pct(x.maxDD * 100, 1)}</td><td class="r">${int(x.trades)}</td><td class="r">${pct(x.winRate * 100, 0, false)}</td><td class="r">${num(x.profitFactor, 2)}</td><td class="r">${pct(x.exposure * 100, 0, false)}</td><td>${x.verified ? '<span class="chip ok">f64 vérifié</span>' : `<span class="chip">${esc(x.engine)}</span>`}</td></tr>`).join('')}</tbody></table></div></div>`;
      if (r.heat) {
        const hz = r.heat, rows = hz.ys.map(String), cols = hz.xs.map(String), vals = hz.ys.map((_, yi) => hz.xs.map((__, xi) => hz.z[yi * hz.xs.length + xi]));
        const mx = Math.max(0.5, ...hz.z.filter((z) => z !== null).map(Math.abs));
        L.plots.push(new HeatGrid($('#sw-heat', body), { rows, cols, values: vals, max: mx, format: (z) => num(z, 3), cell: Math.max(4, Math.min(14, 560 / rows.length)), labelEvery: Math.ceil(rows.length / 30) }));
        L.plots.at(-1).render();
      }
    } catch (e) { toast('Balayage', esc(e.message), 'ko'); } finally { busy(btn, false); }
  };
}

// ======================================================================= walk-forward
function tabWf(body, L) {
  const st = prefs.get('lab.wf', { strategies: ['ema_cross', 'sma_cross', 'rsi_revert', 'boll_revert', 'donchian_break', 'macd_cross', 'supertrend'], folds: 4, costBps: 5, short: false });
  const all = S.meta.strategies.filter((x) => x.id !== 'buy_hold');
  body.innerHTML = `<div class="form" id="wf-f">${all.map((x) => `<label class="chk"><input type="checkbox" data-s="${x.id}" ${st.strategies.includes(x.id) ? 'checked' : ''}> ${esc(x.name)}</label>`).join('')}
    <label class="f">Plis<input type="number" data-k="folds" min="2" max="10"></label><label class="f">Coûts (pb)<input type="number" data-k="costBps" min="0" max="200"></label><label class="chk"><input type="checkbox" data-k="short"> vente à découvert</label><button class="btn primary" id="wf-go">Lancer</button></div>
    <div class="info small" style="margin:0 10px">Principe : pour chaque pli, les paramètres sont choisis sur le passé (dans l'échantillon) puis appliqués sur la période suivante jamais vue (hors échantillon). Seuls les résultats hors échantillon comptent. Exécution à l'ouverture suivante, coûts inclus.</div><div id="wf-out"></div>`;
  const f = $('#wf-f', body);
  field(f, 'folds').value = st.folds;
  field(f, 'costBps').value = st.costBps;
  field(f, 'short').checked = st.short;
  $('#wf-go', body).onclick = async () => {
    st.strategies = [...f.querySelectorAll('[data-s]')].filter((x) => x.checked).map((x) => x.dataset.s);
    st.folds = Number(field(f, 'folds').value);
    st.costBps = Number(field(f, 'costBps').value);
    st.short = field(f, 'short').checked;
    prefs.set('lab.wf', st);
    const btn = $('#wf-go', body);
    busy(btn, true);
    try {
      const r = await post('/api/lab/walkforward', { sym: L.sym, ...st });
      L.plots.forEach((p) => p.destroy());
      L.plots = [];
      const bh = r.buyHold;
      $('#wf-out', body).innerHTML = `<div class="box-body"><table class="tbl"><thead><tr><th>Stratégie</th><th class="r">Sharpe hors éch.</th><th class="r">Sharpe dans l'éch.</th><th class="r">Robustesse</th><th class="r">Rendement</th><th class="r">Perte max</th><th class="r">Transactions</th><th class="r">Combinaisons testées</th><th>Paramètres retenus par pli</th></tr></thead><tbody>
        ${r.results.map((x, i) => `<tr><td><span class="legend-dot" style="background:${PALETTE[i % PALETTE.length]}"></span><b>${esc(x.name)}</b></td><td class="r ${cls(x.oos.sharpe)}"><b>${num(x.oos.sharpe, 2)}</b></td><td class="r">${num(x.isSharpe, 2)}</td><td class="r">${num(x.robustness, 2)}</td><td class="r ${cls(x.oos.totalReturn)}">${pct(x.oos.totalReturn * 100, 1)}</td><td class="r down">${pct(x.oos.maxDD * 100, 1)}</td><td class="r">${int(x.oos.trades)}</td><td class="r">${int(x.combos)}</td><td class="small">${x.chosen.map((c) => esc(Object.values(c.params).join('/'))).join(' → ')}${x.stableParams ? ' <span class="chip ok">stables</span>' : ''}</td></tr>`).join('')}
        <tr class="sel"><td><b>Achat-conservation</b> <small class="muted">même période</small></td><td class="r"><b>${num(bh.sharpe, 2)}</b></td><td></td><td></td><td class="r ${cls(bh.totalReturn)}">${pct(bh.totalReturn * 100, 1)}</td><td class="r down">${pct(bh.maxDD * 100, 1)}</td><td class="r">1</td><td></td><td></td></tr></tbody></table>
        <h4 style="margin-top:10px">Courbes de capital hors échantillon (base 1 au ${ymd(r.dates[0] ?? '')})</h4><canvas class="plot" id="wf-plot"></canvas><p class="help-text">Calcul : ${dur(r.ms)} sur un worker.</p></div>`;
      const xs = r.dates.map((_, i) => i);
      L.plots.push(new Plot($('#wf-plot', body), { height: 280, xs, xFormat: (x) => ymd(r.dates[Math.round(x)] ?? '', false), yFormat: (v) => num(v, 2), series: [...r.results.map((x, i) => ({ type: 'line', data: x.equity, name: S.meta.strategies.find((m) => m.id === x.strategy)?.short ?? x.name, color: PALETTE[i % PALETTE.length] })), { type: 'line', data: r.buyHoldEquity, name: 'Achat-conservation', color: '#8a95a3', dash: [5, 4] }, { type: 'hline', y: 1, color: '#8a95a3' }], tipX: (x, i) => ymd(r.dates[i] ?? '') }));
    } catch (e) { toast('Walk-forward', esc(e.message), 'ko'); } finally { busy(btn, false); }
  };
}

// ======================================================================= régimes de Markov
const STATE_COLORS = { baisse: ['#d64541', '#f28c18'], range: ['#1f6fd1', '#7b4fc9', '#0f8f8f', '#5c6bc0'], hausse: ['#1e9e55', '#9e9d24'] };
/** Couleur de chaque état : rouge(s) en baisse, bleu(s) sans tendance, vert(s) en hausse. */
const stateColors = (states) => {
  const used = { baisse: 0, range: 0, hausse: 0 };
  return states.map((s) => {
    const dir = STATE_COLORS[s.dir] ? s.dir : 'range', list = STATE_COLORS[dir];
    return list[used[dir]++ % list.length];
  });
};
function tabHmm(body, L) {
  const st = prefs.get('lab.hmm2', { K: 0, window: 1000, restarts: 8 });
  body.innerHTML = `<div class="form" id="hm-f"><label class="f">Nombre d'états<select data-k="K"><option value="0">auto (critère BIC)</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></label>
    <label class="f">Historique (séances)<input type="number" data-k="window" min="200" max="1259"></label><label class="f">Redémarrages (EM)<input type="number" data-k="restarts" min="1" max="40"></label><button class="btn primary" id="hm-go">Ajuster le modèle</button>
    <span class="help-text">Markov caché gaussien sur les rendements quotidiens : Baum-Welch régularisé (a priori faibles contre les « états » bâtis sur quelques jours extrêmes), plusieurs départs, chemin de Viterbi. Toujours comparé au modèle à un seul état.</span></div><div id="hm-out"></div>`;
  const f = $('#hm-f', body);
  for (const k of Object.keys(st)) field(f, k).value = st[k];
  $('#hm-go', body).onclick = async () => {
    for (const k of Object.keys(st)) st[k] = Number(field(f, k).value);
    prefs.set('lab.hmm2', st);
    const btn = $('#hm-go', body);
    busy(btn, true);
    try {
      const r = await post('/api/lab/hmm', { sym: L.sym, ...st });
      L.plots.forEach((p) => p.destroy());
      L.plots = [];
      const K = r.states.length, colors = stateColors(r.states), col = (k) => colors[k];
      const cur = r.states[r.current], T = r.T;
      const durTxt = (d) => (d >= T - 0.5 ? `≥ ${int(T)} séances` : `${num(d, 1)} séances`);
      const sel = r.selection ? `<h4>Choix du nombre d'états (BIC : plus petit = meilleur)</h4><table class="tbl compact"><thead><tr><th>États</th><th class="r">Log-vraisemblance</th><th class="r">BIC</th><th></th></tr></thead><tbody>${r.selection.map((x) => `<tr class="${x.K === K ? 'sel' : ''}"><td>${x.K}${x.K === 1 ? ' <small class="muted">(loi normale unique)</small>' : ''}</td><td class="r">${num(x.ll, 1)}</td><td class="r">${num(x.bic, 1)}</td><td>${x.K === K ? '<span class="chip ok">retenu</span>' : ''}${x.rare ? ' <span class="chip warn">état quasi vide</span>' : ''}</td></tr>`).join('')}</tbody></table>` : '';
      $('#hm-out', body).innerHTML = `<div class="box-body">
        <div class="kpis"><div class="kpi"><span>État actuel</span><b style="font-size:13px;line-height:1.3">${r.current + 1}. ${esc(cur.label)}</b><small>probabilité filtrée ${pct(r.filtered[r.current] * 100, 0, false)}</small></div>
          <div class="kpi"><span>Durée moyenne de cet état</span><b>${durTxt(r.expectedDuration)}</b><small>1 / (1 − p<sub>reste</sub>)</small></div>
          <div class="kpi"><span>Régimes significatifs ?</span><b class="${r.regimesSupported ? 'up' : 'down'}">${r.regimesSupported ? 'Oui' : 'Non'}</b><small>BIC ${num(r.bic, 1)} contre ${num(r.baseline.bic, 1)} (1 état)</small></div>
          <div class="kpi"><span>Nombre d'états</span><b>${K}</b><small>${r.auto ? 'choisi par le BIC' : 'imposé'}</small></div>
          <div class="kpi"><span>Calcul</span><b>${dur(r.ms)}</b><small>${r.iterations} itérations EM · départ n° ${r.start + 1}</small></div></div>
        ${r.regimesSupported ? '' : '<div class="notice small" style="margin-top:8px">Le modèle à <b>un seul état</b> (loi normale unique) explique les rendements au moins aussi bien, une fois la complexité pénalisée (BIC) : les états ci-dessous ne sont <b>pas statistiquement distincts</b>. Ne t\'appuie pas sur ce régime ; l\'analyse IA l\'ignore aussi.</div>'}
        <h4 style="margin-top:8px">États (du plus baissier au plus haussier)</h4><div class="scroll"><table class="tbl"><thead><tr><th>État</th><th class="r">Rendement / jour</th><th class="r">Vol. / jour</th><th class="r">Occupation</th><th class="r">Durée moy.</th><th class="r">Proba. actuelle</th><th class="r">Dans 5 j</th><th class="r">Dans 20 j</th></tr></thead><tbody>${r.states.map((s2, k) => `<tr class="${k === r.current ? 'sel' : ''}"><td><span class="legend-dot" style="background:${col(k)}"></span><b>${k + 1}. ${esc(s2.label)}</b>${s2.rare ? ' <span class="chip warn">rare</span>' : ''}</td><td class="r ${cls(s2.mu)}">${pct(s2.mu * 100, 3)}</td><td class="r">${pct(s2.sd * 100, 2, false)}</td><td class="r">${pct(s2.occupancyPosterior * 100, 0, false)}</td><td class="r">${s2.duration >= T - 0.5 ? `≥ ${int(T)}` : num(s2.duration, 1)} j</td><td class="r"><b>${pct(r.filtered[k] * 100, 1, false)}</b></td><td class="r">${pct(r.forecast5[k] * 100, 1, false)}</td><td class="r">${pct(r.forecast20[k] * 100, 1, false)}</td></tr>`).join('')}</tbody></table></div>
          <p class="help-text">Occupation : part du temps passée dans l'état (probabilités lissées). Durée moyenne d'un séjour : 1 / (1 − probabilité d'y rester d'une séance à l'autre).</p>
        <div class="cols cols-2"><div><h4>Matrice de transition (ligne → colonne, par séance)</h4><canvas id="hm-A" style="width:100%"></canvas></div><div>${sel}</div></div>
        <h4 style="margin-top:8px">Cours coloré par état (chemin de Viterbi)</h4><canvas class="plot" id="hm-plot"></canvas></div>`;
      const names = r.states.map((_, k) => `État ${k + 1}`);
      L.plots.push(new HeatGrid($('#hm-A', body), { rows: names, cols: names, values: r.A, max: 1, showValues: true, format: (v) => pct(v * 100, 1, false), color: (v) => `rgba(31,111,209,${0.08 + v * 0.85})`, cell: 34 }));
      L.plots.at(-1).render();
      const pts = r.close.map((c, i) => [i, c, col(r.viterbi[i] ?? 0)]);
      L.plots.push(new Plot($('#hm-plot', body), { height: 260, xs: r.close.map((_, i) => i), xFormat: (x) => ymd(r.dates[Math.round(x)] ?? '', false), series: [{ type: 'line', data: r.close, color: '#8a95a3', width: 1 }, { type: 'scatter', data: pts, r: 2 }], tipX: (x, i) => `${ymd(r.dates[i] ?? '')} · ${r.states[r.viterbi[i]]?.label ?? ''}` }));
    } catch (e) { toast('Régimes', esc(e.message), 'ko'); } finally { busy(btn, false); }
  };
}

// ======================================================================= cycles
function tabFft(body, L) {
  body.innerHTML = `<div class="form" id="ff-f"><label class="f">Historique (séances)<input type="number" data-k="window" value="512" min="128" max="1259"></label><label class="f">Période min.<input type="number" data-k="minPeriod" value="5" min="2"></label><label class="f">Période max.<input type="number" data-k="maxPeriod" value="170" min="10"></label><button class="btn primary" id="ff-go">Analyser</button>
    <span class="help-text">Transformée de Fourier du log-prix détendancé (fenêtre de Hann, zéro-padding ×4), chaque pic testé contre un bruit rouge AR(1) de même autocorrélation (seuil 95 %).</span></div><div id="ff-out"></div>`;
  const f = $('#ff-f', body);
  $('#ff-go', body).onclick = async () => {
    const btn = $('#ff-go', body);
    busy(btn, true);
    try {
      const r = await post('/api/lab/cycles', { sym: L.sym, window: Number(field(f, 'window').value), minPeriod: Number(field(f, 'minPeriod').value), maxPeriod: Number(field(f, 'maxPeriod').value) });
      L.plots.forEach((p) => p.destroy());
      L.plots = [];
      const sig = r.cycles.filter((c) => c.significant), loc = r.cycles.filter((c) => c.significantLocal && !c.significant);
      const chip = (c) => (c.significant ? '<span class="chip ok">significatif</span>' : c.significantLocal ? '<span class="chip warn" title="franchit le seuil ponctuel mais pas le seuil corrigé des tests multiples">local</span>' : '<span class="chip none">bruit</span>');
      $('#ff-out', body).innerHTML = `<div class="box-body"><div class="kpis"><div class="kpi"><span>Cycles significatifs (95 % global)</span><b class="${sig.length ? 'up' : ''}">${sig.length} / ${r.cycles.length}</b><small>${loc.length} de plus au seuil ponctuel</small></div>
          <div class="kpi"><span>Seuils (puissance / bruit)</span><b>${num(r.thresholds.global, 2)}</b><small>global sur ${int(r.tests)} fréquences · ponctuel ${num(r.thresholds.local, 2)}</small></div>
          <div class="kpi"><span>Autocorrélation (lag 1)</span><b>${num(r.rho, 4)}</b><small>du log-prix détendancé</small></div>
          <div class="kpi"><span>Échantillon</span><b>${int(r.n)} séances</b><small>périodes ${num(r.spectrum.period[0], 0)} à ${num(r.spectrum.period.at(-1), 0)} j</small></div></div>
        ${sig.length ? '' : '<div class="notice small" style="margin-top:8px">Aucun pic ne dépasse le seuil global du bruit rouge : le spectre est compatible avec une marche aléatoire. Ces « cycles » ne sont pas exploitables (l\'analyse IA les ignore).</div>'}
        <div class="cols cols-2" style="margin-top:8px"><div><table class="tbl"><thead><tr><th>Période</th><th class="r">Part du spectre</th><th class="r">Puissance / bruit</th><th class="r">Amplitude</th><th>Phase actuelle</th><th class="r">Prochain creux</th><th class="r">Prochain sommet</th></tr></thead><tbody>${r.cycles.map((c) => `<tr><td><b>${num(c.period, 1)} j</b></td><td class="r">${pct(c.share * 100, 1, false)}</td><td class="r">${num(c.redRatio, 2)} ${chip(c)}</td><td class="r">${pct(c.amplitude * 100, 2, false)}</td><td>${esc(c.state)}</td><td class="r">J+${num(c.barsToTrough, 0)}</td><td class="r">J+${num(c.barsToPeak, 0)}</td></tr>`).join('')}</tbody></table>
          <p class="help-text">Part du spectre : puissance du lobe du pic dans la bande étudiée. Puissance / bruit : rapport au spectre d'un bruit rouge AR(1) (χ² à 2 degrés de liberté). « Local » : franchit le seuil ponctuel ${num(r.thresholds.local, 2)}, que ~5 % des fréquences franchissent par hasard ; « significatif » : franchit le seuil corrigé des ${int(r.tests)} tests (${num(r.thresholds.global, 2)}). Les cycles de marché sont instables : indice de timing, pas prévision.</p></div>
        <div><h4>Spectre rapporté au bruit rouge (périodes en échelle log.)</h4><canvas class="plot" id="ff-plot"></canvas></div></div></div>`;
      const sp = r.spectrum, xs = sp.period.map((p) => Math.log(p)), ratio = sp.power.map((v, i) => (sp.red[i] > 0 ? v / sp.red[i] : null));
      L.plots.push(new Plot($('#ff-plot', body), { height: 260, xs, xFormat: (x) => `${num(Math.exp(x), 0)} j`, yFormat: (v) => num(v, 1), zero: true,
        series: [{ type: 'line', data: ratio, name: 'puissance / bruit rouge', color: '#1f6fd1' }, { type: 'hline', y: r.thresholds.local, color: '#f28c18', label: 'ponctuel 95 %' }, { type: 'hline', y: r.thresholds.global, color: '#d64541', label: 'global 95 %' }, { type: 'hline', y: 1, color: '#8a95a3' },
          ...r.cycles.map((c) => ({ type: 'vline', x: Math.log(c.period), color: c.significant ? '#1e9e55' : c.significantLocal ? '#f28c18' : '#c0c6cf', label: `${num(c.period, 0)} j` }))],
        tipX: (x) => `période ${num(Math.exp(x), 1)} séances` }));
    } catch (e) { toast('Cycles', esc(e.message), 'ko'); } finally { busy(btn, false); }
  };
  $('#ff-go', body).click();
}

// ======================================================================= analogues historiques
function tabAnalog(body, L) {
  const st = prefs.get('lab.analog', { k: 30, spacing: 5, horizon: 20 });
  body.innerHTML = `<div class="form" id="an-f"><label class="f">Analogues (k)<input type="number" data-k="k" min="10" max="60"></label><label class="f">Espacement min. (séances)<input type="number" data-k="spacing" min="1" max="30"></label><label class="f">Horizon long (séances)<input type="number" data-k="horizon" min="10" max="60"></label><button class="btn primary" id="an-go">Chercher</button>
    <span class="help-text">Les séances passées dont la situation ressemble le plus à aujourd'hui (8 variables d'état normalisées), et ce qui s'est passé ensuite — comparé à toutes les séances.</span></div><div id="an-out"></div>`;
  const f = $('#an-f', body);
  for (const k of Object.keys(st)) field(f, k).value = st[k];
  $('#an-go', body).onclick = async () => {
    for (const k of Object.keys(st)) st[k] = Number(field(f, k).value);
    prefs.set('lab.analog', st);
    const btn = $('#an-go', body);
    busy(btn, true);
    try {
      const r = await post('/api/lab/analogs', { sym: L.sym, ...st });
      L.plots.forEach((p) => p.destroy());
      L.plots = [];
      const kpi = (h) => `<div class="kpi"><span>À ${h.h} séances (${h.k} cas)</span><b class="${h.significant ? cls(h.z) : ''}">${pct(h.analog.pPos * 100, 0, false)} de hausses</b><small>base ${pct(h.base.pPos * 100, 0, false)} · z = ${num(h.z, 2)} ${h.significant ? '<span class="chip ok">significatif</span>' : '<span class="chip none">hasard possible</span>'}</small></div>
        <div class="kpi"><span>Médiane à ${h.h} séances</span><b class="${cls(h.analog.median)}">${pct(h.analog.median * 100, 2)}</b><small>base ${pct(h.base.median * 100, 2)} · 10–90 % : ${pct(h.analog.q10 * 100, 1)} / ${pct(h.analog.q90 * 100, 1)}</small></div>`;
      const anySig = r.horizons.some((h) => h.significant);
      $('#an-out', body).innerHTML = `<div class="box-body"><div class="kpis">${r.horizons.map(kpi).join('')}<div class="kpi"><span>Candidates</span><b>${int(r.candidates)}</b><small>distance moyenne ${num(r.meanDistance, 2)} · ${dur(r.ms)}</small></div></div>
        ${anySig ? '' : '<div class="notice small" style="margin-top:8px">Aucun écart significatif avec la base : les situations comparables du passé n\'ont pas eu de suite différente de la moyenne. C\'est le cas le plus fréquent — et c\'est une information.</div>'}
        <div class="cols cols-2" style="margin-top:8px"><div><h4>Les ${r.paths.length} analogues les plus proches, espacés d'au moins ${r.spacingLongest} séances (base 100 le jour J)</h4><canvas class="plot" id="an-plot"></canvas></div>
        <div><h4>Analogues les plus proches</h4><table class="tbl compact"><thead><tr><th>Date</th><th class="r">Distance</th>${r.horizons.map((h) => `<th class="r">Ensuite ${h.h} s.</th>`).join('')}</tr></thead><tbody>${r.nearest.map((nb) => `<tr><td>${ymd(nb.date)}</td><td class="r">${num(nb.distance, 2)}</td>${r.horizons.map((h) => `<td class="r ${cls(nb.fwd[h.h])}">${pct(nb.fwd[h.h] * 100, 2)}</td>`).join('')}</tr>`).join('')}</tbody></table>
          <p class="help-text">Variables d'état : ${r.features.map(esc).join(' · ')}. Chaque variable est centrée-réduite sur l'historique ; distance euclidienne. Seules les séances dont l'horizon s'est terminé au moins 20 séances avant aujourd'hui sont candidates (aucune fuite du futur), et pour chaque horizon les analogues retenus sont espacés pour que leurs fenêtres futures ne se recouvrent pas. Test z : proportion de hausses des analogues contre la base, corrigé du recouvrement des fenêtres de la base.</p></div></div></div>`;
      const xs = Array.from({ length: r.back + r.maxH + 1 }, (_, i) => i - r.back);
      const mean = xs.map((_, i) => { const v = r.paths.map((p) => p[i]).filter((x) => x !== null); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null; });
      const cur = xs.map((x, i) => (x <= 0 ? r.current[i] : null));
      L.plots.push(new Plot($('#an-plot', body), { height: 280, xs, xFormat: (x) => (x === 0 ? 'J' : `J${x > 0 ? '+' : ''}${num(x, 0)}`), yFormat: (v) => num(v, 1),
        series: [...r.paths.map((p, i) => ({ type: 'line', data: p, color: PALETTE[i % PALETTE.length], width: 1, alpha: 0.55, name: i === 0 ? 'analogues' : undefined })),
          { type: 'line', data: mean, name: 'moyenne des analogues', color: '#1f2d3d', width: 2, dash: [5, 4] }, { type: 'line', data: cur, name: 'aujourd\'hui', color: '#e07b10', width: 2.5 },
          { type: 'vline', x: 0, color: '#8a95a3', label: 'J' }, { type: 'hline', y: 100, color: '#8a95a3' }] }));
    } catch (e) { toast('Analogues', esc(e.message), 'ko'); } finally { busy(btn, false); }
  };
  $('#an-go', body).click();
}

// ======================================================================= statistiques
function tabStats(body, L) {
  body.innerHTML = '<div class="form"><label class="f">Historique (séances)<input type="number" id="stt-w" value="1260" min="100" max="1260"></label><button class="btn primary" id="stt-go">Calculer</button></div><div id="stt-out"></div>';
  $('#stt-go', body).onclick = async () => {
    const btn = $('#stt-go', body);
    busy(btn, true);
    try {
      const st = await post('/api/lab/stats', { sym: L.sym, window: Number($('#stt-w', body).value) }), m = st.moments, F = (x, d = 3) => num(x, d);
      L.plots.forEach((p) => p.destroy());
      L.plots = [];
      $('#stt-out', body).innerHTML = `<div class="box-body cols cols-2"><table class="kv"><tr><th>Observations</th><td>${st.window}</td></tr><tr><th>Moyenne / jour</th><td>${pct(m.mean * 100, 4)}</td></tr><tr><th>Écart-type / jour</th><td>${pct(m.sd * 100, 3, false)} (${pct(m.sd * Math.sqrt(252) * 100, 1, false)} /an)</td></tr><tr><th>Asymétrie</th><td>${F(m.skew)}</td></tr><tr><th>Kurtosis (excès)</th><td>${F(m.kurt)}</td></tr>
        <tr><th>Jarque-Bera</th><td>${F(st.jb.jb, 1)} · p ${F(st.jb.p, 4)}</td></tr><tr><th>Ljung-Box (10)</th><td>${F(st.ljung.q, 2)} · p ${F(st.ljung.p, 4)}</td></tr><tr><th>Hurst (R/S)</th><td>${F(st.hurst)}</td></tr><tr><th>Ratio de variance (5)</th><td>${F(st.vr.vr)} · z* ${F(st.vr.zStar, 2)}</td></tr>
        <tr><th>ADF (log-prix)</th><td>${st.adf ? `${F(st.adf.stat)} · seuils 1/5/10 % : ${F(st.adf.crit[1])} / ${F(st.adf.crit[5])} / ${F(st.adf.crit[10])} → ${st.adf.stationary ? 'stationnaire' : 'racine unitaire'}` : '—'}</td></tr></table>
        <div><h4>Autocorrélations des rendements</h4><canvas class="plot" id="stt-acf"></canvas></div></div>`;
      const band = 1.96 / Math.sqrt(st.window);
      L.plots.push(new Plot($('#stt-acf', body), { height: 220, xs: st.acf.map((_, i) => i + 1), series: [{ type: 'bars', data: Array.from(st.acf), name: 'ACF', colorOf: (v) => (Math.abs(v) > band ? '#f28c18' : '#7fa6d6') }, { type: 'hline', y: band, color: '#d64541', label: 'IC 95 %' }, { type: 'hline', y: -band, color: '#d64541' }], zero: true }));
    } catch (e) { toast('Statistiques', esc(e.message), 'ko'); } finally { busy(btn, false); }
  };
  $('#stt-go', body).click();
}

// ======================================================================= corrélations (liste libre)
function tabCorr(body, L) {
  const st = prefs.get('lab.corr', { syms: [...new Set([L.sym, ...S.favorites])].slice(0, 12).join(' '), window: 252 });
  body.innerHTML = `<div class="form"><label class="f grow">Valeurs (codes ou symboles séparés par des espaces)<input type="text" id="lc-s" value="${esc(st.syms)}" style="width:100%"></label><label class="f">Fenêtre (séances)<input type="number" id="lc-w" value="${st.window}" min="30" max="1259"></label><button class="btn primary" id="lc-go">Calculer</button></div><div class="box-body"><canvas id="lc-cv" style="width:100%"></canvas><p class="help-text" id="lc-info"></p></div>`;
  $('#lc-go', body).onclick = async () => {
    st.syms = $('#lc-s', body).value;
    st.window = Number($('#lc-w', body).value);
    prefs.set('lab.corr', st);
    try {
      const r = await post('/api/lab/correlation', { syms: st.syms.split(/[\s,;]+/).filter(Boolean), window: st.window });
      L.plots.forEach((p) => p.destroy());
      L.plots = [];
      const names = r.order.map((i) => S.info(r.syms[i])?.code ?? r.syms[i]);
      L.plots.push(new HeatGrid($('#lc-cv', body), { rows: names, cols: names, values: r.order.map((i) => r.order.map((j) => r.matrix[i][j])), max: 1, showValues: names.length <= 16, format: (v) => num(v, 2) }));
      L.plots.at(-1).render();
      $('#lc-info', body).textContent = `${r.syms.length} valeurs · ${r.window} séances · rendements quotidiens · ordre par regroupement hiérarchique.`;
    } catch (e) { toast('Corrélations', esc(e.message), 'ko'); }
  };
  $('#lc-go', body).click();
}

// ======================================================================= test de charge
function tabStress(body) {
  body.innerHTML = `<div class="form"><label class="f">Durée (secondes)<input type="number" id="ss-s" value="15" min="3" max="120"></label><button class="btn warn" id="ss-go">🔥 Fondre les serveurs</button>
    <span class="help-text">Charge maximale simultanée : Monte Carlo sur le GPU, Monte Carlo C++ sur tous les cœurs, indicateurs sur tous les workers. Mesure les débits réels de ta machine.</span></div>
    <div class="box-body"><div class="kpis" id="ss-k"></div><div class="cols cols-2" style="margin-top:10px"><div><h4>Débits en direct</h4><canvas class="plot" id="ss-plot"></canvas></div><div><h4>Charge des cœurs</h4><div class="cores" id="ss-cores"></div><div id="ss-gpu"></div></div></div></div>`;
  const hist = { t: [], gpu: [], cpu: [], wk: [] };
  const plot = new Plot($('#ss-plot', body), { height: 220, xs: [], series: [], yFormat: (v) => rate(v, '') });
  const kpis = (p, done = false) => {
    $('#ss-k', body).innerHTML = [['GPU (Monte Carlo)', p.gpu.batches ? rate(p.gpu.rate, ' pas/s') : '—', p.gpu.batches ? `${int(p.gpu.batches)} lots` : 'GPU non utilisé (voir Système)'], ['CPU natif (Monte Carlo)', rate(p.cpu.rate, ' pas/s'), `${int(p.cpu.batches)} lots`], ['Workers (indicateurs)', rate(p.workers.rate, ' points/s'), `${int(p.workers.tasks)} tâches`], ['Total Monte Carlo', rate(p.gpu.rate + p.cpu.rate, ' pas/s'), `${num(p.elapsed, 1)} s${done ? ' · terminé' : ''}`]].map(([k, v, s2]) => `<div class="kpi"><span>${k}</span><b>${v}</b><small>${s2}</small></div>`).join('');
  };
  const offStress = live.on('stress', ({ progress: p }) => {
    hist.t.push(p.elapsed); hist.gpu.push(p.gpu.rate); hist.cpu.push(p.cpu.rate); hist.wk.push(p.workers.rate);
    plot.set({ xs: hist.t, xFormat: (x) => `${num(x, 0)} s`, series: [{ type: 'line', data: hist.gpu, name: 'GPU pas/s', color: '#7b4fc9' }, { type: 'line', data: hist.cpu, name: 'CPU natif pas/s', color: '#1f6fd1' }, { type: 'line', data: hist.wk, name: 'workers points/s', color: '#f28c18' }] });
    kpis(p);
  });
  const offTopic = live.topic('sys');
  const offSys = live.on('sys', (m) => {
    const c = m.snapshot.cpu.perCore;
    $('#ss-cores', body).innerHTML = c.map((u, i) => `<div class="core ${u > 0.85 ? 'hot' : ''}"><i style="height:${Math.round(u * 100)}%"></i><span>${i}</span><b>${Math.round(u * 100)} %</b></div>`).join('');
    const g = m.snapshot.gpu.devices[0];
    $('#ss-gpu', body).innerHTML = g ? `<table class="kv"><tr><th>GPU</th><td>${esc(g.name)}</td></tr><tr><th>Utilisation</th><td>${meter((g.util ?? 0) / 100, 'hot')} ${num(g.util, 0)} %</td></tr>${g.memTotalMb ? `<tr><th>VRAM</th><td>${int(g.memUsedMb)} / ${int(g.memTotalMb)} Mo</td></tr>` : ''}${Number.isFinite(g.tempC) ? `<tr><th>Température</th><td>${num(g.tempC, 0)} °C</td></tr>` : ''}${Number.isFinite(g.powerW) ? `<tr><th>Puissance</th><td>${num(g.powerW, 0)} W</td></tr>` : ''}</table>` : '<p class="help-text">Pas de nvidia-smi / rocm-smi : la charge GPU n\'est pas mesurable ici.</p>';
  });
  $('#ss-go', body).onclick = async () => {
    const btn = $('#ss-go', body);
    Object.assign(hist, { t: [], gpu: [], cpu: [], wk: [] });
    busy(btn, true, 'Chauffe en cours…');
    try {
      const r = await post('/api/lab/stress', { seconds: Number($('#ss-s', body).value) });
      kpis(r, true);
      toast('Test de charge terminé', `Monte Carlo : ${rate(r.gpu.rate + r.cpu.rate, ' pas/s')}`, 'ok');
    } catch (e) { toast('Test de charge', esc(e.message), 'ko'); } finally { busy(btn, false); }
  };
  return { destroy() { offStress(); offTopic(); offSys(); plot.destroy(); } };
}
void [el, histogram];

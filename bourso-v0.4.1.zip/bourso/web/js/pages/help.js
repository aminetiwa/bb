// ============================================================================
//  BOURSO :: pages/help.js — AIDE : raccourcis, fonctionnement (données, calcul, IA, agent),
//  précision et limites, glossaire des indicateurs, installation sous Ubuntu.
// ============================================================================
import { S } from '../core/store.js';

const KEYS = [
  ['F1 / F2', 'Bon d\'ordre d\'achat / de vente sur la valeur affichée (ou la dernière consultée)'],
  ['/ ou Ctrl+K', 'Rechercher une valeur (toutes les places, Europe en premier)'],
  ['Molette', 'Zoom du graphique centré sur la souris · sur l\'axe des prix : échelle verticale'],
  ['Glisser', 'Déplacer le graphique · sur un axe : changer l\'échelle · sur un séparateur : hauteur des panneaux'],
  ['Double-clic', 'Recentrer le graphique · sur un axe : échelle automatique · sur un tracé : ses propriétés'],
  ['← / →', 'Faire défiler le graphique'], ['+ / −', 'Zoomer / dézoomer'], ['Fin / Début', 'Revenir aux dernières bougies / tout afficher'],
  ['Clic droit', 'Menu : alerte, ordre limite ou ligne horizontale au prix pointé ; options d\'un tracé'],
  ['Échap', 'Annuler l\'outil de tracé en cours / désélectionner'], ['Suppr', 'Effacer le tracé sélectionné'], ['Ctrl+Z / Ctrl+Y', 'Annuler / rétablir (tracés)'],
  ['Maj (en posant le dernier point)', 'Garder l\'outil actif pour enchaîner plusieurs tracés'],
  ['Alt+F', 'Retracement de Fibonacci'], ['Alt+T', 'Ligne de tendance'], ['Alt+H / Alt+V', 'Ligne horizontale / verticale'], ['Alt+C', 'Canal parallèle'],
  ['Alt+P', 'Fourchette d\'Andrews'], ['Alt+G', 'Éventail de Gann'], ['Alt+X', 'Figure harmonique XABCD'], ['Alt+E', 'Vague d\'Elliott 1-2-3-4-5'],
  ['Alt+R', 'Rectangle'], ['Alt+M', 'Mesure (prix, %, durée, volume)'], ['Alt+L', 'Position longue (entrée, stop, objectif)'],
];
const GLOSSARY = [
  ['RSI', 'Indice de force relative (Wilder, 14) : rapport des hausses aux baisses lissées. > 70 surachat, < 30 survente.'],
  ['MACD', 'Écart entre deux moyennes exponentielles (12, 26) et sa ligne de signal (9). L\'histogramme mesure l\'accélération.'],
  ['ADX / DI', 'Force de la tendance (ADX > 25 : tendance établie) et son sens (DI+ au-dessus de DI− : haussière).'],
  ['ATR', 'Amplitude réelle moyenne : la « respiration » d\'une valeur, pour placer stops et objectifs.'],
  ['Bollinger', 'Moyenne ± 2 écarts-types. Bandes serrées = compression, souvent avant un mouvement.'],
  ['VWAP', 'Prix moyen pondéré par les volumes depuis l\'ouverture : la référence des professionnels en séance.'],
  ['Ichimoku', 'Système complet : équilibres court/moyen terme, nuage projeté de 26 périodes (supports et résistances futurs).'],
  ['SuperTrend / SAR', 'Stops suiveurs fondés sur la volatilité : leur retournement signale un changement de tendance.'],
  ['Profil de volume', 'Volumes échangés par niveau de prix. POC = prix le plus échangé ; zone de valeur = 70 % des volumes.'],
  ['Profil TPO', 'Temps passé à chaque prix, par périodes de 30 min (lettres A, B, C…). Initial balance = première heure.'],
  ['Monte Carlo', 'Des millions de trajectoires simulées (GARCH ou rééchantillonnage de l\'historique) : probabilités d\'atteindre un objectif avant un stop, avec leur erreur standard.'],
  ['GARCH(1,1)', 'Modèle de volatilité qui se regroupe (les fortes séances se suivent) ; ajusté par maximum de vraisemblance.'],
  ['Régimes (HMM)', 'Modèle de Markov caché : le marché alterne entre états (sans tendance · vol. calme, baisse · vol. agitée…) ; probabilité de l\'état actuel et durée moyenne. Toujours comparé au modèle à un seul état (BIC) : si ce dernier gagne, les régimes ne sont pas significatifs et l\'IA les ignore.'],
  ['Cycles (FFT)', 'Analyse de Fourier du prix détendancé : périodes dominantes et phase (montante, descendante), chaque pic testé contre un bruit rouge avec correction des tests multiples. La plupart des « cycles » boursiers ne passent pas ce test.'],
  ['Analogues historiques', 'Les séances passées dont la situation (rendements, écart aux moyennes, RSI, volatilité, volume) ressemble le plus à aujourd\'hui, et ce qui s\'est passé ensuite, comparé à la moyenne. Rarement significatif — et c\'est une information.'],
  ['Mémoire de l\'IA', 'Avant chaque analyse, l\'IA reçoit ses analyses précédentes sur la valeur, leur issue réelle (objectif, stop, expiré) et sa fiabilité mesurée par niveau de confiance, pour calibrer sa confiance.'],
  ['Walk-forward', 'Paramètres choisis sur le passé, testés sur la période suivante jamais vue : la seule mesure honnête d\'une stratégie.'],
  ['Sharpe / Sortino', 'Rendement par unité de risque (volatilité totale / volatilité des baisses), annualisé.'],
  ['VaR / ES', 'Perte journalière dépassée dans 5 % des cas (VaR 95 %) et perte moyenne au-delà (ES).'],
  ['Hurst', '≈ 0,5 marche aléatoire ; > 0,5 tendances persistantes ; < 0,5 retour à la moyenne.'],
  ['ADF', 'Test de racine unitaire : une série « stationnaire » revient vers sa moyenne.'],
  ['TTF', 'Taxe sur les transactions financières : 0,4 % à l\'achat d\'actions de sociétés françaises de plus d\'1 Md€ de capitalisation (depuis le 1er avril 2025).'],
  ['PRU', 'Prix de revient unitaire d\'une position (frais exclus).'],
];

export default {
  title: 'Aide',
  mount(root) {
    root.innerHTML = `<div class="page-title"><h1>Aide</h1><span class="sub">raccourcis, fonctionnement, précision, glossaire, installation</span></div>
      <div class="cols cols-2">
        <div>
          <section class="box"><h2 class="box-title"><span class="ico">⌨</span>Raccourcis clavier et souris</h2><table class="tbl keys"><tbody>${KEYS.map(([k, d]) => `<tr><td>${k.split(' / ').map((x) => `<kbd>${x}</kbd>`).join(' / ')}</td><td>${d}</td></tr>`).join('')}</tbody></table></section>
          <section class="box"><h2 class="box-title"><span class="ico">?</span>Glossaire</h2><table class="kv wide">${GLOSSARY.map(([k, d]) => `<tr><th>${k}</th><td class="help">${d}</td></tr>`).join('')}</table></section>
        </div>
        <div>
          <section class="box"><h2 class="box-title"><span class="ico">⚙</span>Comment fonctionne Bourso</h2><div class="box-body md">
            <h3>Les données</h3>${S.real ? `<p><b>Données réelles</b>, de sources publiques gratuites, sur ${S.universe.length} actions et ${S.meta.exchanges.length} places (l'Europe en premier) — et toute action du monde s'ajoute depuis la recherche :</p>
            <ul><li><b>Cours et historiques</b> : Yahoo Finance (accès public non officiel, usage personnel), cours <b>différés</b> (≈ 15 min en Europe), 5 ans de séances, bougies 1 min sur 5 séances, 5/15/30 min sur un mois, 1 h sur six mois.</li>
              <li><b>Change</b> : taux de référence de la BCE (Frankfurter en secours), affinés en séance.</li>
              <li><b>Actualités</b> : titres de presse (flux RSS), Google Actualités, GDELT — liens vers les articles ; transmis à l'IA comme données non fiables.</li>
              <li><b>Fondamentaux</b> : dividendes et extrêmes 52 semaines sans clé ; PER, BPA, consensus… avec une clé gratuite Finnhub ou FMP (<a href="#/reglages">Réglages → Données</a>).</li>
              <li><b>Non disponible gratuitement</b> : carnet d'ordres, bande des transactions, bougies à la seconde. La fourchette de négociation est estimée (± 0,05 %).</li></ul>
            <p>Bourso respecte les sources : une requête à la fois et au plus une par seconde pour Yahoo, cache sur disque, pause automatique dès qu'un site refuse (plus rien ne lui est envoyé jusqu'à la reprise), aucun contournement (captcha, connexion, paywall, imitation de navigateur). L'état de chaque source est sur la page <a href="#/systeme">Système</a>. Le portefeuille et les ordres restent <b>fictifs</b> : rien ne quitte ta machine.</p>`
              : `<p>Mode <b>démonstration</b> : le marché est <b>simulé</b> sur le serveur local : ${S.universe.length} actions réelles (noms, ISIN, places, devises, pas de cotation, calendriers et horaires exacts) sur ${S.meta.exchanges.length} places, l'Europe en premier. Cinq ans d'historique quotidien, minutes et secondes cohérentes entre elles, carnet d'ordres, transactions, actualités qui font bouger les cours. Rien n'est réel : c'est un terrain d'entraînement sans risque. Les données réelles s'activent dans <a href="#/reglages">Réglages → Données</a>.</p>`}
            <h3>Le calcul</h3><p>Les gros calculs sont <b>dosés</b> entre la carte graphique (WebGPU natif via Dawn/Vulkan), le processeur (module C++ sur tous les cœurs) et des workers JavaScript, en proportion de leurs débits mesurés. Les résultats GPU (float32) sont recontrôlés en double précision par le CPU. Le graphique est dessiné par WebGL2.</p>
            <h3>L'IA d'analyse</h3><p>Un <b>seul modèle</b> (~30 milliards de paramètres, via Ollama, au choix dans les <a href="#/reglages">Réglages</a>) analyse tes favoris, dans l'ordre, et seulement quand il y a du nouveau. Avant chaque appel, la machine calcule tout (≈ 60 indicateurs, Monte Carlo, backtests, régimes, cycles, niveaux, actualités, position) : le modèle raisonne sur ces chiffres et répond dans un format JSON imposé, puis des garde-fous vérifient le plan (stop du bon côté, gain/risque, cohérence avec les calculs).</p>
            <h3>L'agent Bourso Pro</h3><p>Un expert à qui parler : il appelle les outils de calcul (cotation, dossier, Monte Carlo, backtests, screener, portefeuille…) avant de répondre, et cite leurs résultats. Il ne passe jamais d'ordre lui-même.</p>
            <h3>Précision et limites</h3><p>Les <b>calculs</b> sont exacts : sommes compensées, loi normale exacte à 10⁻¹⁵ près, GPU contrôlé par le CPU, mêmes formules partout (graphique, screener, dossier, backtests). Mais <b>aucune IA ne prédit le marché à 100 %</b> : c'est pourquoi chaque décision est suivie jusqu'à son objectif ou son stop, et la page Analyse IA affiche le <b>taux de réussite réel</b> par niveau de confiance.</p>
          </div></section>
          <section class="box"><h2 class="box-title"><span class="ico">⬇</span>Installation (Ubuntu)</h2><div class="box-body md">
            <ol><li>Node.js 22 ou plus récent, et les outils de compilation : <code>sudo apt install build-essential python3</code></li>
              <li>Pilote Vulkan de la carte graphique (NVIDIA : pilote propriétaire ; AMD/Intel : <code>mesa-vulkan-drivers</code>). Vérification : <code>vulkaninfo --summary</code></li>
              <li>Dans le dossier du projet : <code>npm install</code> (compile le module C++, installe WebGPU/Dawn)</li>
              <li>Ollama : <code>curl -fsSL https://ollama.com/install.sh | sh</code> puis <code>npm run ollama:setup</code> (télécharge qwen3:30b et crée le modèle « bourso ») — ou choisis/télécharge un modèle depuis la page <a href="#/reglages">Réglages</a></li>
              <li><code>npm start</code> puis ouvre <code>http://localhost:3000</code></li></ol>
            <p>Sans Ollama : <code>npm run demo</code> lance un faux serveur Ollama (réponses simulées, étiquetées) et le marché simulé pour tout essayer.</p>
            <p>Vérifier l'accès aux sources de données depuis ta machine : <code>npm run data:check</code>.</p>
          </div></section>
        </div>
      </div>`;
  },
};

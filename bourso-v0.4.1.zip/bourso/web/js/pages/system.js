// ============================================================================
//  BOURSO :: pages/system.js — SYSTÈME : la machine en direct et les moteurs de calcul.
//  CPU par cœur, mémoire, GPU (nvidia-smi / rocm-smi), adaptateur WebGPU natif (Dawn/Vulkan),
//  addon C++, workers, débits mesurés et dosage GPU/CPU, niveau de calcul (Éco → Fondre les
//  serveurs), mode (auto/GPU/CPU), étalonnage, derniers calculs, Ollama, serveur, navigateur,
//  et l'état de chaque SOURCE DE DONNÉES (requêtes, refus, pauses, budgets, erreurs).
// ============================================================================
import { S } from '../core/store.js';
import { get, post } from '../core/api.js';
import { live } from '../core/live.js';
import { $, setHtml, setText, toast, meter, sparkSvg } from '../core/dom.js';
import { esc, num, int, pct, dur, rate, big, bytes, dateTime, ago, until } from '../core/fmt.js';

const LEVEL_HELP = {
  eco: '100 000 trajectoires, grilles réduites, 1 fil : laisse la machine libre.',
  equilibre: '1 million de trajectoires, grilles normales, tous les cœurs sauf un.',
  max: '5 millions de trajectoires, grilles doublées, tous les cœurs.',
  fondre: '20 millions de trajectoires, grilles ×4, tous les cœurs : précision maximale.',
};

export default {
  title: 'Système',
  async mount(root) {
    root.innerHTML = `<div class="page-title"><h1>Système</h1><span class="sub" id="sy-sub"></span></div>
      <div class="cols cols-3">
        <div><section class="box"><h2 class="box-title"><span class="ico">▦</span>Processeur <span class="title-note" id="sy-cpu-n"></span></h2><div class="cores" id="sy-cores"></div><div class="box-body" id="sy-cpu"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">▤</span>Mémoire</h2><div class="box-body" id="sy-ram"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">◧</span>Carte graphique (pilote)</h2><div class="box-body" id="sy-gpu"></div></section></div>
        <div><section class="box"><h2 class="box-title"><span class="ico">⚙</span>Niveau de calcul</h2><div class="box-body" id="sy-level"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">⚡</span>Moteurs de calcul</h2><div class="box-body" id="sy-eng"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">☰</span>Derniers calculs</h2><div class="scroll tall"><table class="tbl compact" id="sy-jobs"></table></div></section></div>
        <div><section class="box"><h2 class="box-title"><span class="ico">◆</span>IA (Ollama)</h2><div class="box-body" id="sy-ai"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">⇄</span>Serveur Bourso</h2><div class="box-body" id="sy-srv"></div></section>
          <section class="box"><h2 class="box-title"><span class="ico">▣</span>Ce navigateur</h2><div class="box-body" id="sy-web"></div></section></div>
      </div>
      <section class="box"><h2 class="box-title"><span class="ico">⇅</span>Sources de données <span class="title-note" id="sy-data-note"></span><span class="tools"><a class="btn btn-xs" href="#/reglages">réglages et test</a></span></h2><div id="sy-data"></div></section>`;
    const R = (s) => root.querySelector(s);
    const hist = { cpu: [], ram: [], gpu: [] };
    let info = null;

    const renderSnap = (snap, extra) => {
      const c = snap.cpu, perCore = c.perCore;
      R('#sy-cpu-n').textContent = `${c.cores} cœurs`;
      setHtml(R('#sy-cores'), perCore.map((u, i) => `<div class="core ${u > 0.85 ? 'hot' : ''}"><i style="height:${Math.round(u * 100)}%"></i><span>${i}</span><b>${Math.round(u * 100)} %</b></div>`).join(''));
      hist.cpu.push(c.avg * 100);
      hist.ram.push(((snap.ram.totalMb - snap.ram.freeMb) / snap.ram.totalMb) * 100);
      for (const k of ['cpu', 'ram', 'gpu']) if (hist[k].length > 120) hist[k].shift();
      setHtml(R('#sy-cpu'), `<table class="kv"><tr><th>Modèle</th><td>${esc(c.model)}</td></tr><tr><th>Fréquence</th><td>${c.speedMhz ? `${int(c.speedMhz)} MHz` : '—'}</td></tr><tr><th>Charge moyenne</th><td>${meter(c.avg, 'hot')} ${pct(c.avg * 100, 0, false)}</td></tr>
        <tr><th>Load average (1/5/15 min)</th><td>${c.load.map((x) => num(x, 2)).join(' · ')}</td></tr><tr><th>Historique (3 min)</th><td>${sparkSvg(hist.cpu, { w: 200, h: 30, color: '#f28c18', fill: true })}</td></tr>${extra ? `<tr><th>Workers occupés</th><td>${extra.compute.pool.busy} / ${extra.compute.pool.size} · file ${extra.compute.pool.queued}</td></tr><tr><th>Pas du marché simulé</th><td>${num(extra.stepMs, 2)} ms / 50 ms</td></tr>` : ''}</table>`);
      const r = snap.ram;
      setHtml(R('#sy-ram'), `<table class="kv"><tr><th>Mémoire vive</th><td>${meter((r.totalMb - r.freeMb) / r.totalMb, 'blue')} ${int(r.totalMb - r.freeMb)} / ${int(r.totalMb)} Mo</td></tr><tr><th>Processus Bourso (RSS)</th><td>${int(r.processRssMb)} Mo</td></tr><tr><th>Tas JavaScript</th><td>${int(r.heapUsedMb)} Mo</td></tr><tr><th>Tampons (séries, SharedArrayBuffer)</th><td>${int(r.externalMb)} Mo</td></tr><tr><th>Historique</th><td>${sparkSvg(hist.ram, { w: 200, h: 30, color: '#1f6fd1', fill: true })}</td></tr></table>`);
      const g = snap.gpu;
      if (g.devices.length) {
        const d = g.devices[0];
        hist.gpu.push(d.util ?? 0);
        setHtml(R('#sy-gpu'), `<table class="kv">${g.devices.map((x) => `<tr><th>Carte</th><td>${esc(x.name)}</td></tr><tr><th>Utilisation</th><td>${meter((x.util ?? 0) / 100, 'hot')} ${num(x.util, 0)} %</td></tr>${x.memTotalMb ? `<tr><th>VRAM</th><td>${meter(x.memUsedMb / x.memTotalMb, 'blue')} ${int(x.memUsedMb)} / ${int(x.memTotalMb)} Mo</td></tr>` : ''}${Number.isFinite(x.tempC) ? `<tr><th>Température</th><td>${num(x.tempC, 0)} °C</td></tr>` : ''}${Number.isFinite(x.powerW) ? `<tr><th>Puissance</th><td>${num(x.powerW, 0)} / ${num(x.powerLimitW, 0)} W</td></tr>` : ''}${x.clockMhz ? `<tr><th>Fréquence</th><td>${int(x.clockMhz)} MHz</td></tr>` : ''}`).join('')}<tr><th>Source</th><td>${esc(g.tool)}</td></tr><tr><th>Historique</th><td>${sparkSvg(hist.gpu, { w: 200, h: 30, color: '#7b4fc9', fill: true })}</td></tr></table>`);
      } else setHtml(R('#sy-gpu'), '<p class="help-text">nvidia-smi / rocm-smi introuvables : la charge de la carte n\'est pas mesurable ici (le calcul GPU, lui, passe par WebGPU/Vulkan — voir « Moteurs de calcul »).</p>');
    };

    const renderInfo = () => {
      const s = info, c = s.compute;
      R('#sy-sub').textContent = `${s.snapshot.platform} · Node ${s.snapshot.node} · ${s.snapshot.host} · serveur démarré ${dateTime(s.startedAt)}`;
      setHtml(R('#sy-level'), `<div class="stack">${Object.entries(c.levels).map(([k, l]) => `<label class="chk" style="align-items:flex-start"><input type="radio" name="lvl" value="${k}" ${c.level === k ? 'checked' : ''}> <span><b>${esc(l)}</b><br><span class="help-text">${LEVEL_HELP[k] ?? ''}</span></span></label>`).join('')}
        <div class="row"><span class="muted">Répartition :</span><div class="seg" id="sy-mode">${[['auto', 'dosée GPU + CPU'], ['gpu', 'GPU seul'], ['cpu', 'CPU seul']].map(([k, l]) => `<button data-m="${k}" class="${c.mode === k ? 'on' : ''}">${l}</button>`).join('')}</div></div>
        <div class="row"><button class="btn btn-small" id="sy-cal">Ré-étalonner les débits</button><a class="btn btn-small warn" href="#/labo/stress">🔥 Test de charge</a></div></div>`);
      R('#sy-level').onchange = async (e) => { if (e.target.name === 'lvl') { await post('/api/system/level', { level: e.target.value }); toast('Niveau de calcul', esc(c.levels[e.target.value]), 'ok', 1500); load(); } };
      R('#sy-mode').onclick = async (e) => { const b = e.target.closest('[data-m]'); if (b) { await post('/api/system/mode', { mode: b.dataset.m }); load(); } };
      R('#sy-cal').onclick = async () => { R('#sy-cal').disabled = true; await post('/api/system/calibrate'); R('#sy-cal').disabled = false; toast('Étalonnage terminé', '', 'ok', 1500); load(); };
      const g = c.gpu;
      setHtml(R('#sy-eng'), `<table class="kv">
        <tr><th>GPU (WebGPU natif, Dawn/Vulkan)</th><td>${g.ok ? `<span class="chip ok">actif</span> ${esc(g.vendor)} · ${esc(g.architecture)} <small>${esc(g.description)}${g.software ? ' — moteur logiciel (pas de vraie carte)' : ''}</small>` : `<span class="chip ko">inactif</span><small>${esc(g.reason ?? '')}</small>`}</td></tr>
        ${g.ok ? `<tr><th>Limites GPU</th><td>tampon max ${bytes(g.limits.maxBuffer)} · stockage ${bytes(g.limits.maxStorage)} · ${g.limits.maxWorkgroup} fils/groupe</td></tr><tr><th>Travaux GPU</th><td>${int(g.jobs)} · en cours ${g.busy}</td></tr>
          <tr><th>Isolation</th><td>${g.isolated ? `processus séparé (pid ${g.pid}) <small>un plantage du pilote n'arrête pas le serveur</small>` : 'dans le processus du serveur (BOURSO_GPU_INPROCESS=1)'}</td></tr>` : ''}
        ${g.crashes ? `<tr><th>Plantages du pilote GPU</th><td><span class="chip warn">${g.crashes}</span>${g.lastCrash ? `<small>dernier : ${esc(g.lastCrash.why)}${g.lastCrash.op ? ` pendant « ${esc(g.lastCrash.op)} »` : ''} — ${dateTime(g.lastCrash.at)}. Les calculs concernés ont été refaits sur le CPU.</small>` : ''}</td></tr>` : ''}
        <tr><th>CPU natif (addon C++ N-API)</th><td>${c.native.ok ? `<span class="chip ok">actif</span> ${esc(c.native.version)}` : `<span class="chip warn">non compilé</span><small>repli sur les workers JavaScript (mêmes résultats) — npm run build:native</small>`}</td></tr>
        <tr><th>Fils de calcul natifs</th><td>${c.threads} / ${c.cpu.cores}</td></tr><tr><th>Workers JavaScript</th><td>${c.pool.size} · ${int(c.pool.done)} tâches · utilisation ${pct(c.pool.utilization * 100, 0, false)}</td></tr>
        <tr><th>Débit Monte Carlo GPU</th><td>${rate(c.rates.mcGpu, ' pas/s')}</td></tr><tr><th>Débit Monte Carlo CPU</th><td>${rate(c.rates.mcCpu, ' pas/s')}</td></tr>
        <tr><th>Débit balayage GPU / CPU</th><td>${rate(c.rates.sweepGpu, ' bougies/s')} / ${rate(c.rates.sweepCpu, ' bougies/s')}</td></tr>
        <tr><th>Part confiée au GPU</th><td>Monte Carlo ${pct(c.shares.mc * 100, 0, false)} · balayages ${pct(c.shares.sweep * 100, 0, false)}</td></tr></table>
        <p class="help-text">Le dosage suit les débits mesurés : GPU et CPU finissent en même temps. Les résultats GPU (float32) sont contrôlés en double précision par le CPU.</p>`);
      setHtml(R('#sy-jobs'), `<thead><tr><th>Quand</th><th>Calcul</th><th>Répartition</th><th class="r">Durée</th><th class="r">Débit</th></tr></thead><tbody>${[...c.jobs].reverse().map((j) => `<tr><td class="small">${dateTime(j.at)}</td><td>${esc(j.type)}</td><td class="small">${(j.split ?? []).map((x) => `${esc(x.backend)} ${x.paths ? int(x.paths) : x.combos ? int(x.combos) : x.pathSteps ? big(x.pathSteps) : x.points ? big(x.points) : ''}`).join(' + ')}</td><td class="r">${dur(j.ms)}</td><td class="r">${rate(j.rate)}</td></tr>`).join('') || '<tr class="empty"><td colspan="5">Aucun calcul</td></tr>'}</tbody>`);
      const o = s.ollama;
      setHtml(R('#sy-ai'), `<table class="kv"><tr><th>Serveur</th><td>${esc(o.host ?? '')}</td></tr><tr><th>État</th><td>${o.up ? `<span class="chip ok">joignable</span> v${esc(o.version)}` : `<span class="chip ko">injoignable</span><small>${esc(o.error ?? '')}</small>`}</td></tr><tr><th>Modèle utilisé</th><td>${esc(s.model)}</td></tr>
        <tr><th>Analyses</th><td>${int(s.ai.analyzed)} faites · ${int(s.ai.skipped)} évitées · ${int(s.ai.simulated)} simulées · ${int(s.ai.errors)} erreurs</td></tr><tr><th>Agent</th><td>${int(s.agent.messages)} questions · ${int(s.agent.toolCalls)} appels d'outils</td></tr>
        ${(o.loaded ?? []).map((m) => `<tr><th>En mémoire</th><td>${esc(m.name)} · ${bytes(m.vram)} en VRAM</td></tr>`).join('')}</table>
        ${(o.models ?? []).length ? `<table class="tbl compact"><thead><tr><th>Modèle</th><th class="r">Taille</th><th>Paramètres</th><th>Quantif.</th></tr></thead><tbody>${o.models.map((m) => `<tr><td>${esc(m.name)}</td><td class="r">${bytes(m.size)}</td><td>${esc(m.params ?? '')}</td><td>${esc(m.quant ?? '')}</td></tr>`).join('')}</tbody></table>` : ''}`);
      setHtml(R('#sy-srv'), `<table class="kv"><tr><th>Version</th><td>Bourso ${esc(s.version)}</td></tr>${s.market.real ? `<tr><th>Données réelles</th><td>${int(s.market.instruments)} actions · ${s.market.exchanges} places · ${int(s.market.quotesLive)} cours reçus · ${int(s.market.histories)} historiques</td></tr>` : `<tr><th>Marché simulé</th><td>${int(s.market.instruments)} actions · ${s.market.exchanges} places</td></tr><tr><th>Pas de simulation</th><td>${num(s.market.stepMs, 2)} ms (20 pas/s)</td></tr>`}<tr><th>Screener (${int(s.market.instruments)} valeurs)</th><td>${dur(s.market.screenMs)} sur ${c.pool.size} workers</td></tr><tr><th>Actualités en mémoire</th><td>${int(s.market.news)}</td></tr>
        ${s.ws ? `<tr><th>Clients temps réel</th><td>${s.ws.clients}</td></tr><tr><th>Messages envoyés</th><td>${int(s.ws.sent)} (${bytes(s.ws.bytes)})</td></tr><tr><th>Messages abandonnés (client lent)</th><td>${int(s.ws.dropped)}</td></tr>` : ''}<tr><th>Durée de fonctionnement</th><td>${dur(s.snapshot.processUptime * 1000)}</td></tr></table>`);
    };

    const renderWeb = () => {
      let gl = '—';
      try {
        const c = document.createElement('canvas').getContext('webgl2'), d = c?.getExtension('WEBGL_debug_renderer_info');
        gl = c ? (d ? c.getParameter(d.UNMASKED_RENDERER_WEBGL) : c.getParameter(c.RENDERER)) : 'WebGL2 indisponible';
      } catch { /* indisponible */ }
      setHtml(R('#sy-web'), `<table class="kv"><tr><th>Rendu des graphiques</th><td class="help">${esc(gl)}</td></tr><tr><th>Écran</th><td>${screen.width} × ${screen.height} · densité ${num(devicePixelRatio, 2)}</td></tr><tr><th>Cœurs vus par le navigateur</th><td>${navigator.hardwareConcurrency ?? '—'}</td></tr>
        <tr><th>Isolation (SharedArrayBuffer)</th><td>${self.crossOriginIsolated ? '<span class="chip ok">active</span>' : '<span class="chip warn">inactive</span>'}</td></tr><tr><th>Flux temps réel</th><td>${live.status === 'open' ? 'connecté' : 'déconnecté'} · ${live.stats.rate} msg/s · ${bytes(live.stats.bytes)} reçus · ${live.stats.reconnects} reconnexion(s)</td></tr></table>`);
    };

    const renderData = async () => {
      const st = await get('/api/data/status').catch(() => null);
      if (!st) return;
      if (!st.real) {
        setText(R('#sy-data-note'), 'démonstration');
        setHtml(R('#sy-data'), '<div class="box-body">Démonstration : marché simulé, aucune source externe interrogée. <a href="#/reglages">Passer aux données réelles</a>.</div>');
        return;
      }
      setText(R('#sy-data-note'), `données réelles · intensité ${st.intensityLabel ?? ''}`);
      const chip = (state) => `<span class="chip ${state === 'ok' ? 'ok' : state === 'instable' ? 'warn' : 'ko'}">${esc(state)}</span>`;
      const kp = [['Cours reçus', `${int(st.quotesLive)} / ${int(st.instruments)}`, `${int(st.quotesFresh15min)} de moins de 15 min`], ['Historiques', `${int(st.histories)} / ${int(st.instruments)}`, st.historyQueue ? `${int(st.historyQueue)} en file` : 'à jour'],
        ['Indices', `${st.indices.filter((i) => i.ok).length} / ${st.indices.length}`, 'niveaux différés'], ['Change', esc(st.fx?.source ?? '—'), st.fx?.date ? `taux du ${esc(st.fx.date)}` : ''],
        ['Actualités', int(st.news?.items), st.news?.general?.at ? `flux lus ${ago(st.news.general.at)}` : 'première lecture en cours'], ['Cotations groupées', esc(st.spark ?? '—'), 'Yahoo spark']];
      const srcRows = (st.sources ?? []).map((g) => `<tr><td><b>${esc(g.host)}</b></td><td>${chip(g.state)}${g.pausedUntil ? `<small>reprise ${until(g.pausedUntil)}</small>` : ''}</td><td class="r">${int(g.requests)}</td><td class="r">${int(g.ok)}</td><td class="r">${g.errors ? `<span class="down">${int(g.errors)}</span>` : '0'}</td>
        <td class="r">${g.blocked ? `<span class="warn">${int(g.blocked)}</span>` : '0'}</td><td class="r">${int(g.cached)}</td><td class="r">${g.avgMs ? `${int(g.avgMs)} ms` : '—'}</td><td class="r">${g.budget ? `${int(g.budget.used)} / ${int(g.budget.max)}` : '—'}</td>
        <td class="small">${g.lastOk ? ago(g.lastOk) : '—'}</td><td class="small">${g.lastError ? `${esc(g.lastError)}<small>${ago(g.lastErrorAt)}</small>` : ''}</td></tr>`).join('');
      const news = Object.entries(st.news?.sources ?? {}).sort((a, b) => b[1].at - a[1].at).map(([k, v]) => `<tr><td>${esc(k)}</td><td class="small">${ago(v.at)}</td><td class="r">${int(v.total)}</td><td class="small">${st.news.errors?.[k] && st.news.errors[k].at > v.at ? `<span class="down">${esc(st.news.errors[k].message)}</span>` : ''}</td></tr>`).join('');
      const keys = Object.entries(st.keys ?? {}).map(([k, v]) => `${esc(k)} ${v.configured ? '<span class="chip ok">clé</span>' : '<span class="muted">—</span>'}${v.notCovered ? ` <small>${int(v.notCovered)} non couverte(s)</small>` : ''}`).join(' · ');
      setHtml(R('#sy-data'), `${st.yahooPausedUntil > Date.now() ? `<div class="notice" style="margin:8px 10px 0">Yahoo Finance a refusé des requêtes (HTTP 429) : Bourso ne lui demande plus rien jusqu'à <b>${new Date(st.yahooPausedUntil).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</b>, puis reprend seul. Les derniers cours connus restent affichés. Si cela dure, garde l'intensité « économe » quelques heures (Réglages → Données).</div>` : ''}<div class="kpis" style="padding:8px 10px">${kp.map(([k, v, sub]) => `<div class="kpi"><span>${k}</span><b>${v}</b><small>${sub}</small></div>`).join('')}</div>
        <div class="scroll"><table class="tbl compact"><thead><tr><th>Site</th><th>État</th><th class="r">Requêtes</th><th class="r">Réussies</th><th class="r">Erreurs</th><th class="r">Refus</th><th class="r">Cache</th><th class="r">Latence</th><th class="r">Budget du jour</th><th>Dernière réussite</th><th>Dernière erreur</th></tr></thead>
        <tbody>${srcRows || '<tr class="empty"><td colspan="11">Aucune requête pour l\'instant</td></tr>'}</tbody></table></div>
        <div class="cols cols-2" style="padding:8px 10px"><div><h4>Actualités par source</h4><table class="tbl compact"><thead><tr><th>Source</th><th>Dernière collecte</th><th class="r">Titres</th><th></th></tr></thead><tbody>${news || '<tr class="empty"><td colspan="4">—</td></tr>'}</tbody></table></div>
        <div><h4>Sources à clé</h4><p class="small">${keys}</p>
          ${st.notFound?.length ? `<h4>Valeurs introuvables</h4><p class="small">${st.notFound.map((x) => `${esc(x.yahoo)} <span class="muted">(${esc(x.error ?? '')})</span>`).join(' · ')}</p>` : ''}
          <h4>Dernières erreurs</h4>${st.errors?.length ? `<ul class="log small">${st.errors.slice(0, 10).map((e) => `<li>${dateTime(e.at)} — ${esc(e.message)}</li>`).join('')}</ul>` : '<p class="small muted">aucune</p>'}
          <p class="help-text">« Refus » = réponses 429/403 : le site est alors mis en pause 1, 2, 5, 15 puis 30 min (coupe-circuit). Rien n'est contourné.</p></div></div>`);
    };
    const load = async () => { info = await get('/api/system'); renderInfo(); renderSnap(info.snapshot); renderData(); };
    await load();
    renderWeb();
    const offT = live.topic('sys');
    const offS = live.on('sys', (m) => renderSnap(m.snapshot, m));
    const t1 = setInterval(load, 10_000), t2 = setInterval(renderWeb, 2000);
    return { unmount() { offT(); offS(); clearInterval(t1); clearInterval(t2); } };
  },
};
void [$, S];

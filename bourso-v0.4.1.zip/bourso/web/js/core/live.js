// ============================================================================
//  BOURSO :: core/live.js — flux temps réel (WebSocket) avec reconnexion automatique.
//  Abonnements par valeur (comptés : plusieurs widgets peuvent suivre la même valeur),
//  thèmes optionnels (« sys » : état machine), statistiques de débit.
// ============================================================================
export class Emitter {
  constructor() {
    this.h = new Map();
  }
  on(type, fn) {
    if (!this.h.has(type)) this.h.set(type, new Set());
    this.h.get(type).add(fn);
    return () => this.h.get(type)?.delete(fn);
  }
  emit(type, data) {
    for (const fn of this.h.get(type) ?? []) {
      try { fn(data); } catch (e) { console.error(`[bourso] ${type}`, e); }
    }
  }
}

class Live extends Emitter {
  constructor() {
    super();
    this.ws = null;
    this.status = 'connecting';
    this.subs = new Map();
    this.tfs = new Map();
    this.topicCount = new Map();
    this.stats = { msgs: 0, bytes: 0, rate: 0, connectedAt: 0, reconnects: 0 };
    this.delay = 500;
    let last = 0;
    setInterval(() => {
      this.stats.rate = this.stats.msgs - last;
      last = this.stats.msgs;
    }, 1000);
  }

  connect() {
    const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`);
    this.ws = ws;
    ws.onopen = () => {
      this.status = 'open';
      this.delay = 500;
      this.stats.connectedAt = Date.now();
      for (const sym of this.subs.keys()) this.send({ t: 'sub', sym, tf: this.tfs.get(sym) });
      this.#sendTopics();
      this.emit('status', this.status);
    };
    ws.onmessage = (e) => {
      this.stats.msgs++;
      this.stats.bytes += e.data.length;
      let m;
      try { m = JSON.parse(e.data); } catch { return; }
      this.emit(m.t, m);
      this.emit('*', m);
    };
    ws.onclose = () => {
      if (this.ws !== ws) return;
      this.status = 'closed';
      this.emit('status', this.status);
      this.stats.reconnects++;
      setTimeout(() => this.connect(), this.delay);
      this.delay = Math.min(8000, this.delay * 1.7);
    };
    ws.onerror = () => ws.close();
  }

  send(m) {
    if (this.ws?.readyState === 1) this.ws.send(JSON.stringify(m));
  }

  /** Suit une valeur (transactions + bougies en cours, à l'unité `tf`). Renvoie la fonction de désabonnement. */
  sub(sym, tf = undefined) {
    const n = this.subs.get(sym) ?? 0;
    this.subs.set(sym, n + 1);
    if (tf !== undefined) this.tfs.set(sym, tf);
    if (!n || tf !== undefined) this.send({ t: 'sub', sym, tf: this.tfs.get(sym) });
    let done = false;
    return () => {
      if (done) return;
      done = true;
      const k = (this.subs.get(sym) ?? 1) - 1;
      if (k <= 0) {
        this.subs.delete(sym);
        this.tfs.delete(sym);
        this.send({ t: 'unsub', sym });
      } else this.subs.set(sym, k);
    };
  }

  /** Thème optionnel (ex. « sys »). Renvoie la fonction de retrait. */
  topic(name) {
    this.topicCount.set(name, (this.topicCount.get(name) ?? 0) + 1);
    this.#sendTopics();
    let done = false;
    return () => {
      if (done) return;
      done = true;
      const k = (this.topicCount.get(name) ?? 1) - 1;
      if (k <= 0) this.topicCount.delete(name);
      else this.topicCount.set(name, k);
      this.#sendTopics();
    };
  }

  #sendTopics() {
    this.send({ t: 'topics', list: [...this.topicCount.keys()] });
  }
}

export const live = new Live();

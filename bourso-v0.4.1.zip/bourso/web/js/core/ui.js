// ============================================================================
//  BOURSO :: core/ui.js — fragments d'interface réutilisés par toutes les pages
//  (cellule « valeur », étoile de favori, variation colorée, tonalité d'actualité…).
// ============================================================================
import { S } from './store.js';
import { esc, pct, cls, price, ago, num } from './fmt.js';
import { on, toast } from './dom.js';

export const symHref = (sym) => `#/valeur/${encodeURIComponent(sym)}`;

/** Nom cliquable + mnémonique · place (sur deux lignes). */
export function nameCell(sym, { sub = true, name } = {}) {
  const u = S.info(sym);
  return `<a class="name" href="${symHref(sym)}">${esc(name ?? u?.name ?? sym)}</a>${sub ? `<small>${esc(u?.code ?? '')} · ${esc(u?.ex ?? '')}${u?.region && u.region !== 'Europe' ? ` · ${esc(u.country)}` : ''}</small>` : ''}`;
}

export const star = (sym) => `<button class="star ${S.isFav(sym) ? 'on' : ''}" type="button" data-fav="${esc(sym)}" title="${S.isFav(sym) ? 'Retirer des favoris' : 'Ajouter aux favoris (analysé par l\'IA)'}">${S.isFav(sym) ? '★' : '☆'}</button>`;
export const chg = (x, d = 2) => `<span class="${cls(x)}">${pct(x, d)}</span>`;
export const px = (sym, v) => price(v, S.tick(sym));

/** Active les étoiles de favoris d'un conteneur (délégation). */
export function bindStars(root) {
  return on(root, 'click', '[data-fav]', async (e, b) => {
    e.preventDefault();
    e.stopPropagation();
    const sym = b.dataset.fav, was = S.isFav(sym);
    try {
      await S.toggleFav(sym);
      toast(was ? 'Retiré des favoris' : 'Ajouté aux favoris', `${esc(S.name(sym))}${was ? '' : ' — l\'IA l\'analysera à son tour'}`, 'ok', 2500);
    } catch (err) { toast('Favoris', esc(err.message), 'ko'); }
  });
}

/** Petite barre de tonalité (−1 … +1). */
export function tone(score) {
  const v = Math.max(-1, Math.min(1, score ?? 0));
  return `<span class="tone" title="tonalité ${num(v, 2)}"><i style="left:${v >= 0 ? 50 : 50 + v * 50}%;width:${Math.abs(v) * 50}%;background:${v >= 0 ? 'var(--up)' : 'var(--down)'}"></i></span>`;
}

const SCOPE = { valeur: 'Valeur', secteur: 'Secteur', 'région': 'Région', monde: 'Monde', 'marché': 'Marché' };
/** Lien externe sûr (http/https uniquement : un flux ne peut pas injecter « javascript: »). */
export function safeUrl(u) {
  try {
    const x = new URL(String(u));
    return x.protocol === 'https:' || x.protocol === 'http:' ? x.href : null;
  } catch { return null; }
}

/** Élément de liste d'actualité (titre cliquable vers l'article quand la source en donne l'adresse). */
export function newsItem(n, { fresh = false } = {}) {
  const who = n.sym ? `<a href="${symHref(n.sym)}">${esc(n.name ?? S.name(n.sym))}</a>` : esc(n.sector ?? n.region ?? n.tag ?? '');
  const url = n.url ? safeUrl(n.url) : null;
  const title = url ? `<a class="ext-link" href="${esc(url)}" target="_blank" rel="noopener noreferrer" referrerpolicy="no-referrer" title="Ouvrir l'article (site externe)">${esc(n.title)}</a>` : esc(n.title);
  return `<li class="${fresh ? 'fresh' : ''}"><span class="tag">${SCOPE[n.scope] ?? esc(n.scope)}</span>${title}${tone(n.score)}
    <div class="meta">${who} · ${ago(n.ts)} · ${esc(n.source ?? '')}</div></li>`;
}

/** Statut d'une place : « séance en cours » / « fermée », avec la progression. */
export function clockRow(c) {
  const p = Math.max(0, Math.min(1, c.progress ?? 0));
  return `<tr><td><b>${esc(c.short)}</b><small>${esc(c.name)}</small></td><td class="num">${esc(c.time)}</td>
    <td>${c.live ? '<span class="chip ok">ouverte</span>' : '<span class="chip">fermée</span>'}</td>
    <td style="width:70px"><div class="meter blue"><i style="width:${(p * 100).toFixed(1)}%"></i></div></td></tr>`;
}

export { ago, esc, num, pct, price, cls };

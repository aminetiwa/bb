// ============================================================================
//  BOURSO :: core/fmt.js — formats français (virgule décimale, espace fine des milliers),
//  prix au pas de cotation, pourcentages signés, volumes abrégés, dates et durées.
// ============================================================================
const NF = new Map();
const nf = (min, max = min) => {
  const k = `${min}|${max}`;
  if (!NF.has(k)) NF.set(k, new Intl.NumberFormat('fr-FR', { minimumFractionDigits: min, maximumFractionDigits: max }));
  return NF.get(k);
};

export const isNum = (x) => typeof x === 'number' && Number.isFinite(x);

/** Nombre de décimales d'un pas de cotation (0.005 → 3, 0.5 → 1, 1 → 0). */
export function decOf(tick) {
  if (!isNum(tick) || tick <= 0) return 2;
  const s = String(tick);
  if (s.includes('e-')) return Number(s.split('e-')[1]);
  return s.includes('.') ? s.split('.')[1].length : 0;
}

export const num = (x, d = 2) => (isNum(x) ? nf(d).format(x) : '—');
export const int = (x) => (isNum(x) ? nf(0).format(Math.round(x)) : '—');
export const price = (x, tick = 0.01) => (isNum(x) ? nf(Math.min(6, decOf(tick))).format(x) : '—');
export const pct = (x, d = 2, sign = true) => (isNum(x) ? `${sign && x > 0 ? '+' : ''}${nf(d).format(x)} %` : '—');
export const pct01 = (x, d = 1) => (isNum(x) ? `${nf(d).format(x * 100)} %` : '—');
export const signed = (x, d = 2) => (isNum(x) ? `${x > 0 ? '+' : ''}${nf(d).format(x)}` : '—');
export const cls = (x) => (!isNum(x) || x === 0 ? 'flat' : x > 0 ? 'up' : 'down');

/** 1 234 567 → « 1,23 M » ; milliards « Md ». */
export function big(x, d = 2) {
  if (!isNum(x)) return '—';
  const a = Math.abs(x);
  if (a >= 1e12) return `${nf(d).format(x / 1e12)} T`;
  if (a >= 1e9) return `${nf(d).format(x / 1e9)} Md`;
  if (a >= 1e6) return `${nf(d).format(x / 1e6)} M`;
  if (a >= 1e4) return `${nf(1).format(x / 1e3)} k`;
  return nf(0).format(x);
}

/** Taille en octets : « 18,6 Go », « 640 Mo ». */
export function bytes(x) {
  if (!isNum(x)) return '—';
  const a = Math.abs(x);
  if (a >= 1e12) return `${nf(2).format(x / 1e12)} To`;
  if (a >= 1e9) return `${nf(1).format(x / 1e9)} Go`;
  if (a >= 1e6) return `${nf(0).format(x / 1e6)} Mo`;
  if (a >= 1e3) return `${nf(0).format(x / 1e3)} ko`;
  return `${nf(0).format(x)} o`;
}

const SUP = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
/** Notation scientifique à la française : 1,477 × 10⁻⁴ (0 → « 0 »). */
export function sci(x, d = 2) {
  if (!isNum(x)) return '—';
  if (x === 0) return '0';
  const e = Math.floor(Math.log10(Math.abs(x)));
  if (e >= -2 && e < 6) return nf(0, d + Math.max(0, -e)).format(x);
  const m = x / 10 ** e;
  return `${nf(d).format(m)} × 10${String(e).replace(/[-\d]/g, (c) => SUP[c])}`;
}

/** Débit de calcul : 2,4 G pas/s. */
export function rate(x, unit = '/s') {
  if (!isNum(x)) return '—';
  const a = Math.abs(x);
  const [v, s] = a >= 1e12 ? [x / 1e12, 'T'] : a >= 1e9 ? [x / 1e9, 'G'] : a >= 1e6 ? [x / 1e6, 'M'] : a >= 1e3 ? [x / 1e3, 'k'] : [x, ''];
  return `${nf(v >= 100 ? 0 : v >= 10 ? 1 : 2).format(v)} ${s}${unit}`;
}

const CCY = { EUR: '€', USD: '$', GBP: '£', GBX: 'p', JPY: '¥', CHF: 'CHF', CNY: '¥', HKD: 'HK$', CAD: 'C$', AUD: 'A$', SEK: 'kr', NOK: 'kr', DKK: 'kr', PLN: 'zł', KRW: '₩', TWD: 'NT$', INR: '₹', BRL: 'R$', MXN: 'MX$', ZAR: 'R', ZAC: 'c', SGD: 'S$' };
export const ccySym = (c) => CCY[c] ?? c ?? '';
export const money = (x, ccy = 'EUR', d = 2) => (isNum(x) ? `${nf(d).format(x)} ${ccySym(ccy)}` : '—');
export const eur = (x, d = 0) => money(x, 'EUR', d);

const TZ = 'Europe/Paris';
const DT = {
  time: new Intl.DateTimeFormat('fr-FR', { timeZone: TZ, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
  hm: new Intl.DateTimeFormat('fr-FR', { timeZone: TZ, hour: '2-digit', minute: '2-digit' }),
  dt: new Intl.DateTimeFormat('fr-FR', { timeZone: TZ, day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }),
  full: new Intl.DateTimeFormat('fr-FR', { timeZone: TZ, weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
};
export const time = (ms) => (isNum(ms) ? DT.time.format(ms) : '—');
export const hm = (ms) => (isNum(ms) ? DT.hm.format(ms) : '—');
export const dateTime = (ms) => (isNum(ms) ? DT.dt.format(ms) : '—');
export const fullDate = (ms) => DT.full.format(ms);

/** « 2026-10-27 » → « 27/10/2026 » (ou « 27/10 » en court). */
export function ymd(s, short = false) {
  if (!s) return '—';
  const [y, m, d] = s.split('-');
  return short ? `${d}/${m}` : `${d}/${m}/${y}`;
}

/** Délai jusqu'à une date future : « dans 4 min ». */
export function until(ms) {
  if (!isNum(ms)) return '—';
  const s = Math.max(0, (ms - Date.now()) / 1000);
  if (s < 45) return 'dans un instant';
  if (s < 3600) return `dans ${Math.round(s / 60)} min`;
  return `dans ${Math.floor(s / 3600)} h ${String(Math.round((s % 3600) / 60)).padStart(2, '0')}`;
}

export function ago(ms) {
  if (!isNum(ms)) return '—';
  const s = Math.max(0, (Date.now() - ms) / 1000);
  if (s < 45) return 'à l\'instant';
  if (s < 3600) return `il y a ${Math.round(s / 60)} min`;
  if (s < 86_400) return `il y a ${Math.floor(s / 3600)} h ${String(Math.round((s % 3600) / 60)).padStart(2, '0')}`;
  return `il y a ${Math.floor(s / 86_400)} j`;
}

export function dur(ms) {
  if (!isNum(ms)) return '—';
  if (ms < 1) return `${nf(2).format(ms * 1000)} µs`;
  if (ms < 1000) return `${nf(ms < 10 ? 1 : 0).format(ms)} ms`;
  if (ms < 120_000) return `${nf(1).format(ms / 1000)} s`;
  return `${Math.floor(ms / 60_000)} min ${String(Math.round((ms % 60_000) / 1000)).padStart(2, '0')} s`;
}

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ESC[c]);

/** Décisions de l'IA : libellé français + classe CSS. */
export const DECISION = {
  STRONG_BUY: ['Achat fort', 'sbuy', 'Achat fort'], BUY: ['Achat', 'buy', 'Achat'], HOLD: ['Conserver / attendre', 'hold', 'Attendre'], SELL: ['Vente', 'sell', 'Vente'], STRONG_SELL: ['Vente forte', 'ssell', 'Vente forte'],
};
export const decisionChip = (d, extra = '') => (DECISION[d] ? `<span class="chip ${DECISION[d][1]}" title="${DECISION[d][0]}">${DECISION[d][2]}${extra}</span>` : '<span class="chip none">—</span>');
/** Note technique (−1 … +1) → puce. */
export function ratingChip(x, label) {
  if (!isNum(x)) return '<span class="chip none">—</span>';
  const c = x >= 0.5 ? 'sbuy' : x > 0.1 ? 'buy' : x >= -0.1 ? 'hold' : x > -0.5 ? 'sell' : 'ssell';
  return `<span class="chip ${c}">${esc(label ?? (x >= 0.5 ? 'Achat fort' : x > 0.1 ? 'Achat' : x >= -0.1 ? 'Neutre' : x > -0.5 ? 'Vente' : 'Vente forte'))}</span>`;
}

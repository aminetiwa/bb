// ============================================================================
//  BOURSO :: core/dom.js — petits outils DOM : sélection, délégation d'événements, fenêtres,
//  notifications, onglets, tri de tableaux, éclair de variation.
// ============================================================================
import { esc } from './fmt.js';

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/** Crée un élément à partir de HTML (premier élément). */
export function el(html) {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}

/** Événement délégué : on(root, 'click', '.btn', (e, target) => …). Renvoie la fonction de retrait. */
export function on(root, type, selector, fn, opts) {
  const h = (e) => {
    const t = e.target.closest?.(selector);
    if (t && root.contains(t)) fn(e, t);
  };
  root.addEventListener(type, h, opts);
  return () => root.removeEventListener(type, h, opts);
}

/** Éclair vert/rouge sur une cellule qui change (deux animations pour relancer sans reflow). */
export function flash(node, dir) {
  if (!node || !dir) return;
  const a = dir > 0 ? (node.classList.contains('fu-a') ? 'fu-b' : 'fu-a') : node.classList.contains('fd-a') ? 'fd-b' : 'fd-a';
  node.classList.remove('fu-a', 'fu-b', 'fd-a', 'fd-b');
  node.classList.add(a);
}

/** Met à jour le contenu seulement s'il change (évite les reflows inutiles). */
export function setText(node, text) {
  if (node && node.textContent !== text) node.textContent = text;
}
export function setHtml(node, html) {
  if (node && node._h !== html) {
    node.innerHTML = html;
    node._h = html;
  }
}

// ---------------------------------------------------------------- notifications
export function toast(title, text = '', kind = '', ms = 6000) {
  const box = $('#toasts');
  if (!box) return;
  const t = el(`<div class="toast ${kind}"><b>${esc(title)}</b>${text ? `<div>${text}</div>` : ''}</div>`);
  box.prepend(t);
  while (box.children.length > 5) box.lastChild.remove();
  setTimeout(() => t.remove(), ms);
  t.addEventListener('click', () => t.remove());
}

// ---------------------------------------------------------------- fenêtre modale
let modalClose = null;
/**
 * @param {{ title:string, body:string|Node, wide?:boolean, buttons?:{label:string, cls?:string, onClick?:(close)=>any}[], onClose?:()=>void }} o
 */
export function modal({ title, body, wide = false, buttons = [], onClose }) {
  modalClose?.();
  const m = $('#modal'), box = $('#modal-box');
  box.className = `modal-box${wide ? ' wide' : ''}`;
  box.innerHTML = `<h2 class="box-title">${esc(title)}<button class="btn btn-small" type="button" data-x>Fermer</button></h2><div class="modal-body"></div>${buttons.length ? '<div class="modal-foot"></div>' : ''}`;
  const b = box.querySelector('.modal-body');
  if (typeof body === 'string') b.innerHTML = body;
  else if (body) b.append(body);
  const close = () => {
    m.hidden = true;
    box.innerHTML = '';
    document.removeEventListener('keydown', key, true);
    modalClose = null;
    onClose?.();
  };
  const key = (e) => {
    if (e.key === 'Escape') { e.stopPropagation(); close(); }
  };
  document.addEventListener('keydown', key, true);
  box.querySelector('[data-x]').onclick = close;
  m.onclick = (e) => { if (e.target === m) close(); };
  const foot = box.querySelector('.modal-foot');
  for (const bt of buttons) {
    const x = el(`<button class="btn ${bt.cls ?? ''}" type="button">${esc(bt.label)}</button>`);
    x.onclick = () => (bt.onClick ? bt.onClick(close) : close());
    foot.append(x);
  }
  m.hidden = false;
  modalClose = close;
  return { close, body: b, box };
}

export function confirmBox(text, { title = 'Confirmation', ok = 'Confirmer', danger = false } = {}) {
  return new Promise((resolve) => {
    let done = false;
    modal({
      title, body: `<div class="box-body">${text}</div>`,
      buttons: [{ label: 'Annuler', onClick: (c) => { done = true; resolve(false); c(); } }, { label: ok, cls: danger ? 'sell' : 'primary', onClick: (c) => { done = true; resolve(true); c(); } }],
      onClose: () => { if (!done) resolve(false); },
    });
  });
}

// ---------------------------------------------------------------- onglets
/** Barre d'onglets : items [{ id, label }], renvoie { set(id), get() }. */
export function tabs(container, items, onChange, initial = items[0]?.id) {
  container.classList.add('tabs');
  container.innerHTML = items.map((t) => `<button type="button" data-tab="${esc(t.id)}">${t.label}</button>`).join('');
  let cur = null;
  const set = (id, silent = false) => {
    cur = id;
    for (const b of container.children) b.classList.toggle('on', b.dataset.tab === id);
    if (!silent) onChange?.(id);
  };
  container.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-tab]');
    if (b && b.dataset.tab !== cur) set(b.dataset.tab);
  });
  set(initial, true);
  return { set, get: () => cur };
}

// ---------------------------------------------------------------- tri de tableau
/**
 * Tableau triable rendu à partir de lignes de données.
 * cols : [{ key, label, cls?, sort?: (row)=>value, html:(row)=>string, title? }]
 */
export class SortTable {
  constructor(table, cols, { key, dir = -1, rowAttrs = () => '', empty = 'Aucune donnée', limit = Infinity } = {}) {
    this.t = table;
    this.cols = cols;
    this.key = key ?? null;
    this.dir = dir;
    this.rowAttrs = rowAttrs;
    this.emptyText = empty;
    this.limit = limit;
    this.rows = [];
    table.classList.add('tbl', 'sortable');
    table.innerHTML = `<thead><tr>${cols.map((c) => `<th class="${c.cls ?? ''}" data-k="${esc(c.key)}" title="${esc(c.title ?? '')}">${c.label}</th>`).join('')}</tr></thead><tbody></tbody>`;
    this.body = table.tBodies[0];
    table.tHead.addEventListener('click', (e) => {
      const th = e.target.closest('th');
      if (!th) return;
      const k = th.dataset.k, c = this.cols.find((x) => x.key === k);
      if (!c || c.sort === false) return;
      if (this.key === k) this.dir = -this.dir;
      else { this.key = k; this.dir = c.defaultDir ?? -1; }
      this.render();
    });
  }

  set(rows) {
    this.rows = rows;
    this.render();
  }

  sorted() {
    const c = this.cols.find((x) => x.key === this.key);
    if (!c) return this.rows;
    const f = c.sort ?? ((r) => r[c.key]);
    return [...this.rows].sort((a, b) => {
      const x = f(a), y = f(b);
      if (x === y) return 0;
      if (x === null || x === undefined || Number.isNaN(x)) return 1;
      if (y === null || y === undefined || Number.isNaN(y)) return -1;
      return (typeof x === 'string' ? x.localeCompare(y, 'fr') : x - y) * this.dir;
    });
  }

  render() {
    for (const th of this.t.tHead.rows[0].cells) {
      th.classList.toggle('sorted', th.dataset.k === this.key);
      th.classList.toggle('asc', th.dataset.k === this.key && this.dir > 0);
    }
    const rows = this.sorted().slice(0, this.limit);
    this.body.innerHTML = rows.length
      ? rows.map((r) => `<tr ${this.rowAttrs(r)}>${this.cols.map((c) => `<td class="${c.cls ?? ''}">${c.html(r)}</td>`).join('')}</tr>`).join('')
      : `<tr class="empty"><td colspan="${this.cols.length}">${esc(this.emptyText)}</td></tr>`;
  }
}

/** Copie de texte dans le presse-papiers (repli silencieux). */
export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    toast('Copié', '', 'ok', 1500);
  } catch { /* indisponible */ }
}

/** Téléchargement d'un fichier généré côté navigateur. */
export function saveFile(name, data, type = 'text/plain') {
  const url = URL.createObjectURL(data instanceof Blob ? data : new Blob([data], { type }));
  const a = Object.assign(document.createElement('a'), { href: url, download: name });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/** Petite courbe SVG (tableaux) : valeurs → polyline. */
export function sparkSvg(values, { w = 80, h = 22, color, fill = false, base = null } = {}) {
  const v = (values ?? []).filter((x) => Number.isFinite(x));
  if (v.length < 2) return `<svg class="spark" width="${w}" height="${h}"></svg>`;
  let lo = Math.min(...v), hi = Math.max(...v);
  if (base !== null) { lo = Math.min(lo, base); hi = Math.max(hi, base); }
  const span = hi - lo || 1, n = v.length;
  const pts = v.map((y, i) => `${((i / (n - 1)) * (w - 2) + 1).toFixed(1)},${(h - 2 - ((y - lo) / span) * (h - 4)).toFixed(1)}`).join(' ');
  const col = color ?? (v[n - 1] >= (base ?? v[0]) ? 'var(--up)' : 'var(--down)');
  const by = base !== null ? (h - 2 - ((base - lo) / span) * (h - 4)).toFixed(1) : null;
  return `<svg class="spark" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${by !== null ? `<line x1="0" x2="${w}" y1="${by}" y2="${by}" stroke="var(--border)" stroke-dasharray="2 2"/>` : ''}${fill ? `<polygon points="1,${h - 1} ${pts} ${w - 1},${h - 1}" fill="${col}" opacity="0.12"/>` : ''}<polyline points="${pts}" fill="none" stroke="${col}" stroke-width="1.3"/></svg>`;
}

/** Barre de jauge HTML (0 … 1). */
export const meter = (x, cls = '') => `<div class="meter ${cls}"><i style="width:${Math.max(0, Math.min(1, x || 0)) * 100}%"></i></div>`;
/** Jauge centrée (−1 … +1). */
export function meterCenter(x) {
  const v = Math.max(-1, Math.min(1, x || 0));
  return `<div class="meter center"><i style="left:${v >= 0 ? 50 : 50 + v * 50}%;width:${Math.abs(v) * 50}%;background:${v >= 0 ? 'var(--up)' : 'var(--down)'}"></i></div>`;
}

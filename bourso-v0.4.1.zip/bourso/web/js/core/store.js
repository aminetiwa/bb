// ============================================================================
//  BOURSO :: core/store.js — état partagé de l'interface : univers des valeurs, cotations en
//  direct, favoris, réglages, horloges des places, file de l'IA, screener, actualités récentes.
// ============================================================================
import { get, put, post } from './api.js';
import { live, Emitter } from './live.js';

class Store extends Emitter {
  constructor() {
    super();
    this.meta = null;
    this.universe = [];
    this.bySym = new Map();
    this.quotes = new Map();
    this.favorites = [];
    this.settings = null;
    this.clocks = [];
    this.ai = { queue: null, ollama: null, model: null, running: null };
    this.screen = { rows: [], at: 0, bySym: new Map() };
    this.news = [];
    this.lastSym = null;
  }

  /** Données réelles (sources gratuites) ou démonstration (simulateur). */
  get real() {
    return Boolean(this.meta?.data?.real);
  }
  /** Ce que la source sait fournir (carnet, bande, secondes, flux acheteurs/vendeurs). */
  get caps() {
    return this.meta?.data?.capabilities ?? { book: true, tape: true, seconds: true, flow: true };
  }

  info(sym) {
    return this.bySym.get(sym) ?? null;
  }
  name(sym) {
    return this.bySym.get(sym)?.name ?? sym;
  }
  quote(sym) {
    return this.quotes.get(sym) ?? null;
  }
  row(sym) {
    return this.screen.bySym.get(sym) ?? null;
  }
  tick(sym) {
    return this.bySym.get(sym)?.tick ?? 0.01;
  }
  isFav(sym) {
    return this.favorites.includes(sym);
  }

  async toggleFav(sym) {
    return this.setFavorites(this.isFav(sym) ? this.favorites.filter((s) => s !== sym) : [...this.favorites, sym]);
  }
  async setFavorites(list) {
    this.favorites = await put('/api/favorites', list);
    this.emit('favorites', this.favorites);
    return this.favorites;
  }
  async saveSettings(patch) {
    this.settings = await put('/api/settings', patch);
    this.emit('settings', this.settings);
    return this.settings;
  }

  /** Recharge l'univers (une valeur a été ajoutée par la recherche mondiale). */
  async refreshUniverse() {
    this.universe = await get('/api/universe');
    this.bySym = new Map(this.universe.map((u) => [u.sym, u]));
    this.emit('universe', this.universe);
  }

  /** Ajoute à Bourso une valeur trouvée par la recherche mondiale (symbole Yahoo) ; renvoie son symbole. */
  async addExternal(x) {
    const r = await post('/api/data/add', { yahoo: x.yahoo, name: x.name, exchange: x.exchangeCode ?? null, sector: x.sector ?? null });
    await this.refreshUniverse();
    return r.sym;
  }

  async refreshScreener() {
    const r = await get('/api/screener');
    this.screen = { rows: r.rows, at: r.at, ms: r.ms, bySym: new Map(r.rows.map((x) => [x.sym, x])) };
    this.emit('screener', this.screen);
    return this.screen;
  }

  #applyQuote(a) {
    const [sym, last, chgPct, volume, bid, ask, high, low, open, prev, turnover] = a;
    const old = this.quotes.get(sym);
    const q = { sym, last, chgPct, volume, bid, ask, high, low, open, prev, turnover, dir: old ? Math.sign(last - old.last) : 0, at: Date.now() };
    this.quotes.set(sym, q);
    return q;
  }

  async init() {
    const [meta, universe] = await Promise.all([get('/api/meta'), get('/api/universe')]);
    this.meta = meta;
    this.settings = meta.settings;
    this.favorites = meta.favorites;
    this.universe = universe;
    this.bySym = new Map(universe.map((u) => [u.sym, u]));
    this.exchanges = new Map(meta.exchanges.map((e) => [e.mic, e]));
    live.on('hello', (m) => {
      for (const a of m.quotes) this.#applyQuote(a);
      this.clocks = m.clocks;
      Object.assign(this.ai, { queue: m.ai, ollama: m.ollama, model: m.model });
      this.emit('quotes', null);
      this.emit('clock', this.clocks);
      this.emit('ai', { ev: 'queue', queue: m.ai });
    });
    live.on('q', (m) => {
      const changed = [];
      for (const a of m.d) changed.push(this.#applyQuote(a));
      this.emit('quotes', changed);
    });
    live.on('clock', (m) => {
      this.clocks = m.clocks;
      this.emit('clock', this.clocks);
    });
    live.on('news', (m) => {
      this.news.unshift(m.item);
      if (this.news.length > 300) this.news.length = 300;
      this.emit('news', m.item);
    });
    live.on('ai', (m) => {
      if (m.ev === 'queue') {
        this.ai.queue = m.queue;
        this.ai.running = m.queue.running;
      }
      this.emit('ai', m);
    });
    live.on('favorites', (m) => {
      this.favorites = m.favorites;
      this.emit('favorites', this.favorites);
    });
    live.on('settings', (m) => {
      this.settings = m.settings;
      this.emit('settings', this.settings);
    });
    live.on('screener', () => this.refreshScreener().catch(() => {}));
    live.on('universe', () => this.refreshUniverse().catch(() => {}));
    // bascule données réelles ↔ démonstration : l'interface repart sur les nouvelles données
    live.on('reload', () => setTimeout(() => location.reload(), 300));
    live.connect();
    const [news] = await Promise.all([get('/api/news?limit=120'), this.refreshScreener()]);
    this.news = news;
    try { this.lastSym = localStorage.getItem('bourso.lastSym'); } catch { /* stockage indisponible */ }
    if (!this.bySym.has(this.lastSym)) this.lastSym = this.favorites[0] ?? universe[0]?.sym;
  }

  remember(sym) {
    this.lastSym = sym;
    try { localStorage.setItem('bourso.lastSym', sym); } catch { /* stockage indisponible */ }
  }
}

export const S = new Store();

/** Préférences d'affichage locales (onglets, colonnes…) : jamais bloquant si le stockage est indisponible. */
export const prefs = {
  get(key, def) {
    try {
      const v = localStorage.getItem(`bourso.${key}`);
      return v === null ? def : JSON.parse(v);
    } catch { return def; }
  },
  set(key, v) {
    try { localStorage.setItem(`bourso.${key}`, JSON.stringify(v)); } catch { /* stockage indisponible */ }
  },
};

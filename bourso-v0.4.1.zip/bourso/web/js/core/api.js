// ============================================================================
//  BOURSO :: core/api.js — appels REST au serveur local + décodage des historiques binaires.
//  Format binaire : [u32 longueur][en-tête JSON][bourrage → 8][5 × count float64 (O H L C V)].
// ============================================================================
export class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export async function api(path, { method = 'GET', body, signal } = {}) {
  const init = { method, signal, headers: {} };
  if (body !== undefined) {
    init.headers['content-type'] = 'application/json';
    init.body = JSON.stringify(body);
  }
  let r;
  try {
    r = await fetch(path, init);
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    throw new ApiError(0, 'serveur Bourso injoignable (npm start lancé ?)');
  }
  const ct = r.headers.get('content-type') ?? '';
  const data = ct.includes('json') ? await r.json() : await r.arrayBuffer();
  if (!r.ok) throw new ApiError(r.status, data?.error ?? `HTTP ${r.status}`);
  return data;
}

export const get = (p, o) => api(p, o);
export const post = (p, body = {}, o = {}) => api(p, { ...o, method: 'POST', body });
export const put = (p, body = {}) => api(p, { method: 'PUT', body });
export const del = (p) => api(p, { method: 'DELETE' });

/** Historique d'une valeur à l'unité de temps `tf` (tableaux Float64Array, aucune copie). */
export async function history(sym, tf, { days, signal } = {}) {
  const q = new URLSearchParams({ sym, tf });
  if (days) q.set('days', days);
  const buf = await api(`/api/history?${q}`, { signal });
  const dv = new DataView(buf), hl = dv.getUint32(0, true);
  const header = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, 4, hl)));
  const off = Math.ceil((4 + hl) / 8) * 8, n = header.count;
  const arr = (k) => new Float64Array(buf, off + k * n * 8, n);
  return { header, open: arr(0), high: arr(1), low: arr(2), close: arr(3), volume: arr(4) };
}

/** Lien de téléchargement (export CSV servi par le serveur). */
export function download(path) {
  const a = Object.assign(document.createElement('a'), { href: path, download: '' });
  document.body.append(a);
  a.click();
  a.remove();
}

// ============================================================================
//  BOURSO :: app.js — démarrage de l'interface : état partagé, temps réel, routeur des pages
//  (chaque bouton du menu ouvre sa page), recherche, bandeau défilant, barre d'état,
//  notifications (ordres exécutés, alertes, décisions de l'IA), raccourcis clavier.
// ============================================================================
import { S } from './core/store.js';
import { live } from './core/live.js';
import { get } from './core/api.js';
import { $, $$, el, toast, setText } from './core/dom.js';
import { post } from './core/api.js';
import { esc, pct, price, cls, eur, num, DECISION, rate } from './core/fmt.js';
import { openTicket } from './widgets/order-ticket.js';
import { localTimeOf, EXCHANGES } from '/src/market/exchanges.js';

const PAGES = {
  accueil: () => import('./pages/home.js'),
  marches: () => import('./pages/markets.js'),
  valeur: () => import('./pages/stock.js'),
  favoris: () => import('./pages/favorites.js'),
  ia: () => import('./pages/ai.js'),
  agent: () => import('./pages/agent.js'),
  actualites: () => import('./pages/news.js'),
  portefeuille: () => import('./pages/portfolio.js'),
  labo: () => import('./pages/lab.js'),
  outils: () => import('./pages/tools.js'),
  systeme: () => import('./pages/system.js'),
  reglages: () => import('./pages/settings.js'),
  aide: () => import('./pages/help.js'),
};

// ---------------------------------------------------------------- routeur
let current = { name: null, inst: null, token: 0 };

function parseHash() {
  const raw = location.hash.replace(/^#\/?/, '');
  const [path, query = ''] = raw.split('?');
  const parts = path.split('/').filter(Boolean).map(decodeURIComponent);
  return { name: PAGES[parts[0]] ? parts[0] : 'accueil', params: parts.slice(1), query: new URLSearchParams(query) };
}

export function navigate(hash) {
  if (location.hash === hash) route();
  else location.hash = hash;
}

async function route() {
  const r = parseHash(), token = ++current.token;
  for (const a of $$('#nav a')) a.classList.toggle('active', a.dataset.page === r.name);
  const ctx = { params: r.params, query: r.query, navigate };
  if (current.name === r.name && current.inst?.update) {
    current.inst.update(ctx);
    return;
  }
  const mod = (await PAGES[r.name]()).default;
  if (token !== current.token) return;
  try { current.inst?.unmount?.(); } catch (e) { console.error(e); }
  const root = $('#page');
  root.innerHTML = '';
  document.title = `${mod.title} — Bourso`;
  window.scrollTo(0, 0);
  current = { name: r.name, inst: null, token };
  try {
    current.inst = (await mod.mount(root, ctx)) ?? null;
  } catch (e) {
    console.error(e);
    root.innerHTML = `<div class="box"><h2 class="box-title">Erreur d'affichage</h2><div class="box-body err">${esc(e.stack ?? e.message)}</div></div>`;
  }
}

// ---------------------------------------------------------------- recherche (toutes les places, Europe d'abord)
function setupSearch() {
  const input = $('#search'), box = $('#suggest'), form = $('#search-form');
  let items = [], sel = -1, timer = null, seq = 0;
  const close = () => { box.classList.add('hidden'); sel = -1; };
  const render = () => {
    box.innerHTML = items.length ? items.map((x, i) => (x.external
      ? `<a href="#" class="${i === sel ? 'on' : ''} ext" data-i="${i}" data-ext="${i}" title="Valeur pas encore suivie : un clic l'ajoute à Bourso (cours, historique, actualités)">
      <span class="code">${esc(x.code)}</span><span>${esc(x.name)} <span class="where">${esc(x.ex ?? '')}${x.type ? ` · ${esc(x.type)}` : ''}</span></span><span class="chip ok">+ ajouter</span><span></span></a>`
      : `<a href="#/valeur/${encodeURIComponent(x.sym)}" class="${i === sel ? 'on' : ''}" data-i="${i}">
      <span class="code">${esc(x.code)}</span><span>${esc(x.name)} <span class="where">${esc(x.ex)}${x.country ? ` · ${esc(x.country)}` : ''}</span></span>
      <span class="num">${price(x.last, S.tick(x.sym))} ${esc(x.ccy ?? '')}</span><span class="num ${cls(x.chgPct)}">${pct(x.chgPct)}</span></a>`)).join('')
      : `<div class="empty">Aucune valeur trouvée${S.real ? ' (ni dans Bourso, ni dans la recherche mondiale)' : ''}</div>`;
    box.classList.remove('hidden');
  };
  input.addEventListener('input', () => {
    clearTimeout(timer);
    const v = input.value.trim();
    if (!v) { close(); return; }
    timer = setTimeout(async () => {
      const my = ++seq, r = await get(`/api/search?q=${encodeURIComponent(v)}&limit=14`).catch(() => []);
      if (my !== seq) return;
      items = r;
      sel = -1;
      render();
    }, 110);
  });
  input.addEventListener('keydown', (e) => {
    if (box.classList.contains('hidden')) return;
    if (e.key === 'ArrowDown') { sel = Math.min(items.length - 1, sel + 1); render(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { sel = Math.max(0, sel - 1); render(); e.preventDefault(); }
    else if (e.key === 'Escape') close();
  });
  /** Valeur de la recherche mondiale : ajoutée à Bourso puis ouverte. */
  const addExt = async (x) => {
    toast('Ajout de la valeur', `${esc(x.name)} (${esc(x.yahoo)}) : cours et historique en cours de chargement…`, '', 2500);
    try {
      const sym = await S.addExternal({ ...x, exchangeCode: null });
      toast('Valeur ajoutée', `${esc(x.name)} est maintenant suivie par Bourso`, 'ok', 3000);
      navigate(`#/valeur/${encodeURIComponent(sym)}`);
    } catch (err) { toast('Ajout impossible', esc(err.message), 'ko', 6000); }
  };
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const x = items[Math.max(0, sel)];
    if (!x) return;
    input.value = '';
    input.blur();
    close();
    if (x.external) addExt(x);
    else navigate(`#/valeur/${encodeURIComponent(x.sym)}`);
  });
  box.addEventListener('click', (e) => {
    const a = e.target.closest('[data-ext]');
    if (a) { e.preventDefault(); addExt(items[Number(a.dataset.ext)]); }
    input.value = '';
    close();
  });
  document.addEventListener('click', (e) => { if (!form.contains(e.target)) close(); });
}

// ---------------------------------------------------------------- en-tête : séance et horloge (Paris)
function setupClock() {
  let paris = null, at = 0;
  const upd = () => {
    paris = S.clocks.find((c) => c.mic === 'XPAR') ?? S.clocks[0];
    at = Date.now();
  };
  S.on('clock', upd);
  upd();
  setInterval(() => {
    if (!paris) return;
    if (S.real) {
      // données réelles : heure réelle de Paris et état réel de la séance
      setText($('#clock'), new Date().toLocaleTimeString('fr-FR', { timeZone: paris.tz ?? 'Europe/Paris' }));
      setText($('#session'), `${paris.short} : ${(paris.realLabel ?? '').toLowerCase()}`);
      return;
    }
    const ex = EXCHANGES[paris.mic];
    const sec = Math.min(paris.sessionSec, paris.sec + (paris.live ? (Date.now() - at) / 1000 : 0));
    setText($('#clock'), ex ? localTimeOf(ex, Math.floor(sec)) : paris.time);
    setText($('#session'), `${paris.short} : ${paris.live ? 'séance en cours' : 'fermée'}${paris.label?.includes('démo') ? ' (démo)' : ''}`);
  }, 500);
}

// ---------------------------------------------------------------- bandeau défilant (indices + favoris)
async function refreshTicker() {
  try {
    const o = await get('/api/overview');
    S.overview = o;
    S.emit('overview', o);
    const order = ['EUROPE', 'XPAR', 'XETR', 'XAMS', 'XLON', 'XMIL', 'XMAD', 'XSWX', 'MONDE', 'XNYS', 'XNAS', 'XTKS', 'XHKG'];
    const idx = order.map((k) => o.indices.find((i) => i.key === k)).filter(Boolean);
    const favs = S.favorites.map((s) => [s, S.quote(s)]).filter(([, q]) => q);
    const html = [...idx.filter((i) => Number.isFinite(i.level)).map((i) => `<span class="item" data-href="#/marches/places"><b>${esc(i.name.replace(' (panier sim.)', ''))}</b> ${num(i.level, 2)} <span class="${cls(i.chgPct)}">${pct(i.chgPct)}</span></span>`),
      ...favs.map(([s, q]) => `<span class="item" data-href="#/valeur/${encodeURIComponent(s)}">★ <b>${esc(S.name(s))}</b> ${price(q.last, S.tick(s))} <span class="${cls(q.chgPct)}">${pct(q.chgPct)}</span></span>`)].join('');
    $('#ticker').innerHTML = html + html; // deux copies : défilement continu
  } catch { /* serveur indisponible : on réessaiera */ }
}

// ---------------------------------------------------------------- barre d'état
const sys = { info: null, pf: null };
async function refreshSys() {
  try {
    sys.info = await get('/api/system');
    S.ai.ollama = sys.info.ollama;
    S.ai.model = sys.info.model;
    S.sys = sys.info;
    S.emit('system', sys.info);
  } catch { /* indisponible */ }
}
async function refreshPf() {
  try { sys.pf = await get('/api/portfolio'); } catch { /* indisponible */ }
}
function renderStatus() {
  const s = sys.info, o = S.ai.ollama, run = S.ai.queue?.running, w = live.status === 'open';
  const parts = [
    `Temps réel : <b class="${w ? 'ok' : 'ko'}">${w ? 'connecté' : 'reconnexion…'}</b> (${live.stats.rate} msg/s)`,
    S.real
      ? `<a href="#/systeme">Données réelles : <b>${S.universe.length} actions · ${S.meta?.exchanges.length ?? '—'} places</b>${s?.market?.quotesLive !== undefined ? ` · cours ${s.market.quotesLive}/${s.market.instruments} · historiques ${s.market.histories}` : ''}${s?.market?.yahooPausedUntil > Date.now() ? ` · <b class="warn" title="Yahoo a refusé des requêtes (429) : Bourso ne lui demande plus rien jusqu'à la fin de la pause, puis reprend seul. Derniers cours connus affichés.">Yahoo en pause jusqu'à ${new Date(s.market.yahooPausedUntil).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</b>` : ''}</a>`
      : `Marché simulé : <b>${S.universe.length} actions · ${S.meta?.exchanges.length ?? '—'} places</b>`,
    o ? (o.up ? `<a href="#/reglages">IA : <b class="${s?.modelStatus?.analysis?.installed === false ? 'warn' : 'ok'}">${esc(S.ai.model ?? '—')}</b>${s?.modelStatus?.analysis?.installed === false ? ` (« ${esc(s.modelStatus.analysis.wanted)} » absent)` : ''}</a> · Ollama ${esc(o.version ?? '')}` : '<a href="#/reglages" class="warn">IA : Ollama injoignable → réponses simulées</a>') : 'IA : —',
    run ? `Analyse en cours : <b>${esc(run.name)}</b> (${esc(run.stage ?? '')})` : `File IA : <b>${S.ai.queue?.manual?.length ?? 0}</b> demande(s)`,
  ];
  if (s) {
    const g = s.compute.gpu;
    parts.push(`GPU : <b class="${g.ok && !g.software ? 'ok' : 'warn'}">${g.ok ? esc(`${g.vendor} ${g.description !== '—' ? g.description : g.architecture}`.slice(0, 40)) : 'non utilisé'}</b>`);
    parts.push(`CPU : <b>${s.snapshot.cpu.cores} cœurs · ${Math.round(s.snapshot.cpu.avg * 100)} %</b> · niveau <b>${esc(s.compute.levels[s.compute.level])}</b>`);
    if (s.compute.rates.mcCpu || s.compute.rates.mcGpu) parts.push(`Monte Carlo : <b>${rate((s.compute.rates.mcGpu ?? 0) + (s.compute.rates.mcCpu ?? 0), ' pas/s')}</b>`);
  }
  if (sys.pf) parts.push(`<a href="#/portefeuille">Portefeuille : <b>${eur(sys.pf.totalEur)}</b> <span class="${sys.pf.perfPct >= 0 ? 'ok' : 'ko'}">${pct(sys.pf.perfPct)}</span></a>`);
  $('#status-bar').innerHTML = parts.join('<span>·</span>');
  const n = (S.ai.queue?.manual?.length ?? 0) + (run ? 1 : 0), badge = $('#nav-ia');
  badge.classList.toggle('hidden', !n);
  badge.textContent = n;
}

// ---------------------------------------------------------------- notifications globales
function setupToasts() {
  live.on('fill', ({ ex }) => toast('Ordre exécuté', `${ex.side === 'BUY' ? 'Achat' : 'Vente'} de ${num(ex.qty, 0)} ${esc(ex.name)} à ${price(ex.px, S.tick(ex.sym))} ${esc(ex.ccy)}`, 'ok'));
  live.on('alert', ({ alert: a }) => {
    const cond = a.op === 'above' ? `≥ ${price(a.value, S.tick(a.sym))}` : a.op === 'below' ? `≤ ${price(a.value, S.tick(a.sym))}` : a.op === 'chg_above' ? `variation ≥ ${pct(a.value)}` : `variation ≤ ${pct(a.value)}`;
    toast(`Alerte : ${a.name}`, `${cond} — cours ${price(a.triggerPrice, S.tick(a.sym))}${a.note ? `<br><i>${esc(a.note)}</i>` : ''} <a href="#/valeur/${encodeURIComponent(a.sym)}">Voir</a>`, 'warn', 12000);
  });
  S.on('ai', (m) => {
    if (m.ev === 'result' && current.name !== 'ia') {
      const sg = m.signal, d = DECISION[sg.decision] ?? [sg.decision, 'hold'];
      toast(`IA : ${sg.name}`, `<span class="chip ${d[1]}">${d[0]}</span> confiance ${Math.round(sg.confidence * 100)} %${sg.simulated ? ' <span class="chip sim">simulé</span>' : ''} — <a href="#/ia/${encodeURIComponent(sg.id)}">détails</a>`, sg.decision.includes('BUY') ? 'ok' : sg.decision.includes('SELL') ? 'ko' : '', 9000);
    }
    renderStatus();
  });
  live.on('agent', (m) => {
    if (m.type === 'done' && current.name !== 'agent') toast('Bourso Pro a répondu', `<a href="#/agent/${encodeURIComponent(m.conv)}">Ouvrir la discussion</a>`, '', 8000);
  });
  live.on('pf', () => { clearTimeout(sys.pfT); sys.pfT = setTimeout(() => refreshPf().then(renderStatus), 400); });
}

// ---------------------------------------------------------------- raccourcis globaux
function setupKeys() {
  document.addEventListener('keydown', (e) => {
    const typing = /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName ?? '');
    if (e.key === 'F1' || e.key === 'F2') {
      e.preventDefault();
      const sym = current.name === 'valeur' && current.inst?.sym ? current.inst.sym : S.lastSym;
      openTicket(sym, e.key === 'F1' ? 'BUY' : 'SELL');
      return;
    }
    if (typing) return;
    if (e.key === '/' || (e.ctrlKey && e.key.toLowerCase() === 'k')) { e.preventDefault(); $('#search').focus(); }
  });
}

function setupTheme() {
  const btn = $('#theme-toggle');
  const sync = () => { btn.textContent = document.documentElement.dataset.theme === 'dark' ? 'Thème clair' : 'Thème sombre'; };
  btn.addEventListener('click', () => {
    const t = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = t;
    try { localStorage.setItem('bourso.theme', t); } catch { /* stockage indisponible */ }
    sync();
    S.emit('theme', t);
  });
  sync();
}

// ---------------------------------------------------------------- démarrage
async function boot() {
  setupTheme();
  try {
    await S.init();
  } catch (e) {
    $('#page').innerHTML = `<div class="box"><h2 class="box-title">Serveur Bourso injoignable</h2><div class="box-body">${esc(e.message)}<p>Lance le serveur avec <kbd>npm start</kbd> puis recharge la page.</p></div></div>`;
    return;
  }
  // bandeau : nature des données
  const ban = $('#data-banner');
  if (S.real) {
    ban.classList.add('real');
    ban.innerHTML = `Données <b>réelles</b> de sources publiques gratuites (Yahoo Finance, BCE, Google Actualités, GDELT, presse) : cours <b>différés</b> (≈ 15 min en Europe). Portefeuille et ordres <b>fictifs</b> : rien n'est transmis à un courtier. Aucune analyse n'est une garantie. <a href="#/systeme">État des sources</a>`;
  } else ban.innerHTML = 'Démonstration : cours, actualités, fondamentaux et ordres <b>simulés</b> (aucune donnée réelle, aucun ordre transmis). Les calculs, eux, sont exacts. <a href="#/reglages">Passer aux données réelles</a>';
  setupSearch();
  setupClock();
  setupToasts();
  setupKeys();
  $('#ticker').addEventListener('click', (e) => { const it = e.target.closest('[data-href]'); if (it) navigate(it.dataset.href); });
  live.on('status', renderStatus);
  S.on('settings', () => refreshSys().then(renderStatus));
  await Promise.all([refreshSys(), refreshPf()]);
  renderStatus();
  refreshTicker();
  setInterval(refreshTicker, 10_000);
  setInterval(() => refreshSys().then(renderStatus), 20_000);
  setInterval(renderStatus, 2000);
  window.addEventListener('hashchange', route);
  route();
}

boot();

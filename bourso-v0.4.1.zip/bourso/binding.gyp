{
  "targets": [
    {
      "target_name": "bourso_native",
      "sources": ["native/src/addon.cc"],
      "include_dirs": ["native/include"],
      "dependencies": ["<!(node -p \"require('node-addon-api').targets\"):node_addon_api_except"],
      "defines": ["NAPI_VERSION=8"],
      "conditions": [
        ["OS=='linux' and target_arch=='x64'", {
          "cflags_cc": ["-O3", "-march=native", "-fno-math-errno", "-ffp-contract=off", "-pthread", "-Wall", "-Wextra"], "ldflags": ["-pthread"]
        }],
        ["OS=='linux' and target_arch!='x64'", {
          "cflags_cc": ["-O3", "-mcpu=native", "-fno-math-errno", "-ffp-contract=off", "-Wall", "-Wextra"]
        }],
        ["OS=='mac'", {
          "xcode_settings": {
            "MACOSX_DEPLOYMENT_TARGET": "11.0",
            "OTHER_CPLUSPLUSFLAGS": ["-O3", "-fno-math-errno", "-ffp-contract=off"]
          }
        }],
        ["OS=='win'", {
          "msvs_settings": {
            "VCCLCompilerTool": { "AdditionalOptions": ["/O2", "/arch:AVX2", "/fp:precise"] }
          }
        }]
      ]
    }
  ]
}

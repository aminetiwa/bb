// ============================================================================
//  BOURSO :: compute/quant.worker.js — worker de calcul (worker_threads).
//  Reçoit des tâches { id, type, payload } ; les séries arrivent en SharedArrayBuffer (zéro copie)
//  ou en ArrayBuffer transféré. Aucune tâche ne bloque le thread du serveur.
// ============================================================================
import { parentPort } from 'node:worker_threads';
import { buildDossier, dossierText, aggregateBars } from '../core/quant/dossier.js';
import { technicalRating } from '../core/quant/signals.js';
import { walkForward, STRATEGIES, backtest, cumulative } from '../core/quant/backtest.js';
import { fitHmm, fitHmmAuto } from '../core/quant/hmm.js';
import { cycleAnalysis } from '../core/quant/fft.js';
import { historicalAnalogs } from '../core/quant/analogs.js';
import * as I from '../core/quant/indicators.js';
import * as V from '../core/quant/volatility.js';
import * as S from '../core/quant/stats.js';
import { isNum } from '../core/quant/numeric.js';
import { simulateMC } from '../core/quant/montecarlo.js';

const last = (a) => a[a.length - 1];
const r = (x, d = 4) => (isNum(x) ? Number(x.toFixed(d)) : null);

/** Métriques de screener d'une valeur (quotidien terminé + cotation du jour). */
function screenRow(x) {
  const d = x.daily, n = d.n;
  const c = new Float64Array(n + 1), h = new Float64Array(n + 1), l = new Float64Array(n + 1), o = new Float64Array(n + 1), v = new Float64Array(n + 1);
  c.set(d.close.subarray(0, n)); h.set(d.high.subarray(0, n)); l.set(d.low.subarray(0, n)); o.set(d.open.subarray(0, n)); v.set(d.volume.subarray(0, n));
  const q = x.quote;
  c[n] = q.last; h[n] = Math.max(q.high, q.last); l[n] = Math.min(q.low, q.last); o[n] = q.open; v[n] = q.volume;
  const N = n + 1, px = q.last, perf = (k) => (N > k ? (px / c[N - 1 - k] - 1) * 100 : NaN);
  const rs = I.rsi(c, 14), m = I.macd(c), ax = I.adx(h, l, c, 14), at = I.atr(h, l, c, 14), st = I.supertrend(h, l, c, 10, 3);
  const e20 = I.ema(c, 20), e50 = I.ema(c, 50), s200 = I.sma(c, 200), bb = I.bollinger(c, 20, 2);
  const ret = V.logReturns(c), ret1y = ret.subarray(Math.max(1, N - 252));
  const vol20 = last(V.rollingVol(c, 20)), dd = S.drawdowns(c.subarray(Math.max(0, N - 252)));
  const ext = I.extremes(h, l, Math.max(0, N - 252));
  let vAvg = 0;
  for (let i = Math.max(0, n - 20); i < n; i++) vAvg += v[i];
  vAvg /= Math.min(20, n);
  const tr = technicalRating({ open: o, high: h, low: l, close: c, volume: v });
  const hu = S.hurst(ret.subarray(Math.max(1, N - 504)));
  // x.dates = les DERNIÈRES dates du quotidien terminé (pas forcément tout l'historique) : on recale
  // l'indice sur la série complète c (n séances terminées + la séance du jour)
  const ytdIdx = x.dates?.length ? n - x.dates.length + x.dates.findIndex((s) => s.slice(0, 4) === x.dates[x.dates.length - 1].slice(0, 4)) : -1;
  return {
    sym: x.sym, perf1s: r(perf(5), 2), perf1m: r(perf(21), 2), perf3m: r(perf(63), 2), perf6m: r(perf(126), 2), perf1a: r(perf(252), 2), perf5a: r(perf(N - 1), 2),
    ytd: ytdIdx > 0 ? r((px / c[ytdIdx - 1] - 1) * 100, 2) : null,
    rsi14: r(last(rs), 1), macdHist: r(last(m.hist), 4), adx: r(last(ax.adx), 1), diPlus: r(last(ax.pdi), 1), diMinus: r(last(ax.mdi), 1),
    atrPct: r((last(at) / px) * 100, 2), vol20: r(vol20 * 100, 1), supertrend: last(st.dir) > 0 ? 1 : -1,
    aboveEma20: px > last(e20), aboveEma50: px > last(e50), aboveSma200: px > last(s200), ema50: r(last(e50), 4), sma200: r(last(s200), 4),
    bollPctB: r(last(bb.pctB), 3), bollWidth: r(last(bb.width) * 100, 2),
    hi52: ext.hi, lo52: ext.lo, distHi52: r((px / ext.hi - 1) * 100, 2), distLo52: r((px / ext.lo - 1) * 100, 2),
    relVol: vAvg > 0 ? r(q.volume / (vAvg * Math.max(0.05, x.sessionFrac)), 2) : null, avgVol20: Math.round(vAvg),
    maxDD1a: r(dd.maxDD * 100, 1), sharpe1a: r(S.sharpe(ret1y), 2), var95: r(S.varHistorical(ret1y, 0.05).var * 100, 2),
    rating: r(tr.rating, 3), ratingKey: tr.key, ratingLabel: tr.label, hurst: r(hu, 3),
    trendScore: r((px > last(e20) ? 1 : -1) * 0.3 + (px > last(e50) ? 1 : -1) * 0.3 + (px > last(s200) ? 1 : -1) * 0.2 + (last(st.dir) > 0 ? 0.2 : -0.2), 2),
  };
}

const TASKS = {
  dossier: (p) => {
    const d = buildDossier(p);
    return { dossier: d, text: dossierText(d) };
  },
  screen: (p) => p.items.map((x) => {
    try {
      return screenRow(x);
    } catch (e) {
      return { sym: x.sym, error: e.message };
    }
  }),
  technical: (p) => technicalRating(p.data),
  walkforward: (p) => {
    const ids = p.strategies ?? Object.keys(STRATEGIES).filter((k) => k !== 'buy_hold');
    const bpy = p.barsPerYear ?? 252, N = p.data.close.length;
    const wfs = ids.map((id) => walkForward(p.data, id, { folds: p.folds ?? 4, costBps: p.costBps ?? 5, barsPerYear: bpy, short: p.short ?? false })).filter(Boolean);
    // une seule grille de dates pour toutes les courbes (≈ 300 points), à partir du premier jour hors échantillon
    const from = wfs.length ? Math.min(...wfs.map((w) => w.from)) : 1;
    const step = Math.max(1, Math.floor((N - from) / 300)), idx = [];
    for (let t = from; t < N; t += step) idx.push(t);
    if (idx.at(-1) !== N - 1) idx.push(N - 1);
    // référence achat-conservation sur la MÊME période hors échantillon (comparaison équitable)
    const bh = backtest(p.data, 'buy_hold', {}, { barsPerYear: bpy, costBps: p.costBps ?? 5, from, to: N });
    const bhEq = cumulative(bh.ret, from);
    return {
      from, dates: idx.map((t) => p.data.dates?.[t] ?? null),
      results: wfs.map((w) => ({ ...w, equity: idx.map((t) => (t >= w.from ? w.equity[t] : null)) })),
      buyHold: bh.metrics, buyHoldEquity: idx.map((t) => bhEq[t]),
    };
  },
  hmm: (p) => {
    const m = p.K ? fitHmm(p.returns, { K: p.K, restarts: p.restarts ?? 8 }) : fitHmmAuto(p.returns, { Ks: [2, 3, 4], restarts: p.restarts ?? 8 });
    if (!m) return null;
    const { forecast, ...rest } = m;
    return { ...rest, viterbi: Array.from(m.viterbi), forecast5: forecast(5), forecast20: forecast(20) };
  },
  cycles: (p) => cycleAnalysis(p.close, p.opts ?? {}),
  correlation: (p) => {
    const M = S.correlationMatrix(p.series);
    const order = p.series.length <= 80 ? S.clusterOrder(M) : p.series.map((_, i) => i);
    return { matrix: M.map((row) => Array.from(row, (v) => r(v, 3))), order };
  },
  analogs: (p) => {
    const d = p.data, h = p.horizons ?? [5, 20], maxH = Math.max(...h), back = p.back ?? 20;
    const a = historicalAnalogs(d, { k: p.k ?? 30, horizons: h, spacing: p.spacing ?? 5, dates: d.dates });
    if (!a) return null;
    // trajectoires superposées : de t − back à t + maxH, base 100 au jour de l'analogue
    const c = d.close, n = c.length;
    const paths = a.nearest.map((nb) => Array.from({ length: back + maxH + 1 }, (_, i) => { const t = nb.t - back + i; return t >= 0 && t < n ? (100 * c[t]) / c[nb.t] : null; }));
    const current = Array.from({ length: back + 1 }, (_, i) => { const t = n - 1 - back + i; return (100 * c[t]) / c[n - 1]; });
    // trajectoire moyenne des analogues (tous, pas seulement les 8 plus proches) pour l'horizon le plus long
    return { ...a, back, maxH, paths, current };
  },
  stats: (p) => {
    const ret = V.logReturns(p.close);
    return { moments: S.moments(ret), jb: S.jarqueBera(ret), acf: S.acf(ret, 20), ljung: S.ljungBox(ret, 10), hurst: S.hurst(ret), vr: S.varianceRatio(ret, 5), adf: S.adf(Array.from(p.close, Math.log)) };
  },
  aggregate: (p) => aggregateBars(p.data, p.k, p.sessionBars),
  /** Monte Carlo JavaScript (repli quand l'addon C++ n'est pas compilé) : une tranche de trajectoires. */
  mc: (p) => {
    const t0 = performance.now();
    const r = simulateMC({ ...p, returns: p.returns ? Float64Array.from(p.returns) : undefined, range: { lo: p.rangeLo, hi: p.rangeHi } });
    return { hist: r.hist, cpHist: r.cpHist, sum: r.sum, sum2: r.sum2, minSum: r.minSum, upCount: r.upCount, hitUp: r.hitUp, hitDown: r.hitDown, paths: r.paths, ms: performance.now() - t0 };
  },
  /** Balayage JavaScript (repli) : une tranche de combinaisons, mêmes 10 métriques que le C++/GPU. */
  sweep: (p) => {
    const ids = ['ema_cross', 'sma_cross', 'rsi_revert', 'boll_revert', 'donchian_break', 'macd_cross'];
    const out = new Float64Array(p.K * 10), d = { open: p.open, high: p.high, low: p.low, close: p.close };
    for (let k = 0; k < p.K; k++) {
      const prm = Object.fromEntries(p.keys.map((key, j) => [key, p.params[k * p.P + j]]));
      const m = backtest(d, ids[p.strategy], prm, { costBps: p.costBps, short: p.short, barsPerYear: p.barsPerYear }).metrics;
      out.set([m.totalReturn, m.annReturn, m.sharpe, m.sortino, m.maxDD, m.trades, m.winRate, m.profitFactor, m.exposure, m.annVol], k * 10);
    }
    return { metrics: out };
  },
  /** Charge CPU pure (banc d'essai) : indicateurs sur une série synthétique. */
  burn: (p) => {
    const n = p.n ?? 200_000, c = new Float64Array(n);
    let x = 100;
    for (let i = 0; i < n; i++) { x *= 1 + 0.001 * Math.sin(i * 0.37 + p.seed); c[i] = x; }
    const t0 = performance.now();
    I.ema(c, 20); I.rsi(c, 14); I.bollinger(c, 20, 2); I.macd(c);
    return { n, ms: performance.now() - t0 };
  },
};

parentPort.on('message', ({ id, type, payload }) => {
  const t0 = performance.now();
  try {
    const fn = TASKS[type];
    if (!fn) throw new Error(`tâche inconnue : ${type}`);
    parentPort.postMessage({ id, ok: true, result: fn(payload), ms: performance.now() - t0 });
  } catch (e) {
    parentPort.postMessage({ id, ok: false, error: `${e.message}\n${e.stack?.split('\n').slice(1, 4).join('\n') ?? ''}`, ms: performance.now() - t0 });
  }
});

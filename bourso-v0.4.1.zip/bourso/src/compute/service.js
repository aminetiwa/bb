// ============================================================================
//  BOURSO :: compute/service.js — le « chef d'orchestre » du calcul : GPU natif (Dawn/Vulkan),
//  CPU natif (C++ multi-cœurs) et workers JavaScript, DOSÉS selon leurs débits mesurés.
//
//  Dosage : chaque gros calcul (Monte Carlo, balayage de stratégies) est découpé entre GPU et
//  CPU en proportion de leur vitesse (étalonnage au démarrage puis moyenne mobile des débits
//  observés) : les deux finissent en même temps, aucun ne reste inactif.
//  Précision : les résultats GPU (float32) sont contrôlés par le CPU (float64) — Monte Carlo :
//  mêmes trajectoires recalculées ; balayages : les meilleures combinaisons sont recalculées en
//  double précision et ce sont ces valeurs exactes qui sont affichées.
//  Robustesse : le GPU tourne dans un processus à part (gpu-proxy.js). S'il plante, la part GPU
//  du calcul en cours est refaite sur le CPU, le serveur continue, et le GPU est relancé (2 fois
//  au plus, ensuite il reste désactivé pour la session, avec la raison sur la page Système).
// ============================================================================
import os from 'node:os';
import { GpuEngine } from './gpu.js';
import { GpuProxy } from './gpu-proxy.js';
import { native } from './native.js';
import { WorkerPool } from './pool.js';
import { histRange, checkpointSteps, mergeMC, summarizeMC } from '../core/quant/montecarlo.js';
import { STRATEGIES, backtest } from '../core/quant/backtest.js';

export const LEVELS = {
  eco: { label: 'Éco', mcPaths: 100_000, sweepScale: 0.5, threads: 1 },
  equilibre: { label: 'Équilibré', mcPaths: 1_000_000, sweepScale: 1, threads: -1 },
  max: { label: 'Maximum', mcPaths: 5_000_000, sweepScale: 2, threads: 0 },
  fondre: { label: 'Fondre les serveurs', mcPaths: 20_000_000, sweepScale: 4, threads: 0 },
};

export const SWEEP_CODES = { ema_cross: 0, sma_cross: 1, rsi_revert: 2, boll_revert: 3, donchian_break: 4, macd_cross: 5 };

const range = (a, b, step = 1) => {
  const out = [];
  for (let x = a; x <= b + 1e-9; x += step) out.push(Number(x.toFixed(4)));
  return out;
};

/** Grilles fines pour les balayages massifs (taille × `scale`). */
export function fineGrid(id, scale = 1) {
  const s = Math.max(0.5, scale), g = {
    ema_cross: { fast: range(2, Math.round(2 + 58 * s)), slow: range(10, Math.round(10 + 190 * s), 2) },
    sma_cross: { fast: range(2, Math.round(2 + 58 * s)), slow: range(10, Math.round(10 + 190 * s), 2) },
    rsi_revert: { n: range(2, Math.round(2 + 20 * s)), lo: range(5, 40), exit: range(45, 80, 5) },
    boll_revert: { n: range(5, Math.round(5 + 70 * s)), k: range(1, 3.5, 0.1) },
    donchian_break: { n: range(5, Math.round(5 + 150 * s)) },
    macd_cross: { fast: range(4, Math.round(4 + 14 * s)), slow: range(12, Math.round(12 + 30 * s)), signal: range(3, 15) },
  }[id];
  let combos = [{}];
  for (const k of Object.keys(g)) combos = combos.flatMap((c) => g[k].map((v) => ({ ...c, [k]: v })));
  return { keys: Object.keys(g), combos: combos.filter((p) => !STRATEGIES[id].valid || STRATEGIES[id].valid(p)) };
}

export class ComputeService {
  static async create({ gpu = 'auto', level = 'equilibre', log = () => {}, gpuHost = undefined } = {}) {
    const s = new ComputeService();
    s.gpuHost = gpuHost; // processus GPU de remplacement (tests)
    s.level = LEVELS[level] ? level : 'equilibre';
    s.mode = 'auto';
    s.log = log;
    s.pool = new WorkerPool();
    s.native = native;
    s.gpu = null;
    s.gpuReason = null;
    s.gpuCrashes = 0;
    s.lastGpuCrash = null;
    if (gpu !== 'off') await s.#startGpu();
    else s.gpuReason = 'désactivé';
    s.rates = { mc: { gpu: null, cpu: null }, sweep: { gpu: null, cpu: null } };
    s.jobs = [];
    s.cpuModel = os.cpus()[0]?.model ?? '—';
    return s;
  }

  /** Démarre le GPU : processus isolé par défaut, dans le processus du serveur si BOURSO_GPU_INPROCESS=1 (débogage). */
  async #startGpu() {
    const inproc = process.env.BOURSO_GPU_INPROCESS === '1';
    const { engine, reason } = inproc ? await GpuEngine.create() : await GpuProxy.create(this.gpuHost ? { host: this.gpuHost } : {});
    this.gpu = engine;
    this.gpuReason = engine ? null : reason ?? 'indisponible';
    if (engine && !inproc) engine.on('crash', (d) => this.#onGpuCrash(engine, d));
    return engine;
  }

  #onGpuCrash(engine, d) {
    if (this.gpu !== engine) return;
    this.gpu = null;
    this.gpuCrashes++;
    this.lastGpuCrash = { why: d.why, op: d.op, at: d.at };
    this.gpuReason = `le pilote GPU a planté (${d.why})${d.op ? ` pendant « ${d.op} »` : ''} — calculs basculés sur le CPU`;
    this.log(`⚠ ${this.gpuReason}`);
    if (this.gpuCrashes > 2) {
      this.gpuReason += ' ; GPU désactivé pour cette session après 3 plantages';
      this.log('GPU désactivé pour cette session (3 plantages). Pour ne plus l\'essayer : BOURSO_GPU=off');
      return;
    }
    const t = setTimeout(async () => {
      if (this.closed || this.gpu) return;
      const e = await this.#startGpu().catch(() => null);
      this.log(e ? 'GPU relancé (processus neuf)' : `GPU non relancé : ${this.gpuReason}`);
    }, 5000 * this.gpuCrashes);
    t.unref?.();
  }

  /** Part GPU d'un calcul : si le GPU échoue (plantage, erreur), la même tranche est refaite sur le CPU. */
  #gpuOr(gpuPromise, cpuFallback) {
    return gpuPromise.catch(async (e) => {
      this.log(`GPU indisponible pour ce calcul (${e.message}) → repli sur le CPU`);
      const r = await cpuFallback();
      return { ...r, backend: `${r.backend} (repli GPU)` };
    });
  }

  get threads() {
    const t = LEVELS[this.level].threads;
    return t === 0 ? native.cores : t < 0 ? Math.max(1, native.cores - 1) : t;
  }

  /** Part confiée au GPU pour un type de calcul (0 … 1). */
  share(kind) {
    if (!this.gpu || this.mode === 'cpu') return 0;
    if (this.mode === 'gpu') return 1;
    const r = this.rates[kind];
    if (!r.gpu || !r.cpu) return this.gpu.info.software ? 0.25 : 0.85;
    return r.gpu / (r.gpu + r.cpu);
  }

  #observe(kind, backend, work, ms) {
    if (!(ms > 0) || !(work > 0)) return;
    const key = backend === 'gpu' ? 'gpu' : 'cpu', rate = work / (ms / 1000), r = this.rates[kind];
    r[key] = r[key] ? r[key] * 0.6 + rate * 0.4 : rate;
  }

  #record(job) {
    this.jobs.push({ ...job, at: Date.now() });
    if (this.jobs.length > 60) this.jobs.shift();
  }

  /** Étalonnage rapide des débits (au démarrage, puis à la demande). */
  async calibrate() {
    const spec = { model: 'garch', s0: 100, steps: 100, seed: 3, mu: 0, omega: 1e-6, alpha: 0.05, beta: 0.93, h0: 1e-4, up: 110, down: 90, bins: 2048, rangeLo: -0.5, rangeHi: 0.5, checkpoints: [100] };
    const cpuPaths = 20_000;
    const c = await this.cpuMC({ ...spec, pathFrom: 0, pathTo: cpuPaths });
    this.#observe('mc', 'cpu', cpuPaths * 100, c.ms);
    if (this.gpu && !this.gpu.info.software) {
      try {
        const n = 262_144, g = await this.gpu.monteCarlo({ ...spec, pathFrom: 0, pathTo: n });
        this.#observe('mc', 'gpu', n * 100, g.ms);
      } catch (e) {
        this.log(`étalonnage GPU impossible : ${e.message}`);
      }
    }
    return this.info();
  }

  /**
   * Monte Carlo dosé GPU + CPU.
   * @param {object} model { model:'garch'|'bootstrap', mu, omega, alpha, beta, h0, uncondVar, returns, block, nu }
   * @param {{ s0:number, steps:number, up?:number, down?:number, paths?:number, seed?:number, mode?:string }} o
   */
  async monteCarlo(model, o) {
    const t0 = performance.now(), N = Math.round(o.paths ?? LEVELS[this.level].mcPaths);
    const spec = { ...model, s0: o.s0, steps: o.steps, up: o.up ?? 0, down: o.down ?? 0, seed: o.seed ?? ((Date.now() / 1000) | 0), bins: 2048 };
    const rg = histRange(spec), cps = checkpointSteps(spec.steps);
    const full = { ...spec, rangeLo: rg.lo, rangeHi: rg.hi, checkpoints: cps, returns: model.returns ? Float64Array.from(model.returns) : undefined };
    const mode = o.mode ?? this.mode, g = mode === 'cpu' || !this.gpu ? 0 : mode === 'gpu' ? 1 : this.share('mc');
    const nG = Math.round(N * g);
    const tasks = [];
    if (nG > 0) tasks.push(this.#gpuOr(this.gpu.monteCarlo({ ...full, pathFrom: 0, pathTo: nG }), () => this.cpuMC({ ...full, pathFrom: 0, pathTo: nG })));
    if (nG < N) tasks.push(this.cpuMC({ ...full, pathFrom: nG, pathTo: N }));
    const parts = (await Promise.all(tasks)).map((p) => ({ ...p, bins: 2048, range: rg, checkpoints: cps, steps: spec.steps }));
    for (const p of parts) this.#observe('mc', p.backend, p.paths * spec.steps, p.ms);
    const merged = mergeMC(parts);
    const summary = summarizeMC(merged, o.s0);
    // distribution finale (128 classes de rendement logarithmique) pour l'affichage
    const B = 128, per = merged.bins / B;
    summary.histogram = { lo: rg.lo, hi: rg.hi, counts: Array.from({ length: B }, (_, k) => { let c = 0; for (let i = k * per; i < (k + 1) * per; i++) c += merged.hist[i]; return c; }) };
    const wall = performance.now() - t0;
    const split = parts.map((p) => ({ backend: p.backend, paths: p.paths, ms: Math.round(p.ms), threads: p.threads ?? null }));
    this.#record({ type: 'Monte Carlo', paths: N, steps: spec.steps, split, ms: wall, rate: (N * spec.steps) / (wall / 1000) });
    return { summary, split, wallMs: wall, pathSteps: N * spec.steps, seed: spec.seed, range: rg };
  }

  /** Contrôle croisé : mêmes trajectoires [0, n[ sur GPU et CPU (double précision). */
  async verifyMC(model, o, n = 50_000) {
    if (!this.gpu) return { available: false };
    const spec = { ...model, s0: o.s0, steps: o.steps, up: o.up ?? 0, down: o.down ?? 0, seed: o.seed ?? 7, bins: 2048 };
    const rg = histRange(spec), cps = checkpointSteps(spec.steps);
    const full = { ...spec, rangeLo: rg.lo, rangeHi: rg.hi, checkpoints: cps, pathFrom: 0, pathTo: n, returns: model.returns ? Float64Array.from(model.returns) : undefined };
    let g, c;
    try {
      [g, c] = await Promise.all([this.gpu.monteCarlo(full), this.cpuMC(full)]);
    } catch (e) {
      return { available: false, reason: e.message };
    }
    let l1 = 0;
    for (let i = 0; i < 2048; i++) l1 += Math.abs(g.hist[i] - c.hist[i]);
    return {
      available: true, paths: n, gpu: { hitUp: g.hitUp, hitDown: g.hitDown, up: g.upCount, ms: g.ms }, cpu: { hitUp: c.hitUp, hitDown: c.hitDown, up: c.upCount, ms: c.ms },
      maxDiffPaths: Math.max(Math.abs(g.hitUp - c.hitUp), Math.abs(g.hitDown - c.hitDown), Math.abs(g.upCount - c.upCount)), histogramL1: l1,
      meanDiff: Math.abs(g.sum - c.sum) / n,
    };
  }

  /**
   * Balayage massif dosé GPU + CPU, puis vérification exacte (float64) des meilleures combinaisons.
   * @param {{ open, high, low, close }} data @param {string} strategy
   * @param {{ combos?:object[], keys?:string[], costBps?:number, barsPerYear?:number, short?:boolean, topVerify?:number, mode?:string, scale?:number }} o
   */
  async sweep(data, strategy, o = {}) {
    const t0 = performance.now(), code = SWEEP_CODES[strategy];
    if (code === undefined) throw new Error(`stratégie non balayable : ${strategy}`);
    const grid = o.combos ? { combos: o.combos, keys: o.keys } : fineGrid(strategy, o.scale ?? LEVELS[this.level].sweepScale);
    const K = grid.combos.length, P = grid.keys.length, params = new Float64Array(K * P);
    grid.combos.forEach((c, i) => grid.keys.forEach((k, j) => { params[i * P + j] = c[k]; }));
    const base = { open: data.open, high: data.high, low: data.low, close: data.close, strategy: code, P, short: Boolean(o.short), costBps: o.costBps ?? 5, barsPerYear: o.barsPerYear ?? 252, keys: grid.keys };
    const mode = o.mode ?? this.mode, g = mode === 'cpu' || !this.gpu ? 0 : mode === 'gpu' ? 1 : this.share('sweep');
    const kG = Math.round(K * g), N = data.close.length;
    const tasks = [];
    if (kG > 0) tasks.push(this.#gpuOr(this.gpu.sweep({ ...base, params: params.subarray(0, kG * P), K: kG }), () => this.cpuSweep({ ...base, params: params.slice(0, kG * P), K: kG })).then((r) => ({ ...r, from: 0 })));
    if (kG < K) tasks.push(this.cpuSweep({ ...base, params: params.slice(kG * P), K: K - kG }).then((r) => ({ ...r, from: kG })));
    const parts = await Promise.all(tasks);
    const gpuOk = parts.some((p) => p.backend === 'gpu');
    const metrics = new Float64Array(K * 10);
    for (const p of parts) {
      metrics.set(p.metrics, p.from * 10);
      this.#observe('sweep', p.backend, (p.metrics.length / 10) * N, p.ms);
    }
    const rows = grid.combos.map((c, i) => {
      const m = metrics.subarray(i * 10, i * 10 + 10);
      return { params: c, totalReturn: m[0], annReturn: m[1], sharpe: m[2], sortino: m[3], maxDD: m[4], trades: m[5], winRate: m[6], profitFactor: m[7], exposure: m[8], annVol: m[9], engine: i < kG && gpuOk ? 'gpu' : 'cpu' };
    });
    rows.sort((a, b) => b.sharpe - a.sharpe);
    // vérification exacte (double précision) des meilleures combinaisons
    let maxDiff = 0;
    const top = rows.slice(0, o.topVerify ?? 20);
    for (const r of top) {
      const m = backtest(data, strategy, r.params, { costBps: base.costBps, short: base.short, barsPerYear: base.barsPerYear }).metrics;
      maxDiff = Math.max(maxDiff, Math.abs(m.sharpe - r.sharpe));
      Object.assign(r, { totalReturn: m.totalReturn, annReturn: m.annReturn, sharpe: m.sharpe, sortino: m.sortino, maxDD: m.maxDD, trades: m.trades, winRate: m.winRate, profitFactor: m.profitFactor, exposure: m.exposure, annVol: m.annVol, verified: true });
    }
    rows.splice(0, top.length, ...top.sort((a, b) => b.sharpe - a.sharpe));
    const wall = performance.now() - t0;
    const split = parts.map((p) => ({ backend: p.backend, combos: p.metrics.length / 10, ms: Math.round(p.ms), threads: p.threads ?? null }));
    this.#record({ type: `Balayage ${STRATEGIES[strategy].name}`, combos: K, bars: N, split, ms: wall, rate: (K * N) / (wall / 1000) });
    return { strategy, name: STRATEGIES[strategy].name, combos: K, bars: N, keys: grid.keys, top: rows.slice(0, 200), heat: o.heat === false ? null : heatOf(rows, grid.keys), split, wallMs: wall, verification: { verified: top.length, maxSharpeDiff: maxDiff } };
  }

  /**
   * Partie CPU d'un Monte Carlo : addon C++ multi-cœurs, sinon (addon non compilé) tranches
   * réparties sur les workers JavaScript — jamais sur le thread du serveur.
   */
  async cpuMC(full) {
    if (native.ok) return native.monteCarlo({ ...full, threads: this.threads });
    const t0 = performance.now(), from = full.pathFrom ?? 0, to = full.pathTo ?? full.paths, n = to - from;
    const k = Math.max(1, Math.min(this.pool.size, Math.ceil(n / 2000))), parts = [];
    const payload = { ...full, returns: full.returns ? Array.from(full.returns) : undefined };
    for (let i = 0; i < k; i++) {
      const a = from + Math.floor((n * i) / k), b = from + Math.floor((n * (i + 1)) / k);
      if (b > a) parts.push(this.pool.run('mc', { ...payload, pathFrom: a, pathTo: b }, { priority: 2 }));
    }
    const res = await Promise.all(parts), bins = full.bins ?? 2048, cpn = (full.checkpoints ?? []).length;
    const out = { backend: 'cpu-js', hist: new Uint32Array(bins), cpHist: new Uint32Array(cpn * bins), sum: 0, sum2: 0, minSum: 0, upCount: 0, hitUp: 0, hitDown: 0, paths: 0, threads: k };
    for (const r of res) {
      for (let i = 0; i < bins; i++) out.hist[i] += r.hist[i];
      for (let i = 0; i < cpn * bins; i++) out.cpHist[i] += r.cpHist[i];
      for (const f of ['sum', 'sum2', 'minSum', 'upCount', 'hitUp', 'hitDown', 'paths']) out[f] += r[f];
    }
    out.ms = performance.now() - t0;
    return out;
  }

  /** Partie CPU d'un balayage : addon C++, sinon tranches de combinaisons sur les workers. */
  async cpuSweep(spec) {
    if (native.ok) return native.sweep({ ...spec, threads: this.threads });
    const t0 = performance.now(), K = spec.K, P = spec.P, k = Math.max(1, Math.min(this.pool.size, Math.ceil(K / 8))), jobs = [];
    const series = { open: Float64Array.from(spec.open), high: Float64Array.from(spec.high), low: Float64Array.from(spec.low), close: Float64Array.from(spec.close) };
    for (let i = 0; i < k; i++) {
      const a = Math.floor((K * i) / k), b = Math.floor((K * (i + 1)) / k);
      if (b > a) jobs.push(this.pool.run('sweep', { ...series, strategy: spec.strategy, keys: spec.keys, P, K: b - a, params: spec.params.slice(a * P, b * P), costBps: spec.costBps, short: spec.short, barsPerYear: spec.barsPerYear }, { priority: 2 }).then((r) => ({ a, r })));
    }
    const metrics = new Float64Array(K * 10);
    for (const { a, r } of await Promise.all(jobs)) metrics.set(r.metrics, a * 10);
    return { backend: 'cpu-js', metrics, fields: 10, ms: performance.now() - t0, threads: k };
  }

  /**
   * « Fondre les serveurs » : charge maximale SIMULTANÉE — GPU (Monte Carlo), CPU natif (Monte Carlo
   * sur tous les cœurs) et workers JavaScript (indicateurs) pendant `seconds` secondes.
   * Les lots s'adaptent pour durer ~1 s ; le résultat donne les débits réels de chaque moteur.
   */
  async stress({ seconds = 15, onProgress } = {}) {
    if (this.stressing) throw new Error('un test de charge est déjà en cours');
    this.stressing = true;
    const t0 = performance.now(), end = t0 + Math.min(120, Math.max(3, seconds)) * 1000, H = 250;
    const spec = { model: 'garch', s0: 100, steps: H, mu: 0.0003, omega: 2e-6, alpha: 0.08, beta: 0.9, h0: 2e-4, uncondVar: 1e-4, up: 130, down: 75, bins: 2048 };
    const rg = histRange(spec), full = { ...spec, rangeLo: rg.lo, rangeHi: rg.hi, checkpoints: checkpointSteps(H) };
    const tot = { gpu: { pathSteps: 0, ms: 0, batches: 0 }, cpu: { pathSteps: 0, ms: 0, batches: 0 }, workers: { points: 0, ms: 0, tasks: 0 } };
    let seed = 1;
    const adapt = (n, ms, min) => (ms < 500 ? n * 2 : ms > 1600 && n > min ? Math.floor(n / 2) : n);
    const gpuLoop = async () => {
      if (!this.gpu || this.gpu.info.software) return;
      try {
        for (let n = 1 << 18; performance.now() < end && this.gpu;) {
          const r = await this.gpu.monteCarlo({ ...full, seed: seed++, pathFrom: 0, pathTo: n });
          tot.gpu.pathSteps += n * H; tot.gpu.ms += r.ms; tot.gpu.batches++;
          n = Math.min(1 << 25, adapt(n, r.ms, 1 << 14));
        }
      } catch (e) {
        tot.gpu.error = e.message;
      }
    };
    const cpuLoop = async () => {
      if (!native.ok) return;
      for (let n = 20_000; performance.now() < end;) {
        const r = await native.monteCarlo({ ...full, seed: seed++, pathFrom: 0, pathTo: n, threads: native.cores });
        tot.cpu.pathSteps += n * H; tot.cpu.ms += r.ms; tot.cpu.batches++;
        n = Math.min(50_000_000, adapt(n, r.ms, 2000));
      }
    };
    const workerLoop = async (k) => {
      while (performance.now() < end) {
        const r = await this.pool.run('burn', { n: 300_000, seed: k }, { priority: 0 });
        tot.workers.points += r.n; tot.workers.ms += r.ms; tot.workers.tasks++;
      }
    };
    const snap = () => {
      const el = (performance.now() - t0) / 1000;
      return { elapsed: el, total: seconds, gpu: { ...tot.gpu, rate: tot.gpu.pathSteps / el }, cpu: { ...tot.cpu, rate: tot.cpu.pathSteps / el }, workers: { ...tot.workers, rate: tot.workers.points / el } };
    };
    const timer = setInterval(() => onProgress?.(snap()), 1000);
    try {
      await Promise.all([gpuLoop(), cpuLoop(), ...Array.from({ length: this.pool.size }, (_, k) => workerLoop(k))]);
    } finally {
      clearInterval(timer);
      this.stressing = false;
    }
    const res = snap();
    this.#record({ type: 'Test de charge', split: [{ backend: 'gpu', pathSteps: tot.gpu.pathSteps }, { backend: 'cpu-natif', pathSteps: tot.cpu.pathSteps }, { backend: 'workers', points: tot.workers.points }], ms: res.elapsed * 1000, rate: (tot.gpu.pathSteps + tot.cpu.pathSteps) / res.elapsed });
    return res;
  }

  async close() {
    this.closed = true;
    await this.pool.close().catch(() => {});
    this.gpu?.destroy?.();
  }

  /** Tâche JavaScript sur le pool de workers. */
  task(type, payload, opts) {
    return this.pool.run(type, payload, opts);
  }

  info() {
    const r = (x) => (x ? Math.round(x) : null);
    return {
      level: this.level, levels: Object.fromEntries(Object.entries(LEVELS).map(([k, v]) => [k, v.label])), mode: this.mode, threads: this.threads,
      cpu: { model: this.cpuModel, cores: native.cores },
      native: { ok: native.ok, version: native.version, error: native.ok ? null : native.error },
      gpu: this.gpu ? { ok: true, ...this.gpu.info, jobs: this.gpu.stats.jobs, busy: this.gpu.busy, crashes: this.gpuCrashes, lastCrash: this.lastGpuCrash }
        : { ok: false, reason: this.gpuReason, crashes: this.gpuCrashes, lastCrash: this.lastGpuCrash },
      pool: this.pool.info(),
      rates: { mcGpu: r(this.rates.mc.gpu), mcCpu: r(this.rates.mc.cpu), sweepGpu: r(this.rates.sweep.gpu), sweepCpu: r(this.rates.sweep.cpu) },
      shares: { mc: this.share('mc'), sweep: this.share('sweep') },
      jobs: this.jobs.slice(-20),
    };
  }
}

/** Carte de chaleur Sharpe sur les 2 premiers paramètres (meilleur Sharpe par case). */
function heatOf(rows, keys) {
  if (keys.length < 2) return null;
  const [a, b] = keys, xs = [...new Set(rows.map((r) => r.params[a]))].sort((x, y) => x - y), ys = [...new Set(rows.map((r) => r.params[b]))].sort((x, y) => x - y);
  if (xs.length * ys.length > 40_000) return null;
  const ix = new Map(xs.map((v, i) => [v, i])), iy = new Map(ys.map((v, i) => [v, i])), z = new Float64Array(xs.length * ys.length).fill(NaN);
  for (const r of rows) {
    const k = iy.get(r.params[b]) * xs.length + ix.get(r.params[a]);
    if (!(z[k] >= r.sharpe)) z[k] = r.sharpe;
  }
  return { x: a, y: b, xs, ys, z: Array.from(z, (v) => (Number.isFinite(v) ? Number(v.toFixed(3)) : null)) };
}

// ============================================================================
//  BOURSO :: compute/gpu-proxy.js — le GPU vu par le serveur, mais exécuté dans un processus à part.
//
//  Même interface que GpuEngine (info, monteCarlo, sweep, busy, stats, destroy) : le reste du code
//  ne voit pas la différence. Si le processus GPU s'arrête brutalement (pilote, Dawn), les calculs
//  en cours sont rejetés avec une erreur marquée `gpuCrash` et l'événement 'crash' est émis : le
//  service de calcul refait alors ces calculs sur le CPU, sans que le serveur ne s'arrête.
// ============================================================================
import { fork } from 'node:child_process';
import { EventEmitter } from 'node:events';
import { fileURLToPath } from 'node:url';

const SIGNALS = {
  SIGSEGV: 'accès mémoire invalide dans le pilote ou Dawn', SIGABRT: 'arrêt forcé par le pilote ou Dawn', SIGBUS: 'erreur de bus mémoire',
  SIGILL: 'instruction non supportée', SIGKILL: 'tué par le système (mémoire ?)', SIGFPE: 'erreur arithmétique',
};

// avertissements de Dawn sans conséquence (limites ramenées à des valeurs raisonnables, ex. sur NVIDIA)
const HARMLESS = [/artificially reduced from \d+ to \d+ to fit dynamic offset allocation limit/i];

/** Relaie la sortie du processus GPU, ligne par ligne, préfixée « [GPU] », sans les avertissements anodins. */
function relay(stream, out) {
  if (!stream) return;
  let buf = '';
  stream.setEncoding('utf8');
  stream.on('data', (d) => {
    buf += d;
    for (let i = buf.indexOf('\n'); i >= 0; i = buf.indexOf('\n')) {
      const line = buf.slice(0, i);
      buf = buf.slice(i + 1);
      if (line.trim() && !HARMLESS.some((re) => re.test(line))) out.write(`[GPU] ${line}\n`);
    }
  });
}

export const describeExit = (code, signal) => (signal ? `signal ${signal}${SIGNALS[signal] ? ` — ${SIGNALS[signal]}` : ''}` : `code ${code}`);

export class GpuProxy extends EventEmitter {
  /**
   * Lance le processus GPU et attend qu'il soit prêt.
   * @returns {Promise<{ engine: GpuProxy|null, reason?: string }>}
   */
  static create({ host = new URL('./gpu-host.js', import.meta.url), timeoutMs = 45_000, env = process.env } = {}) {
    return new GpuProxy().#start(host, timeoutMs, env);
  }

  #start(host, timeoutMs, env) {
    this.pending = new Map();
    this.seq = 0;
    this.busy = 0;
    this.stats = { jobs: 0, ms: 0, last: null };
    this.lastOp = null;
    this.dead = null;
    this.closing = false;
    return new Promise((resolve) => {
      let settled = false;
      const done = (r) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(r);
      };
      let child;
      try {
        // execArgv vide : ne pas hériter de --watch, --inspect… du serveur
        child = fork(fileURLToPath(host), [], { serialization: 'advanced', stdio: ['ignore', 'pipe', 'pipe', 'ipc'], execArgv: [], env });
        relay(child.stdout, process.stdout);
        relay(child.stderr, process.stderr);
      } catch (e) {
        done({ engine: null, reason: `processus GPU impossible à lancer : ${e.message}` });
        return;
      }
      this.child = child;
      const timer = setTimeout(() => {
        child.kill('SIGKILL');
        done({ engine: null, reason: `initialisation du GPU trop longue (> ${Math.round(timeoutMs / 1000)} s)` });
      }, timeoutMs);
      child.on('message', (m) => {
        if (m?.t === 'ready') {
          this.info = { ...m.info, isolated: true, pid: m.pid };
          done({ engine: this });
        } else if (m?.t === 'fail') {
          done({ engine: null, reason: m.reason });
        } else if (m?.t === 'done') {
          const j = this.pending.get(m.id);
          if (!j) return;
          this.pending.delete(m.id);
          this.busy = Math.max(0, this.busy - 1);
          if (!this.busy) this.lastOp = null;
          if (m.ok) {
            this.stats.jobs++;
            this.stats.ms += m.result?.ms ?? 0;
            this.stats.last = Date.now();
            j.resolve(m.result);
          } else j.reject(new Error(`GPU : ${m.error}`));
        } else if (m?.t === 'lost') {
          this.lost = m.reason;
        }
      });
      child.on('error', (e) => done({ engine: null, reason: `processus GPU : ${e.message}` }));
      child.on('exit', (code, signal) => {
        const why = describeExit(code, signal);
        this.dead = { code, signal, why, at: Date.now(), op: this.lastOp };
        if (!settled) {
          done({ engine: null, reason: code === 0 && !signal ? 'processus GPU arrêté pendant l\'initialisation' : `le processus GPU a planté pendant l'initialisation (${why})` });
          return;
        }
        const err = Object.assign(new Error(`le processus GPU s'est arrêté (${why})`), { gpuCrash: true });
        for (const j of this.pending.values()) j.reject(err);
        this.pending.clear();
        this.busy = 0;
        // arrêt demandé (Ctrl+C, arrêt du service) : ce n'est pas un plantage du pilote
        const stopped = signal === 'SIGINT' || signal === 'SIGTERM' || signal === 'SIGHUP';
        if (!this.closing && !stopped) this.emit('crash', this.dead);
      });
    });
  }

  #job(op, spec, label) {
    if (this.dead || this.closing) return Promise.reject(Object.assign(new Error('GPU arrêté'), { gpuCrash: true }));
    return new Promise((resolve, reject) => {
      const id = ++this.seq;
      this.pending.set(id, { resolve, reject });
      this.busy++;
      this.lastOp = label;
      try {
        this.child.send({ t: 'job', id, op, spec });
      } catch (e) {
        this.pending.delete(id);
        this.busy = Math.max(0, this.busy - 1);
        reject(Object.assign(new Error(`GPU injoignable : ${e.message}`), { gpuCrash: true }));
      }
    });
  }

  monteCarlo(spec) {
    const n = (spec.pathTo ?? spec.paths ?? 0) - (spec.pathFrom ?? 0);
    return this.#job('mc', spec, `Monte Carlo GPU (${n.toLocaleString('fr-FR')} trajectoires × ${spec.steps} pas)`);
  }

  sweep(spec) {
    return this.#job('sweep', spec, `balayage GPU (${Number(spec.K).toLocaleString('fr-FR')} combinaisons)`);
  }

  destroy() {
    if (this.closing) return;
    this.closing = true;
    try { this.child?.send({ t: 'exit' }); } catch { /* déjà arrêté */ }
    setTimeout(() => { try { this.child?.kill('SIGKILL'); } catch { /* déjà arrêté */ } }, 1500).unref();
  }
}

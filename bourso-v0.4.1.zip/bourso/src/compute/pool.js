// ============================================================================
//  BOURSO :: compute/pool.js — pool de worker_threads pour le moteur quantitatif JavaScript.
//  Une file à priorités (interactif avant arrière-plan), un worker par cœur (moins un pour le
//  serveur), statistiques d'occupation pour la page Système.
// ============================================================================
import { Worker } from 'node:worker_threads';
import os from 'node:os';

export class WorkerPool {
  constructor({ size = Math.max(1, (os.availableParallelism?.() ?? os.cpus().length) - 1), url = new URL('./quant.worker.js', import.meta.url) } = {}) {
    this.size = size;
    this.queue = [];
    this.seq = 0;
    this.pending = new Map();
    this.done = 0;
    this.failed = 0;
    this.busyMs = 0;
    this.started = Date.now();
    this.workers = Array.from({ length: size }, (_, k) => this.#spawn(url, k));
  }

  #spawn(url, k) {
    const w = new Worker(url, { name: `bourso-quant-${k}` });
    const slot = { w, busy: null, k, done: 0 };
    w.on('message', (m) => {
      const job = this.pending.get(m.id);
      this.pending.delete(m.id);
      slot.busy = null;
      slot.done++;
      w.unref(); // inactif : ne retient plus le processus
      this.busyMs += m.ms ?? 0;
      if (job) {
        if (m.ok) { this.done++; job.resolve(m.result); } else { this.failed++; job.reject(new Error(m.error)); }
      }
      this.#pump();
    });
    w.on('error', (e) => {
      if (slot.busy) {
        const job = this.pending.get(slot.busy);
        this.pending.delete(slot.busy);
        job?.reject(e);
      }
      slot.busy = null;
      this.workers[k] = this.#spawn(url, k);
      this.#pump();
    });
    w.unref();
    return slot;
  }

  /** @param {string} type @param {object} payload @param {{ priority?:number, transfer?:Transferable[] }} [o] */
  run(type, payload, { priority = 1, transfer = [] } = {}) {
    return new Promise((resolve, reject) => {
      const id = ++this.seq;
      this.queue.push({ id, type, payload, priority, transfer, resolve, reject });
      this.queue.sort((a, b) => b.priority - a.priority || a.id - b.id);
      this.#pump();
    });
  }

  #pump() {
    for (const slot of this.workers) {
      if (slot.busy || !this.queue.length) continue;
      const job = this.queue.shift();
      slot.busy = job.id;
      slot.w.ref(); // une tâche en cours retient le processus
      this.pending.set(job.id, job);
      slot.w.postMessage({ id: job.id, type: job.type, payload: job.payload }, job.transfer);
    }
  }

  info() {
    const up = (Date.now() - this.started) / 1000;
    return {
      size: this.size, busy: this.workers.filter((s) => s.busy).length, queued: this.queue.length, done: this.done, failed: this.failed,
      utilization: up > 0 ? Math.min(1, this.busyMs / 1000 / (up * this.size)) : 0,
    };
  }

  async close() {
    await Promise.all(this.workers.map((s) => s.w.terminate()));
  }
}

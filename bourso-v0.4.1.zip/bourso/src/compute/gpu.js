// ============================================================================
//  BOURSO :: compute/gpu.js — moteur GPU NATIF de Node (Dawn, l'implémentation WebGPU de Chrome,
//  paquet npm « webgpu »). Sous Ubuntu : Vulkan (NVIDIA, AMD/RADV, Intel/ANV) ; macOS : Metal ;
//  Windows : D3D12. Aucun navigateur n'intervient : les noyaux WGSL tournent dans le serveur.
//
//  Ce moteur tourne dans un PROCESSUS SÉPARÉ (gpu-host.js, piloté par gpu-proxy.js) : un plantage du
//  pilote graphique ne peut pas arrêter le serveur ; les calculs basculent alors sur le CPU.
//
//  Variables utiles :
//    BOURSO_GPU=off               désactive le GPU (tout passe sur le CPU natif)
//    BOURSO_GPU_INPROCESS=1       GPU dans le processus du serveur (débogage uniquement)
//    BOURSO_GPU_ADAPTER="nom"     choisit une carte précise (cf. Système → adaptateurs)
//    VK_ICD_FILENAMES=…           pilote Vulkan à utiliser (tests : SwiftShader logiciel)
// ============================================================================
import { MC_WGSL, SWEEP_WGSL } from './kernels.js';

const MAX_WG = 65_535;

export class GpuEngine {
  /** Node : Dawn natif (paquet « webgpu »). @returns {Promise<{ engine: GpuEngine|null, reason?: string }>} */
  static async create({ adapterName = globalThis.process?.env?.BOURSO_GPU_ADAPTER } = {}) {
    if (globalThis.process?.env?.BOURSO_GPU === 'off') return { engine: null, reason: 'GPU désactivé (BOURSO_GPU=off)' };
    let mod;
    try {
      mod = await import('webgpu');
    } catch {
      return { engine: null, reason: 'module « webgpu » (Dawn) non installé : npm install webgpu' };
    }
    try {
      Object.assign(globalThis, mod.globals);
      // IMPORTANT : l'instance Dawn n'existe que tant que l'objet renvoyé par create() est référencé.
      // Si le ramasse-miettes le récupère, Dawn est détruit sous le device encore utilisé : le processus
      // plante au calcul suivant (SIGSEGV / SIGABRT, sans message JavaScript). On le garde donc en vie
      // aussi longtemps que le moteur (engine.instance), et on le relâche dans destroy().
      const gpu = mod.create(adapterName ? [`adapter=${adapterName}`] : []);
      const adapter = await gpu.requestAdapter({ powerPreference: 'high-performance' });
      if (!adapter) return { engine: null, reason: 'aucun adaptateur GPU (pilote Vulkan installé ? vulkaninfo pour vérifier)' };
      const engine = await GpuEngine.fromAdapter(adapter);
      engine.instance = gpu;
      return { engine };
    } catch (e) {
      return { engine: null, reason: `initialisation GPU impossible : ${e.message}` };
    }
  }

  /** Depuis n'importe quel adaptateur WebGPU (Dawn dans Node, ou navigator.gpu d'un navigateur pour les tests). */
  static async fromAdapter(adapter) {
    const L = adapter.limits;
    const device = await adapter.requestDevice({
      requiredLimits: {
        maxStorageBufferBindingSize: L.maxStorageBufferBindingSize, maxBufferSize: L.maxBufferSize,
        maxComputeWorkgroupStorageSize: L.maxComputeWorkgroupStorageSize, maxStorageBuffersPerShaderStage: L.maxStorageBuffersPerShaderStage,
      },
    });
    const engine = new GpuEngine(adapter, device);
    await engine.compile();
    return engine;
  }

  constructor(adapter, device) {
    this.adapter = adapter;
    this.device = device;
    const i = adapter.info ?? {};
    this.info = {
      vendor: i.vendor || '—', architecture: i.architecture || '—', device: i.device || '—', description: i.description || '—',
      fallback: Boolean(i.isFallbackAdapter), software: /swiftshader|llvmpipe|lavapipe/i.test(`${i.architecture} ${i.device} ${i.description}`),
      limits: { maxBuffer: adapter.limits.maxBufferSize, maxStorage: adapter.limits.maxStorageBufferBindingSize, maxWorkgroup: adapter.limits.maxComputeInvocationsPerWorkgroup },
    };
    this.busy = 0;
    this.stats = { jobs: 0, ms: 0, last: null };
    device.lost?.then?.((x) => { this.lost = x?.message ?? 'perdu'; });
  }

  destroy() {
    try { this.device.destroy(); } catch { /* déjà détruit */ }
    this.instance = null; // relâche l'instance Dawn : le processus peut alors se terminer
  }

  async compile() {
    const d = this.device;
    const mk = async (code, label) => {
      const module = d.createShaderModule({ code, label });
      const info = await module.getCompilationInfo?.();
      const errs = info?.messages?.filter((m) => m.type === 'error') ?? [];
      if (errs.length) throw new Error(`WGSL ${label} : ${errs.map((m) => `${m.lineNum}:${m.linePos} ${m.message}`).join(' | ')}`);
      return d.createComputePipelineAsync({ layout: 'auto', compute: { module, entryPoint: 'main' }, label });
    };
    this.mcPipe = await mk(MC_WGSL, 'montecarlo');
    this.sweepPipe = await mk(SWEEP_WGSL, 'balayage');
  }

  #buffer(data, usage) {
    const d = this.device, size = Math.max(16, Math.ceil(data.byteLength / 4) * 4);
    const b = d.createBuffer({ size, usage: usage | GPUBufferUsage.COPY_DST, mappedAtCreation: true });
    new Uint8Array(b.getMappedRange()).set(new Uint8Array(data.buffer, data.byteOffset, data.byteLength));
    b.unmap();
    return b;
  }

  #empty(size, usage) {
    return this.device.createBuffer({ size: Math.max(16, Math.ceil(size / 4) * 4), usage });
  }

  async #read(src, size) {
    const d = this.device, rb = d.createBuffer({ size, usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST });
    const e = d.createCommandEncoder();
    e.copyBufferToBuffer(src, 0, rb, 0, size);
    d.queue.submit([e.finish()]);
    await rb.mapAsync(GPUMapMode.READ);
    const copy = rb.getMappedRange().slice(0);
    rb.unmap();
    rb.destroy();
    return copy;
  }

  /**
   * Monte Carlo sur le GPU, même spécification et même format de résultat que le C++ natif.
   * @param {{ model, s0, steps, seed, mu, omega, alpha, beta, h0, nu, returns, block, up, down, bins, rangeLo, rangeHi, checkpoints, pathFrom, pathTo }} spec
   */
  async monteCarlo(spec) {
    const t0 = performance.now(), d = this.device, S = GPUBufferUsage.STORAGE;
    this.busy++;
    try {
      const bins = Math.min(2048, spec.bins ?? 2048), cps = Uint32Array.from(spec.checkpoints ?? [spec.steps]);
      const from = spec.pathFrom ?? 0, to = spec.pathTo ?? spec.paths, total = to - from;
      const rets = Float32Array.from(spec.model === 'bootstrap' ? spec.returns : [0]);
      const hist = this.#empty(bins * 4, S | GPUBufferUsage.COPY_SRC), cpHist = this.#empty(cps.length * bins * 4, S | GPUBufferUsage.COPY_SRC);
      const counters = this.#empty(16, S | GPUBufferUsage.COPY_SRC);
      const retBuf = this.#buffer(rets, S), cpBuf = this.#buffer(cps, S);
      const lnUp = spec.up > 0 ? Math.log(spec.up / spec.s0) : 0, lnDown = spec.down > 0 ? Math.log(spec.down / spec.s0) : 0;
      // découpage : ≤ ~4e8 pas par soumission (pas de chien de garde du pilote)
      const chunk = Math.max(65_536, Math.floor(4e8 / Math.max(1, spec.steps)));
      let sum = 0, sum2 = 0, minSum = 0;
      for (let a = 0; a < total; a += chunk) {
        const count = Math.min(chunk, total - a), wg = Math.ceil(count / 256), wgX = Math.min(wg, MAX_WG), wgY = Math.ceil(wg / wgX);
        const u = new ArrayBuffer(96), dv = new DataView(u);
        const U = [spec.steps, spec.seed ?? 1, from + a, count, spec.model === 'bootstrap' ? 1 : 0, spec.nu ?? 0, rets.length, bins,
          cps.length, spec.up > 0 ? 1 : 0, spec.down > 0 ? 1 : 0, wgX];
        U.forEach((v, i) => dv.setUint32(i * 4, v >>> 0, true));
        const Fv = [spec.mu ?? 0, spec.omega ?? 0, spec.alpha ?? 0, spec.beta ?? 0, spec.h0 ?? 0, lnUp, lnDown, spec.rangeLo,
          bins / (spec.rangeHi - spec.rangeLo), 1 / Math.max(1, spec.block ?? 10), (spec.nu ?? 0) > 2 ? Math.sqrt((spec.nu - 2) / spec.nu) : 1, 0];
        Fv.forEach((v, i) => dv.setFloat32(48 + i * 4, v, true));
        const ub = d.createBuffer({ size: 96, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
        d.queue.writeBuffer(ub, 0, u);
        const partial = this.#empty(wgX * wgY * 16, S | GPUBufferUsage.COPY_SRC);
        const bg = d.createBindGroup({ layout: this.mcPipe.getBindGroupLayout(0), entries: [ub, retBuf, cpBuf, hist, cpHist, counters, partial].map((b, i) => ({ binding: i, resource: { buffer: b } })) });
        const e = d.createCommandEncoder(), pass = e.beginComputePass();
        pass.setPipeline(this.mcPipe);
        pass.setBindGroup(0, bg);
        pass.dispatchWorkgroups(wgX, wgY);
        pass.end();
        d.queue.submit([e.finish()]);
        const pr = new Float32Array(await this.#read(partial, wgX * wgY * 16));
        for (let k = 0; k < wgX * wgY; k++) { sum += pr[4 * k]; sum2 += pr[4 * k + 1]; minSum += pr[4 * k + 2]; }
        partial.destroy();
        ub.destroy();
      }
      const [h, cp, cnt] = await Promise.all([this.#read(hist, bins * 4), this.#read(cpHist, cps.length * bins * 4), this.#read(counters, 16)]);
      const c = new Uint32Array(cnt);
      for (const b of [hist, cpHist, counters, retBuf, cpBuf]) b.destroy();
      const ms = performance.now() - t0;
      this.#account(ms);
      return { backend: 'gpu', hist: new Uint32Array(h), cpHist: new Uint32Array(cp), sum, sum2, minSum, upCount: c[0], hitUp: c[1], hitDown: c[2], paths: total, ms, bins };
    } finally {
      this.busy--;
    }
  }

  /**
   * Balayage de stratégies sur le GPU. Données OHLC (Float64Array), combinaisons `params` (K × P).
   * @returns {Promise<{ metrics: Float64Array, fields: number, ms: number }>}
   */
  async sweep({ open, high, low, close, strategy, params, K, P, short = false, costBps = 5, from = 1, to = close.length, barsPerYear = 252 }) {
    const t0 = performance.now(), d = this.device, S = GPUBufferUsage.STORAGE, N = close.length;
    this.busy++;
    try {
      const ref = close[0];
      const c32 = Float32Array.from(close, (v) => v - ref), h32 = Float32Array.from(high, (v) => v - ref), l32 = Float32Array.from(low, (v) => v - ref);
      const lr = new Float32Array(4 * N);
      for (let t = 1; t < N; t++) {
        lr[4 * t] = Math.log(open[t] / close[t - 1]);
        lr[4 * t + 1] = Math.log(close[t] / open[t]);
        lr[4 * t + 2] = Math.log(close[t] / close[t - 1]);
      }
      const prm = new Float32Array(K * 4);
      for (let k = 0; k < K; k++) for (let j = 0; j < Math.min(4, P); j++) prm[4 * k + j] = params[k * P + j];
      const u = new ArrayBuffer(48), dv = new DataView(u);
      [N, K, strategy, short ? 1 : 0, from, to, 0, 0].forEach((v, i) => dv.setUint32(i * 4, v >>> 0, true));
      dv.setFloat32(32, costBps, true);
      dv.setFloat32(36, barsPerYear, true);
      const ub = d.createBuffer({ size: 48, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
      d.queue.writeBuffer(ub, 0, u);
      const bufs = [ub, this.#buffer(c32, S), this.#buffer(h32, S), this.#buffer(l32, S), this.#buffer(lr, S), this.#buffer(prm, S), this.#empty(K * 40, S | GPUBufferUsage.COPY_SRC)];
      const bg = d.createBindGroup({ layout: this.sweepPipe.getBindGroupLayout(0), entries: bufs.map((b, i) => ({ binding: i, resource: { buffer: b } })) });
      const wg = Math.ceil(K / 64);
      const e = d.createCommandEncoder(), pass = e.beginComputePass();
      pass.setPipeline(this.sweepPipe);
      pass.setBindGroup(0, bg);
      pass.dispatchWorkgroups(Math.min(wg, MAX_WG), Math.ceil(wg / MAX_WG));
      pass.end();
      d.queue.submit([e.finish()]);
      const out = new Float32Array(await this.#read(bufs[6], K * 40));
      for (const b of bufs) b.destroy();
      const metrics = Float64Array.from(out, (v) => (v >= 1e38 ? Infinity : v));
      const ms = performance.now() - t0;
      this.#account(ms);
      return { backend: 'gpu', metrics, fields: 10, ms };
    } finally {
      this.busy--;
    }
  }

  #account(ms) {
    this.stats.jobs++;
    this.stats.ms += ms;
    this.stats.last = Date.now();
  }
}

// ============================================================================
//  BOURSO :: compute/native.js — accès à l'addon C++ (N-API) avec repli JavaScript.
//  L'addon exécute Monte Carlo et balayages sur TOUS les cœurs (std::thread), hors du thread
//  JavaScript (AsyncWorker) : le serveur reste réactif pendant les calculs.
// ============================================================================
import { createRequire } from 'node:module';
import os from 'node:os';
import { simulateMC } from '../core/quant/montecarlo.js';
import { backtest } from '../core/quant/backtest.js';

const require = createRequire(import.meta.url);
let addon = null, loadError = null;
if (process.env.BOURSO_NO_NATIVE === '1') loadError = 'module C++ désactivé (BOURSO_NO_NATIVE=1)';
else {
  const errors = [];
  for (const p of ['../../build/Release/bourso_native.node', '../../build/Debug/bourso_native.node']) {
    try {
      addon = require(p);
      break;
    } catch (e) {
      errors.push(e);
    }
  }
  if (!addon) {
    // absent partout : il n'a pas été compilé ; sinon, le fichier existe mais ne se charge pas
    const real = errors.find((e) => e.code !== 'MODULE_NOT_FOUND');
    loadError = real
      ? `module C++ présent mais inutilisable (${real.message.split('\n')[0]}) — recompile-le : npm run build:native`
      : 'module C++ non compilé (build/Release/bourso_native.node absent) — pour l\'activer : sudo apt install -y build-essential python3 puis npm run build:native';
  }
}

/**
 * Trace de l'opération native en cours, envoyée au superviseur (scripts/run.js) s'il est là : en cas
 * de plantage du processus, il peut dire quel calcul natif tournait.
 */
const crumb = (op) => {
  if (process.env.BOURSO_SUPERVISED !== '1' || typeof process.send !== 'function') return;
  try { process.send({ t: 'op', op }); } catch { /* superviseur absent */ }
};

export const native = {
  ok: Boolean(addon?.monteCarlo),
  version: addon?.version ?? null,
  error: addon ? null : loadError,
  cores: addon?.hardwareConcurrency ?? os.availableParallelism?.() ?? os.cpus().length,

  /** Monte Carlo (même spécification que le GPU). */
  async monteCarlo(spec) {
    if (addon?.monteCarlo) {
      crumb(`Monte Carlo C++ (${((spec.pathTo ?? spec.paths ?? 0) - (spec.pathFrom ?? 0)).toLocaleString('fr-FR')} trajectoires, ${spec.threads ?? 'tous les'} fils)`);
      try {
        return { backend: 'cpu-natif', ...(await addon.monteCarlo(spec)) };
      } finally {
        crumb(null);
      }
    }
    const t0 = performance.now();
    const r = simulateMC({ ...spec, range: { lo: spec.rangeLo, hi: spec.rangeHi } });
    return { backend: 'cpu-js', hist: r.hist, cpHist: r.cpHist, sum: r.sum, sum2: r.sum2, minSum: r.minSum, upCount: r.upCount, hitUp: r.hitUp, hitDown: r.hitDown, paths: r.paths, ms: performance.now() - t0, threads: 1 };
  },

  /** Balayage de stratégies (codes 0…5 : EMA, SMA, RSI, Bollinger, Donchian, MACD). */
  async sweep(spec) {
    if (addon?.sweep) {
      crumb(`balayage C++ (${spec.K} combinaisons, ${spec.threads ?? 'tous les'} fils)`);
      try {
        return { backend: 'cpu-natif', ...(await addon.sweep(spec)) };
      } finally {
        crumb(null);
      }
    }
    const t0 = performance.now(), ids = ['ema_cross', 'sma_cross', 'rsi_revert', 'boll_revert', 'donchian_break', 'macd_cross'];
    const keys = spec.keys, out = new Float64Array(spec.K * 10), d = { open: spec.open, high: spec.high, low: spec.low, close: spec.close };
    for (let k = 0; k < spec.K; k++) {
      const p = Object.fromEntries(keys.map((key, j) => [key, spec.params[k * spec.P + j]]));
      const m = backtest(d, ids[spec.strategy], p, { costBps: spec.costBps, short: spec.short, barsPerYear: spec.barsPerYear }).metrics;
      out.set([m.totalReturn, m.annReturn, m.sharpe, m.sortino, m.maxDD, m.trades, m.winRate, m.profitFactor, m.exposure, m.annVol], k * 10);
    }
    return { backend: 'cpu-js', metrics: out, fields: 10, ms: performance.now() - t0, threads: 1 };
  },
};

// ============================================================================
//  BOURSO :: compute/kernels.js — noyaux de calcul GPU (WGSL), exécutés par Dawn dans Node
//  (Vulkan sur Ubuntu, Metal sur macOS, D3D12 sous Windows).
//
//  Précision : le GPU calcule en float32. Pour que ses résultats soient comparables au CPU :
//   - même générateur aléatoire que le CPU (xoshiro128**, même graine par trajectoire) : la
//     trajectoire n° p du GPU suit les mêmes tirages que la n° p du C++ / JS ;
//   - sinus/cosinus maison (réduction d'argument + polynômes, erreur < 1e-7) au lieu des
//     fonctions intégrées dont la norme WGSL ne garantit que 2^-11 ;
//   - sommes de Kahan, prix relatifs à une référence (aucune perte de chiffres) ;
//   - réductions finales (sommes) faites en float64 côté CPU.
// ============================================================================

export const RNG_WGSL = /* wgsl */ `
fn rotl(x: u32, k: u32) -> u32 { return (x << k) | (x >> (32u - k)); }
fn path_seed(seed: u32, p: u32) -> u32 {
  var z = seed ^ ((p + 1u) * 0x9e3779b9u);
  z = (z ^ (z >> 16u)) * 0x85ebca6bu;
  z = (z ^ (z >> 13u)) * 0xc2b2ae35u;
  return z ^ (z >> 16u);
}
struct Rng { a: u32, b: u32, c: u32, d: u32, spare: f32, has: u32 }
fn splitmix(s: ptr<function, u32>) -> u32 {
  *s = *s + 0x9e3779b9u;
  var z = *s;
  z = (z ^ (z >> 16u)) * 0x85ebca6bu;
  z = (z ^ (z >> 13u)) * 0xc2b2ae35u;
  return z ^ (z >> 16u);
}
fn rng_init(seed: u32) -> Rng {
  var s = seed;
  var r: Rng;
  r.a = splitmix(&s); r.b = splitmix(&s); r.c = splitmix(&s); r.d = splitmix(&s);
  if ((r.a | r.b | r.c | r.d) == 0u) { r.a = 1u; }
  r.spare = 0.0; r.has = 0u;
  return r;
}
fn next_u32(r: ptr<function, Rng>) -> u32 {
  let res = rotl((*r).b * 5u, 7u) * 9u;
  let t = (*r).b << 9u;
  (*r).c = (*r).c ^ (*r).a;
  (*r).d = (*r).d ^ (*r).b;
  (*r).b = (*r).b ^ (*r).c;
  (*r).a = (*r).a ^ (*r).d;
  (*r).c = (*r).c ^ t;
  (*r).d = rotl((*r).d, 11u);
  return res;
}
// uniforme ]0,1[ : mêmes 2 tirages 32 bits que le CPU (53 bits ramenés en float32)
fn unif(r: ptr<function, Rng>) -> f32 {
  let hi = next_u32(r) >> 5u;
  let lo = next_u32(r) >> 6u;
  return (f32(hi) * 67108864.0 + f32(lo) + 0.5) / 9007199254740992.0;
}
// sin/cos de 2πv : réduction exacte dans [-π/2, π/2] puis polynômes de Taylor (erreur < 1e-7)
fn sincos_2pi(v: f32) -> vec2<f32> {
  let t = v - round(v);
  var x = 6.283185307179586 * t;
  var sgn = 1.0;
  if (x > 1.5707963267948966) { x = 3.141592653589793 - x; sgn = -1.0; }
  else if (x < -1.5707963267948966) { x = -3.141592653589793 - x; sgn = -1.0; }
  let x2 = x * x;
  let s = x * (1.0 + x2 * (-1.0 / 6.0 + x2 * (1.0 / 120.0 + x2 * (-1.0 / 5040.0 + x2 * (1.0 / 362880.0 + x2 * (-1.0 / 39916800.0 + x2 / 6227020800.0))))));
  let c = 1.0 + x2 * (-0.5 + x2 * (1.0 / 24.0 + x2 * (-1.0 / 720.0 + x2 * (1.0 / 40320.0 + x2 * (-1.0 / 3628800.0 + x2 / 479001600.0)))));
  return vec2<f32>(sgn * c, s);
}
fn normal(r: ptr<function, Rng>) -> f32 {
  if ((*r).has == 1u) { (*r).has = 0u; return (*r).spare; }
  let u = unif(r);
  let v = unif(r);
  let rad = sqrt(-2.0 * log(u));
  let cs = sincos_2pi(v);
  (*r).spare = rad * cs.y;
  (*r).has = 1u;
  return rad * cs.x;
}
fn intn(r: ptr<function, Rng>, n: u32) -> u32 { return min(n - 1u, u32(floor(unif(r) * f32(n)))); }
`;

/** Monte Carlo GARCH / bootstrap, barrières à surveillance continue (pont brownien). */
export const MC_WGSL = /* wgsl */ `
${RNG_WGSL}
struct P {
  steps: u32, seed: u32, start: u32, count: u32,
  model: u32, nu: u32, nRet: u32, bins: u32,
  nCp: u32, hasUp: u32, hasDown: u32, wgX: u32,
  mu: f32, omega: f32, alpha: f32, beta: f32,
  h0: f32, lnUp: f32, lnDown: f32, lo: f32,
  scale: f32, pNew: f32, tScale: f32, _pad: f32,
}
@group(0) @binding(0) var<uniform> p: P;
@group(0) @binding(1) var<storage, read> rets: array<f32>;
@group(0) @binding(2) var<storage, read> cps: array<u32>;
@group(0) @binding(3) var<storage, read_write> hist: array<atomic<u32>>;
@group(0) @binding(4) var<storage, read_write> cpHist: array<atomic<u32>>;
@group(0) @binding(5) var<storage, read_write> counters: array<atomic<u32>, 4>;
@group(0) @binding(6) var<storage, read_write> partial: array<vec4<f32>>;

var<workgroup> lh: array<atomic<u32>, 2048>;
var<workgroup> lc: array<atomic<u32>, 4>;
var<workgroup> red: array<vec4<f32>, 256>;

fn bin_of(x: f32) -> u32 {
  let f = floor((x - p.lo) * p.scale);
  return u32(clamp(f, 0.0, f32(p.bins - 1u)));
}

@compute @workgroup_size(256)
fn main(@builtin(workgroup_id) wg: vec3<u32>, @builtin(local_invocation_index) li: u32) {
  for (var i = li; i < p.bins; i = i + 256u) { atomicStore(&lh[i], 0u); }
  if (li < 4u) { atomicStore(&lc[li], 0u); }
  workgroupBarrier();
  let wgi = wg.y * p.wgX + wg.x;
  let idx = wgi * 256u + li;
  var acc = vec4<f32>(0.0);
  if (idx < p.count) {
    var r = rng_init(path_seed(p.seed, p.start + idx));
    var x = 0.0; var xc = 0.0; var xmin = 0.0;
    var h = p.h0;
    var first = 0;
    var cpk = 0u;
    var j = intn(&r, max(1u, p.nRet));
    for (var t = 1u; t <= p.steps; t = t + 1u) {
      var ret = 0.0; var vs = 0.0;
      if (p.model == 0u) {
        var z = normal(&r);
        if (p.nu > 2u) {
          var chi = 0.0;
          for (var k = 0u; k < p.nu; k = k + 1u) { let g = normal(&r); chi = chi + g * g; }
          z = z / sqrt(chi / f32(p.nu)) * p.tScale;
        }
        let e = sqrt(h) * z;
        ret = p.mu + e;
        vs = h;
        h = p.omega + p.alpha * e * e + p.beta * h;
      } else {
        if (unif(&r) < p.pNew) { j = intn(&r, p.nRet); } else { j = (j + 1u) % p.nRet; }
        ret = rets[j];
        vs = max(1e-14, ret * ret);
      }
      let a = x;
      // somme de Kahan du log-prix
      let y = ret - xc; let s = x + y; xc = (s - x) - y; x = s;
      xmin = min(xmin, x);
      if (first == 0) {
        var up = p.hasUp == 1u && x >= p.lnUp;
        var dn = p.hasDown == 1u && x <= p.lnDown;
        if (!up && p.hasUp == 1u) { up = unif(&r) < exp(-2.0 * (p.lnUp - a) * (p.lnUp - x) / vs); }
        if (!dn && p.hasDown == 1u) { dn = unif(&r) < exp(-2.0 * (a - p.lnDown) * (x - p.lnDown) / vs); }
        if (up && dn) { if (unif(&r) < 0.5) { first = 1; } else { first = -1; } }
        else if (up) { first = 1; }
        else if (dn) { first = -1; }
      }
      if (cpk < p.nCp && t == cps[cpk]) {
        atomicAdd(&cpHist[cpk * p.bins + bin_of(x)], 1u);
        cpk = cpk + 1u;
      }
    }
    atomicAdd(&lh[bin_of(x)], 1u);
    if (x > 0.0) { atomicAdd(&lc[0], 1u); }
    if (first == 1) { atomicAdd(&lc[1], 1u); }
    if (first == -1) { atomicAdd(&lc[2], 1u); }
    acc = vec4<f32>(x, x * x, xmin, 1.0);
  }
  red[li] = acc;
  workgroupBarrier();
  for (var s = 128u; s > 0u; s = s >> 1u) {
    if (li < s) { red[li] = red[li] + red[li + s]; }
    workgroupBarrier();
  }
  if (li == 0u) { partial[wgi] = red[0]; }
  if (li < 3u) { let v = atomicLoad(&lc[li]); if (v > 0u) { atomicAdd(&counters[li], v); } }
  for (var i = li; i < p.bins; i = i + 256u) {
    let v = atomicLoad(&lh[i]);
    if (v > 0u) { atomicAdd(&hist[i], v); }
  }
}
`;

/**
 * Balayage de stratégies : 1 invocation = 1 jeu de paramètres, parcours de toute la série
 * (indicateurs, positions, exécution à l'ouverture suivante, métriques) en un seul passage.
 * Stratégies : 0 EMA, 1 SMA, 2 RSI, 3 Bollinger, 4 Donchian, 5 MACD (mêmes règles que le CPU).
 */
export const SWEEP_WGSL = /* wgsl */ `
struct S { N: u32, K: u32, strat: u32, shortOk: u32, fromBar: u32, toBar: u32, _a: u32, _b: u32, cost: f32, bpy: f32, _c: f32, _d: f32 }
@group(0) @binding(0) var<uniform> s: S;
@group(0) @binding(1) var<storage, read> c: array<f32>;
@group(0) @binding(2) var<storage, read> hh: array<f32>;
@group(0) @binding(3) var<storage, read> ll: array<f32>;
@group(0) @binding(4) var<storage, read> lr: array<vec4<f32>>;
@group(0) @binding(5) var<storage, read> prm: array<vec4<f32>>;
@group(0) @binding(6) var<storage, read_write> out: array<f32>;

struct Ema { n: u32, a: f32, sum: f32, e: f32, ok: u32 }
fn ema_new(n: u32) -> Ema { return Ema(n, 2.0 / f32(n + 1u), 0.0, 0.0, 0u); }
// t : rang de la valeur dans la série lissée (0 = première valeur)
fn ema_step(m: ptr<function, Ema>, x: f32, t: u32) {
  if ((*m).ok == 1u) { (*m).e = (*m).e + (*m).a * (x - (*m).e); return; }
  (*m).sum = (*m).sum + x;
  if (t + 1u == (*m).n) { (*m).e = (*m).sum / f32((*m).n); (*m).ok = 1u; }
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(num_workgroups) nwg: vec3<u32>) {
  let k = gid.y * nwg.x * 64u + gid.x;
  if (k >= s.K) { return; }
  let q = prm[k];
  let N = s.N;
  let cost = s.cost / 10000.0;
  // état de la stratégie
  var e1 = ema_new(max(1u, u32(q.x)));
  var e2 = ema_new(max(1u, u32(q.y)));
  var e3 = ema_new(max(1u, u32(q.z)));
  var macdT = 0u;
  var s1 = 0.0; var s1c = 0.0; var s2 = 0.0; var s2c = 0.0;
  var g = 0.0; var lo_ = 0.0;
  var cur = 0;          // position de la stratégie (machine à états)
  var posPrev = 0;      // position décidée à la clôture précédente
  // simulation et métriques
  var held = 0;         // position effectivement détenue
  var sum = 0.0; var eq = 0.0; var peak = 0.0; var maxDD = 0.0; var downs = 0.0;
  var wn = 0.0; var wm = 0.0; var ws = 0.0; var expo = 0.0;
  var tn = 0.0; var wins = 0.0; var gw = 0.0; var gl = 0.0;
  var open = false; var ot = 0.0; var oentry = 0u;
  let b0 = max(1u, s.fromBar);
  let b1 = min(s.toBar, N);
  let x0 = c[0];
  for (var t = 0u; t < N; t = t + 1u) {
    // ---- 1) rendement de la bougie t avec la position décidée en t-1
    if (t >= b0 && t < b1) {
      let tgt = posPrev;
      let L = lr[t];
      var r = 0.0;
      if (tgt != held) {
        r = f32(held) * L.x + f32(tgt) * L.y - cost * f32(abs(tgt - held));
        if (open && held != 0) {
          ot = ot + f32(held) * L.x - cost * f32(abs(held));
          if (oentry >= b0 && oentry < b1) { tn = tn + 1.0; if (ot > 0.0) { wins = wins + 1.0; gw = gw + ot; } else { gl = gl - ot; } }
          open = false;
        }
        if (tgt != 0) { open = true; oentry = t; ot = f32(tgt) * L.y - cost * f32(abs(tgt)); }
        held = tgt;
      } else {
        r = f32(held) * L.z;
        if (open) { ot = ot + r; }
      }
      sum = sum + r; eq = eq + r;
      peak = max(peak, eq); maxDD = min(maxDD, eq - peak);
      if (r < 0.0) { downs = downs + r * r; }
      if (posPrev != 0) { expo = expo + 1.0; }
      wn = wn + 1.0; let dl = r - wm; wm = wm + dl / wn; ws = ws + dl * (r - wm);
    }
    // ---- 2) indicateurs et position décidée à la clôture de t
    let x = c[t];
    var np = posPrev;
    switch s.strat {
      case 0u: {
        ema_step(&e1, x, t); ema_step(&e2, x, t);
        if (e2.ok == 1u) { if (e1.e > e2.e) { np = 1; } else if (s.shortOk == 1u) { np = -1; } else { np = 0; } } else { np = 0; }
      }
      case 1u: {
        let nf = u32(q.x); let ns = u32(q.y);
        // sommes glissantes compensées (Kahan) : ajout de la nouvelle valeur, retrait de la plus ancienne
        var a1 = x; if (t >= nf) { a1 = x - c[t - nf]; }
        let y1 = a1 - s1c; let t1 = s1 + y1; s1c = (t1 - s1) - y1; s1 = t1;
        var a2 = x; if (t >= ns) { a2 = x - c[t - ns]; }
        let y2 = a2 - s2c; let t2 = s2 + y2; s2c = (t2 - s2) - y2; s2 = t2;
        if (t + 1u >= ns) { if (s1 / f32(nf) > s2 / f32(ns)) { np = 1; } else if (s.shortOk == 1u) { np = -1; } else { np = 0; } } else { np = 0; }
      }
      case 2u: {
        let n = u32(q.x);
        if (t >= 1u) {
          let d = x - c[t - 1u];
          if (t <= n) { if (d > 0.0) { g = g + d; } else { lo_ = lo_ - d; } if (t == n) { g = g / f32(n); lo_ = lo_ / f32(n); } }
          else { g = (g * f32(n - 1u) + max(d, 0.0)) / f32(n); lo_ = (lo_ * f32(n - 1u) + max(-d, 0.0)) / f32(n); }
        }
        if (t >= n) {
          var rs = 50.0;
          if (lo_ == 0.0) { if (g != 0.0) { rs = 100.0; } } else { rs = 100.0 - 100.0 / (1.0 + g / lo_); }
          if (cur == 0) { if (rs < q.y) { cur = 1; } else if (s.shortOk == 1u && rs > 100.0 - q.y) { cur = -1; } }
          else if (cur == 1 && rs > q.z) { cur = 0; }
          else if (cur == -1 && rs < 100.0 - q.z) { cur = 0; }
          np = cur;
        } else { np = 0; }
      }
      case 3u: {
        let n = u32(q.x);
        let d = x - x0;
        // Kahan sur Σd et Σd²
        let y1 = d - s1c; let t1 = s1 + y1; s1c = (t1 - s1) - y1; s1 = t1;
        let y2 = d * d - s2c; let t2 = s2 + y2; s2c = (t2 - s2) - y2; s2 = t2;
        if (t >= n) {
          let e = c[t - n] - x0;
          let z1 = -e - s1c; let u1 = s1 + z1; s1c = (u1 - s1) - z1; s1 = u1;
          let z2 = -e * e - s2c; let u2 = s2 + z2; s2c = (u2 - s2) - z2; s2 = u2;
        }
        if (t + 1u >= n) {
          let m = s1 / f32(n);
          let sd = sqrt(max(0.0, s2 / f32(n) - m * m));
          let mid = x0 + m;
          if (cur == 0) { if (x < mid - q.y * sd) { cur = 1; } else if (s.shortOk == 1u && x > mid + q.y * sd) { cur = -1; } }
          else if (cur == 1 && x > mid) { cur = 0; }
          else if (cur == -1 && x < mid) { cur = 0; }
          np = cur;
        } else { np = 0; }
      }
      case 4u: {
        let n = u32(q.x);
        let half = max(2u, u32(floor(f32(n) / 2.0 + 0.5))); // arrondi « demi vers le haut » comme le CPU (round() WGSL arrondit au pair)
        if (t >= n) {
          var hi = -3.4e38; var loL = 3.4e38; var hiL = -3.4e38; var lo = 3.4e38;
          for (var j = t - n; j < t; j = j + 1u) { hi = max(hi, hh[j]); loL = min(loL, ll[j]); }
          for (var j = t - half; j < t; j = j + 1u) { hiL = max(hiL, hh[j]); lo = min(lo, ll[j]); }
          if (cur <= 0 && x > hi) { cur = 1; }
          else if (cur >= 0 && s.shortOk == 1u && x < loL) { cur = -1; }
          else if (cur == 1 && x < lo) { cur = 0; }
          else if (cur == -1 && x > hiL) { cur = 0; }
          np = cur;
        } else { np = 0; }
      }
      default: {
        ema_step(&e1, x, t); ema_step(&e2, x, t);
        if (e2.ok == 1u) {
          let line = e1.e - e2.e;
          ema_step(&e3, line, macdT);
          macdT = macdT + 1u;
          if (e3.ok == 1u) { if (line > e3.e) { np = 1; } else if (s.shortOk == 1u) { np = -1; } else { np = 0; } } else { np = 0; }
        } else { np = 0; }
      }
    }
    posPrev = np;
  }
  if (open && oentry >= b0 && oentry < b1) { tn = tn + 1.0; if (ot > 0.0) { wins = wins + 1.0; gw = gw + ot; } else { gl = gl - ot; } }
  let n = max(1.0, f32(b1) - f32(b0));
  let sd = select(0.0, sqrt(ws / (wn - 1.0)), wn > 1.0);
  let dsd = sqrt(downs / n) * sqrt(s.bpy);
  let o = k * 10u;
  out[o + 0u] = exp(sum) - 1.0;
  out[o + 1u] = exp(sum / n * s.bpy) - 1.0;
  out[o + 2u] = select(0.0, wm / sd * sqrt(s.bpy), sd > 0.0);
  out[o + 3u] = select(0.0, (sum / n * s.bpy) / dsd, dsd > 0.0);
  out[o + 4u] = exp(maxDD) - 1.0;
  out[o + 5u] = tn;
  out[o + 6u] = select(0.0, wins / tn, tn > 0.0);
  out[o + 7u] = select(select(0.0, 3.0e38, gw > 0.0), gw / gl, gl > 0.0);
  out[o + 8u] = expo / n;
  out[o + 9u] = sd * sqrt(s.bpy);
}
`;

// ============================================================================
//  BOURSO :: compute/gpu-host.js — processus dédié au GPU (Dawn / Vulkan).
//
//  Lancé par gpu-proxy.js (fork + canal IPC, sérialisation « advanced » : les tableaux typés
//  passent tels quels). Le pilote graphique et Dawn sont du code natif : s'ils plantent, seul ce
//  processus s'arrête ; le serveur bascule les calculs sur le CPU et peut relancer le GPU.
//
//  Messages reçus  : { t:'job', id, op:'mc'|'sweep', spec } · { t:'exit' }
//  Messages émis   : { t:'ready', info } · { t:'fail', reason } · { t:'done', id, ok, result|error } · { t:'lost', reason }
// ============================================================================
import { GpuEngine } from './gpu.js';

const send = (m) => {
  try { process.send?.(m); } catch { /* canal fermé : le parent est parti */ }
};

// le parent a disparu (arrêt du serveur, plantage) : on s'arrête aussi
process.on('disconnect', () => process.exit(0));
// Ctrl+C dans le terminal touche tout le groupe de processus : c'est au serveur de décider de
// l'arrêt (il envoie « exit », ou le canal se ferme) — sinon l'arrêt passerait pour un plantage
process.on('SIGINT', () => {});

// essai de plantage volontaire (tests uniquement) : BOURSO_GPU_CRASH_TEST=<n> → SIGSEGV au n-ième calcul
const crashAt = Number(process.env.BOURSO_GPU_CRASH_TEST ?? 0);
let jobs = 0;

const { engine, reason } = await GpuEngine.create();
if (!engine) {
  send({ t: 'fail', reason });
  process.exit(0);
}
engine.device.lost?.then?.((x) => send({ t: 'lost', reason: x?.message || 'device perdu' }));
send({ t: 'ready', info: engine.info, pid: process.pid });

process.on('message', async (m) => {
  if (m?.t === 'exit') {
    engine.destroy();
    process.exit(0);
  }
  if (m?.t !== 'job') return;
  if (crashAt && ++jobs >= crashAt) process.kill(process.pid, 'SIGSEGV');
  try {
    const result = m.op === 'mc' ? await engine.monteCarlo(m.spec) : await engine.sweep(m.spec);
    send({ t: 'done', id: m.id, ok: true, result });
  } catch (e) {
    send({ t: 'done', id: m.id, ok: false, error: e?.message ?? String(e) });
  }
});

// ============================================================================
//  BOURSO :: quant/dossier.js — le DOSSIER COMPLET d'une valeur, calculé avant l'IA.
//
//  « L'IA qui calcule » : tout ce qu'un analyste quantitatif regarderait, sur deux échelles de
//  temps (court terme : bougies 1 min de la séance et des séances récentes ; moyen terme :
//  historique quotidien), puis traduit en FAITS SAILLANTS hiérarchisés et en SCORES
//  déterministes. Le modèle de langage reçoit ce dossier (texte compact) et raisonne dessus ;
//  il ne calcule rien lui-même, il ne peut donc pas inventer un chiffre.
//
//  Entrées : séries Float64Array (OHLCV), métadonnées, carnet, flux, actualités, résultats
//  optionnels du Monte Carlo (GPU/CPU natif) et des backtests walk-forward.
// ============================================================================
import { isNum, meanVar, linreg, clamp, quantile } from './numeric.js';
import * as I from './indicators.js';
import * as V from './volatility.js';
import * as S from './stats.js';
import { fitHmmAuto } from './hmm.js';
import { dominantCycles } from './fft.js';
import { historicalAnalogs } from './analogs.js';
import { candlePatterns, supportResistance, doubleTopBottom, detectHarmonics } from './patterns.js';
import { technicalRating } from './signals.js';
import { currentSignals } from './backtest.js';
import { marketProfile } from './tpo.js';
import { scoreText } from './sentiment.js';
import { VolumeProfileJS, findVolumeNodes } from '../math/volume-profile.js';

const r2 = (x, d = 2) => (isNum(x) ? Number(x.toFixed(d)) : null);
const pctOf = (a, b) => (isNum(a) && isNum(b) && b !== 0 ? (a / b - 1) * 100 : NaN);
const last = (a) => a[a.length - 1];
const at = (a, k) => a[a.length - 1 - k];
const slice = (d, from, to = d.close.length) => ({
  open: d.open.subarray(from, to), high: d.high.subarray(from, to), low: d.low.subarray(from, to),
  close: d.close.subarray(from, to), volume: d.volume.subarray(from, to),
});

/** Agrège des bougies 1 min en bougies de k minutes, sans franchir les séances. */
export function aggregateBars(d, k, sessionBars) {
  const N = d.close.length, nb = Math.ceil(N / k) + Math.ceil(N / sessionBars), o = [], h = [], l = [], c = [], v = [];
  let cur = -1;
  for (let i = 0; i < N; i++) {
    const day = Math.floor(i / sessionBars), key = day * nb + Math.floor((i % sessionBars) / k);
    if (key !== cur) {
      cur = key;
      o.push(d.open[i]); h.push(d.high[i]); l.push(d.low[i]); c.push(d.close[i]); v.push(d.volume[i]);
    } else {
      const j = c.length - 1;
      if (d.high[i] > h[j]) h[j] = d.high[i];
      if (d.low[i] < l[j]) l[j] = d.low[i];
      c[j] = d.close[i];
      v[j] += d.volume[i];
    }
  }
  return { open: Float64Array.from(o), high: Float64Array.from(h), low: Float64Array.from(l), close: Float64Array.from(c), volume: Float64Array.from(v) };
}

function trendBlock(d, label) {
  const c = d.close, N = c.length, px = last(c);
  const e = (n) => last(I.ema(c, n)), s = (n) => last(I.sma(c, n));
  const ax = I.adx(d.high, d.low, c, 14), st = I.supertrend(d.high, d.low, c, 10, 3), ps = I.psar(d.high, d.low);
  const ich = I.ichimoku(d.high, d.low, c);
  const lr = linreg(Array.from({ length: Math.min(N, 30) }, (_, i) => i), Array.from(c.subarray(N - Math.min(N, 30)), Math.log));
  const cloudTop = Math.max(last(ich.spanA), last(ich.spanB)), cloudBot = Math.min(last(ich.spanA), last(ich.spanB));
  const mas = { ema9: e(9), ema20: e(20), ema50: e(50), ema100: e(100), ema200: e(200), sma20: s(20), sma50: s(50), sma200: s(200) };
  const above = Object.values(mas).filter((m) => isNum(m)).map((m) => (px > m ? 1 : -1));
  return {
    label, price: px, ...Object.fromEntries(Object.entries(mas).map(([k, v]) => [k, r2(v, 4)])),
    maAbove: above.filter((x) => x > 0).length, maCount: above.length,
    alignment: isNum(mas.ema20) && isNum(mas.ema50) && isNum(mas.ema200)
      ? (mas.ema20 > mas.ema50 && mas.ema50 > mas.ema200 ? 'haussier (20 > 50 > 200)' : mas.ema20 < mas.ema50 && mas.ema50 < mas.ema200 ? 'baissier (20 < 50 < 200)' : 'mixte')
      : 'insuffisant',
    adx: r2(last(ax.adx), 1), diPlus: r2(last(ax.pdi), 1), diMinus: r2(last(ax.mdi), 1),
    supertrend: last(st.dir) > 0 ? 'haussier' : 'baissier', supertrendLine: r2(last(st.line), 4),
    psar: last(ps.dir) > 0 ? 'haussier' : 'baissier',
    ichimoku: !isNum(cloudTop) ? 'insuffisant' : px > cloudTop ? 'au-dessus du nuage' : px < cloudBot ? 'sous le nuage' : 'dans le nuage',
    tenkanKijun: isNum(last(ich.tenkan)) ? (last(ich.tenkan) > last(ich.kijun) ? 'tenkan > kijun' : 'tenkan < kijun') : '—',
    slopePctPerBar: r2(lr.slope * 100, 4), slopeR2: r2(lr.r2, 3),
  };
}

function momentumBlock(d) {
  const c = d.close, m = I.macd(c), st = I.stoch(d.high, d.low, c), r = I.rsi(c, 14);
  return {
    rsi14: r2(last(r), 1), rsi14prev: r2(at(r, 1), 1), rsi2: r2(last(I.rsi(c, 2)), 1),
    macd: r2(last(m.line), 4), macdSignal: r2(last(m.signal), 4), macdHist: r2(last(m.hist), 4), macdHistPrev: r2(at(m.hist, 1), 4),
    stochK: r2(last(st.k), 1), stochD: r2(last(st.d), 1), cci20: r2(last(I.cci(d.high, d.low, c, 20)), 1),
    williamsR: r2(last(I.williamsR(d.high, d.low, c, 14)), 1), mfi14: r2(last(I.mfi(d.high, d.low, c, d.volume, 14)), 1),
    roc10: r2(last(I.roc(c, 10)), 2), roc20: r2(last(I.roc(c, 20)), 2), zscore20: r2(last(I.zscore(c, 20)), 2),
    bollPctB: r2(last(I.bollinger(c, 20, 2).pctB), 3), ultimate: r2(last(I.ultimate(d.high, d.low, c)), 1),
  };
}

/** Volume profile (rangées de `tick × k`) de bougies OHLCV. */
function profileOf(d, tick, from = 0, to = d.close.length) {
  let lo = Infinity, hi = -Infinity;
  for (let i = from; i < to; i++) { if (d.low[i] < lo) lo = d.low[i]; if (d.high[i] > hi) hi = d.high[i]; }
  if (!(hi >= lo)) return null;
  const vp = new VolumeProfileJS({ tickSize: tick, ticksPerRow: Math.max(1, Math.ceil((hi - lo) / tick / 120)) });
  for (let i = from; i < to; i++) vp.addBar(d.high[i], d.low[i], d.volume[i]);
  const st = vp.stats();
  if (!st.valid) return null;
  const snap = vp.snapshot(), nodes = findVolumeNodes(snap.total), rowPx = (r) => snap.lowPrice + (r + 0.5) * snap.ticksPerRow * snap.tickSize;
  return { poc: st.poc, vah: st.vah, val: st.val, hvn: nodes.hvn.map(rowPx), lvn: nodes.lvn.map(rowPx) };
}

/**
 * Construit le dossier complet.
 * @param {object} x voir l'en-tête : { meta, now, quote, daily, intraday, sessionBars, todayFrom, index, sector,
 *   book, flow, news, fundamentals, position, mc, backtests, peers }
 */
export function buildDossier(x) {
  const t0 = Date.now();
  const { meta, quote: q } = x, tick = meta.tick, px = q.last;
  const D = x.daily, Nd = D.close.length;
  // série quotidienne + séance du jour (bougie en cours) pour les indicateurs « au fil de l'eau »
  const DL = {
    open: Float64Array.of(...D.open, q.open), high: Float64Array.of(...D.high, Math.max(q.high, px)), low: Float64Array.of(...D.low, Math.min(q.low, px)),
    close: Float64Array.of(...D.close, px), volume: Float64Array.of(...D.volume, q.volume),
  };
  const ret = V.logReturns(DL.close), ret1y = ret.subarray(Math.max(1, ret.length - 252));
  const sections = {}, faits = [];
  const fait = (texte, sens, poids, theme) => faits.push({ texte, sens, poids, theme });

  // ---------------------------------------------------------------- identité, cotation
  sections.identite = {
    nom: meta.name, code: meta.code, isin: meta.isin || null, place: meta.exchangeName, pays: meta.country, devise: meta.currency,
    secteur: meta.sector, pasCotation: tick, indice: x.index?.name ?? null,
    donnees: x.data ? (x.data.mode === 'réel' ? `RÉELLES — ${x.data.source ?? 'source publique'}, cours différé${x.data.coursA ? ` (dernier cours ${x.data.coursA})` : ''} ; carnet d'ordres et flux acheteurs/vendeurs non disponibles` : 'SIMULÉES (mode démonstration)') : null,
  };
  const spreadTicks = q.ask > 0 && q.bid > 0 ? Math.round((q.ask - q.bid) / tick) : null;
  const book = x.book, bidQ = book ? book.bids.slice(0, 10).reduce((a, b) => a + b[1], 0) : 0, askQ = book ? book.asks.slice(0, 10).reduce((a, b) => a + b[1], 0) : 0;
  const imbalance = bidQ + askQ > 0 ? (bidQ - askQ) / (bidQ + askQ) : 0;
  const micro = book && book.bids[0] && book.asks[0] ? (book.bids[0][0] * book.asks[0][1] + book.asks[0][0] * book.bids[0][1]) / (book.bids[0][1] + book.asks[0][1]) : px;
  sections.cotation = {
    dernier: px, veille: q.prev, ouverture: q.open, plusHaut: q.high, plusBas: q.low, variationPct: r2(pctOf(px, q.prev), 2),
    gapOuverturePct: r2(pctOf(q.open, q.prev), 2), volume: q.volume, capitauxEchanges: q.turnover ?? null,
    achat: q.bid, vente: q.ask, ecartTicks: spreadTicks, microPrix: r2(micro, 4), desequilibreCarnet10: r2(imbalance, 3),
    seance: x.now?.session ?? 'CONTINUOUS', heureLocale: x.now?.time ?? null,
  };
  if (Math.abs(imbalance) > 0.25) fait(`Carnet nettement ${imbalance > 0 ? 'acheteur' : 'vendeur'} (déséquilibre ${Math.round(imbalance * 100)} % sur 10 limites)`, Math.sign(imbalance), 1, 'flux');

  // ---------------------------------------------------------------- performances
  const perf = (k) => (Nd > k ? pctOf(px, DL.close[DL.close.length - 1 - k]) : NaN);
  let ytdBase = NaN;
  if (x.dailyDates) {
    const year = x.dailyDates[Nd - 1]?.slice(0, 4);
    const idx = x.dailyDates.findIndex((s) => s.slice(0, 4) === year);
    if (idx > 0) ytdBase = D.close[idx - 1];
  }
  const ext52 = I.extremes(DL.high, DL.low, Math.max(0, DL.close.length - 252));
  sections.performances = {
    jour: r2(pctOf(px, q.prev)), semaine: r2(perf(5)), mois: r2(perf(21)), trimestre: r2(perf(63)), semestre: r2(perf(126)),
    debutAnnee: r2(pctOf(px, ytdBase)), unAn: r2(perf(252)), troisAns: r2(perf(756)), cinqAns: r2(perf(Math.min(1259, Nd - 1))),
    plusHaut52s: ext52.hi, plusBas52s: ext52.lo, positionDans52s: r2((px - ext52.lo) / (ext52.hi - ext52.lo), 3),
    ecartAuPlusHaut52sPct: r2(pctOf(px, ext52.hi)),
  };
  if (px >= ext52.hi * 0.995) fait('Cours au plus haut de 52 semaines (cassure de résistance annuelle)', 1, 2, 'tendance');
  if (px <= ext52.lo * 1.005) fait('Cours au plus bas de 52 semaines', -1, 2, 'tendance');

  // ---------------------------------------------------------------- tendance (deux échelles)
  const tD = trendBlock(DL, 'quotidien');
  sections.tendance = { quotidien: tD };
  const ID = x.intraday, sb = x.sessionBars ?? 510;
  let i15 = null, tI = null;
  if (ID && ID.close.length > 60) {
    i15 = aggregateBars(ID, 15, sb);
    tI = trendBlock(slice(ID, Math.max(0, ID.close.length - 1500)), 'intraday 1 min');
    sections.tendance.intraday = tI;
    sections.tendance.intraday15 = trendBlock(i15, 'intraday 15 min');
  }
  if (tD.maAbove >= tD.maCount - 1 && tD.maCount >= 6) fait(`Cours au-dessus de ${tD.maAbove}/${tD.maCount} moyennes mobiles quotidiennes (tendance de fond haussière)`, 1, 2, 'tendance');
  else if (tD.maAbove <= 1 && tD.maCount >= 6) fait(`Cours sous ${tD.maCount - tD.maAbove}/${tD.maCount} moyennes mobiles quotidiennes (tendance de fond baissière)`, -1, 2, 'tendance');
  if (tD.alignment.startsWith('haussier')) fait('Moyennes 20/50/200 alignées à la hausse', 1, 2, 'tendance');
  if (tD.alignment.startsWith('baissier')) fait('Moyennes 20/50/200 alignées à la baisse', -1, 2, 'tendance');
  if (tD.adx > 25) fait(`Tendance quotidienne forte (ADX ${tD.adx}, ${tD.diPlus > tD.diMinus ? 'DI+ dominant' : 'DI− dominant'})`, tD.diPlus > tD.diMinus ? 1 : -1, 2, 'tendance');
  else if (tD.adx < 18) fait(`Pas de tendance quotidienne marquée (ADX ${tD.adx}) : marché en range`, 0, 1, 'tendance');
  const ema50 = I.ema(DL.close, 50), ema200 = I.ema(DL.close, 200);
  if (isNum(at(ema200, 1)) && at(ema50, 1) < at(ema200, 1) && last(ema50) >= last(ema200)) fait('Croisement doré : EMA 50 passe au-dessus de l’EMA 200', 1, 3, 'tendance');
  if (isNum(at(ema200, 1)) && at(ema50, 1) > at(ema200, 1) && last(ema50) <= last(ema200)) fait('Croisement de la mort : EMA 50 passe sous l’EMA 200', -1, 3, 'tendance');
  if (tI) fait(`Court terme (1 min) : SuperTrend ${tI.supertrend}, ${tI.ichimoku}`, tI.supertrend === 'haussier' ? 1 : -1, 1, 'tendance');

  // ---------------------------------------------------------------- momentum
  const mD = momentumBlock(DL);
  sections.momentum = { quotidien: mD };
  if (i15) sections.momentum.intraday15 = momentumBlock(i15);
  if (mD.rsi14 > 70) fait(`RSI 14 quotidien à ${mD.rsi14} : surachat`, -1, 2, 'momentum');
  else if (mD.rsi14 < 30) fait(`RSI 14 quotidien à ${mD.rsi14} : survente`, 1, 2, 'momentum');
  if (mD.macdHist > 0 && mD.macdHistPrev <= 0) fait('MACD quotidien vient de croiser son signal à la hausse', 1, 2, 'momentum');
  if (mD.macdHist < 0 && mD.macdHistPrev >= 0) fait('MACD quotidien vient de croiser son signal à la baisse', -1, 2, 'momentum');
  if (mD.bollPctB > 1) fait('Clôture au-dessus de la bande de Bollinger haute (extension)', 0, 1, 'momentum');
  if (mD.bollPctB < 0) fait('Clôture sous la bande de Bollinger basse (extension baissière)', 0, 1, 'momentum');
  const div = (() => {
    const rs = I.rsi(DL.close, 14), z = I.zigzag(DL.high, DL.low, { atrSeries: I.atr(DL.high, DL.low, DL.close, 14), mult: 2 });
    const hs = z.swings.filter((s) => s.type === 1).slice(-2), ls = z.swings.filter((s) => s.type === -1).slice(-2);
    if (hs.length === 2 && hs[1].price > hs[0].price && rs[hs[1].i] < rs[hs[0].i] - 3) return { type: 'baissière', i: hs[1].i };
    if (ls.length === 2 && ls[1].price < ls[0].price && rs[ls[1].i] > rs[ls[0].i] + 3) return { type: 'haussière', i: ls[1].i };
    return null;
  })();
  if (div && DL.close.length - div.i < 25) {
    sections.momentum.divergence = div.type;
    fait(`Divergence ${div.type} RSI / prix sur les derniers sommets-creux`, div.type === 'haussière' ? 1 : -1, 2, 'momentum');
  }

  // ---------------------------------------------------------------- volatilité
  const atr14 = last(I.atr(DL.high, DL.low, DL.close, 14));
  const volSeries = V.rollingVol(DL.close, 20), vol20 = last(volSeries), volPct = V.percentileRank(volSeries.subarray(Math.max(0, volSeries.length - 252)), vol20);
  const garch = V.garch11(ret.subarray(Math.max(1, ret.length - 756)));
  const bb = I.bollinger(DL.close, 20, 2), bw = bb.width, bwPct = V.percentileRank(bw.subarray(Math.max(0, bw.length - 252)), last(bw));
  sections.volatilite = {
    atr14: r2(atr14, 4), atrPct: r2((atr14 / px) * 100, 2), vol20jAnnualisee: r2(vol20 * 100, 1), centileVol1an: r2(volPct * 100, 0),
    parkinson20: r2(V.parkinson(DL.high, DL.low, 20) * 100, 1), garmanKlass20: r2(V.garmanKlass(DL.open, DL.high, DL.low, DL.close, 20) * 100, 1),
    yangZhang20: r2(V.yangZhang(DL.open, DL.high, DL.low, DL.close, 20) * 100, 1),
    garch: garch ? { alpha: r2(garch.alpha, 4), beta: r2(garch.beta, 4), persistance: r2(garch.persistence, 4), demiVieChocsJours: r2(garch.halfLife, 1),
      volDemainAnnualisee: r2(Math.sqrt(garch.nextVar * 252) * 100, 1), volLongTermeAnnualisee: r2(Math.sqrt(garch.uncondVar * 252) * 100, 1) } : null,
    amplitudeJourVsAtr: r2((q.high - q.low) / atr14, 2), largeurBollingerCentile: r2(bwPct * 100, 0),
  };
  if (bwPct < 0.1) fait('Bandes de Bollinger très resserrées (compression : mouvement fort à venir, sens inconnu)', 0, 2, 'volatilite');
  if (volPct > 0.9) fait(`Volatilité dans les 10 % les plus élevées de l’année (${r2(vol20 * 100, 0)} % annualisée)`, 0, 2, 'volatilite');
  if (garch && Math.sqrt(garch.nextVar) > 1.3 * Math.sqrt(garch.uncondVar)) fait('GARCH : volatilité attendue demain nettement au-dessus de la normale', 0, 1, 'volatilite');

  // ---------------------------------------------------------------- volumes, flux
  const vAvg20 = meanVar(D.volume, { from: Math.max(0, Nd - 20), to: Nd }).mean;
  let relVol = NaN;
  if (ID && x.todayFrom >= sb) {
    // volume relatif à heure égale : volume cumulé du jour vs moyenne des séances précédentes à la même minute
    const m = ID.close.length - x.todayFrom;
    let today = 0, past = 0, days = 0;
    for (let i = x.todayFrom; i < ID.close.length; i++) today += ID.volume[i];
    for (let s = x.todayFrom - sb; s >= 0 && days < 10; s -= sb, days++) for (let i = s; i < s + m; i++) past += ID.volume[i];
    relVol = days ? today / (past / days) : NaN;
  }
  const obv = I.obv(DL.close, DL.volume), obvSlope = linreg([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], Array.from(obv.subarray(obv.length - 10))).slope;
  const fl = x.flow;
  sections.volumes = {
    volumeJour: q.volume, moyenne20j: Math.round(vAvg20), volumeRelatifHeureEgale: r2(relVol, 2),
    cmf20: r2(last(I.cmf(DL.high, DL.low, DL.close, DL.volume, 20)), 3), obvPente10j: obvSlope > 0 ? 'montante' : 'descendante',
    flux: fl ? { volumeAcheteur: fl.buyVol, volumeVendeur: fl.sellVol, partAcheteuse: r2(fl.buyVol / Math.max(1, fl.buyVol + fl.sellVol), 3),
      grosOrdresAchat: fl.largeBuys ?? 0, grosOrdresVente: fl.largeSells ?? 0 } : null,
  };
  if (relVol > 2) fait(`Volume ${r2(relVol, 1)}× supérieur à la normale à cette heure : intérêt marqué`, 0, 2, 'volume');
  if (relVol < 0.5) fait('Volume faible pour l’heure : mouvement peu confirmé', 0, 1, 'volume');
  if (fl && fl.buyVol + fl.sellVol > 0) {
    const share = fl.buyVol / (fl.buyVol + fl.sellVol);
    if (share > 0.58) fait(`Acheteurs agressifs majoritaires (${Math.round(share * 100)} % du volume)`, 1, 1, 'flux');
    if (share < 0.42) fait(`Vendeurs agressifs majoritaires (${Math.round((1 - share) * 100)} % du volume)`, -1, 1, 'flux');
  }

  // ---------------------------------------------------------------- profil de volume, TPO, VWAP
  sections.profil = {};
  if (ID && ID.close.length > x.todayFrom) {
    const today = slice(ID, x.todayFrom);
    const vw = I.vwap(today.high, today.low, today.close, today.volume);
    const vwapNow = last(vw.mid), vsd = last(vw.sd);
    const vpToday = profileOf(ID, tick, x.todayFrom);
    const vp5 = profileOf(ID, tick, Math.max(0, x.todayFrom - 4 * sb));
    const tpo = marketProfile({ high: ID.high, low: ID.low, from: x.todayFrom, to: ID.close.length, periodBars: 30, tick });
    sections.profil = {
      vwap: r2(vwapNow, 4), ecartVwapSigma: r2(vsd > 0 ? (px - vwapNow) / vsd : 0, 2), seance: vpToday, cinqSeances: vp5,
      tpo: tpo ? { poc: tpo.poc, vah: tpo.vah, val: tpo.val, balanceInitiale: tpo.ib, singlePrints: tpo.singlePrints.length, extremeHautPauvre: tpo.poorHigh, extremeBasPauvre: tpo.poorLow } : null,
      positionZoneValeur: vpToday ? (px > vpToday.vah ? 'au-dessus' : px < vpToday.val ? 'en dessous' : 'dans la zone') : null,
    };
    if (vsd > 0 && Math.abs(px - vwapNow) / vsd > 2) fait(`Cours à ${r2((px - vwapNow) / vsd, 1)} écarts-types du VWAP (tension, retour possible)`, px > vwapNow ? -1 : 1, 1, 'profil');
    else fait(`Cours ${px > vwapNow ? 'au-dessus' : 'en dessous'} du VWAP de séance (${px > vwapNow ? 'acheteurs' : 'vendeurs'} en contrôle)`, px > vwapNow ? 1 : -1, 1, 'profil');
    if (vpToday && px > vpToday.vah) fait('Cours au-dessus de la zone de valeur de la séance (acceptation de prix plus hauts ?)', 1, 1, 'profil');
    if (vpToday && px < vpToday.val) fait('Cours sous la zone de valeur de la séance', -1, 1, 'profil');
  }

  // ---------------------------------------------------------------- niveaux
  const piv = Nd ? I.pivots(D.high[Nd - 1], D.low[Nd - 1], D.close[Nd - 1]) : null;
  const atrD = I.atr(DL.high, DL.low, DL.close, 14);
  const zz = I.zigzag(DL.high, DL.low, { atrSeries: atrD, mult: 2, from: Math.max(0, DL.close.length - 260) });
  const vpNodes = [...(sections.profil.cinqSeances?.hvn ?? []), sections.profil.cinqSeances?.poc].filter(isNum);
  const sr = supportResistance({ price: px, atr: atr14, swings: zz.swings, volumeNodes: vpNodes, pivots: piv?.classic ?? {} });
  sections.niveaux = {
    pivotsClassiques: piv ? Object.fromEntries(Object.entries(piv.classic).map(([k, v]) => [k, r2(v, 4)])) : null,
    pivotsCamarilla: piv ? { R3: r2(piv.camarilla.R3, 4), R4: r2(piv.camarilla.R4, 4), S3: r2(piv.camarilla.S3, 4), S4: r2(piv.camarilla.S4, 4) } : null,
    supports: sr.supports.map((z) => ({ prix: r2(z.price, 4), force: r2(z.strength, 1), origine: z.kinds.join('+') })),
    resistances: sr.resistances.map((z) => ({ prix: r2(z.price, 4), force: r2(z.strength, 1), origine: z.kinds.join('+') })),
    derniersPivotsZigZag: zz.swings.slice(-6).map((s) => ({ type: s.type > 0 ? 'sommet' : 'creux', prix: r2(s.price, 4), ilYa: DL.close.length - 1 - s.i })),
  };
  if (sr.nearestSupport && (px - sr.nearestSupport.price) / atr14 < 0.5) fait(`Cours proche d’un support (${r2(sr.nearestSupport.price, 2)}, ${sr.nearestSupport.kinds.join('+')})`, 1, 1, 'niveaux');
  if (sr.nearestResistance && (sr.nearestResistance.price - px) / atr14 < 0.5) fait(`Cours sous une résistance proche (${r2(sr.nearestResistance.price, 2)}, ${sr.nearestResistance.kinds.join('+')})`, -1, 1, 'niveaux');

  // ---------------------------------------------------------------- statistiques
  const mo = S.moments(ret1y), ac1 = S.autocorr(ret1y, 1), vr = S.varianceRatio(ret1y, 5), hu = S.hurst(ret.subarray(Math.max(1, ret.length - 756)));
  const logP = Float64Array.from(DL.close.subarray(Math.max(0, DL.close.length - 252)), Math.log);
  const adfRes = S.adf(logP), lb = S.ljungBox(ret1y, 10), jb = S.jarqueBera(ret1y);
  const e50 = I.ema(DL.close, 50);
  const dev = Float64Array.from(DL.close, (v, i) => (isNum(e50[i]) ? Math.log(v / e50[i]) : NaN)).subarray(Math.max(60, DL.close.length - 252));
  sections.statistiques = {
    rendementMoyenJourPct: r2(mo.mean * 100, 3), ecartTypeJourPct: r2(mo.sd * 100, 3), asymetrie: r2(mo.skew, 3), kurtosisExces: r2(mo.kurt, 2),
    normaliteJarqueBera: jb.normal ? 'compatible' : 'rejetée (queues épaisses)', autocorrelation1: r2(ac1, 3), ljungBoxP: r2(lb.p, 4),
    hurst: r2(hu, 3), ratioVariance5: r2(vr.vr, 3), ratioVarianceZ: r2(vr.zStar, 2),
    adf: adfRes ? { stat: r2(adfRes.stat, 3), seuil5: r2(adfRes.crit[5], 3), stationnaire: adfRes.stationary } : null,
    demiVieEcartEma50Jours: r2(S.halfLife(dev), 1),
  };
  if (ID && ID.close.length > 200) {
    const ri = V.logReturns(ID.close.subarray(Math.max(0, ID.close.length - 3000)));
    sections.statistiques.intraday = { autocorrelation1min: r2(S.autocorr(ri, 1), 3), ratioVariance10: r2(S.varianceRatio(ri, 10).vr, 3) };
  }
  if (hu > 0.58) fait(`Exposant de Hurst ${r2(hu, 2)} : série persistante (les tendances ont tendance à durer)`, 0, 1, 'stats');
  if (hu < 0.42) fait(`Exposant de Hurst ${r2(hu, 2)} : retour à la moyenne marqué`, 0, 1, 'stats');

  // ---------------------------------------------------------------- régime (Markov caché)
  const hmm = fitHmmAuto(ret.subarray(Math.max(1, ret.length - 1000)), { Ks: [2, 3], restarts: 4 });
  if (hmm) {
    const cur = hmm.states[hmm.current], f5 = hmm.forecast(5);
    sections.regime = {
      regimesSignificatifs: hmm.regimesSupported,
      choixNombreEtats: hmm.selection.map((x) => ({ etats: x.K, bic: r2(x.bic, 1) })),
      etats: hmm.states.map((s) => ({ nom: s.label, rendementJourPct: r2(s.mu * 100, 3), volJourPct: r2(s.sd * 100, 2), occupation: r2(s.occupancyPosterior, 3), dureeMoyenneJours: r2(s.duration, 1) })),
      etatActuel: cur.label, probabiliteEtatActuel: r2(hmm.filtered[hmm.current], 3), dureeAttendueJours: r2(hmm.expectedDuration, 1),
      probabilitesDans5Jours: hmm.states.map((s, k) => ({ nom: s.label, p: r2(f5[k], 3) })),
      transitions: hmm.A.map((row) => row.map((v) => r2(v, 3))),
    };
    if (hmm.regimesSupported) {
      fait(`Régime de Markov : « ${cur.label} » (probabilité ${Math.round(hmm.filtered[hmm.current] * 100)} %, durée moyenne ${r2(hmm.expectedDuration, 0)} j)`,
        cur.dir === 'hausse' ? 1 : cur.dir === 'baisse' ? -1 : 0, 2, 'regime');
    } else {
      sections.regime.note = 'Le modèle à un seul état est préféré (BIC) : pas de régime distinct détecté, ne pas s\'appuyer sur ces états.';
    }
  }

  // ---------------------------------------------------------------- cycles
  const cyc = dominantCycles(DL.close.subarray(Math.max(0, DL.close.length - 512)), { minPeriod: 8, maxPeriod: 120, top: 3 });
  sections.cycles = cyc.map((cy) => ({ periodeJours: r2(cy.period, 1), partSpectre: r2(cy.share, 3), significatif95: cy.significant, ratioBruitRouge: r2(cy.redRatio, 2), etat: cy.state, joursAvantCreux: r2(cy.barsToTrough, 0), joursAvantSommet: r2(cy.barsToPeak, 0) }));
  if (cyc[0] && cyc[0].significant && cyc[0].share > 0.12) fait(`Cycle dominant ~${r2(cyc[0].period, 0)} séances, actuellement ${cyc[0].state}`, cyc[0].state.includes('montante') ? 1 : cyc[0].state.includes('descendante') ? -1 : 0, 1, 'cycles');

  // ---------------------------------------------------------------- analogues historiques (mémoire du marché)
  const an = historicalAnalogs(DL, { k: 30, horizons: [5, 20], liveLast: true, dates: x.dailyDates ? [...x.dailyDates, x.now?.date ?? 'aujourd’hui'] : null });
  if (an) {
    sections.analogues = {
      methode: '30 séances passées les plus proches (8 variables d’état normalisées), espacées pour que leurs fenêtres futures ne se recouvrent pas ; comparées à toutes les séances',
      candidats: an.candidates,
      horizons: an.horizons.map((h) => ({
        seances: h.h, cas: h.k, hausseAnaloguesPct: r2(h.analog.pPos * 100, 1), hausseBasePct: r2(h.base.pPos * 100, 1),
        medianeAnaloguesPct: r2(h.analog.median * 100, 2), medianeBasePct: r2(h.base.median * 100, 2),
        q10AnaloguesPct: r2(h.analog.q10 * 100, 2), q90AnaloguesPct: r2(h.analog.q90 * 100, 2), z: r2(h.z, 2), significatif: h.significant,
      })),
      plusProches: an.nearest.slice(0, 5).map((nb) => ({ date: nb.date, distance: r2(nb.distance, 2), ensuite5sPct: r2(nb.fwd[5] * 100, 2), ensuite20sPct: r2(nb.fwd[20] * 100, 2) })),
    };
    for (const h of an.horizons) {
      if (!h.significant) continue;
      fait(`Situations comparables du passé (${h.k} cas) : hausse à ${h.h} séances dans ${Math.round(h.analog.pPos * 100)} % des cas, contre ${Math.round(h.base.pPos * 100)} % en moyenne (z = ${r2(h.z, 1)})`,
        Math.sign(h.z), 1, 'analogues');
    }
  }

  // ---------------------------------------------------------------- relatif (indice, secteur)
  if (x.index?.daily) {
    const ri = V.logReturns(x.index.daily), n = Math.min(ret.length, ri.length, 252);
    const bc = S.betaCorr(ret.subarray(ret.length - n), ri.subarray(ri.length - n));
    const rs3m = perf(63) - pctOf(last(x.index.daily), at(x.index.daily, 63));
    sections.relatif = { indice: x.index.name, beta1an: r2(bc.beta, 2), correlation1an: r2(bc.corr, 2), forceRelative3mPts: r2(rs3m, 2), secteur: x.sector ?? null };
    if (rs3m > 5) fait(`Surperforme son indice de ${r2(rs3m, 1)} pts sur 3 mois`, 1, 1, 'relatif');
    if (rs3m < -5) fait(`Sous-performe son indice de ${r2(-rs3m, 1)} pts sur 3 mois`, -1, 1, 'relatif');
  }

  // ---------------------------------------------------------------- risque
  const dd = S.drawdowns(DL.close.subarray(Math.max(0, DL.close.length - 252)));
  const vh = S.varHistorical(ret1y, 0.05), vh99 = S.varHistorical(ret1y, 0.01), cf = S.varCornishFisher(mo.mean, mo.sd, mo.skew, mo.kurt, 0.05);
  sections.risque = {
    var95JourPct: r2(vh.var * 100, 2), es95JourPct: r2(vh.es * 100, 2), var99JourPct: r2(vh99.var * 100, 2), varCornishFisher95Pct: r2(cf.var * 100, 2),
    perteMaxi1anPct: r2(dd.maxDD * 100, 1), drawdownActuelPct: r2(dd.current * 100, 1), sharpe1an: r2(S.sharpe(ret1y), 2), sortino1an: r2(S.sortino(ret1y), 2),
  };

  // ---------------------------------------------------------------- résumé technique, figures
  sections.technique = { quotidien: summarizeRating(technicalRating(DL)) };
  if (i15 && i15.close.length > 210) sections.technique.intraday15 = summarizeRating(technicalRating(i15));
  const trendDir = tD.ema20 > tD.ema50 ? 1 : -1;
  const cps = candlePatterns(DL.open, DL.high, DL.low, DL.close, DL.close.length - 1, trendDir, atr14);
  sections.chandeliers = cps.map((p) => ({ figure: p.name, biais: p.bias, force: p.strength, sens: p.text }));
  for (const p of cps.filter((c) => c.strength >= 2)) fait(`Chandelier quotidien : ${p.name} (${p.text})`, p.bias, p.strength >= 3 ? 2 : 1, 'figures');
  const dtb = doubleTopBottom(zz.swings);
  const harm = detectHarmonics(zz.provisional ? [...zz.swings, zz.provisional] : zz.swings);
  sections.figures = { doubles: dtb.map((f) => f.text), harmonique: harm ? { figure: harm.name, biais: harm.bias > 0 ? 'haussier' : 'baissier', erreurPct: r2(harm.error * 100, 1), zoneRetournement: { bas: r2(harm.prz.lo, 4), haut: r2(harm.prz.hi, 4) } } : null };
  for (const f of dtb) fait(`${f.name} : ${f.text}`, f.bias, 2, 'figures');
  if (harm) fait(`Figure harmonique ${harm.name} ${harm.bias > 0 ? 'haussière' : 'baissière'} détectée (écart moyen ${r2(harm.error * 100, 1)} %)`, harm.bias, 1, 'figures');

  // ---------------------------------------------------------------- stratégies (signal actuel + robustesse)
  sections.strategies = { signauxActuels: currentSignals(DL).map((s) => ({ strategie: s.name, position: s.position > 0 ? 'acheteur' : s.position < 0 ? 'vendeur' : 'neutre' })) };
  if (x.backtests?.length) {
    sections.strategies.walkForward = x.backtests.map((b) => ({ strategie: b.name, sharpeHorsEchantillon: r2(b.oos.sharpe, 2), rendementHorsEchantillonPct: r2(b.oos.totalReturn * 100, 1),
      perteMaxPct: r2(b.oos.maxDD * 100, 1), transactions: b.oos.trades, robustesse: r2(b.robustness, 2), parametres: b.chosen.at(-1)?.params ?? null }));
    const best = [...x.backtests].sort((a, b) => b.oos.sharpe - a.oos.sharpe)[0];
    if (best && best.oos.sharpe > 0.8) fait(`Stratégie la plus robuste hors échantillon : ${best.name} (Sharpe ${r2(best.oos.sharpe, 2)})`, 0, 1, 'strategies');
  }

  // ---------------------------------------------------------------- Monte Carlo (calcul GPU / CPU natif)
  if (x.mc) {
    const m = x.mc;
    sections.montecarlo = {
      moteur: m.backend, trajectoires: m.paths, horizon: x.mcHorizon ?? null, dureeMs: r2(m.ms, 0),
      probaHausse: r2(m.pUp.p, 4), probaObjectifAvantStop: r2(m.pTarget.p, 4), probaStopAvantObjectif: r2(m.pStop.p, 4), erreurStandard: r2(m.pTarget.se, 5),
      objectif: x.mcLevels?.up ?? null, stop: x.mcLevels?.down ?? null,
      quantilesPrix: Object.fromEntries(Object.entries(m.quantiles).map(([k, v]) => [`q${Math.round(Number(k) * 100)}`, r2(v.price, 4)])),
      var95Pct: r2(m.var95 * 100, 2), es95Pct: r2(m.es95 * 100, 2),
    };
    if (isNum(m.pTarget.p) && isNum(m.pStop.p)) {
      const edge = m.pTarget.p - m.pStop.p;
      fait(`Monte Carlo (${m.paths.toLocaleString('fr-FR')} trajectoires) : objectif avant stop ${Math.round(m.pTarget.p * 100)} % contre ${Math.round(m.pStop.p * 100)} %`, Math.abs(edge) > 0.08 ? Math.sign(edge) : 0, 2, 'montecarlo');
    }
  }

  // ---------------------------------------------------------------- actualités
  const news = (x.news ?? []).map((n) => {
    const lex = scoreText(n.title + ' ' + (n.summary ?? ''));
    return { titre: n.title, source: n.source ?? null, ilYaMin: n.minutesAgo ?? null, tonalite: r2(isNum(n.score) ? n.score : lex.score, 2), confiance: r2(lex.confidence, 2) };
  });
  const recent = news.filter((n) => n.ilYaMin === null || n.ilYaMin < 60 * 24 * 3);
  const newsScore = recent.length ? recent.reduce((a, n) => a + n.tonalite * (n.ilYaMin !== null && n.ilYaMin < 120 ? 1.5 : 1), 0) / recent.length : 0;
  sections.actualites = { nombre: news.length, tonaliteMoyenne: r2(newsScore, 2), titres: news.slice(0, 10) };
  if (recent.length && Math.abs(newsScore) > 0.2) fait(`Actualités récentes ${newsScore > 0 ? 'favorables' : 'défavorables'} (tonalité ${r2(newsScore, 2)})`, Math.sign(newsScore), 2, 'actualites');

  if (x.fundamentals) sections.fondamentaux = { ...x.fundamentals };
  if (x.position) sections.position = x.position;
  // mémoire de l'IA : ses analyses précédentes sur cette valeur, leur issue réelle, sa fiabilité mesurée
  if (x.memory) sections.memoire = x.memory;

  // ---------------------------------------------------------------- scores déterministes
  const tr = sections.technique.quotidien.note;
  const sTrend = clamp(((tD.maAbove / Math.max(1, tD.maCount)) * 2 - 1) * 0.5 + (tD.supertrend === 'haussier' ? 0.25 : -0.25) + (tD.diPlus > tD.diMinus ? 0.25 : -0.25) * Math.min(1, (tD.adx ?? 0) / 25), -1, 1);
  const sMom = clamp(((mD.rsi14 ?? 50) - 50) / 25 * 0.5 + (mD.macdHist > 0 ? 0.3 : -0.3) + clamp((mD.roc20 ?? 0) / 10, -0.2, 0.2), -1, 1);
  const sFlow = clamp(imbalance * 0.5 + (fl ? ((fl.buyVol / Math.max(1, fl.buyVol + fl.sellVol)) - 0.5) * 2 * 0.5 : 0), -1, 1);
  const sMc = x.mc ? clamp((x.mc.pTarget.p - x.mc.pStop.p) * 2, -1, 1) : 0;
  const sRegime = hmm?.regimesSupported ? (hmm.states[hmm.current].dir === 'hausse' ? 1 : hmm.states[hmm.current].dir === 'baisse' ? -1 : 0) * hmm.filtered[hmm.current] : 0;
  const scores = { tendance: r2(sTrend, 3), momentum: r2(sMom, 3), flux: r2(sFlow, 3), actualites: r2(newsScore, 3), regime: r2(sRegime, 3), montecarlo: r2(sMc, 3), technique: r2(tr, 3) };
  const W = { tendance: 0.25, momentum: 0.15, flux: 0.1, actualites: 0.15, regime: 0.1, montecarlo: 0.1, technique: 0.15 };
  scores.global = r2(Object.entries(W).reduce((a, [k, w]) => a + w * (scores[k] ?? 0), 0), 3);

  faits.sort((a, b) => b.poids - a.poids);
  const features = {
    price: px, tick_size: tick, spread_ticks: spreadTicks ?? 1, age_ms: x.ageMs ?? 0, session: x.now?.session ?? 'CONTINUOUS',
    volume_profile: sections.profil.seance ? { poc: sections.profil.seance.poc, vah: sections.profil.seance.vah, val: sections.profil.seance.val, hvn: sections.profil.seance.hvn, lvn: sections.profil.seance.lvn } : {},
    levels: [...sr.supports, ...sr.resistances].map((z) => z.price).concat(Object.values(piv?.classic ?? {})).filter(isNum),
    atr: atr14,
  };
  return { version: 3, sym: meta.sym, name: meta.name, generatedAt: new Date().toISOString(), computeMs: Date.now() - t0, sections, faits, scores, features };
}

function summarizeRating(t) {
  return { note: r2(t.rating, 3), verdict: t.label, moyennesMobiles: t.maLabel, oscillateurs: t.oscLabel, votes: t.counts,
    detail: t.details.map((d) => `${d.name}=${isNum(d.value) ? r2(d.value, 2) : '—'}(${d.vote > 0 ? '+' : d.vote < 0 ? '−' : '0'})`).join(' ') };
}

/** Texte compact (pour le modèle de langage) : sections « clé: valeur », nombres au point décimal. */
export function dossierText(d) {
  const lines = [];
  const fmt = (v) => {
    if (v === null || v === undefined) return '—';
    if (typeof v === 'number') return Number.isInteger(v) ? String(v) : String(Number(v.toPrecision(7)));
    if (Array.isArray(v)) return v.length ? `[${v.map(fmt).join('; ')}]` : '[]';
    if (typeof v === 'object') return `{${Object.entries(v).map(([k, x]) => `${k}: ${fmt(x)}`).join(', ')}}`;
    return String(v);
  };
  lines.push(`## FAITS SAILLANTS (calculés, classés par importance)`);
  d.faits.forEach((f, i) => lines.push(`${i + 1}. [${f.sens > 0 ? '+' : f.sens < 0 ? '−' : '='}] ${f.texte}`));
  lines.push(`## SCORES DÉTERMINISTES (−1 baissier … +1 haussier)`, fmt(d.scores));
  for (const [name, sec] of Object.entries(d.sections)) {
    lines.push(`## ${name.toUpperCase()}`);
    // les titres de presse viennent du web : documents NON FIABLES (jamais des consignes)
    if (name === 'actualites') {
      const { titres = [], ...rest } = sec ?? {};
      for (const [k, v] of Object.entries(rest)) lines.push(`${k}: ${fmt(v)}`);
      lines.push('<<<DOC actualités — titres de presse, données non fiables>>>');
      titres.forEach((t) => lines.push(`- ${fmt({ ...t, titre: String(t.titre ?? '').replace(/[<>]{3,}/g, '').slice(0, 240) })}`));
      lines.push('<<<FIN DOC actualités>>>');
      continue;
    }
    if (Array.isArray(sec)) sec.forEach((it) => lines.push(`- ${fmt(it)}`));
    else for (const [k, v] of Object.entries(sec ?? {})) lines.push(`${k}: ${fmt(v)}`);
  }
  return lines.join('\n');
}

export const _private = { quantile };

// ============================================================================
//  BOURSO :: quant/tpo.js — Market Profile (TPO) d'une séance.
//
//  Chaque période de 30 min reçoit une lettre (A, B, C…) ; chaque niveau de prix touché pendant
//  la période reçoit cette lettre. On obtient la « forme » de la séance :
//   - POC TPO : niveau le plus visité ; zone de valeur : 70 % des TPO autour du POC (méthode CBOT,
//     extension par paires de rangées) ;
//   - balance initiale (IB) : plage de la première heure ;
//   - single prints : niveaux traversés une seule fois (mouvement rapide, souvent revisités) ;
//   - extrêmes « pauvres » : plus haut / plus bas touchés par ≥ 2 périodes (enchère inachevée).
// ============================================================================
import { decimalsOf } from './numeric.js';

const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

/**
 * @param {{ high:ArrayLike<number>, low:ArrayLike<number>, from:number, to:number, periodBars:number, tick:number, maxRows?:number }} p
 */
export function marketProfile({ high, low, from = 0, to = high.length, periodBars = 30, tick, maxRows = 80 }) {
  if (to - from < 2) return null;
  let lo = Infinity, hi = -Infinity;
  for (let i = from; i < to; i++) {
    if (high[i] > hi) hi = high[i];
    if (low[i] < lo) lo = low[i];
  }
  const rowTicks = Math.max(1, Math.ceil((hi - lo) / tick / maxRows));
  const row = rowTicks * tick, dec = decimalsOf(tick);
  const base = Math.floor(lo / row + 1e-9) * row;
  const nRows = Math.floor((hi - base) / row + 1e-9) + 1;
  const marks = Array.from({ length: nRows }, () => new Set());
  const periods = Math.ceil((to - from) / periodBars);
  for (let p = 0; p < periods; p++) {
    let ph = -Infinity, pl = Infinity;
    for (let i = from + p * periodBars; i < Math.min(to, from + (p + 1) * periodBars); i++) {
      if (high[i] > ph) ph = high[i];
      if (low[i] < pl) pl = low[i];
    }
    const a = Math.floor((pl - base) / row + 1e-9), b = Math.floor((ph - base) / row + 1e-9);
    for (let r = Math.max(0, a); r <= Math.min(nRows - 1, b); r++) marks[r].add(LETTERS[p % LETTERS.length]);
  }
  const counts = marks.map((s) => s.size);
  const total = counts.reduce((a, b) => a + b, 0);
  const mid = (nRows - 1) / 2;
  let poc = 0;
  for (let r = 1; r < nRows; r++) if (counts[r] > counts[poc] || (counts[r] === counts[poc] && Math.abs(r - mid) < Math.abs(poc - mid))) poc = r;
  let up = poc, dn = poc, acc = counts[poc];
  while (acc < 0.7 * total && (up < nRows - 1 || dn > 0)) {
    const a = (up + 1 < nRows ? counts[up + 1] : 0) + (up + 2 < nRows ? counts[up + 2] : 0);
    const b = (dn - 1 >= 0 ? counts[dn - 1] : 0) + (dn - 2 >= 0 ? counts[dn - 2] : 0);
    if (a >= b && up < nRows - 1) {
      const k = Math.min(2, nRows - 1 - up);
      for (let j = 1; j <= k; j++) acc += counts[up + j];
      up += k;
    } else if (dn > 0) {
      const k = Math.min(2, dn);
      for (let j = 1; j <= k; j++) acc += counts[dn - j];
      dn -= k;
    } else break;
  }
  const px = (r) => Number((base + r * row).toFixed(dec));
  let ibHi = -Infinity, ibLo = Infinity;
  for (let i = from; i < Math.min(to, from + 2 * periodBars); i++) {
    if (high[i] > ibHi) ibHi = high[i];
    if (low[i] < ibLo) ibLo = low[i];
  }
  const single = [];
  for (let r = 1; r < nRows - 1; r++) if (counts[r] === 1) single.push(px(r));
  return {
    rowSize: row, rows: marks.map((s, r) => ({ price: px(r), letters: [...s].join(''), count: counts[r] })),
    poc: px(poc), vah: Number((base + (up + 1) * row - tick).toFixed(dec)), val: px(dn), ib: { hi: ibHi, lo: ibLo }, singlePrints: single,
    poorHigh: counts[nRows - 1] >= 2, poorLow: counts[0] >= 2, periods, total,
  };
}

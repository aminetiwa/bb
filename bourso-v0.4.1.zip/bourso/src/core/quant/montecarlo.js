// ============================================================================
//  BOURSO :: quant/montecarlo.js — simulation de Monte Carlo (référence CPU, double précision).
//
//  Modèles de trajectoire (pas = 1 bougie de l'horizon choisi, rendements logarithmiques) :
//   - 'garch'     : GARCH(1,1) ajusté sur l'historique, innovations normales ou Student-t ;
//   - 'bootstrap' : rééchantillonnage par blocs stationnaire (Politis-Romano) des rendements réels,
//                   qui conserve queues épaisses et grappes de volatilité.
//  Barrières (objectif / stop) surveillées en CONTINU grâce à la correction du pont brownien :
//  entre deux pas, la probabilité d'avoir touché la barrière vaut exp(−2(B−a)(B−b)/σ²).
//  Format de sortie commun aux trois moteurs (JS, C++ natif, GPU Dawn) → comparaisons directes.
//  Chaque trajectoire a son propre flux aléatoire (graine dérivée de son numéro) : résultat
//  identique quel que soit le nombre de cœurs / l'ordre d'exécution.
// ============================================================================
import { Rng, isNum, sortedFinite, quantileSorted } from './numeric.js';

export const QUANTILES = [0.01, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.99];

/** Graine du flux de la trajectoire p (splitmix32). */
export function pathSeed(seed, p) {
  let z = (seed ^ Math.imul(p + 1, 0x9e3779b9)) >>> 0;
  z = Math.imul(z ^ (z >>> 16), 0x85ebca6b);
  z = Math.imul(z ^ (z >>> 13), 0xc2b2ae35);
  return (z ^ (z >>> 16)) >>> 0;
}

/** Bornes de l'histogramme (rendement log) : ±k écarts-types de l'horizon, au moins ±30 %. */
export function histRange(spec) {
  const H = spec.steps;
  let v;
  if (spec.model === 'garch') v = spec.uncondVar ?? spec.h0;
  else {
    let s = 0, s2 = 0;
    for (const x of spec.returns) { s += x; s2 += x * x; }
    const n = spec.returns.length;
    v = s2 / n - (s / n) ** 2;
  }
  const sd = Math.sqrt(Math.max(1e-12, v * H));
  const half = Math.max(0.3, 9 * sd);
  return { lo: -half, hi: half };
}

/** Bornes et pas des points de contrôle (quantiles intermédiaires pour l'éventail). */
export function checkpointSteps(steps, count = 12) {
  const out = [];
  for (let k = 1; k <= count; k++) out.push(Math.max(1, Math.round((steps * k) / count)));
  return [...new Set(out)];
}

/**
 * @param {{ model:'garch'|'bootstrap', s0:number, steps:number, paths:number, seed?:number,
 *   mu?:number, omega?:number, alpha?:number, beta?:number, h0?:number, uncondVar?:number, nu?:number,
 *   returns?:Float64Array, block?:number, up?:number, down?:number, bins?:number, checkpoints?:number[],
 *   pathFrom?:number, pathTo?:number }} spec
 */
export function simulateMC(spec) {
  const t0 = performance.now();
  const { steps: H, s0 } = spec, seed = spec.seed ?? 1;
  const from = spec.pathFrom ?? 0, to = spec.pathTo ?? spec.paths;
  const bins = spec.bins ?? 2048, range = spec.range ?? histRange(spec), cps = spec.checkpoints ?? checkpointSteps(H);
  const hist = new Uint32Array(bins), cpHist = new Uint32Array(cps.length * bins);
  const lnU = spec.up > 0 ? Math.log(spec.up / s0) : Infinity, lnD = spec.down > 0 ? Math.log(spec.down / s0) : -Infinity;
  const finals = spec.keepFinals ? new Float64Array(to - from) : null;
  let hitUp = 0, hitDown = 0, sum = 0, sum2 = 0, upCount = 0, minSum = 0;
  const scale = bins / (range.hi - range.lo);
  const bin = (x) => Math.min(bins - 1, Math.max(0, Math.floor((x - range.lo) * scale)));
  const garch = spec.model === 'garch';
  const R = spec.returns, nR = R ? R.length : 0, pNew = 1 / Math.max(1, spec.block ?? 10);
  const nu = spec.nu ?? 0, tScale = nu > 2 ? Math.sqrt((nu - 2) / nu) : 1;

  for (let p = from; p < to; p++) {
    const rng = new Rng(pathSeed(seed, p));
    let x = 0, h = spec.h0 ?? 0, first = 0, cpk = 0, idx = rng.int(Math.max(1, nR)), xmin = 0;
    for (let t = 1; t <= H; t++) {
      let r, varStep;
      if (garch) {
        let z = rng.normal();
        if (nu > 2) {
          let chi = 0;
          for (let k = 0; k < nu; k++) { const g = rng.normal(); chi += g * g; }
          z = (z / Math.sqrt(chi / nu)) * tScale;
        }
        const e = Math.sqrt(h) * z;
        r = spec.mu + e;
        varStep = h;
        h = spec.omega + spec.alpha * e * e + spec.beta * h;
      } else {
        idx = rng.next() < pNew ? rng.int(nR) : (idx + 1) % nR;
        r = R[idx];
        varStep = Math.max(1e-14, r * r);
      }
      const a = x;
      x += r;
      if (x < xmin) xmin = x;
      if (!first) {
        // franchissement pendant le pas (pont brownien) ou à la clôture du pas
        let up = x >= lnU, dn = x <= lnD;
        if (!up && lnU !== Infinity) up = rng.next() < Math.exp((-2 * (lnU - a) * (lnU - x)) / varStep);
        if (!dn && lnD !== -Infinity) dn = rng.next() < Math.exp((-2 * (a - lnD) * (x - lnD)) / varStep);
        if (up && dn) first = rng.next() < 0.5 ? 1 : -1;
        else if (up) first = 1;
        else if (dn) first = -1;
      }
      if (cpk < cps.length && t === cps[cpk]) {
        cpHist[cpk * bins + bin(x)]++;
        cpk++;
      }
    }
    hist[bin(x)]++;
    if (finals) finals[p - from] = x;
    sum += x;
    sum2 += x * x;
    minSum += xmin;
    if (x > 0) upCount++;
    if (first === 1) hitUp++;
    else if (first === -1) hitDown++;
  }
  return {
    backend: 'js', paths: to - from, steps: H, range, bins, hist, cpHist, checkpoints: cps,
    sum, sum2, upCount, hitUp, hitDown, minSum, finals, ms: performance.now() - t0,
  };
}

/** Fusionne des résultats partiels (même spec, plages de trajectoires disjointes : multi-cœurs, GPU+CPU). */
export function mergeMC(parts) {
  const a = parts[0], bins = a.bins, cpn = a.checkpoints.length;
  const hist = new Uint32Array(bins), cpHist = new Uint32Array(cpn * bins);
  const out = { backend: [...new Set(parts.map((p) => p.backend))].join('+'), paths: 0, steps: a.steps, range: a.range, bins, hist, cpHist,
    checkpoints: a.checkpoints, sum: 0, sum2: 0, upCount: 0, hitUp: 0, hitDown: 0, minSum: 0, ms: 0, parts: [] };
  for (const p of parts) {
    for (let i = 0; i < bins; i++) hist[i] += p.hist[i];
    for (let i = 0; i < cpn * bins; i++) cpHist[i] += p.cpHist[i];
    for (const k of ['paths', 'sum', 'sum2', 'upCount', 'hitUp', 'hitDown', 'minSum']) out[k] += p[k];
    out.ms = Math.max(out.ms, p.ms);
    out.parts.push({ backend: p.backend, paths: p.paths, ms: p.ms });
  }
  return out;
}

/** Quantile d'un histogramme (interpolation linéaire dans la classe). */
export function histQuantile(hist, range, q) {
  let total = 0;
  for (const c of hist) total += c;
  const target = q * total, w = (range.hi - range.lo) / hist.length;
  let acc = 0;
  for (let i = 0; i < hist.length; i++) {
    if (acc + hist[i] >= target && hist[i] > 0) return range.lo + (i + (target - acc) / hist[i]) * w;
    acc += hist[i];
  }
  return range.hi;
}

/**
 * Résumé lisible : quantiles de prix, probabilités ± erreur standard, VaR/ES de l'horizon.
 * Erreur standard d'une probabilité : √(p(1−p)/N) → la « précision » réelle du Monte Carlo.
 */
export function summarizeMC(res, s0) {
  const N = res.paths, mean = res.sum / N, sd = Math.sqrt(Math.max(0, res.sum2 / N - mean * mean));
  const q = Object.fromEntries(QUANTILES.map((k) => [k, histQuantile(res.hist, res.range, k)]));
  const prob = (k) => ({ p: k / N, se: Math.sqrt(((k / N) * (1 - k / N)) / N) });
  // ES 5 % depuis l'histogramme
  let acc = 0, esSum = 0;
  const w = (res.range.hi - res.range.lo) / res.bins, lim = 0.05 * N;
  for (let i = 0; i < res.bins && acc < lim; i++) {
    const take = Math.min(res.hist[i], lim - acc);
    esSum += take * (res.range.lo + (i + 0.5) * w);
    acc += take;
  }
  const es = acc > 0 ? -(Math.exp(esSum / acc) - 1) : NaN;
  return {
    paths: N, steps: res.steps, backend: res.backend, ms: res.ms, parts: res.parts,
    meanReturn: Math.exp(mean) - 1, sdLog: sd, expectedPrice: s0 * Math.exp(mean + (sd * sd) / 2),
    quantiles: Object.fromEntries(QUANTILES.map((k) => [k, { ret: Math.exp(q[k]) - 1, price: s0 * Math.exp(q[k]) }])),
    pUp: prob(res.upCount), pTarget: prob(res.hitUp), pStop: prob(res.hitDown), pNone: prob(N - res.hitUp - res.hitDown),
    var95: -(Math.exp(q[0.05]) - 1), es95: es, avgMaxDrawdown: Math.exp(res.minSum / N) - 1,
    resolution: (res.range.hi - res.range.lo) / res.bins,
    fan: res.checkpoints.map((step, k) => {
      const h = res.cpHist.subarray(k * res.bins, (k + 1) * res.bins);
      return { step, ...Object.fromEntries([0.05, 0.25, 0.5, 0.75, 0.95].map((x) => [`q${Math.round(x * 100)}`, s0 * Math.exp(histQuantile(h, res.range, x))])) };
    }),
  };
}

/** Quantiles exacts (référence) à partir des trajectoires conservées. */
export function exactQuantiles(finals) {
  const s = sortedFinite(finals);
  return Object.fromEntries(QUANTILES.map((k) => [k, quantileSorted(s, k)]));
}

/** Paramètres de simulation à partir d'un ajustement GARCH (voir volatility.js). */
export function garchSpec(fit, extra = {}) {
  return { model: 'garch', mu: fit.mu, omega: fit.omega, alpha: fit.alpha, beta: fit.beta, h0: fit.nextVar, uncondVar: fit.uncondVar, ...extra };
}

export const _internal = { isNum };

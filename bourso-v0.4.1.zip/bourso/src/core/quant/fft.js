// ============================================================================
//  BOURSO :: quant/fft.js — cycles dominants par transformée de Fourier.
//
//  FFT radix-2 itérative en place (Cooley-Tukey), série prétraitée : log-prix, tendance linéaire
//  retirée (sinon le spectre n'est que la tendance), fenêtre de Hann, zéro-padding ×4 pour une
//  résolution fine des périodes. Chaque pic est raffiné par interpolation parabolique.
//  Phase : position actuelle dans le cycle (sommet, creux, montée, descente) par ajustement
//  d'une sinusoïde de la période trouvée sur la série détendancée (moindres carrés).
//
//  Honnêteté statistique : un cours ressemble à une marche aléatoire, dont le spectre est « rouge »
//  (les longues périodes dominent toujours). Chaque pic est donc comparé au spectre d'un bruit rouge
//  AR(1) de même autocorrélation (méthode de Torrence & Compo). Seuil ponctuel à 95 % : fond × χ²₂/2
//  ≈ 3,0. Mais on teste des dizaines de périodes à la fois : au seuil ponctuel, ~5 % des fréquences
//  « passent » par pur hasard. Un cycle n'est donc déclaré SIGNIFICATIF que s'il franchit le seuil
//  global à 95 % (correction de Šidák sur les M fréquences de Fourier indépendantes de la bande) ;
//  « local » signale un pic qui ne franchit que le seuil ponctuel. La « part du spectre » est la
//  puissance de tout le lobe du pic (entre ses deux creux) rapportée à la bande étudiée.
// ============================================================================
import { isNum, linreg } from './numeric.js';

/** FFT en place (re, im : Float64Array de longueur puissance de 2). `inverse` : transformée inverse. */
export function fft(re, im, inverse = false) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      [re[i], re[j]] = [re[j], re[i]];
      [im[i], im[j]] = [im[j], im[i]];
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = ((inverse ? 2 : -2) * Math.PI) / len, wr = Math.cos(ang), wi = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let cr = 1, ci = 0;
      for (let k = 0; k < len / 2; k++) {
        const ar = re[i + k], ai = im[i + k];
        const br = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci;
        const bi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr;
        re[i + k] = ar + br;
        im[i + k] = ai + bi;
        re[i + k + len / 2] = ar - br;
        im[i + k + len / 2] = ai - bi;
        const t = cr * wr - ci * wi;
        ci = cr * wi + ci * wr;
        cr = t;
      }
    }
  }
  if (inverse) for (let i = 0; i < n; i++) { re[i] /= n; im[i] /= n; }
}

/** Série prête pour l'analyse spectrale : log, sans tendance linéaire. */
export function detrendLog(c) {
  const v = [];
  for (const x of c) if (isNum(x) && x > 0) v.push(Math.log(x));
  const xs = v.map((_, i) => i), fit = linreg(xs, v);
  return Float64Array.from(v, (y, i) => y - (fit.intercept + fit.slope * i));
}

/**
 * Spectre de puissance (fenêtre de Hann, zéro-padding).
 * @returns {{ period:Float64Array, power:Float64Array, n:number }}
 */
export function spectrum(x, pad = 4) {
  const n = x.length;
  let N = 1;
  while (N < n * pad) N <<= 1;
  const re = new Float64Array(N), im = new Float64Array(N);
  for (let i = 0; i < n; i++) re[i] = x[i] * (0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (n - 1)));
  fft(re, im);
  const half = N / 2, period = new Float64Array(half), power = new Float64Array(half);
  for (let k = 1; k < half; k++) {
    period[k] = N / k;
    power[k] = (re[k] * re[k] + im[k] * im[k]) / n;
  }
  return { period, power, n, N };
}

const CHI2_2_95 = 5.991464547107979; // quantile 95 % du χ² à 2 degrés de liberté (= −2·ln 0,05)
/** Seuil (puissance / fond) pour un risque global de 5 % sur M tests indépendants (Šidák). */
const globalRatio = (M) => -Math.log(1 - 0.95 ** (1 / Math.max(1, M)));

/**
 * Analyse spectrale complète entre minPeriod et maxPeriod (en bougies) : cycles dominants testés
 * contre un bruit rouge AR(1), et spectre (période, puissance, seuil 95 %) prêt à tracer.
 * @returns {{ cycles:object[], spectrum:{ period:number[], power:number[], red:number[], sig95:number[] }, rho:number, n:number,
 *            tests:number, thresholds:{ local:number, global:number } }}
 */
export function cycleAnalysis(c, { minPeriod = 6, maxPeriod = null, top = 3, points = 360 } = {}) {
  const x = detrendLog(c), n = x.length;
  const empty = { cycles: [], spectrum: { period: [], power: [], red: [], sig95: [] }, rho: NaN, n };
  if (n < 32) return empty;
  const maxP = maxPeriod ?? Math.floor(n / 2.5);
  const sp = spectrum(x);
  // bruit rouge AR(1) : autocorrélation d'ordre 1 de la série détendancée
  let num = 0, den = 0;
  for (let t = 0; t < n; t++) { den += x[t] * x[t]; if (t) num += x[t] * x[t - 1]; }
  const rho = Math.min(0.999, Math.max(-0.999, den > 0 ? num / den : 0));
  const red = new Float64Array(sp.power.length);
  let sumP = 0, sumR = 0;
  for (let k = 1; k < sp.power.length; k++) {
    red[k] = (1 - rho * rho) / (1 + rho * rho - 2 * rho * Math.cos((2 * Math.PI * k) / sp.N));
    sumP += sp.power[k];
    sumR += red[k];
  }
  const scale = sumR > 0 ? sumP / sumR : 0;
  for (let k = 1; k < red.length; k++) red[k] *= scale;
  // bande étudiée (indices de fréquence croissants = périodes décroissantes)
  const kLo = Math.max(2, Math.ceil(sp.N / maxP)), kHi = Math.min(sp.power.length - 2, Math.floor(sp.N / minPeriod));
  if (kHi <= kLo) return { ...empty, rho };
  let total = 0;
  for (let k = kLo; k <= kHi; k++) total += sp.power[k];
  const peaks = [];
  for (let k = kLo; k <= kHi; k++) {
    if (!(sp.power[k] > sp.power[k - 1] && sp.power[k] >= sp.power[k + 1])) continue;
    // interpolation parabolique de la position du pic
    const a = sp.power[k - 1], b = sp.power[k], d = sp.power[k + 1];
    const off = (0.5 * (a - d)) / (a - 2 * b + d || 1e-300);
    // lobe : du creux de gauche au creux de droite
    let l = k, r = k;
    while (l > kLo && sp.power[l - 1] < sp.power[l]) l--;
    while (r < kHi && sp.power[r + 1] < sp.power[r]) r++;
    let lobe = 0;
    for (let j = l; j <= r; j++) lobe += sp.power[j];
    peaks.push({ period: sp.N / (k + off), power: b, lobe, ratio: red[k] > 0 ? b / red[k] : 0 });
  }
  // fréquences de Fourier indépendantes dans la bande : j/n pour n/maxP ≤ j ≤ n/minP
  const M = Math.max(1, Math.floor(n / minPeriod) - Math.ceil(n / maxP) + 1);
  const gThr = globalRatio(M), lThr = CHI2_2_95 / 2;
  const rank = (pk) => (pk.ratio > gThr ? 2 : pk.ratio > lThr ? 1 : 0);
  peaks.sort((p, q) => rank(q) - rank(p) || q.lobe - p.lobe);
  const cycles = peaks.slice(0, top).map((pk) => {
    // ajustement x_t ≈ a·cos(ωt) + b·sin(ωt) (moindres carrés) → amplitude et phase actuelles
    const w = (2 * Math.PI) / pk.period;
    let scc = 0, sss = 0, scs = 0, sxc = 0, sxs = 0;
    for (let t = 0; t < n; t++) {
      const co = Math.cos(w * t), si = Math.sin(w * t);
      scc += co * co; sss += si * si; scs += co * si; sxc += x[t] * co; sxs += x[t] * si;
    }
    const det = scc * sss - scs * scs, a = (sxc * sss - sxs * scs) / det, b = (sxs * scc - sxc * scs) / det;
    const amplitude = Math.hypot(a, b);
    // x_t = A·cos(ω t − φ) avec φ = atan2(b, a) ; phase actuelle θ = ω(n−1) − φ (mod 2π)
    let theta = (w * (n - 1) - Math.atan2(b, a)) % (2 * Math.PI);
    if (theta < 0) theta += 2 * Math.PI;
    const frac = theta / (2 * Math.PI);
    const state = frac < 0.125 || frac >= 0.875 ? 'proche d\'un sommet' : frac < 0.375 ? 'en phase descendante'
      : frac < 0.625 ? 'proche d\'un creux' : 'en phase montante';
    return {
      period: pk.period, power: pk.power, share: total > 0 ? pk.lobe / total : 0, amplitude, phase: theta, state,
      redRatio: pk.ratio, significant: pk.ratio > gThr, significantLocal: pk.ratio > lThr, cyclesInSample: n / pk.period,
      barsToTrough: ((0.5 - frac + 1) % 1) * pk.period, barsToPeak: ((1 - frac) % 1) * pk.period,
    };
  });
  // spectre décimé pour l'affichage (périodes croissantes)
  const step = Math.max(1, Math.ceil((kHi - kLo + 1) / points));
  const period = [], power = [], redOut = [], sig95 = [];
  // (sig95 : seuil ponctuel ; le seuil global vaut thresholds.global × fond)
  for (let k = kHi; k >= kLo; k -= step) {
    period.push(sp.N / k);
    power.push(total > 0 ? sp.power[k] / total : 0);
    redOut.push(total > 0 ? red[k] / total : 0);
    sig95.push(total > 0 ? (red[k] * CHI2_2_95) / 2 / total : 0);
  }
  return { cycles, spectrum: { period, power, red: redOut, sig95 }, rho, n, tests: M, thresholds: { local: lThr, global: gThr } };
}

/**
 * Cycles dominants entre minPeriod et maxPeriod (en bougies).
 * @returns {{ period:number, power:number, share:number, amplitude:number, phase:number, state:string, barsToTrough:number, barsToPeak:number, significant:boolean, redRatio:number }[]}
 */
export function dominantCycles(c, opts = {}) {
  return cycleAnalysis(c, opts).cycles;
}

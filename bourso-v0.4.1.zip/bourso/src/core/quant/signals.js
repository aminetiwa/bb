// ============================================================================
//  BOURSO :: quant/signals.js — résumé technique (vote d'indicateurs) façon plateformes pro.
//
//  Deux familles votent (achat +1, neutre 0, vente −1) sur la DERNIÈRE bougie :
//   - moyennes mobiles : SMA/EMA 10-20-30-50-100-200, VWMA 20, Hull 9, Ichimoku ;
//   - oscillateurs : RSI, stochastique, CCI, ADX, Awesome, momentum, MACD, Stoch RSI,
//     Williams %R, Bull/Bear Power, Ultimate.
//  Note globale = moyenne des deux notes ; seuils : ≤ −0,5 vente forte, < −0,1 vente,
//  ≤ 0,1 neutre, ≤ 0,5 achat, au-delà achat fort.
// ============================================================================
import { isNum } from './numeric.js';
import * as I from './indicators.js';

const lastTwo = (a) => {
  const n = a.length;
  return [a[n - 1], a[n - 2]];
};

export function ratingLabel(x) {
  if (!isNum(x)) return { key: 'NONE', label: '—' };
  if (x <= -0.5) return { key: 'STRONG_SELL', label: 'Vente forte' };
  if (x < -0.1) return { key: 'SELL', label: 'Vente' };
  if (x <= 0.1) return { key: 'NEUTRAL', label: 'Neutre' };
  if (x <= 0.5) return { key: 'BUY', label: 'Achat' };
  return { key: 'STRONG_BUY', label: 'Achat fort' };
}

/**
 * @param {{open, high, low, close, volume}} d séries (≥ 210 bougies conseillées)
 * @returns {{ rating:number, ma:number, osc:number, label:string, key:string, counts:{buy,sell,neutral},
 *            details:{ group:string, name:string, value:number, vote:-1|0|1, rule:string }[] }}
 */
export function technicalRating(d) {
  const { open: o, high: h, low: l, close: c, volume: v } = d;
  const N = c.length, px = c[N - 1], details = [];
  const vote = (group, name, value, v1, rule) => details.push({ group, name, value, vote: isNum(value) ? v1 : 0, rule });

  for (const n of [10, 20, 30, 50, 100, 200]) {
    const s = I.sma(c, n)[N - 1], e = I.ema(c, n)[N - 1];
    vote('ma', `SMA ${n}`, s, s < px ? 1 : s > px ? -1 : 0, 'cours au-dessus de la moyenne : achat');
    vote('ma', `EMA ${n}`, e, e < px ? 1 : e > px ? -1 : 0, 'cours au-dessus de la moyenne : achat');
  }
  const vw = I.vwma(c, v, 20)[N - 1];
  vote('ma', 'VWMA 20', vw, vw < px ? 1 : vw > px ? -1 : 0, 'moyenne pondérée par le volume');
  const hu = I.hma(c, 9)[N - 1];
  vote('ma', 'Hull 9', hu, hu < px ? 1 : hu > px ? -1 : 0, 'moyenne de Hull, réactive');
  const ich = I.ichimoku(h, l, c);
  const top = Math.max(ich.spanA[N - 1], ich.spanB[N - 1]), bot = Math.min(ich.spanA[N - 1], ich.spanB[N - 1]);
  const kj = ich.kijun[N - 1], tk = ich.tenkan[N - 1];
  vote('ma', 'Ichimoku (ligne de base)', kj, px > top && tk > kj ? 1 : px < bot && tk < kj ? -1 : 0, 'au-dessus du nuage et tenkan > kijun : achat');

  const [r1, r0] = lastTwo(I.rsi(c, 14));
  vote('osc', 'RSI 14', r1, r1 < 30 && r1 > r0 ? 1 : r1 > 70 && r1 < r0 ? -1 : 0, '< 30 et remonte : achat · > 70 et rechute : vente');
  const st = I.stoch(h, l, c, 14, 3, 3);
  const [k1] = lastTwo(st.k), [d1] = lastTwo(st.d);
  vote('osc', 'Stochastique %K', k1, k1 < 20 && k1 > d1 ? 1 : k1 > 80 && k1 < d1 ? -1 : 0, '< 20 et %K > %D : achat');
  const [cc1, cc0] = lastTwo(I.cci(h, l, c, 20));
  vote('osc', 'CCI 20', cc1, cc1 < -100 && cc1 > cc0 ? 1 : cc1 > 100 && cc1 < cc0 ? -1 : 0, '< −100 et remonte : achat');
  const ax = I.adx(h, l, c, 14);
  const [a1, a0] = lastTwo(ax.adx), p1 = ax.pdi[N - 1], m1 = ax.mdi[N - 1];
  vote('osc', 'ADX 14', a1, a1 > 20 && a1 >= a0 ? (p1 > m1 ? 1 : -1) : 0, 'ADX > 20 et croissant : sens donné par DI+ / DI−');
  const [ao1, ao0] = lastTwo(I.awesome(h, l));
  vote('osc', 'Awesome Oscillator', ao1, ao1 > 0 && ao1 > ao0 ? 1 : ao1 < 0 && ao1 < ao0 ? -1 : 0, 'positif et croissant : achat');
  const [mo1, mo0] = lastTwo(I.momentum(c, 10));
  vote('osc', 'Momentum 10', mo1, mo1 > mo0 ? 1 : mo1 < mo0 ? -1 : 0, 'momentum en hausse : achat');
  const m = I.macd(c);
  const ml = m.line[N - 1], ms = m.signal[N - 1];
  vote('osc', 'MACD (12, 26)', ml, ml > ms ? 1 : ml < ms ? -1 : 0, 'MACD au-dessus de son signal : achat');
  const sr = I.stochRsi(c);
  const sk = sr.k[N - 1], sd = sr.d[N - 1];
  vote('osc', 'Stoch RSI', sk, sk < 20 && sk > sd ? 1 : sk > 80 && sk < sd ? -1 : 0, '< 20 et K > D : achat');
  const [w1, w0] = lastTwo(I.williamsR(h, l, c, 14));
  vote('osc', 'Williams %R', w1, w1 < -80 && w1 > w0 ? 1 : w1 > -20 && w1 < w0 ? -1 : 0, '< −80 et remonte : achat');
  const [b1, b0] = lastTwo(I.bullBearPower(h, l, c));
  const e13 = I.ema(c, 13), upTrend = e13[N - 1] > e13[N - 6];
  vote('osc', 'Bull/Bear Power', b1, upTrend && b1 < 0 && b1 > b0 ? 1 : !upTrend && b1 > 0 && b1 < b0 ? -1 : 0, 'creux de puissance en tendance haussière : achat');
  const uo = I.ultimate(h, l, c)[N - 1];
  vote('osc', 'Ultimate Oscillator', uo, uo > 70 ? 1 : uo < 30 ? -1 : 0, '> 70 : achat · < 30 : vente');

  const avg = (g) => {
    const xs = details.filter((x) => x.group === g && isNum(x.value));
    return xs.length ? xs.reduce((a, x) => a + x.vote, 0) / xs.length : NaN;
  };
  const ma = avg('ma'), osc = avg('osc');
  const rating = isNum(ma) && isNum(osc) ? (ma + osc) / 2 : isNum(ma) ? ma : osc;
  const counts = { buy: 0, sell: 0, neutral: 0 };
  for (const x of details) counts[x.vote > 0 ? 'buy' : x.vote < 0 ? 'sell' : 'neutral']++;
  void o;
  return { rating, ma, osc, ...ratingLabel(rating), maLabel: ratingLabel(ma).label, oscLabel: ratingLabel(osc).label, counts, details };
}

// ============================================================================
//  BOURSO :: quant/numeric.js — arithmétique soignée, partagée navigateur / workers / Node.
//
//  Règles de précision appliquées dans tout le moteur :
//   - double précision (float64) partout côté CPU ;
//   - sommes compensées (Neumaier) pour les cumuls longs (VWAP, moyennes glissantes, P&L) ;
//   - variances par Welford / West (pondérée) : pas de « E[x²] − E[x]² » qui s'effondre ;
//   - loi normale : Φ par l'algorithme de Marsaglia (erreur < 1e-15), Φ⁻¹ par Acklam + 1 pas
//     de Halley (pleine précision double) ;
//   - prix ramenés exactement sur la grille du pas de cotation (pas de 0,15000000000000002).
// ============================================================================

export const isNum = Number.isFinite;

/** Tableau float64 rempli de NaN (convention : NaN = « pas encore calculable », période de chauffe). */
export function nanArray(n) {
  const a = new Float64Array(n);
  a.fill(NaN);
  return a;
}

/** Accumulateur de Neumaier (Kahan amélioré) : somme exacte à ~1 ulp, ajouts ET retraits. */
export class Neumaier {
  constructor(v = 0) {
    this.s = v;
    this.c = 0;
  }
  add(x) {
    const t = this.s + x;
    if (Math.abs(this.s) >= Math.abs(x)) this.c += this.s - t + x;
    else this.c += x - t + this.s;
    this.s = t;
    return this;
  }
  get value() {
    return this.s + this.c;
  }
  reset(v = 0) {
    this.s = v;
    this.c = 0;
  }
}

export function sum(x, from = 0, to = x.length) {
  const acc = new Neumaier();
  for (let i = from; i < to; i++) acc.add(x[i]);
  return acc.value;
}

export function mean(x, from = 0, to = x.length) {
  return to > from ? sum(x, from, to) / (to - from) : NaN;
}

/** Moyenne / variance par Welford (une passe, stable). `sample` : variance non biaisée (n − 1). */
export function meanVar(x, { from = 0, to = x.length, sample = true } = {}) {
  let n = 0, m = 0, s = 0;
  for (let i = from; i < to; i++) {
    const v = x[i];
    if (!isNum(v)) continue;
    n++;
    const d = v - m;
    m += d / n;
    s += d * (v - m);
  }
  const variance = n > (sample ? 1 : 0) ? s / (sample ? n - 1 : n) : NaN;
  return { n, mean: n ? m : NaN, variance, sd: Math.sqrt(variance) };
}

/** Variance pondérée incrémentale (West, 1979) — utilisée pour les bandes de VWAP. */
export class WeightedStats {
  constructor() {
    this.w = 0;
    this.m = 0;
    this.s = 0;
  }
  add(x, w) {
    if (!(w > 0) || !isNum(x)) return;
    this.w += w;
    const d = x - this.m;
    this.m += (w / this.w) * d;
    this.s += w * d * (x - this.m);
  }
  get mean() {
    return this.w > 0 ? this.m : NaN;
  }
  get variance() {
    return this.w > 0 ? this.s / this.w : NaN;
  }
}

/** Dernière valeur finie d'une série (et son index). */
export function lastFinite(a) {
  for (let i = a.length - 1; i >= 0; i--) if (isNum(a[i])) return a[i];
  return NaN;
}
export function lastFiniteIndex(a) {
  for (let i = a.length - 1; i >= 0; i--) if (isNum(a[i])) return i;
  return -1;
}
export function firstFiniteIndex(a) {
  for (let i = 0; i < a.length; i++) if (isNum(a[i])) return i;
  return -1;
}

/** Copie triée des valeurs finies. */
export function sortedFinite(x) {
  const out = [];
  for (const v of x) if (isNum(v)) out.push(v);
  return Float64Array.from(out).sort();
}

/** Quantile d'un échantillon trié (définition « type 7 » : interpolation linéaire, comme R / numpy). */
export function quantileSorted(s, q) {
  const n = s.length;
  if (!n) return NaN;
  if (q <= 0) return s[0];
  if (q >= 1) return s[n - 1];
  const h = (n - 1) * q, lo = Math.floor(h);
  return s[lo] + (h - lo) * (s[Math.min(n - 1, lo + 1)] - s[lo]);
}

export function quantile(x, q) {
  return quantileSorted(sortedFinite(x), q);
}

/** Nombre de décimales d'un pas de cotation (0,005 → 3 ; 0,1 → 1 ; 1 → 0). */
export function decimalsOf(tick) {
  for (let d = 0; d <= 10; d++) {
    const s = tick * 10 ** d;
    if (Math.abs(s - Math.round(s)) < 1e-9 * Math.max(1, s)) return d;
  }
  return 10;
}

/** Arrondi EXACT sur la grille du pas de cotation (représentation décimale la plus proche). */
export function roundTick(x, tick) {
  return Number((Math.round(x / tick) * tick).toFixed(decimalsOf(tick)));
}
export const floorTick = (x, tick) => Number((Math.floor(x / tick + 1e-9) * tick).toFixed(decimalsOf(tick)));
export const ceilTick = (x, tick) => Number((Math.ceil(x / tick - 1e-9) * tick).toFixed(decimalsOf(tick)));

export const clamp = (x, a, b) => (x < a ? a : x > b ? b : x);
export const sign = (x) => (x > 0 ? 1 : x < 0 ? -1 : 0);

// ---------------------------------------------------------------- loi normale

/** Densité N(0,1). */
export const normPdf = (x) => Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);

/**
 * Fonction de répartition N(0,1).
 *  - |x| < 1,5 : série de Taylor de Marsaglia (2004), aucune annulation notable ;
 *  - |x| ≥ 1,5 : queue par la fraction continue de Laplace Q(z) = φ(z) / (z + 1/(z + 2/(z + …))),
 *    évaluée à rebours (stable) : précision RELATIVE ~1e-15 même loin dans les queues (VaR extrêmes).
 *  Vérifiée contre une référence en arithmétique exacte à 100 chiffres (test/quant.test.js).
 */
export function normCdf(x) {
  if (!isNum(x)) return x > 0 ? 1 : x < 0 ? 0 : NaN;
  const ax = Math.abs(x);
  if (ax >= 1.5) {
    let f = ax;
    for (let k = ax < 2.5 ? 1200 : 300; k >= 1; k--) f = ax + k / f;
    const q = Math.exp(-0.5 * ax * ax - 0.91893853320467274178) / f;
    return x > 0 ? 1 - q : q;
  }
  let s = x, t = 0, b = x, q = x * x, i = 1;
  while (s !== t) {
    t = s;
    i += 2;
    b *= q / i;
    s = t + b;
  }
  return 0.5 + s * Math.exp(-0.5 * q - 0.91893853320467274178);
}

/**
 * Quantile N(0,1) — Acklam (erreur relative 1,15e-9) raffiné par un pas de Halley sur normCdf :
 * précision double complète sur ]0, 1[.
 */
export function normInv(p) {
  if (!(p > 0 && p < 1)) return p === 0 ? -Infinity : p === 1 ? Infinity : NaN;
  const a = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2, 1.38357751867269e2, -3.066479806614716e1, 2.506628277459239];
  const b = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2, 6.680131188771972e1, -1.328068155288572e1];
  const c = [-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
  const d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996, 3.754408661907416];
  const pl = 0.02425;
  let x;
  if (p < pl) {
    const q = Math.sqrt(-2 * Math.log(p));
    x = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  } else if (p <= 1 - pl) {
    const q = p - 0.5, r = q * q;
    x = ((((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q) / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
  } else {
    const q = Math.sqrt(-2 * Math.log(1 - p));
    x = -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  }
  // Halley : e = Φ(x) − p ; u = e·√(2π)·exp(x²/2) ; x ← x − u / (1 + x·u/2)
  const e = normCdf(x) - p;
  const u = e * Math.sqrt(2 * Math.PI) * Math.exp((x * x) / 2);
  return x - u / (1 + (x * u) / 2);
}

// ---------------------------------------------------------------- fonctions spéciales

/** ln Γ(x) — Lanczos (g = 7, n = 9), précision ~1e-15. */
export function lnGamma(x) {
  const g = 7;
  const C = [0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059,
    12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7];
  if (x < 0.5) return Math.log(Math.PI / Math.sin(Math.PI * x)) - lnGamma(1 - x);
  x -= 1;
  let a = C[0];
  const t = x + g + 0.5;
  for (let i = 1; i < 9; i++) a += C[i] / (x + i);
  return 0.5 * Math.log(2 * Math.PI) + (x + 0.5) * Math.log(t) - t + Math.log(a);
}

/** Gamma incomplète régularisée P(a, x) (série / fraction continue de Lentz). */
export function gammaP(a, x) {
  if (x <= 0) return 0;
  if (x < a + 1) {
    let sum = 1 / a, del = sum, ap = a;
    for (let n = 0; n < 500; n++) {
      ap += 1;
      del *= x / ap;
      sum += del;
      if (Math.abs(del) < Math.abs(sum) * 1e-16) break;
    }
    return sum * Math.exp(-x + a * Math.log(x) - lnGamma(a));
  }
  return 1 - gammaQcf(a, x);
}
function gammaQcf(a, x) {
  const FPMIN = 1e-300;
  let b = x + 1 - a, c = 1 / FPMIN, d = 1 / b, h = d;
  for (let i = 1; i < 500; i++) {
    const an = -i * (i - a);
    b += 2;
    d = an * d + b;
    if (Math.abs(d) < FPMIN) d = FPMIN;
    c = b + an / c;
    if (Math.abs(c) < FPMIN) c = FPMIN;
    d = 1 / d;
    const del = d * c;
    h *= del;
    if (Math.abs(del - 1) < 1e-16) break;
  }
  return Math.exp(-x + a * Math.log(x) - lnGamma(a)) * h;
}
/** Probabilité de queue d'un χ² à k degrés de liberté : P(X > x). */
export const chi2Sf = (x, k) => (x <= 0 ? 1 : 1 - gammaP(k / 2, x / 2));

// ---------------------------------------------------------------- algèbre linéaire (petites tailles)

/** Résout A·x = b (élimination de Gauss, pivot partiel). A : tableau de lignes. */
export function solve(A, b) {
  const n = b.length, M = A.map((r, i) => [...r, b[i]]);
  for (let k = 0; k < n; k++) {
    let p = k;
    for (let i = k + 1; i < n; i++) if (Math.abs(M[i][k]) > Math.abs(M[p][k])) p = i;
    if (Math.abs(M[p][k]) < 1e-300) return null;
    [M[k], M[p]] = [M[p], M[k]];
    for (let i = k + 1; i < n; i++) {
      const f = M[i][k] / M[k][k];
      for (let j = k; j <= n; j++) M[i][j] -= f * M[k][j];
    }
  }
  const x = new Array(n).fill(0);
  for (let i = n - 1; i >= 0; i--) {
    let s = M[i][n];
    for (let j = i + 1; j < n; j++) s -= M[i][j] * x[j];
    x[i] = s / M[i][i];
  }
  return x;
}

/** Inverse d'une petite matrice (Gauss-Jordan). */
export function invert(A) {
  const n = A.length, M = A.map((r, i) => [...r, ...Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))]);
  for (let k = 0; k < n; k++) {
    let p = k;
    for (let i = k + 1; i < n; i++) if (Math.abs(M[i][k]) > Math.abs(M[p][k])) p = i;
    if (Math.abs(M[p][k]) < 1e-300) return null;
    [M[k], M[p]] = [M[p], M[k]];
    const piv = M[k][k];
    for (let j = 0; j < 2 * n; j++) M[k][j] /= piv;
    for (let i = 0; i < n; i++) {
      if (i === k) continue;
      const f = M[i][k];
      if (f) for (let j = 0; j < 2 * n; j++) M[i][j] -= f * M[k][j];
    }
  }
  return M.map((r) => r.slice(n));
}

/**
 * Moindres carrés ordinaires : y = X·β + ε. X : lignes (avec la colonne de 1 si constante voulue).
 * @returns {{ beta:number[], se:number[], t:number[], resid:Float64Array, sigma2:number, r2:number, n:number, k:number }|null}
 */
export function ols(X, y) {
  const n = y.length, k = X[0].length;
  if (n <= k) return null;
  const XtX = Array.from({ length: k }, () => new Array(k).fill(0)), Xty = new Array(k).fill(0);
  for (let i = 0; i < n; i++) {
    const r = X[i];
    for (let a = 0; a < k; a++) {
      Xty[a] += r[a] * y[i];
      for (let b = a; b < k; b++) XtX[a][b] += r[a] * r[b];
    }
  }
  for (let a = 0; a < k; a++) for (let b = 0; b < a; b++) XtX[a][b] = XtX[b][a];
  const inv = invert(XtX);
  if (!inv) return null;
  const beta = inv.map((row) => row.reduce((s, v, j) => s + v * Xty[j], 0));
  const resid = new Float64Array(n);
  let rss = 0;
  const my = mean(y);
  let tss = 0;
  for (let i = 0; i < n; i++) {
    let f = 0;
    for (let a = 0; a < k; a++) f += X[i][a] * beta[a];
    resid[i] = y[i] - f;
    rss += resid[i] * resid[i];
    tss += (y[i] - my) ** 2;
  }
  const sigma2 = rss / (n - k);
  const se = inv.map((row, a) => Math.sqrt(Math.max(0, row[a] * sigma2)));
  return { beta, se, t: beta.map((b, a) => b / se[a]), resid, sigma2, r2: tss > 0 ? 1 - rss / tss : NaN, n, k };
}

/** Régression linéaire simple y = a + b·x sur les points finis. */
export function linreg(xs, ys) {
  let n = 0, mx = 0, my = 0;
  for (let i = 0; i < xs.length; i++) {
    if (!isNum(xs[i]) || !isNum(ys[i])) continue;
    n++;
    mx += (xs[i] - mx) / n;
    my += (ys[i] - my) / n;
  }
  let sxx = 0, sxy = 0, syy = 0;
  for (let i = 0; i < xs.length; i++) {
    if (!isNum(xs[i]) || !isNum(ys[i])) continue;
    const dx = xs[i] - mx, dy = ys[i] - my;
    sxx += dx * dx;
    sxy += dx * dy;
    syy += dy * dy;
  }
  const slope = sxx > 0 ? sxy / sxx : NaN;
  const intercept = my - slope * mx;
  const r2 = sxx > 0 && syy > 0 ? (sxy * sxy) / (sxx * syy) : NaN;
  const resVar = n > 2 ? Math.max(0, syy - slope * sxy) / (n - 2) : NaN;
  return { n, slope, intercept, r2, se: Math.sqrt(resVar), seSlope: Math.sqrt(resVar / sxx) };
}

// ---------------------------------------------------------------- générateurs pseudo-aléatoires

/** xoshiro128** (Blackman & Vigna) : rapide, période 2^128 − 1, reproductible (graine). */
export class Rng {
  constructor(seed = 0x9e3779b9) {
    // initialisation par splitmix32
    let s = seed >>> 0;
    const next = () => {
      s = (s + 0x9e3779b9) >>> 0;
      let z = s;
      z = Math.imul(z ^ (z >>> 16), 0x85ebca6b);
      z = Math.imul(z ^ (z >>> 13), 0xc2b2ae35);
      return (z ^ (z >>> 16)) >>> 0;
    };
    this.a = next(); this.b = next(); this.c = next(); this.d = next();
    if (!(this.a | this.b | this.c | this.d)) this.a = 1;
    this.spare = NaN;
  }
  /** Entier non signé 32 bits. */
  u32() {
    const r = Math.imul(rotl(Math.imul(this.b, 5), 7), 9) >>> 0;
    const t = this.b << 9;
    this.c ^= this.a; this.d ^= this.b; this.b ^= this.c; this.a ^= this.d;
    this.c ^= t;
    this.d = rotl(this.d, 11);
    return r;
  }
  /** Uniforme ]0, 1[ sur 53 bits. */
  next() {
    const hi = this.u32() >>> 5, lo = this.u32() >>> 6;
    return (hi * 67108864 + lo + 0.5) / 9007199254740992;
  }
  /** Normale N(0,1) (Box-Muller, la seconde valeur est mise de côté). */
  normal() {
    if (isNum(this.spare)) {
      const v = this.spare;
      this.spare = NaN;
      return v;
    }
    const u = this.next(), v = this.next();
    const r = Math.sqrt(-2 * Math.log(u)), th = 2 * Math.PI * v;
    this.spare = r * Math.sin(th);
    return r * Math.cos(th);
  }
  /** Student-t à ν degrés de liberté, normalisée à variance 1 (queues épaisses). */
  studentT(nu) {
    let chi = 0;
    for (let i = 0; i < nu; i++) {
      const z = this.normal();
      chi += z * z;
    }
    return (this.normal() / Math.sqrt(chi / nu)) * Math.sqrt((nu - 2) / nu);
  }
  int(n) {
    return Math.floor(this.next() * n);
  }
}
const rotl = (x, k) => ((x << k) | (x >>> (32 - k))) >>> 0;

/** Hachage FNV-1a 32 bits d'une chaîne (graines déterministes par titre). */
export function hash32(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

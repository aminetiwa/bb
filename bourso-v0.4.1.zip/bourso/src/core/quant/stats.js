// ============================================================================
//  BOURSO :: quant/stats.js — statistiques de séries financières.
//
//  Distribution (moments, Jarque-Bera), dépendance (autocorrélation, Ljung-Box, Hurst,
//  ratio de variance de Lo-MacKinlay robuste), stationnarité (Dickey-Fuller augmenté avec
//  valeurs critiques de MacKinnon 2010), retour à la moyenne (demi-vie Ornstein-Uhlenbeck),
//  risque (VaR/ES historique, normale, Cornish-Fisher ; drawdowns ; Sharpe, Sortino, Calmar),
//  relatif (bêta, corrélation, alpha), matrices de corrélation et ordre de regroupement.
// ============================================================================
import { isNum, meanVar, Neumaier, sortedFinite, quantileSorted, ols, chi2Sf, normInv, normPdf } from './numeric.js';

const finite = (x) => {
  const out = [];
  for (const v of x) if (isNum(v)) out.push(v);
  return out;
};

/** Moments centrés : moyenne, écart-type (n − 1), asymétrie, kurtosis en excès (estimateurs ajustés). */
export function moments(x) {
  const v = finite(x), n = v.length;
  if (n < 4) return { n, mean: NaN, sd: NaN, skew: NaN, kurt: NaN };
  const m = new Neumaier();
  for (const a of v) m.add(a);
  const mu = m.value / n;
  let m2 = 0, m3 = 0, m4 = 0;
  for (const a of v) {
    const d = a - mu, d2 = d * d;
    m2 += d2;
    m3 += d2 * d;
    m4 += d2 * d2;
  }
  m2 /= n;
  m3 /= n;
  m4 /= n;
  const g1 = m3 / m2 ** 1.5, g2 = m4 / (m2 * m2) - 3;
  // estimateurs corrigés du biais (comme Excel SKEW / KURT)
  const skew = (Math.sqrt(n * (n - 1)) / (n - 2)) * g1;
  const kurt = ((n - 1) / ((n - 2) * (n - 3))) * ((n + 1) * g2 + 6);
  return { n, mean: mu, sd: Math.sqrt((m2 * n) / (n - 1)), skew, kurt };
}

/** Test de normalité de Jarque-Bera. */
export function jarqueBera(x) {
  const v = finite(x), n = v.length;
  const mv = meanVar(v, { sample: false });
  let m3 = 0, m4 = 0;
  for (const a of v) {
    const d = a - mv.mean;
    m3 += d ** 3;
    m4 += d ** 4;
  }
  const s = m3 / n / mv.variance ** 1.5, k = m4 / n / mv.variance ** 2;
  const jb = (n / 6) * (s * s + ((k - 3) ** 2) / 4);
  return { jb, p: Math.exp(-jb / 2), normal: Math.exp(-jb / 2) > 0.05 };
}

/** Autocorrélation au retard `lag`. */
export function autocorr(x, lag = 1) {
  const v = finite(x), n = v.length;
  if (n <= lag + 2) return NaN;
  const mu = meanVar(v).mean;
  let num = 0, den = 0;
  for (let i = 0; i < n; i++) {
    const d = v[i] - mu;
    den += d * d;
    if (i >= lag) num += d * (v[i - lag] - mu);
  }
  return den > 0 ? num / den : NaN;
}

export function acf(x, maxLag = 20) {
  return Array.from({ length: maxLag }, (_, k) => autocorr(x, k + 1));
}

/** Ljung-Box : absence d'autocorrélation jusqu'au retard h (p-valeur χ²). */
export function ljungBox(x, h = 10) {
  const n = finite(x).length;
  let q = 0;
  for (let k = 1; k <= h; k++) q += autocorr(x, k) ** 2 / (n - k);
  q *= n * (n + 2);
  return { q, p: chi2Sf(q, h), h };
}

/**
 * Exposant de Hurst par analyse R/S (fenêtres doublées).
 * H ≈ 0,5 : marche aléatoire · H > 0,5 : persistance (tendances) · H < 0,5 : retour à la moyenne.
 */
export function hurst(x, minWin = 16) {
  const v = finite(x), n = v.length;
  const pts = [];
  for (let w = minWin; w <= Math.floor(n / 2); w *= 2) {
    let acc = 0, cnt = 0;
    for (let s = 0; s + w <= n; s += w) {
      let mu = 0;
      for (let i = s; i < s + w; i++) mu += v[i];
      mu /= w;
      let z = 0, zmax = -Infinity, zmin = Infinity, ss = 0;
      for (let i = s; i < s + w; i++) {
        const d = v[i] - mu;
        z += d;
        ss += d * d;
        if (z > zmax) zmax = z;
        if (z < zmin) zmin = z;
      }
      const sd = Math.sqrt(ss / w);
      if (sd > 0) {
        acc += (zmax - zmin) / sd;
        cnt++;
      }
    }
    if (cnt) pts.push([Math.log(w), Math.log(acc / cnt)]);
  }
  if (pts.length < 3) return NaN;
  let mx = 0, my = 0;
  for (const [a, b] of pts) { mx += a; my += b; }
  mx /= pts.length;
  my /= pts.length;
  let sxy = 0, sxx = 0;
  for (const [a, b] of pts) { sxy += (a - mx) * (b - my); sxx += (a - mx) ** 2; }
  return sxy / sxx;
}

/**
 * Ratio de variance de Lo-MacKinlay (1988) sur des rendements, statistique z* robuste à
 * l'hétéroscédasticité. VR > 1 : momentum ; VR < 1 : retour à la moyenne.
 */
export function varianceRatio(r, q = 5) {
  const v = finite(r), T = v.length;
  if (T < 4 * q) return { vr: NaN, z: NaN, zStar: NaN, q };
  const mu = meanVar(v).mean;
  let sa = 0;
  for (const a of v) sa += (a - mu) ** 2;
  const varA = sa / (T - 1);
  const m = q * (T - q + 1) * (1 - q / T);
  let sc = 0, run = 0;
  for (let t = 0; t < T; t++) {
    run += v[t];
    if (t >= q) run -= v[t - q];
    if (t >= q - 1) sc += (run - q * mu) ** 2;
  }
  const vr = sc / m / varA;
  const z = (vr - 1) / Math.sqrt((2 * (2 * q - 1) * (q - 1)) / (3 * q * T));
  let theta = 0;
  for (let j = 1; j < q; j++) {
    let num = 0;
    for (let t = j; t < T; t++) num += (v[t] - mu) ** 2 * (v[t - j] - mu) ** 2;
    const delta = (T * num) / sa ** 2;
    theta += ((2 * (q - j)) / q) ** 2 * delta;
  }
  return { vr, z, zStar: (vr - 1) / Math.sqrt(theta), q };
}

/** Valeurs critiques de MacKinnon (2010), ADF avec constante, sans tendance. */
export function adfCritical(T) {
  const cv = (b) => b[0] + b[1] / T + b[2] / T ** 2 + b[3] / T ** 3;
  return { 1: cv([-3.43035, -6.5393, -16.786, -79.433]), 5: cv([-2.86154, -2.8903, -4.234, -40.04]), 10: cv([-2.56677, -1.5384, -2.809, 0]) };
}

/**
 * Dickey-Fuller augmenté : Δx_t = α + γ·x_{t−1} + Σ β_i·Δx_{t−i} + ε. Retard choisi par AIC.
 * γ significativement < 0 (stat < valeur critique) → série stationnaire (retour à la moyenne).
 */
export function adf(x, maxLag = null) {
  const v = finite(x), n = v.length;
  if (n < 30) return null;
  const pMax = maxLag ?? Math.min(12, Math.floor(12 * (n / 100) ** 0.25));
  const dx = v.slice(1).map((a, i) => a - v[i]);
  let best = null;
  for (let p = 0; p <= pMax; p++) {
    const X = [], y = [];
    for (let t = pMax; t < dx.length; t++) {
      const row = [1, v[t]];
      for (let i = 1; i <= p; i++) row.push(dx[t - i]);
      X.push(row);
      y.push(dx[t]);
    }
    const res = ols(X, y);
    if (!res) continue;
    const aic = res.n * Math.log((res.sigma2 * (res.n - res.k)) / res.n) + 2 * res.k;
    if (!best || aic < best.aic) best = { aic, p, stat: res.t[1], gamma: res.beta[1], T: res.n };
  }
  if (!best) return null;
  const crit = adfCritical(best.T);
  return { stat: best.stat, lag: best.p, T: best.T, crit, stationary: best.stat < crit[5], gamma: best.gamma };
}

/** Demi-vie de retour à la moyenne (Ornstein-Uhlenbeck), en périodes. Infinity si pas de rappel. */
export function halfLife(x) {
  const v = finite(x);
  const X = [], y = [];
  for (let t = 1; t < v.length; t++) {
    X.push([1, v[t - 1]]);
    y.push(v[t] - v[t - 1]);
  }
  const res = X.length > 10 ? ols(X, y) : null;
  if (!res) return NaN;
  const b = res.beta[1];
  return b < 0 && b > -1 ? -Math.LN2 / Math.log(1 + b) : Infinity;
}

/** Drawdowns d'une série de prix (ou de valeur de portefeuille). */
export function drawdowns(c) {
  let peak = -Infinity, peakI = 0, maxDD = 0, ddPeakI = 0, ddTroughI = 0, longest = 0, curStart = 0;
  for (let i = 0; i < c.length; i++) {
    const v = c[i];
    if (!isNum(v)) continue;
    if (v >= peak) {
      if (i - curStart > longest) longest = i - curStart;
      peak = v;
      peakI = i;
      curStart = i;
    }
    const dd = v / peak - 1;
    if (dd < maxDD) {
      maxDD = dd;
      ddPeakI = peakI;
      ddTroughI = i;
    }
  }
  const lastI = c.length - 1;
  if (lastI - curStart > longest) longest = lastI - curStart;
  return { maxDD, peakI: ddPeakI, troughI: ddTroughI, current: c[lastI] / peak - 1, longest, sincePeak: lastI - peakI };
}

/** Ratios annualisés à partir de rendements périodiques. */
export function sharpe(r, ppy = 252, rf = 0) {
  const mv = meanVar(r);
  return mv.sd > 0 ? ((mv.mean - rf / ppy) / mv.sd) * Math.sqrt(ppy) : NaN;
}
export function sortino(r, ppy = 252, target = 0) {
  const v = finite(r);
  if (!v.length) return NaN;
  let m = 0, dd = 0;
  for (const a of v) {
    m += a;
    if (a < target) dd += (a - target) ** 2;
  }
  m /= v.length;
  const dsd = Math.sqrt(dd / v.length);
  return dsd > 0 ? ((m - target) / dsd) * Math.sqrt(ppy) : NaN;
}

/** Bêta, corrélation, alpha (par période) et R² de `a` contre `b` (séries alignées). */
export function betaCorr(a, b) {
  let n = 0, ma = 0, mb = 0;
  for (let i = 0; i < a.length; i++) {
    if (!isNum(a[i]) || !isNum(b[i])) continue;
    n++;
    ma += (a[i] - ma) / n;
    mb += (b[i] - mb) / n;
  }
  let sab = 0, saa = 0, sbb = 0;
  for (let i = 0; i < a.length; i++) {
    if (!isNum(a[i]) || !isNum(b[i])) continue;
    const da = a[i] - ma, db = b[i] - mb;
    sab += da * db;
    saa += da * da;
    sbb += db * db;
  }
  const beta = sbb > 0 ? sab / sbb : NaN, corr = saa > 0 && sbb > 0 ? sab / Math.sqrt(saa * sbb) : NaN;
  return { n, beta, corr, r2: corr * corr, alpha: ma - beta * mb };
}

/** VaR / ES historiques (pertes positives) au niveau `alpha` (0,05 → 95 %). */
export function varHistorical(r, alpha = 0.05) {
  const s = sortedFinite(r);
  if (s.length < 20) return { var: NaN, es: NaN };
  const q = quantileSorted(s, alpha);
  let sum = 0, k = 0;
  for (const v of s) {
    if (v > q) break;
    sum += v;
    k++;
  }
  return { var: -q, es: k ? -sum / k : -q };
}
/** VaR / ES gaussiennes. */
export function varNormal(mu, sd, alpha = 0.05) {
  const z = normInv(alpha);
  return { var: -(mu + z * sd), es: -(mu - (sd * normPdf(z)) / alpha) };
}
/** VaR de Cornish-Fisher (corrige la normale par l'asymétrie et la kurtosis). */
export function varCornishFisher(mu, sd, skew, exKurt, alpha = 0.05) {
  const z = normInv(alpha);
  const zcf = z + ((z * z - 1) * skew) / 6 + ((z ** 3 - 3 * z) * exKurt) / 24 - ((2 * z ** 3 - 5 * z) * skew * skew) / 36;
  return { var: -(mu + zcf * sd), z: zcf };
}

/** Matrice de corrélation (paires complètes) de séries de rendements alignées. */
export function correlationMatrix(series) {
  const k = series.length, M = Array.from({ length: k }, () => new Float64Array(k));
  for (let i = 0; i < k; i++) {
    M[i][i] = 1;
    for (let j = i + 1; j < k; j++) {
      const c = betaCorr(series[i], series[j]).corr;
      M[i][j] = M[j][i] = c;
    }
  }
  return M;
}

/**
 * Ordre d'affichage par regroupement hiérarchique (liaison moyenne sur d = 1 − ρ) :
 * les titres qui évoluent ensemble se retrouvent côte à côte dans la matrice.
 */
export function clusterOrder(M) {
  const k = M.length;
  let clusters = Array.from({ length: k }, (_, i) => [i]);
  const d = (A, B) => {
    let s = 0;
    for (const a of A) for (const b of B) s += 1 - (isNum(M[a][b]) ? M[a][b] : 0);
    return s / (A.length * B.length);
  };
  while (clusters.length > 1) {
    let bi = 0, bj = 1, bd = Infinity;
    for (let i = 0; i < clusters.length; i++) {
      for (let j = i + 1; j < clusters.length; j++) {
        const dd = d(clusters[i], clusters[j]);
        if (dd < bd) { bd = dd; bi = i; bj = j; }
      }
    }
    const merged = [...clusters[bi], ...clusters[bj]];
    clusters = clusters.filter((_, i) => i !== bi && i !== bj);
    clusters.push(merged);
  }
  return clusters[0];
}

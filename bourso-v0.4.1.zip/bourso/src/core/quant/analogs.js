// ============================================================================
//  BOURSO :: quant/analogs.js — « analogues historiques » : la mémoire chiffrée du marché.
//
//  Idée : décrire la situation de chaque séance par un vecteur d'état (rendements 5/20/60 séances
//  rapportés à la volatilité, écart aux moyennes 50/200, RSI, régime de volatilité, régime de
//  volume), retrouver les k séances PASSÉES les plus proches de la situation actuelle (k plus
//  proches voisins, distance euclidienne sur variables centrées-réduites), puis regarder ce qui
//  s'est passé ENSUITE (rendement à 5 et 20 séances).
//
//  Honnêteté :
//   • aucune fuite du futur : seules les séances dont l'horizon complet est connu ET terminé au
//     moins 20 séances avant aujourd'hui sont candidates ;
//   • les voisins sont espacés d'au moins `spacing` séances (sinon 30 « voisins » = 6 semaines
//     d'une même situation, donc un seul cas en réalité) ;
//   • le résultat est TOUJOURS comparé à la base (toutes les séances candidates) avec un test de
//     proportion (z) corrigé du recouvrement des fenêtres futures : |z| < 2 = indistinguable du hasard
//     (calibré sur le marché simulé, sans prévisibilité : ~5 % de |z| ≥ 2, comme attendu).
// ============================================================================
import { isNum } from './numeric.js';
import * as I from './indicators.js';

export const ANALOG_FEATURES = [
  'rendement 5 s. / vol.', 'rendement 20 s. / vol.', 'rendement 60 s. / vol.', 'écart MM50 / vol.', 'écart MM200 / vol.',
  'RSI 14', 'vol. 20 s. / vol. 120 s. (log)', 'volume 20 s. / volume 120 s. (log)',
];
const F = ANALOG_FEATURES.length, WARMUP = 200;

/**
 * Vecteurs d'état bruts (NaN tant que l'historique est insuffisant).
 * `liveLast` : la dernière bougie est une séance EN COURS (volume partiel) → sa variable de volume
 * reprend celle de la veille pour ne pas fausser la comparaison.
 */
export function stateVectors(d, { liveLast = false } = {}) {
  const c = d.close, v = d.volume, n = c.length;
  const lr = new Float64Array(n).fill(NaN);
  for (let i = 1; i < n; i++) if (c[i] > 0 && c[i - 1] > 0) lr[i] = Math.log(c[i] / c[i - 1]);
  const sd20 = I.rollingStd(lr, 20), sd60 = I.rollingStd(lr, 60), sd120 = I.rollingStd(lr, 120);
  const ma50 = I.sma(c, 50), ma200 = I.sma(c, 200), rsi = I.rsi(c, 14);
  const v20 = I.sma(v, 20), v120 = I.sma(v, 120);
  const X = new Float64Array(n * F).fill(NaN);
  for (let t = WARMUP; t < n; t++) {
    const s20 = sd20[t], s60 = sd60[t];
    if (!(s20 > 0) || !(s60 > 0)) continue;
    const row = [
      Math.log(c[t] / c[t - 5]) / (s20 * Math.sqrt(5)),
      Math.log(c[t] / c[t - 20]) / (s20 * Math.sqrt(20)),
      Math.log(c[t] / c[t - 60]) / (s60 * Math.sqrt(60)),
      Math.log(c[t] / ma50[t]) / (s20 * 5),
      Math.log(c[t] / ma200[t]) / (s60 * 10),
      (rsi[t] - 50) / 20,
      Math.log(s20 / sd120[t]),
      Math.log(v20[t] / v120[t]),
    ];
    for (let f = 0; f < F; f++) X[t * F + f] = row[f];
  }
  if (liveLast && n > WARMUP + 1) X[(n - 1) * F + 7] = X[(n - 2) * F + 7];
  return { X, F, from: WARMUP, n };
}

const quant = (sorted, p) => {
  if (!sorted.length) return NaN;
  const h = (sorted.length - 1) * p, lo = Math.floor(h), hi = Math.ceil(h);
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (h - lo);
};
function describe(arr) {
  const s = Float64Array.from(arr).sort();
  let sum = 0, pos = 0;
  for (const x of s) { sum += x; if (x > 0) pos++; }
  return { n: s.length, mean: s.length ? sum / s.length : NaN, median: quant(s, 0.5), q10: quant(s, 0.1), q90: quant(s, 0.9), pPos: s.length ? pos / s.length : NaN };
}

/**
 * k analogues historiques de la séance `now` (par défaut la dernière).
 * @param {{close:ArrayLike<number>, volume:ArrayLike<number>}} d série quotidienne (la plus ancienne d'abord)
 * @returns {null | { k:number, candidates:number, horizons:{h:number, analog:object, base:object, z:number, significant:boolean}[],
 *   nearest:{t:number, date:string|null, distance:number, fwd:Object<number,number>}[], meanDistance:number, features:string[] }}
 */
export function historicalAnalogs(d, { k = 30, horizons = [5, 20], spacing = 5, gap = 20, now = null, dates = null, liveLast = false } = {}) {
  const { X, n } = stateVectors(d, { liveLast });
  const t0 = now ?? n - 1, maxH = Math.max(...horizons), c = d.close;
  const lastCand = Math.min(t0 - maxH - gap, n - 1 - maxH);
  if (lastCand - WARMUP < 4 * k) return null;
  // centrage-réduction sur les séances candidates
  const mu = new Float64Array(F), sd = new Float64Array(F), cnt = new Float64Array(F);
  for (let t = WARMUP; t <= lastCand; t++) for (let f = 0; f < F; f++) { const x = X[t * F + f]; if (isNum(x)) { mu[f] += x; cnt[f]++; } }
  for (let f = 0; f < F; f++) mu[f] /= cnt[f] || 1;
  for (let t = WARMUP; t <= lastCand; t++) for (let f = 0; f < F; f++) { const x = X[t * F + f]; if (isNum(x)) sd[f] += (x - mu[f]) ** 2; }
  for (let f = 0; f < F; f++) sd[f] = Math.sqrt(sd[f] / Math.max(1, cnt[f] - 1)) || 1;
  const q = new Float64Array(F);
  for (let f = 0; f < F; f++) {
    const x = X[t0 * F + f];
    if (!isNum(x)) return null;
    q[f] = (x - mu[f]) / sd[f];
  }
  // distances à toutes les séances candidates
  const cand = [];
  for (let t = WARMUP; t <= lastCand; t++) {
    let s = 0, ok = true;
    for (let f = 0; f < F; f++) {
      const x = X[t * F + f];
      if (!isNum(x)) { ok = false; break; }
      const z = (x - mu[f]) / sd[f] - q[f];
      s += z * z;
    }
    if (ok) cand.push([t, Math.sqrt(s)]);
  }
  cand.sort((a, b) => a[1] - b[1]);
  // sélection gloutonne avec espacement minimal : pour chaque horizon h, les voisins retenus sont
  // espacés d'au moins max(spacing, h) séances → leurs fenêtres futures ne se recouvrent pas, ce
  // sont des cas réellement distincts (sinon le test serait trop optimiste).
  const pick = (minGap) => {
    const sel = [];
    for (const [t, dist] of cand) {
      if (sel.length >= k) break;
      if (sel.some(([u]) => Math.abs(u - t) < minGap)) continue;
      sel.push([t, dist]);
    }
    return sel;
  };
  const sel = pick(spacing);
  if (sel.length < Math.min(k, 10)) return null;
  const fwd = (t, h) => c[t + h] / c[t] - 1;
  const out = horizons.map((h) => {
    const selH = h > spacing ? pick(h) : sel;
    const analog = describe(selH.map(([t]) => fwd(t, h)));
    const base = describe(cand.map(([t]) => fwd(t, h)));
    const p0 = Math.min(0.999, Math.max(0.001, base.pPos));
    // la base (séances consécutives) a des fenêtres qui se recouvrent : pour des rendements gaussiens
    // dont une part f de la fenêtre est commune, la corrélation des SIGNES vaut (2/π)·arcsin(f)
    let deffBase = 1;
    for (let l = 1; l < h; l++) deffBase += (4 / Math.PI) * Math.asin(1 - l / h);
    const z = (analog.pPos - p0) / Math.sqrt(p0 * (1 - p0) * (1 / analog.n + deffBase / cand.length));
    return { h, k: selH.length, analog, base, z, significant: Math.abs(z) >= 2, meanDistance: selH.reduce((a, [, dd]) => a + dd, 0) / selH.length, sel: selH };
  });
  // les « plus proches » affichés sont ceux de l'horizon le plus long (cas indépendants à cet horizon)
  const longest = out.reduce((a, b) => (b.h > a.h ? b : a));
  const nearest = longest.sel.slice(0, 8).map(([t, dist]) => ({ t, date: dates?.[t] ?? null, distance: dist, fwd: Object.fromEntries(horizons.map((h) => [h, fwd(t, h)])) }));
  for (const o of out) delete o.sel;
  return {
    k: sel.length, candidates: cand.length, horizons: out, features: ANALOG_FEATURES,
    meanDistance: longest.meanDistance, spacingLongest: Math.max(spacing, longest.h), nearest,
  };
}

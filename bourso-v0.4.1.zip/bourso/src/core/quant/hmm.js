// ============================================================================
//  BOURSO :: quant/hmm.js — régimes de marché par chaîne de Markov cachée gaussienne.
//
//  Modèle : K états cachés (ex. « hausse calme », « baisse agitée », « range »), chacun émettant
//  des rendements ~ N(μ_k, σ_k²) ; passage d'un état à l'autre selon une matrice de transition A.
//  Estimation : Baum-Welch (EM) avec avant/arrière normalisés (pas de sous-dépassement), plusieurs
//  départs reproductibles (le premier part des régimes de volatilité glissante), on garde le meilleur.
//
//  Régularisation (EM « maximum a posteriori », comme hmmlearn) : sans elle, un état finit souvent
//  par « capturer » une poignée de jours extrêmes (publications de résultats) au lieu d'un vrai régime.
//    • moyenne  : a priori N(m₀, σ_k²/κ₀) → μ_k tiré vers la moyenne générale tant que l'état est rare ;
//    • variance : a priori inverse-gamma centré sur la variance générale (ν₀ pseudo-observations) ;
//    • transitions : a priori de Dirichlet « collant » (δ pseudo-séjours sur la diagonale, une petite
//      pseudo-sortie vers chaque autre état : aucun état n'est déclaré strictement absorbant).
//  κ₀ = ν₀ = 1 % de l'échantillon (≥ 5), δ = 0,5 % (≥ 2), 0,1 pseudo-sortie : négligeable pour un vrai
//  régime de plusieurs mois, décisif contre un « état » bâti sur une dizaine de jours extrêmes.
//  Honnêteté : on compare toujours au modèle à UN état (loi normale unique). Si le BIC préfère ce
//  dernier, les « régimes » ne sont pas significatifs et on le dit (regimesSupported = false). Même
//  chose si le gain ne vient que d'un état très bref (« chocs ») : c'est alors l'épaisseur des queues
//  de distribution, pas un changement de régime — il faut au moins deux états qui durent ≥ 5 séances.
//  Le nombre d'états peut être choisi automatiquement (BIC minimal sur K = 2…4 : fitHmmAuto).
//  Sorties : paramètres, probabilités FILTRÉES de l'état actuel (sans regarder le futur),
//  chemin de Viterbi, durée attendue de l'état, prévision de l'état à h pas (p·A^h).
// ============================================================================
import { isNum, Rng, sortedFinite, quantileSorted } from './numeric.js';

const LOG2PI = Math.log(2 * Math.PI);
/** Volatilité d'un état rapportée à celle de tout l'échantillon → libellé. */
const volName = (ratio) => (ratio < 0.75 ? 'très calme' : ratio < 0.9 ? 'calme' : ratio <= 1.15 ? 'normale' : ratio <= 1.6 ? 'agitée' : 'très agitée');

function emission(x, mu, v) {
  return Math.exp(-0.5 * (LOG2PI + Math.log(v) + ((x - mu) * (x - mu)) / v));
}

/** Une passe EM complète ; renvoie la log-vraisemblance. */
function forwardBackward(x, m) {
  const T = x.length, K = m.mu.length;
  const alpha = new Float64Array(T * K), beta = new Float64Array(T * K), c = new Float64Array(T), B = new Float64Array(T * K);
  for (let t = 0; t < T; t++) for (let k = 0; k < K; k++) B[t * K + k] = Math.max(1e-300, emission(x[t], m.mu[k], m.v[k]));
  let s = 0;
  for (let k = 0; k < K; k++) s += alpha[k] = m.pi[k] * B[k];
  c[0] = s || 1e-300;
  for (let k = 0; k < K; k++) alpha[k] /= c[0];
  for (let t = 1; t < T; t++) {
    s = 0;
    for (let j = 0; j < K; j++) {
      let a = 0;
      for (let i = 0; i < K; i++) a += alpha[(t - 1) * K + i] * m.A[i * K + j];
      a *= B[t * K + j];
      alpha[t * K + j] = a;
      s += a;
    }
    c[t] = s || 1e-300;
    for (let j = 0; j < K; j++) alpha[t * K + j] /= c[t];
  }
  for (let k = 0; k < K; k++) beta[(T - 1) * K + k] = 1;
  for (let t = T - 2; t >= 0; t--) {
    for (let i = 0; i < K; i++) {
      let b = 0;
      for (let j = 0; j < K; j++) b += m.A[i * K + j] * B[(t + 1) * K + j] * beta[(t + 1) * K + j];
      beta[t * K + i] = b / c[t + 1];
    }
  }
  let ll = 0;
  for (let t = 0; t < T; t++) ll += Math.log(c[t]);
  return { alpha, beta, c, B, ll };
}

function emStep(x, m, fb) {
  const T = x.length, K = m.mu.length, { alpha, beta, c, B } = fb;
  const gammaSum = new Float64Array(K), gammaSumT1 = new Float64Array(K), xi = new Float64Array(K * K);
  const muNum = new Float64Array(K), pi = new Float64Array(K);
  const gamma = new Float64Array(T * K);
  for (let t = 0; t < T; t++) {
    for (let k = 0; k < K; k++) {
      const g = alpha[t * K + k] * beta[t * K + k];
      gamma[t * K + k] = g;
      gammaSum[k] += g;
      if (t < T - 1) gammaSumT1[k] += g;
      muNum[k] += g * x[t];
      if (t === 0) pi[k] = g;
    }
    if (t < T - 1) {
      for (let i = 0; i < K; i++) {
        for (let j = 0; j < K; j++) {
          xi[i * K + j] += (alpha[t * K + i] * m.A[i * K + j] * B[(t + 1) * K + j] * beta[(t + 1) * K + j]) / c[t + 1];
        }
      }
    }
  }
  const mu = new Float64Array(K), v = new Float64Array(K), A = new Float64Array(K * K);
  const { m0, kappa, nu, tv, delta } = m.prior;
  for (let k = 0; k < K; k++) mu[k] = (muNum[k] + kappa * m0) / (gammaSum[k] + kappa);
  const vFloor = m.vFloor;
  for (let k = 0; k < K; k++) {
    let s = 0;
    for (let t = 0; t < T; t++) s += gamma[t * K + k] * (x[t] - mu[k]) ** 2;
    // mode a posteriori normal–inverse-gamma
    v[k] = Math.max(vFloor, (s + nu * tv + kappa * (mu[k] - m0) ** 2) / (gammaSum[k] + nu + 3));
  }
  for (let i = 0; i < K; i++) {
    let row = 0;
    for (let j = 0; j < K; j++) row += A[i * K + j] = xi[i * K + j] + (i === j ? delta : m.prior.eps);
    for (let j = 0; j < K; j++) A[i * K + j] = row > 0 ? A[i * K + j] / row : 1 / K;
  }
  let ps = 0;
  for (let k = 0; k < K; k++) ps += pi[k];
  for (let k = 0; k < K; k++) pi[k] = ps > 0 ? pi[k] / ps : 1 / K;
  return { mu, v, A, pi, vFloor, prior: m.prior };
}

/** Log-densité a priori (à une constante près, identique pour tous les départs). */
function logPrior(m) {
  const K = m.mu.length, { m0, kappa, nu, tv, delta } = m.prior;
  let lp = 0;
  for (let k = 0; k < K; k++) {
    const v = m.v[k];
    lp += -0.5 * Math.log(v) - (kappa * (m.mu[k] - m0) ** 2) / (2 * v); // N(m₀, v/κ₀)
    lp += -(nu / 2 + 1) * Math.log(v) - (nu * tv) / (2 * v); // inverse-gamma(ν₀/2, ν₀·tv/2)
    for (let j = 0; j < K; j++) lp += (j === k ? delta : m.prior.eps) * Math.log(Math.max(1e-300, m.A[k * K + j])); // Dirichlet collant
  }
  return lp;
}

/** Viterbi (log) : séquence d'états la plus probable. */
export function viterbi(x, m) {
  const T = x.length, K = m.mu.length, delta = new Float64Array(K), psi = new Int32Array(T * K), path = new Int32Array(T);
  const lA = Array.from(m.A, (a) => Math.log(Math.max(1e-300, a)));
  for (let k = 0; k < K; k++) delta[k] = Math.log(Math.max(1e-300, m.pi[k])) + Math.log(Math.max(1e-300, emission(x[0], m.mu[k], m.v[k])));
  const nd = new Float64Array(K);
  for (let t = 1; t < T; t++) {
    for (let j = 0; j < K; j++) {
      let best = -Infinity, arg = 0;
      for (let i = 0; i < K; i++) {
        const s = delta[i] + lA[i * K + j];
        if (s > best) { best = s; arg = i; }
      }
      nd[j] = best + Math.log(Math.max(1e-300, emission(x[t], m.mu[j], m.v[j])));
      psi[t * K + j] = arg;
    }
    delta.set(nd);
  }
  let best = 0;
  for (let k = 1; k < K; k++) if (delta[k] > delta[best]) best = k;
  path[T - 1] = best;
  for (let t = T - 1; t > 0; t--) path[t - 1] = psi[t * K + path[t]];
  return path;
}

/**
 * Ajuste un HMM gaussien à K états sur des rendements.
 * @returns {{ K, mu, sd, A:number[][], pi, ll, bic, filtered:number[], states:object[], viterbi:Int32Array,
 *            current:number, expectedDuration:number, forecast:(h:number)=>number[], iterations:number }|null}
 */
export function fitHmm(r, { K = 3, restarts = 6, maxIter = 300, tol = 1e-8, seed = 12345, eps = 0.1, strength = 0.01, sticky = 0.005 } = {}) {
  const x = [];
  for (const v of r) if (isNum(v)) x.push(v);
  const T = x.length;
  if (T < K * 30) return null;
  const s = sortedFinite(x);
  let tv = 0, tm = 0;
  for (const a of x) tm += a;
  tm /= T;
  for (const a of x) tv += (a - tm) ** 2;
  tv /= T;
  const rng = new Rng(seed);
  const prior = { m0: tm, tv, kappa: Math.max(5, strength * T), nu: Math.max(5, strength * T), delta: Math.max(2, sticky * T), eps };
  // départ n° 0 : régimes de volatilité glissante (20 séances) découpés en K quantiles
  const rv = new Float64Array(T);
  {
    let acc = 0;
    const q = [];
    for (let t = 0; t < T; t++) {
      const d = (x[t] - tm) ** 2;
      q.push(d);
      acc += d;
      if (q.length > 20) acc -= q.shift();
      rv[t] = acc / q.length;
    }
  }
  const rvSorted = Float64Array.from(rv).sort();
  let best = null;
  for (let rs = 0; rs < restarts; rs++) {
    const mu = new Float64Array(K), v = new Float64Array(K), A = new Float64Array(K * K), pi = new Float64Array(K).fill(1 / K);
    if (rs === 0) {
      const cuts = Array.from({ length: K - 1 }, (_, k) => rvSorted[Math.floor(((k + 1) / K) * (T - 1))]);
      const n = new Float64Array(K), sx = new Float64Array(K), sxx = new Float64Array(K);
      for (let t = 0; t < T; t++) {
        let k = 0;
        while (k < K - 1 && rv[t] > cuts[k]) k++;
        n[k]++; sx[k] += x[t]; sxx[k] += x[t] * x[t];
      }
      for (let k = 0; k < K; k++) {
        mu[k] = n[k] ? sx[k] / n[k] : tm;
        v[k] = n[k] > 1 ? Math.max(tv * 0.05, sxx[k] / n[k] - mu[k] * mu[k]) : tv;
      }
    } else {
      // départs suivants : quantiles de la distribution perturbés
      for (let k = 0; k < K; k++) {
        mu[k] = quantileSorted(s, (k + 0.5) / K) * (rs === 1 ? 1 : 0.5) + (rs > 1 ? rng.normal() * Math.sqrt(tv) * 0.3 : 0);
        v[k] = tv * (rs > 1 ? 0.3 + 1.4 * rng.next() : 1);
      }
    }
    for (let k = 0; k < K; k++) for (let j = 0; j < K; j++) A[k * K + j] = k === j ? 0.95 : 0.05 / (K - 1);
    let m = { mu, v, A, pi, vFloor: tv * 1e-3, prior }, prev = -Infinity, obj = -Infinity, ll = -Infinity, it = 0;
    for (; it < maxIter; it++) {
      const fb = forwardBackward(x, m);
      ll = fb.ll;
      obj = ll + logPrior(m);
      if (Math.abs(obj - prev) < tol * Math.abs(obj)) break;
      prev = obj;
      m = emStep(x, m, fb);
    }
    if (!best || obj > best.obj) best = { m, ll, obj, it, start: rs };
  }
  // états triés par rendement moyen croissant (0 = le plus baissier)
  const m0 = best.m, order = Array.from({ length: K }, (_, k) => k).sort((a, b) => m0.mu[a] - m0.mu[b]);
  const m = {
    mu: Float64Array.from(order, (k) => m0.mu[k]), v: Float64Array.from(order, (k) => m0.v[k]),
    pi: Float64Array.from(order, (k) => m0.pi[k]), A: new Float64Array(K * K), vFloor: m0.vFloor, prior: m0.prior,
  };
  for (let i = 0; i < K; i++) for (let j = 0; j < K; j++) m.A[i * K + j] = m0.A[order[i] * K + order[j]];
  const fb = forwardBackward(x, m);
  const filtered = Array.from({ length: K }, (_, k) => fb.alpha[(T - 1) * K + k]);
  const current = filtered.indexOf(Math.max(...filtered));
  const path = viterbi(x, m);
  // libellés : direction (dérive rapportée à la volatilité de l'état) + volatilité rapportée à l'ensemble
  const sdAll = Math.sqrt(tv);
  const gammaOcc = new Float64Array(K);
  for (let t = 0; t < T; t++) {
    let z = 0;
    for (let k = 0; k < K; k++) z += fb.alpha[t * K + k] * fb.beta[t * K + k];
    for (let k = 0; k < K; k++) gammaOcc[k] += (fb.alpha[t * K + k] * fb.beta[t * K + k]) / (z || 1);
  }
  const states = Array.from({ length: K }, (_, k) => {
    const sd = Math.sqrt(m.v[k]), occ = path.reduce((a, p) => a + (p === k ? 1 : 0), 0) / T;
    const dir = m.mu[k] > 0.1 * sd ? 'hausse' : m.mu[k] < -0.1 * sd ? 'baisse' : 'range';
    const vol = volName(sd / sdAll);
    const occP = gammaOcc[k] / T;
    return {
      k, mu: m.mu[k], sd, occupancy: occ, occupancyPosterior: occP, dir, vol, rare: occP < 0.02,
      label: `${dir === 'range' ? 'sans tendance' : dir} · vol. ${vol}`,
      duration: Math.min(T, 1 / Math.max(1e-9, 1 - m.A[k * K + k])),
    };
  });
  for (const st of states) if (st.duration < 3) { st.shocks = true; st.label = `${st.label} · chocs brefs`; }
  // libellés identiques : on les distingue par la volatilité quotidienne
  for (const st of states) {
    if (states.some((o) => o !== st && o.label === st.label)) st.dup = true;
  }
  for (const st of states) if (st.dup) { st.label = `${st.label} (σ ${(st.sd * 100).toFixed(2).replace('.', ',')} %/j)`; delete st.dup; }
  const forecast = (h) => {
    let p = filtered.slice();
    for (let step = 0; step < h; step++) {
      const q = new Array(K).fill(0);
      for (let i = 0; i < K; i++) for (let j = 0; j < K; j++) q[j] += p[i] * m.A[i * K + j];
      p = q;
    }
    return p;
  };
  const nParams = K * K - K + 2 * K + (K - 1);
  const ll1 = -0.5 * T * (Math.log(2 * Math.PI * tv) + 1), bic1 = -2 * ll1 + 2 * Math.log(T);
  const bic = -2 * fb.ll + nParams * Math.log(T);
  // un « régime » doit durer : un état quitté en 1 à 2 séances ne décrit pas un régime mais des chocs
  // isolés (queues épaisses de la distribution) ; il en faut au moins deux qui durent ≥ 5 séances
  const persistent = states.filter((st) => st.duration >= 5 && st.occupancyPosterior >= 0.05).length;
  return {
    baseline: { ll: ll1, bic: bic1 }, regimesSupported: bic < bic1 && persistent >= 2, persistentStates: persistent,
    K, mu: Array.from(m.mu), sd: Array.from(m.v, Math.sqrt), A: Array.from({ length: K }, (_, i) => Array.from(m.A.subarray(i * K, i * K + K))),
    pi: Array.from(m.pi), ll: fb.ll, bic, filtered, states, viterbi: path, current,
    expectedDuration: states[current].duration, forecast, iterations: best.it, T, start: best.start,
    prior: { kappa: m.prior.kappa, nu: m.prior.nu, delta: m.prior.delta },
  };
}

/**
 * Choisit le nombre d'états par le critère BIC (le plus petit l'emporte) parmi `Ks`, en écartant les
 * modèles dont un état est quasi inutilisé (sur-paramétrés). Le modèle à un état sert de référence :
 * `regimesSupported` est faux s'il bat tous les autres. Renvoie le modèle retenu enrichi de
 * `selection: [{K, bic, ll, rare}]` (K = 1 compris).
 */
export function fitHmmAuto(r, { Ks = [2, 3, 4], ...opts } = {}) {
  let best = null;
  const selection = [];
  for (const K of Ks) {
    const m = fitHmm(r, { ...opts, K });
    if (!m) continue;
    const rare = m.states.some((s) => s.rare);
    if (!selection.length) selection.push({ K: 1, bic: m.baseline.bic, ll: m.baseline.ll, rare: false });
    selection.push({ K, bic: m.bic, ll: m.ll, rare });
    if (!best || (!rare && (best.rare || m.bic < best.m.bic)) || (rare && best.rare && m.bic < best.m.bic)) best = { m, rare };
  }
  if (!best) return null;
  return { ...best.m, selection, auto: true };
}

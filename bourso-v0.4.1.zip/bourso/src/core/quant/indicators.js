// ============================================================================
//  BOURSO :: quant/indicators.js — indicateurs techniques (définitions de référence).
//
//  Conventions :
//   - entrées : séries (Float64Array ou tableaux) de même longueur, sans NaN après le début ;
//   - sorties : Float64Array de même longueur ; NaN pendant la période de chauffe ;
//   - lissages de Wilder (RSI, ATR, ADX) = moyenne mobile « RMA » amorcée par une moyenne simple,
//     comme les plateformes de référence ; EMA amorcée par une moyenne simple ;
//   - sommes glissantes compensées (Neumaier) + recalcul exact périodique : aucune dérive, même
//     sur 400 000 bougies.
// ============================================================================
import { nanArray, Neumaier, isNum, WeightedStats } from './numeric.js';

const first = (x) => {
  for (let i = 0; i < x.length; i++) if (isNum(x[i])) return i;
  return x.length;
};
const RESYNC = 4096; // recalcul exact des cumuls glissants toutes les 4096 bougies

// ---------------------------------------------------------------- moyennes mobiles

/** Moyenne mobile simple. */
export function sma(x, n) {
  const N = x.length, out = nanArray(N), f = first(x);
  if (n < 1 || f + n > N) return out;
  const acc = new Neumaier();
  for (let i = f; i < N; i++) {
    acc.add(x[i]);
    if (i - f >= n) acc.add(-x[i - n]);
    if (i - f >= n - 1) {
      if ((i - f) % RESYNC === 0 && i - f >= n) {
        acc.reset();
        for (let j = i - n + 1; j <= i; j++) acc.add(x[j]);
      }
      out[i] = acc.value / n;
    }
  }
  return out;
}

function expSmooth(x, n, alpha) {
  const N = x.length, out = nanArray(N), f = first(x);
  if (n < 1 || f + n > N) return out;
  let s = 0;
  for (let i = f; i < f + n; i++) s += x[i];
  let e = s / n;
  out[f + n - 1] = e;
  for (let i = f + n; i < N; i++) {
    e += alpha * (x[i] - e);
    out[i] = e;
  }
  return out;
}
/** Moyenne mobile exponentielle (α = 2 / (n + 1)). */
export const ema = (x, n) => expSmooth(x, n, 2 / (n + 1));
/** Moyenne de Wilder (α = 1 / n) — base du RSI, de l'ATR et de l'ADX. */
export const rma = (x, n) => expSmooth(x, n, 1 / n);

/** Moyenne mobile pondérée linéairement (poids 1…n), mise à jour O(1). */
export function wma(x, n) {
  const N = x.length, out = nanArray(N), f = first(x);
  if (n < 1 || f + n > N) return out;
  const denom = (n * (n + 1)) / 2;
  let num = 0, S = 0;
  const exact = (end) => {
    num = 0;
    S = 0;
    for (let k = 0; k < n; k++) {
      num += (k + 1) * x[end - n + 1 + k];
      S += x[end - n + 1 + k];
    }
  };
  exact(f + n - 1);
  out[f + n - 1] = num / denom;
  for (let i = f + n; i < N; i++) {
    if ((i - f) % RESYNC === 0) exact(i);
    else {
      num += n * x[i] - S;
      S += x[i] - x[i - n];
    }
    out[i] = num / denom;
  }
  return out;
}

/** Hull : WMA(2·WMA(n/2) − WMA(n), √n) — moyenne rapide et lisse. */
export function hma(x, n) {
  const a = wma(x, Math.max(1, Math.round(n / 2))), b = wma(x, n), d = nanArray(x.length);
  for (let i = 0; i < x.length; i++) if (isNum(a[i]) && isNum(b[i])) d[i] = 2 * a[i] - b[i];
  return wma(d, Math.max(1, Math.round(Math.sqrt(n))));
}

/** Moyenne adaptative de Kaufman (efficacité du mouvement). */
export function kama(x, n = 10, fast = 2, slow = 30) {
  const N = x.length, out = nanArray(N), f = first(x);
  if (f + n >= N) return out;
  const fsc = 2 / (fast + 1), ssc = 2 / (slow + 1);
  let k = x[f + n - 1], vol = 0;
  for (let j = f + 1; j <= f + n - 1; j++) vol += Math.abs(x[j] - x[j - 1]);
  out[f + n - 1] = k;
  for (let i = f + n; i < N; i++) {
    vol += Math.abs(x[i] - x[i - 1]) - (i - n >= f + 1 ? Math.abs(x[i - n] - x[i - n - 1]) : 0);
    if ((i - f) % RESYNC === 0) {
      vol = 0;
      for (let j = i - n + 1; j <= i; j++) vol += Math.abs(x[j] - x[j - 1]);
    }
    const er = vol > 1e-12 ? Math.abs(x[i] - x[i - n]) / vol : 0;
    const sc = (er * (fsc - ssc) + ssc) ** 2;
    k += sc * (x[i] - k);
    out[i] = k;
  }
  return out;
}

/** Moyenne mobile pondérée par le volume. */
export function vwma(c, v, n) {
  const N = c.length, out = nanArray(N);
  const pv = new Neumaier(), vv = new Neumaier();
  for (let i = 0; i < N; i++) {
    pv.add(c[i] * v[i]);
    vv.add(v[i]);
    if (i >= n) {
      pv.add(-c[i - n] * v[i - n]);
      vv.add(-v[i - n]);
    }
    if (i >= n - 1) out[i] = vv.value > 0 ? pv.value / vv.value : c[i];
  }
  return out;
}

/** Écart-type glissant (population par défaut), calculé sur des valeurs recentrées (aucune annulation). */
export function rollingStd(x, n, { sample = false } = {}) {
  const N = x.length, out = nanArray(N), f = first(x);
  if (f + n > N) return out;
  const K = x[f], s1 = new Neumaier(), s2 = new Neumaier();
  for (let i = f; i < N; i++) {
    const d = x[i] - K;
    s1.add(d);
    s2.add(d * d);
    if (i - f >= n) {
      const e = x[i - n] - K;
      s1.add(-e);
      s2.add(-e * e);
    }
    if (i - f >= n - 1) {
      const m = s1.value / n;
      const varp = Math.max(0, s2.value / n - m * m);
      out[i] = Math.sqrt(sample ? (varp * n) / (n - 1) : varp);
    }
  }
  return out;
}

export function rollingMax(x, n) {
  const N = x.length, out = nanArray(N), dq = new Int32Array(N);
  let h = 0, t = 0;
  for (let i = 0; i < N; i++) {
    while (t > h && x[dq[t - 1]] <= x[i]) t--;
    dq[t++] = i;
    if (dq[h] <= i - n) h++;
    if (i >= n - 1) out[i] = x[dq[h]];
  }
  return out;
}
export function rollingMin(x, n) {
  const N = x.length, out = nanArray(N), dq = new Int32Array(N);
  let h = 0, t = 0;
  for (let i = 0; i < N; i++) {
    while (t > h && x[dq[t - 1]] >= x[i]) t--;
    dq[t++] = i;
    if (dq[h] <= i - n) h++;
    if (i >= n - 1) out[i] = x[dq[h]];
  }
  return out;
}
/** Index (dans la fenêtre) du plus haut / plus bas : pour Aroon. */
function rollingArg(x, n, cmp) {
  const N = x.length, out = new Int32Array(N).fill(-1), dq = new Int32Array(N);
  let h = 0, t = 0;
  for (let i = 0; i < N; i++) {
    while (t > h && cmp(x[dq[t - 1]], x[i])) t--;
    dq[t++] = i;
    if (dq[h] <= i - n) h++;
    if (i >= n - 1) out[i] = dq[h];
  }
  return out;
}

// ---------------------------------------------------------------- oscillateurs

/** RSI de Wilder. */
export function rsi(c, n = 14) {
  const N = c.length, out = nanArray(N), f = first(c);
  if (N - f <= n) return out;
  let g = 0, l = 0;
  for (let i = f + 1; i <= f + n; i++) {
    const d = c[i] - c[i - 1];
    if (d > 0) g += d;
    else l -= d;
  }
  g /= n;
  l /= n;
  const val = () => (l === 0 ? (g === 0 ? 50 : 100) : 100 - 100 / (1 + g / l));
  out[f + n] = val();
  for (let i = f + n + 1; i < N; i++) {
    const d = c[i] - c[i - 1];
    g = (g * (n - 1) + (d > 0 ? d : 0)) / n;
    l = (l * (n - 1) + (d < 0 ? -d : 0)) / n;
    out[i] = val();
  }
  return out;
}

/** MACD (12, 26, 9) : ligne, signal, histogramme. */
export function macd(c, fast = 12, slow = 26, signal = 9) {
  const a = ema(c, fast), b = ema(c, slow), N = c.length, line = nanArray(N);
  for (let i = 0; i < N; i++) if (isNum(a[i]) && isNum(b[i])) line[i] = a[i] - b[i];
  const sig = ema(line, signal), hist = nanArray(N);
  for (let i = 0; i < N; i++) if (isNum(sig[i])) hist[i] = line[i] - sig[i];
  return { line, signal: sig, hist };
}

/** Stochastique (14, 3, 3) : %K lissé et %D. */
export function stoch(h, l, c, n = 14, smoothK = 3, smoothD = 3) {
  const N = c.length, hh = rollingMax(h, n), ll = rollingMin(l, n), raw = nanArray(N);
  for (let i = n - 1; i < N; i++) {
    const r = hh[i] - ll[i];
    raw[i] = r > 0 ? (100 * (c[i] - ll[i])) / r : 50;
  }
  const k = sma(raw, smoothK);
  return { k, d: sma(k, smoothD) };
}

/** Stochastique du RSI (3, 3, 14, 14). */
export function stochRsi(c, rsiN = 14, stochN = 14, smoothK = 3, smoothD = 3) {
  const r = rsi(c, rsiN), N = c.length, raw = nanArray(N), f = first(r);
  if (f >= N) return { k: raw, d: raw };
  const sub = r.subarray(f), hh = rollingMax(sub, stochN), ll = rollingMin(sub, stochN);
  for (let i = stochN - 1; i < sub.length; i++) {
    const span = hh[i] - ll[i];
    raw[f + i] = span > 0 ? (100 * (sub[i] - ll[i])) / span : 50;
  }
  const k = sma(raw, smoothK);
  return { k, d: sma(k, smoothD) };
}

/** Williams %R (−100…0). */
export function williamsR(h, l, c, n = 14) {
  const N = c.length, hh = rollingMax(h, n), ll = rollingMin(l, n), out = nanArray(N);
  for (let i = n - 1; i < N; i++) {
    const r = hh[i] - ll[i];
    out[i] = r > 0 ? (-100 * (hh[i] - c[i])) / r : -50;
  }
  return out;
}

/** Commodity Channel Index (prix typique, écart moyen absolu). */
export function cci(h, l, c, n = 20) {
  const N = c.length, tp = new Float64Array(N);
  for (let i = 0; i < N; i++) tp[i] = (h[i] + l[i] + c[i]) / 3;
  const ma = sma(tp, n), out = nanArray(N);
  for (let i = n - 1; i < N; i++) {
    let md = 0;
    for (let j = i - n + 1; j <= i; j++) md += Math.abs(tp[j] - ma[i]);
    md /= n;
    out[i] = md > 0 ? (tp[i] - ma[i]) / (0.015 * md) : 0;
  }
  return out;
}

/** Money Flow Index (RSI pondéré par le volume). */
export function mfi(h, l, c, v, n = 14) {
  const N = c.length, out = nanArray(N), pos = new Float64Array(N), neg = new Float64Array(N);
  let tpPrev = (h[0] + l[0] + c[0]) / 3;
  for (let i = 1; i < N; i++) {
    const tp = (h[i] + l[i] + c[i]) / 3, mf = tp * v[i];
    if (tp > tpPrev) pos[i] = mf;
    else if (tp < tpPrev) neg[i] = mf;
    tpPrev = tp;
  }
  let sp = 0, sn = 0;
  for (let i = 1; i < N; i++) {
    sp += pos[i];
    sn += neg[i];
    if (i > n) {
      sp -= pos[i - n];
      sn -= neg[i - n];
    }
    if (i >= n) out[i] = sn <= 1e-12 ? (sp <= 1e-12 ? 50 : 100) : 100 - 100 / (1 + sp / sn);
  }
  return out;
}

/** Taux de variation (%) sur n bougies. */
export function roc(c, n = 10) {
  const N = c.length, out = nanArray(N);
  for (let i = n; i < N; i++) out[i] = c[i - n] ? (100 * (c[i] - c[i - n])) / c[i - n] : NaN;
  return out;
}
export function momentum(c, n = 10) {
  const N = c.length, out = nanArray(N);
  for (let i = n; i < N; i++) out[i] = c[i] - c[i - n];
  return out;
}

/** Awesome Oscillator : SMA5 − SMA34 du prix médian. */
export function awesome(h, l) {
  const N = h.length, m = new Float64Array(N);
  for (let i = 0; i < N; i++) m[i] = (h[i] + l[i]) / 2;
  const a = sma(m, 5), b = sma(m, 34), out = nanArray(N);
  for (let i = 0; i < N; i++) if (isNum(b[i])) out[i] = a[i] - b[i];
  return out;
}

/** Puissance haussière/baissière d'Elder (somme des deux) autour de l'EMA 13. */
export function bullBearPower(h, l, c, n = 13) {
  const e = ema(c, n), N = c.length, out = nanArray(N);
  for (let i = 0; i < N; i++) if (isNum(e[i])) out[i] = h[i] - e[i] + (l[i] - e[i]);
  return out;
}

/** Oscillateur ultime de Williams (7, 14, 28). */
export function ultimate(h, l, c, a = 7, b = 14, d = 28) {
  const N = c.length, bp = new Float64Array(N), tr = new Float64Array(N), out = nanArray(N);
  for (let i = 1; i < N; i++) {
    const lo = Math.min(l[i], c[i - 1]), hi = Math.max(h[i], c[i - 1]);
    bp[i] = c[i] - lo;
    tr[i] = hi - lo;
  }
  const avg = (n, i) => {
    let s = 0, t = 0;
    for (let j = i - n + 1; j <= i; j++) {
      s += bp[j];
      t += tr[j];
    }
    return t > 0 ? s / t : 0;
  };
  for (let i = d; i < N; i++) out[i] = (100 * (4 * avg(a, i) + 2 * avg(b, i) + avg(d, i))) / 7;
  return out;
}

// ---------------------------------------------------------------- volatilité, tendance

/** True Range. */
export function trueRange(h, l, c) {
  const N = c.length, tr = new Float64Array(N);
  tr[0] = h[0] - l[0];
  for (let i = 1; i < N; i++) tr[i] = Math.max(h[i] - l[i], Math.abs(h[i] - c[i - 1]), Math.abs(l[i] - c[i - 1]));
  return tr;
}
/** Average True Range (Wilder). */
export const atr = (h, l, c, n = 14) => rma(trueRange(h, l, c), n);

/** ADX / DI+ / DI− (Wilder). */
export function adx(h, l, c, n = 14) {
  const N = c.length, pdm = nanArray(N), mdm = nanArray(N), tr = nanArray(N);
  for (let i = 1; i < N; i++) {
    const up = h[i] - h[i - 1], dn = l[i - 1] - l[i];
    pdm[i] = up > dn && up > 0 ? up : 0;
    mdm[i] = dn > up && dn > 0 ? dn : 0;
    tr[i] = Math.max(h[i] - l[i], Math.abs(h[i] - c[i - 1]), Math.abs(l[i] - c[i - 1]));
  }
  const sp = rma(pdm, n), sm = rma(mdm, n), st = rma(tr, n);
  const pdi = nanArray(N), mdi = nanArray(N), dx = nanArray(N);
  for (let i = 0; i < N; i++) {
    if (!isNum(st[i]) || st[i] <= 0) continue;
    pdi[i] = (100 * sp[i]) / st[i];
    mdi[i] = (100 * sm[i]) / st[i];
    const s = pdi[i] + mdi[i];
    dx[i] = s > 0 ? (100 * Math.abs(pdi[i] - mdi[i])) / s : 0;
  }
  return { adx: rma(dx, n), pdi, mdi };
}

/** Bandes de Bollinger (20, 2) + %B + largeur relative. */
export function bollinger(c, n = 20, k = 2) {
  const mid = sma(c, n), sd = rollingStd(c, n), N = c.length;
  const up = nanArray(N), lo = nanArray(N), pctB = nanArray(N), width = nanArray(N);
  for (let i = 0; i < N; i++) {
    if (!isNum(mid[i])) continue;
    up[i] = mid[i] + k * sd[i];
    lo[i] = mid[i] - k * sd[i];
    pctB[i] = up[i] > lo[i] ? (c[i] - lo[i]) / (up[i] - lo[i]) : 0.5;
    width[i] = mid[i] ? (up[i] - lo[i]) / mid[i] : NaN;
  }
  return { mid, up, lo, pctB, width, sd };
}

/** Canaux de Keltner : EMA ± m × ATR. */
export function keltner(h, l, c, n = 20, mult = 2, atrN = 10) {
  const mid = ema(c, n), a = atr(h, l, c, atrN), N = c.length, up = nanArray(N), lo = nanArray(N);
  for (let i = 0; i < N; i++) {
    if (!isNum(mid[i]) || !isNum(a[i])) continue;
    up[i] = mid[i] + mult * a[i];
    lo[i] = mid[i] - mult * a[i];
  }
  return { mid, up, lo };
}

/** Canaux de Donchian (plus haut / plus bas sur n). */
export function donchian(h, l, n = 20) {
  const up = rollingMax(h, n), lo = rollingMin(l, n), N = h.length, mid = nanArray(N);
  for (let i = 0; i < N; i++) if (isNum(up[i])) mid[i] = (up[i] + lo[i]) / 2;
  return { up, lo, mid };
}

/** Ichimoku Kinko Hyo (9, 26, 52, décalage 26). spanA/spanB : nuage APPLICABLE à chaque bougie. */
export function ichimoku(h, l, c, tN = 9, kN = 26, bN = 52, shift = 26) {
  const N = c.length, mid = (n) => {
    const hh = rollingMax(h, n), ll = rollingMin(l, n), o = nanArray(N);
    for (let i = 0; i < N; i++) if (isNum(hh[i])) o[i] = (hh[i] + ll[i]) / 2;
    return o;
  };
  const tenkan = mid(tN), kijun = mid(kN), spanBraw = mid(bN), spanAraw = nanArray(N);
  for (let i = 0; i < N; i++) if (isNum(tenkan[i]) && isNum(kijun[i])) spanAraw[i] = (tenkan[i] + kijun[i]) / 2;
  const spanA = nanArray(N), spanB = nanArray(N), lagging = nanArray(N);
  for (let i = shift; i < N; i++) {
    spanA[i] = spanAraw[i - shift];
    spanB[i] = spanBraw[i - shift];
    lagging[i - shift] = c[i];
  }
  return { tenkan, kijun, spanA, spanB, spanAraw, spanBraw, lagging, shift };
}

/** SuperTrend (ATR 10, facteur 3). dir = +1 tendance haussière (ligne sous le prix), −1 baissière. */
export function supertrend(h, l, c, n = 10, factor = 3) {
  const N = c.length, a = atr(h, l, c, n), line = nanArray(N), dir = new Float64Array(N);
  let up = NaN, dn = NaN, prevSt = NaN;
  for (let i = 0; i < N; i++) {
    if (!isNum(a[i])) continue;
    const src = (h[i] + l[i]) / 2;
    let upper = src + factor * a[i], lower = src - factor * a[i];
    if (isNum(dn) && !(lower > dn || c[i - 1] < dn)) lower = dn;
    if (isNum(up) && !(upper < up || c[i - 1] > up)) upper = up;
    let d;
    if (!isNum(prevSt)) d = -1;
    else if (prevSt === up) d = c[i] > upper ? 1 : -1;
    else d = c[i] < lower ? -1 : 1;
    line[i] = d === 1 ? lower : upper;
    dir[i] = d;
    up = upper;
    dn = lower;
    prevSt = line[i];
  }
  return { line, dir };
}

/** SAR parabolique (0,02 ; 0,2). */
export function psar(h, l, step = 0.02, max = 0.2) {
  const N = h.length, out = nanArray(N), dir = new Float64Array(N);
  if (N < 3) return { sar: out, dir };
  let up = h[1] + l[1] > h[0] + l[0];
  let sar = up ? l[0] : h[0], ep = up ? h[1] : l[1], af = step;
  out[1] = sar;
  dir[1] = up ? 1 : -1;
  for (let i = 2; i < N; i++) {
    sar += af * (ep - sar);
    if (up) {
      sar = Math.min(sar, l[i - 1], l[i - 2]);
      if (l[i] < sar) {
        up = false;
        sar = ep;
        ep = l[i];
        af = step;
      } else if (h[i] > ep) {
        ep = h[i];
        af = Math.min(af + step, max);
      }
    } else {
      sar = Math.max(sar, h[i - 1], h[i - 2]);
      if (h[i] > sar) {
        up = true;
        sar = ep;
        ep = h[i];
        af = step;
      } else if (l[i] < ep) {
        ep = l[i];
        af = Math.min(af + step, max);
      }
    }
    out[i] = sar;
    dir[i] = up ? 1 : -1;
  }
  return { sar: out, dir };
}

/**
 * VWAP de séance + bandes d'écart-type pondéré (variance de West : exacte, sans annulation).
 * @param {(i:number)=>boolean} newSession vrai si la bougie i ouvre une nouvelle séance
 */
export function vwap(h, l, c, v, newSession = (i) => i === 0) {
  const N = c.length, mid = nanArray(N), sd = nanArray(N);
  let ws = new WeightedStats();
  for (let i = 0; i < N; i++) {
    if (i === 0 || newSession(i)) ws = new WeightedStats();
    const tp = (h[i] + l[i] + c[i]) / 3;
    ws.add(tp, v[i]);
    mid[i] = ws.w > 0 ? ws.mean : tp;
    sd[i] = ws.w > 0 ? Math.sqrt(Math.max(0, ws.variance)) : 0;
  }
  const band = (k) => mid.map((m, i) => m + k * sd[i]);
  return { mid, sd, up1: band(1), lo1: band(-1), up2: band(2), lo2: band(-2) };
}

// ---------------------------------------------------------------- volume

export function obv(c, v) {
  const N = c.length, out = new Float64Array(N);
  for (let i = 1; i < N; i++) out[i] = out[i - 1] + (c[i] > c[i - 1] ? v[i] : c[i] < c[i - 1] ? -v[i] : 0);
  return out;
}

/** Ligne d'accumulation / distribution (Chaikin). */
export function adLine(h, l, c, v) {
  const N = c.length, out = new Float64Array(N);
  let acc = 0;
  for (let i = 0; i < N; i++) {
    const r = h[i] - l[i];
    acc += r > 0 ? (((c[i] - l[i]) - (h[i] - c[i])) / r) * v[i] : 0;
    out[i] = acc;
  }
  return out;
}

/** Chaikin Money Flow (20). */
export function cmf(h, l, c, v, n = 20) {
  const N = c.length, mfv = new Float64Array(N), out = nanArray(N);
  for (let i = 0; i < N; i++) {
    const r = h[i] - l[i];
    mfv[i] = r > 0 ? (((c[i] - l[i]) - (h[i] - c[i])) / r) * v[i] : 0;
  }
  let s = 0, sv = 0;
  for (let i = 0; i < N; i++) {
    s += mfv[i];
    sv += v[i];
    if (i >= n) {
      s -= mfv[i - n];
      sv -= v[i - n];
    }
    if (i >= n - 1) out[i] = sv > 0 ? s / sv : 0;
  }
  return out;
}

/** Force Index d'Elder (EMA 13 de Δprix × volume). */
export function forceIndex(c, v, n = 13) {
  const N = c.length, raw = nanArray(N);
  for (let i = 1; i < N; i++) raw[i] = (c[i] - c[i - 1]) * v[i];
  return ema(raw, n);
}

/** Aroon (25) : 100 × (n − ancienneté du plus haut) / n. */
export function aroon(h, l, n = 25) {
  const N = h.length, ah = rollingArg(h, n + 1, (a, b) => a <= b), al = rollingArg(l, n + 1, (a, b) => a >= b);
  const up = nanArray(N), down = nanArray(N), osc = nanArray(N);
  for (let i = n; i < N; i++) {
    up[i] = (100 * (n - (i - ah[i]))) / n;
    down[i] = (100 * (n - (i - al[i]))) / n;
    osc[i] = up[i] - down[i];
  }
  return { up, down, osc };
}

/** Régression linéaire glissante : pente (par bougie), valeur en fin de fenêtre, R². */
export function linregRolling(x, n) {
  const N = x.length, slope = nanArray(N), endVal = nanArray(N), r2 = nanArray(N);
  const sk = ((n - 1) * n) / 2, skk = ((n - 1) * n * (2 * n - 1)) / 6, den = n * skk - sk * sk;
  for (let i = n - 1; i < N; i++) {
    let sy = 0, sky = 0, syy = 0;
    const base = x[i - n + 1];
    for (let k = 0; k < n; k++) {
      const y = x[i - n + 1 + k] - base;
      sy += y;
      sky += k * y;
      syy += y * y;
    }
    const b = (n * sky - sk * sy) / den, a = (sy - b * sk) / n;
    slope[i] = b;
    endVal[i] = base + a + b * (n - 1);
    const ssTot = syy - (sy * sy) / n, ssReg = b * (sky - (sk * sy) / n);
    r2[i] = ssTot > 0 ? Math.min(1, Math.max(0, ssReg / ssTot)) : 0;
  }
  return { slope, endVal, r2 };
}

/** Z-score du prix par rapport à sa moyenne glissante. */
export function zscore(x, n = 20) {
  const m = sma(x, n), s = rollingStd(x, n, { sample: true }), N = x.length, out = nanArray(N);
  for (let i = 0; i < N; i++) if (isNum(m[i]) && s[i] > 0) out[i] = (x[i] - m[i]) / s[i];
  return out;
}

// ---------------------------------------------------------------- transformations, niveaux

/** Bougies Heikin-Ashi. */
export function heikinAshi(o, h, l, c) {
  const N = c.length, ho = new Float64Array(N), hh = new Float64Array(N), hl = new Float64Array(N), hc = new Float64Array(N);
  for (let i = 0; i < N; i++) {
    hc[i] = (o[i] + h[i] + l[i] + c[i]) / 4;
    ho[i] = i === 0 ? (o[0] + c[0]) / 2 : (ho[i - 1] + hc[i - 1]) / 2;
    hh[i] = Math.max(h[i], ho[i], hc[i]);
    hl[i] = Math.min(l[i], ho[i], hc[i]);
  }
  return { open: ho, high: hh, low: hl, close: hc };
}

/** Points pivots de la séance précédente : classiques, Fibonacci, Camarilla, Woodie. */
export function pivots(H, L, C) {
  const r = H - L, P = (H + L + C) / 3, W = (H + L + 2 * C) / 4;
  return {
    classic: { P, R1: 2 * P - L, R2: P + r, R3: H + 2 * (P - L), S1: 2 * P - H, S2: P - r, S3: L - 2 * (H - P) },
    fibonacci: { P, R1: P + 0.382 * r, R2: P + 0.618 * r, R3: P + r, S1: P - 0.382 * r, S2: P - 0.618 * r, S3: P - r },
    camarilla: {
      P, R1: C + (r * 1.1) / 12, R2: C + (r * 1.1) / 6, R3: C + (r * 1.1) / 4, R4: C + (r * 1.1) / 2,
      S1: C - (r * 1.1) / 12, S2: C - (r * 1.1) / 6, S3: C - (r * 1.1) / 4, S4: C - (r * 1.1) / 2,
    },
    woodie: { P: W, R1: 2 * W - L, R2: W + r, S1: 2 * W - H, S2: W - r },
  };
}

/**
 * Sommets / creux significatifs (ZigZag). Seuil : `pct` du prix, ou `mult` × ATR si `atrSeries`.
 * @returns {{ swings: {i:number, price:number, type:1|-1}[], provisional: {i:number, price:number, type:1|-1}|null }}
 */
export function zigzag(h, l, { pct = 0.02, atrSeries = null, mult = 2.5, from = 0 } = {}) {
  const N = h.length, swings = [];
  if (N - from < 3) return { swings, provisional: null };
  const thr = (i) => (atrSeries && isNum(atrSeries[i]) ? mult * atrSeries[i] : pct * (h[i] + l[i]) * 0.5);
  let mode = 0, hiI = from, loI = from;
  for (let i = from + 1; i < N; i++) {
    if (mode >= 0 && h[i] >= h[hiI]) hiI = i;
    if (mode <= 0 && l[i] <= l[loI]) loI = i;
    if (mode >= 0 && h[hiI] - l[i] >= thr(i) && hiI < i) {
      if (mode === 0 && loI < hiI) swings.push({ i: loI, price: l[loI], type: -1 });
      swings.push({ i: hiI, price: h[hiI], type: 1 });
      mode = -1;
      loI = hiI + 1;
      for (let j = hiI + 1; j <= i; j++) if (l[j] <= l[loI]) loI = j;
    } else if (mode <= 0 && h[i] - l[loI] >= thr(i) && loI < i) {
      if (mode === 0 && hiI < loI) swings.push({ i: hiI, price: h[hiI], type: 1 });
      swings.push({ i: loI, price: l[loI], type: -1 });
      mode = 1;
      hiI = loI + 1;
      for (let j = loI + 1; j <= i; j++) if (h[j] >= h[hiI]) hiI = j;
    }
  }
  const provisional = mode === 1 ? { i: hiI, price: h[hiI], type: 1 } : mode === -1 ? { i: loI, price: l[loI], type: -1 } : null;
  return { swings, provisional };
}

/** Plus haut / plus bas sur toute une série (utile pour 52 semaines). */
export function extremes(h, l, from = 0, to = h.length) {
  let hi = -Infinity, lo = Infinity, hiI = -1, loI = -1;
  for (let i = from; i < to; i++) {
    if (h[i] > hi) { hi = h[i]; hiI = i; }
    if (l[i] < lo) { lo = l[i]; loI = i; }
  }
  return { hi, lo, hiI, loI };
}

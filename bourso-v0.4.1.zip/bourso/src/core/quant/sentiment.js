// ============================================================================
//  BOURSO :: quant/sentiment.js — tonalité d'un texte financier en français (lexique pondéré).
//
//  Rapide et déterministe : sert de premier filtre et de garde-fou face à l'IA (si le modèle
//  contredit franchement le lexique, c'est signalé). Gère les négations simples (« ne … pas »,
//  « sans ») et les intensificateurs (« fortement », « nettement »).
// ============================================================================

const POS = {
  hausse: 1, haussier: 1.2, rebond: 0.9, record: 1, relève: 1.1, relevé: 1.1, relevées: 1.1, relèvement: 1.1, dépasse: 0.9, dépassent: 0.9,
  supérieur: 0.7, supérieurs: 0.7, solide: 0.8, solides: 0.8, croissance: 0.8, accélération: 0.8, accélère: 0.8, bénéfice: 0.5,
  bénéfices: 0.5, contrat: 0.6, commande: 0.5, commandes: 0.5, gagne: 0.8, succès: 1, encourageant: 0.9, encourageants: 0.9,
  amélioration: 0.8, améliore: 0.8, optimisme: 1, optimiste: 1, rachat: 0.6, dividende: 0.4, surperformance: 1, achat: 0.6,
  relèvent: 1.1, recommandation: 0.2, favorable: 0.9, favorables: 0.9, soutient: 0.6, soutien: 0.5, approbation: 0.9, autorisation: 0.6,
  feu: 0.3, vert: 0.4, synergies: 0.6, fusion: 0.3, désinflation: 0.5, baisse_des_taux: 0.6, robuste: 0.8, résilient: 0.7, résiliente: 0.7,
  // titres de presse réels : verbes de marché, et anglais (Yahoo Finance, GDELT)
  bondit: 1.1, grimpe: 0.9, progresse: 0.7, envole: 1.2, flambe: 1, rebondit: 0.9, relevée: 1.1, dépassé: 0.8, surpasse: 0.9, plébiscité: 0.8,
  rises: 0.9, rise: 0.8, rising: 0.7, jumps: 1, jump: 0.9, surges: 1.2, surge: 1.1, soars: 1.2, gains: 0.8, gain: 0.6, beats: 1, beat: 0.9,
  raises: 1, raised: 0.9, upgrade: 1.1, upgraded: 1.1, upgrades: 1.1, strong: 0.7, stronger: 0.8, rally: 0.9, rallies: 0.9, outperform: 0.9,
  approval: 0.9, approved: 0.8, wins: 0.8, buyback: 0.7, higher: 0.5, bullish: 1.1, boost: 0.7, boosts: 0.7, tops: 0.7, exceeds: 0.9, growth: 0.6,
};
const NEG = {
  baisse: -1, baissier: -1.2, chute: -1.2, recul: -0.8, recule: -0.8, abaisse: -1.1, abaissées: -1.1, abaissé: -1.1, avertissement: -1.3,
  perte: -1, pertes: -1, déception: -1.1, décevant: -1.1, décevants: -1.1, inférieur: -0.7, inférieurs: -0.7, ralentissement: -0.8,
  ralentit: -0.8, restrictions: -0.9, sanction: -1, sanctions: -1, amende: -1, enquête: -0.8, rappel: -0.7, grève: -0.8, dette: -0.4,
  endettement: -0.6, dégradation: -1, dégradé: -1, abaissement: -1, vente: -0.4, prudence: -0.5, prudent: -0.4, incertitude: -0.7,
  inquiétudes: -0.9, inquiétude: -0.9, risque: -0.4, risques: -0.4, tension: -0.6, tensions: -0.6, inflation: -0.4, faucon: -0.5,
  licenciements: -0.7, dépréciation: -0.9, échec: -1.2, retard: -0.6, retards: -0.6, litige: -0.7, cession: -0.1, contrefaçon: -0.6,
  sous: -0.2, pression: -0.5, effondrement: -1.5, faillite: -1.6, défaut: -1.2, rétrogradation: -1.1, coupe: -0.6, suppression: -0.6,
  plonge: -1.3, dévisse: -1.3, décroche: -1.1, lâche: -0.7, rechute: -0.9, sanctionné: -1, abaissée: -1.1, déçoit: -1.1,
  falls: -0.9, fall: -0.8, drops: -0.9, drop: -0.8, plunges: -1.3, plunge: -1.2, slumps: -1.2, slump: -1.1, slides: -0.9, slide: -0.8, tumbles: -1.2,
  sinks: -1.1, misses: -1, miss: -0.8, cuts: -0.8, downgrade: -1.1, downgraded: -1.1, downgrades: -1.1, weak: -0.8, weaker: -0.8, warning: -1.2,
  warns: -1.1, probe: -0.8, lawsuit: -0.8, fined: -1, loss: -0.9, losses: -0.9, layoffs: -0.8, recall: -0.7, lowers: -0.9, concern: -0.6,
  concerns: -0.6, fears: -0.8, bearish: -1.1, crash: -1.5, bankruptcy: -1.6, slowdown: -0.8,
};
const NEGATORS = new Set(['pas', 'jamais', 'sans', 'aucun', 'aucune', 'ni', 'plus']);
const BOOST = { fortement: 1.5, nettement: 1.4, très: 1.3, massivement: 1.6, légèrement: 0.6, modérément: 0.7 };

/** @returns {{ score:number, confidence:number, hits:string[] }} score dans [−1, 1] */
export function scoreText(text) {
  const words = text.toLowerCase().replace(/[«»"“”().,;:!?'’]/g, ' ').split(/\s+/).filter(Boolean);
  let s = 0, n = 0;
  const hits = [];
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    let v = POS[w] ?? NEG[w];
    if (w === 'des' && words[i + 1] === 'taux' && words[i - 1] === 'baisse') v = 0;
    if (v === undefined) continue;
    const prev = words.slice(Math.max(0, i - 3), i), next = words.slice(i + 1, i + 3);
    // « ne … pas / plus / jamais » encadre le verbe ; « sans », « aucun » le précèdent
    const neWrap = prev.slice(-2).some((p) => p === 'ne' || p === 'n') && next.some((p) => ['pas', 'plus', 'jamais', 'guère', 'point'].includes(p));
    if (neWrap || prev.some((p) => NEGATORS.has(p))) v = -v * 0.8;
    const b = BOOST[words[i - 1]];
    if (b) v *= b;
    s += v;
    n++;
    hits.push(w);
  }
  const score = Math.tanh(s / 2.2);
  return { score, confidence: Math.min(0.9, 0.3 + 0.15 * n), hits };
}

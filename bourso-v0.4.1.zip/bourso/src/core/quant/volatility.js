// ============================================================================
//  BOURSO :: quant/volatility.js — estimateurs de volatilité et modèle GARCH(1,1).
//
//  Tous les estimateurs renvoient une volatilité ANNUALISÉE (fraction : 0,25 = 25 %/an) à partir
//  de `ppy` périodes par an (252 en quotidien, 252 × 510 en minutes de séance).
//   - close-to-close : écart-type des rendements logarithmiques ;
//   - Parkinson (1980) : amplitude haut/bas, ~5× plus efficace ;
//   - Garman-Klass (1980) : OHLC ; Rogers-Satchell (1991) : robuste à la tendance ;
//   - Yang-Zhang (2000) : gère les gaps d'ouverture (le meilleur pour des actions) ;
//   - GARCH(1,1) gaussien, ciblage de variance, maximum de vraisemblance (Nelder-Mead).
// ============================================================================
import { isNum, nanArray, meanVar, Neumaier } from './numeric.js';

const LN2 = Math.LN2;

/** Rendements logarithmiques (NaN en 0). */
export function logReturns(c) {
  const N = c.length, r = nanArray(N);
  for (let i = 1; i < N; i++) if (c[i] > 0 && c[i - 1] > 0) r[i] = Math.log(c[i] / c[i - 1]);
  return r;
}

/** Fenêtre [N − n, N[ bornée. */
const win = (N, n) => [Math.max(0, N - n), N];

export function closeToClose(c, n, ppy = 252) {
  const r = logReturns(c), [a, b] = win(r.length, n);
  return meanVar(r, { from: Math.max(1, a), to: b }).sd * Math.sqrt(ppy);
}

export function parkinson(h, l, n, ppy = 252) {
  const [a, b] = win(h.length, n), s = new Neumaier();
  for (let i = a; i < b; i++) s.add(Math.log(h[i] / l[i]) ** 2);
  return Math.sqrt((s.value / (b - a)) / (4 * LN2) * ppy);
}

export function garmanKlass(o, h, l, c, n, ppy = 252) {
  const [a, b] = win(h.length, n), s = new Neumaier();
  for (let i = a; i < b; i++) s.add(0.5 * Math.log(h[i] / l[i]) ** 2 - (2 * LN2 - 1) * Math.log(c[i] / o[i]) ** 2);
  return Math.sqrt(Math.max(0, s.value / (b - a)) * ppy);
}

export function rogersSatchell(o, h, l, c, n, ppy = 252) {
  const [a, b] = win(h.length, n), s = new Neumaier();
  for (let i = a; i < b; i++) s.add(Math.log(h[i] / c[i]) * Math.log(h[i] / o[i]) + Math.log(l[i] / c[i]) * Math.log(l[i] / o[i]));
  return Math.sqrt(Math.max(0, s.value / (b - a)) * ppy);
}

export function yangZhang(o, h, l, c, n, ppy = 252) {
  const N = c.length, a = Math.max(1, N - n), m = N - a;
  if (m < 3) return NaN;
  const on = new Float64Array(m), oc = new Float64Array(m), rs = new Neumaier();
  for (let i = a; i < N; i++) {
    on[i - a] = Math.log(o[i] / c[i - 1]);
    oc[i - a] = Math.log(c[i] / o[i]);
    rs.add(Math.log(h[i] / c[i]) * Math.log(h[i] / o[i]) + Math.log(l[i] / c[i]) * Math.log(l[i] / o[i]));
  }
  const k = 0.34 / (1.34 + (m + 1) / (m - 1));
  const vo = meanVar(on).variance, vc = meanVar(oc).variance, vrs = rs.value / m;
  return Math.sqrt(Math.max(0, vo + k * vc + (1 - k) * vrs) * ppy);
}

/** Volatilité close-to-close glissante (annualisée). */
export function rollingVol(c, n, ppy = 252) {
  const r = logReturns(c), N = c.length, out = nanArray(N);
  let s = 0, s2 = 0, k = 0;
  for (let i = 1; i < N; i++) {
    const x = r[i];
    s += x;
    s2 += x * x;
    k++;
    if (k > n) {
      const y = r[i - n];
      s -= y;
      s2 -= y * y;
      k--;
    }
    if (k === n) {
      const m = s / n;
      out[i] = Math.sqrt(Math.max(0, (s2 - n * m * m) / (n - 1)) * ppy);
    }
  }
  return out;
}

/** Rang centile (0…1) d'une valeur dans une série (valeurs finies). */
export function percentileRank(series, v) {
  let below = 0, n = 0;
  for (const x of series) {
    if (!isNum(x)) continue;
    n++;
    if (x < v) below++;
    else if (x === v) below += 0.5;
  }
  return n ? below / n : NaN;
}

// ---------------------------------------------------------------- optimisation

/** Nelder-Mead (simplexe), minimisation sans dérivées. */
export function nelderMead(f, x0, { step = 0.5, maxIter = 600, tol = 1e-10 } = {}) {
  const n = x0.length;
  let simplex = [x0.slice()];
  for (let i = 0; i < n; i++) {
    const p = x0.slice();
    p[i] += step;
    simplex.push(p);
  }
  let vals = simplex.map(f);
  for (let it = 0; it < maxIter; it++) {
    const idx = vals.map((v, i) => i).sort((a, b) => vals[a] - vals[b]);
    simplex = idx.map((i) => simplex[i]);
    vals = idx.map((i) => vals[i]);
    if (Math.abs(vals[n] - vals[0]) < tol * (Math.abs(vals[0]) + tol)) break;
    const c = new Array(n).fill(0);
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) c[j] += simplex[i][j] / n;
    const move = (t) => c.map((cj, j) => cj + t * (simplex[n][j] - cj));
    const xr = move(-1), fr = f(xr);
    if (fr < vals[0]) {
      const xe = move(-2), fe = f(xe);
      if (fe < fr) { simplex[n] = xe; vals[n] = fe; } else { simplex[n] = xr; vals[n] = fr; }
    } else if (fr < vals[n - 1]) {
      simplex[n] = xr;
      vals[n] = fr;
    } else {
      const xc = fr < vals[n] ? move(-0.5) : move(0.5), fc = f(xc);
      if (fc < Math.min(fr, vals[n])) {
        simplex[n] = xc;
        vals[n] = fc;
      } else {
        for (let i = 1; i <= n; i++) {
          simplex[i] = simplex[i].map((v, j) => simplex[0][j] + 0.5 * (v - simplex[0][j]));
          vals[i] = f(simplex[i]);
        }
      }
    }
  }
  const best = vals.indexOf(Math.min(...vals));
  return { x: simplex[best], f: vals[best] };
}

const sigm = (u) => 1 / (1 + Math.exp(-u));

/**
 * GARCH(1,1) gaussien par maximum de vraisemblance, avec ciblage de variance (ω = s²·(1 − α − β)).
 * @param {ArrayLike<number>} r rendements (les NaN sont ignorés)
 * @returns {{ omega, alpha, beta, persistence, uncondVar, lastVar, nextVar, halfLife, ll, n, forecast:(h:number)=>Float64Array }}
 */
export function garch11(r) {
  const x = [];
  for (const v of r) if (isNum(v)) x.push(v);
  const n = x.length;
  if (n < 30) return null;
  const mv = meanVar(x, { sample: false }), mu = mv.mean, s2 = mv.variance;
  const e2 = x.map((v) => (v - mu) ** 2);
  const unpack = ([p, q]) => {
    const phi = 0.9999 * sigm(p), alpha = phi * sigm(q);
    return { alpha, beta: phi - alpha, omega: s2 * (1 - phi) };
  };
  const negLL = (th) => {
    const { alpha, beta, omega } = unpack(th);
    let h = s2, ll = 0;
    for (let t = 0; t < n; t++) {
      ll += Math.log(h) + e2[t] / h;
      h = omega + alpha * e2[t] + beta * h;
    }
    return 0.5 * (ll + n * Math.log(2 * Math.PI));
  };
  // départ classique (α ≈ 0,08, β ≈ 0,90) + second départ pour éviter un minimum local
  const starts = [[Math.log(0.98 / 0.0199), Math.log(0.0816 / 0.9184)], [Math.log(0.9 / 0.1), Math.log(0.15 / 0.85)]];
  let best = null;
  for (const s of starts) {
    const res = nelderMead(negLL, s, { step: 0.6 });
    if (!best || res.f < best.f) best = res;
  }
  const { alpha, beta, omega } = unpack(best.x);
  let h = s2;
  for (let t = 0; t < n; t++) h = omega + alpha * e2[t] + beta * h;
  // h : variance conditionnelle de la PROCHAINE période
  const persistence = alpha + beta;
  const forecast = (H) => {
    const out = new Float64Array(H);
    for (let k = 0; k < H; k++) out[k] = s2 + persistence ** k * (h - s2);
    return out;
  };
  return {
    omega, alpha, beta, persistence, mu, uncondVar: s2, nextVar: h, ll: -best.f, n,
    halfLife: persistence < 1 ? Math.log(0.5) / Math.log(persistence) : Infinity, forecast,
  };
}

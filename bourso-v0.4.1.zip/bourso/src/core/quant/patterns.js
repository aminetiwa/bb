// ============================================================================
//  BOURSO :: quant/patterns.js — figures : chandeliers japonais, supports/résistances,
//  doubles sommets/creux, figures harmoniques (XABCD) détectées automatiquement.
//
//  Les seuils sont exprimés en fractions de l'amplitude de la bougie ou de l'ATR : la détection
//  ne dépend ni du prix ni de l'unité de temps.
// ============================================================================
import { isNum } from './numeric.js';

/**
 * Figures de chandeliers sur la bougie `i` (et ses voisines).
 * @param {number} trend tendance préalable (+1 hausse, −1 baisse, 0 indéterminée)
 * @returns {{ name:string, bias:1|-1|0, strength:1|2|3, text:string }[]}
 */
export function candlePatterns(o, h, l, c, i, trend = 0, atrV = NaN) {
  const out = [];
  if (i < 2) return out;
  const body = (k) => Math.abs(c[k] - o[k]), range = (k) => Math.max(1e-12, h[k] - l[k]);
  const up = (k) => c[k] > o[k], down = (k) => c[k] < o[k];
  const upper = (k) => h[k] - Math.max(o[k], c[k]), lower = (k) => Math.min(o[k], c[k]) - l[k];
  const big = (k) => (isNum(atrV) ? body(k) > 0.6 * atrV : body(k) > 0.6 * range(k));
  const add = (name, bias, strength, text) => out.push({ name, bias, strength, text });
  const b = body(i), r = range(i);

  if (b <= 0.08 * r) {
    if (lower(i) > 0.6 * r) add('Doji libellule', trend < 0 ? 1 : 0, 1, 'indécision, rejet des prix bas');
    else if (upper(i) > 0.6 * r) add('Doji pierre tombale', trend > 0 ? -1 : 0, 1, 'indécision, rejet des prix hauts');
    else add('Doji', 0, 1, 'indécision : acheteurs et vendeurs à égalité');
  }
  if (b > 0.08 * r && lower(i) >= 2 * b && upper(i) <= 0.35 * b + 0.05 * r) {
    if (trend < 0) add('Marteau', 1, 2, 'rejet des plus bas après une baisse : retournement haussier possible');
    else if (trend > 0) add('Pendu', -1, 1, 'mèche basse longue après une hausse : prudence');
  }
  if (b > 0.08 * r && upper(i) >= 2 * b && lower(i) <= 0.35 * b + 0.05 * r) {
    if (trend > 0) add('Étoile filante', -1, 2, 'rejet des plus hauts après une hausse : retournement baissier possible');
    else if (trend < 0) add('Marteau inversé', 1, 1, 'tentative de rebond après une baisse');
  }
  if (b >= 0.9 * r && big(i)) add(up(i) ? 'Marubozu haussier' : 'Marubozu baissier', up(i) ? 1 : -1, 2, 'bougie pleine sans mèche : forte conviction');
  // deux bougies
  const p = i - 1;
  if (down(p) && up(i) && o[i] <= c[p] && c[i] >= o[p] && b > body(p)) add('Avalement haussier', 1, trend < 0 ? 3 : 2, 'la bougie haussière englobe la précédente');
  if (up(p) && down(i) && o[i] >= c[p] && c[i] <= o[p] && b > body(p)) add('Avalement baissier', -1, trend > 0 ? 3 : 2, 'la bougie baissière englobe la précédente');
  if (big(p) && b < 0.5 * body(p) && Math.max(o[i], c[i]) <= Math.max(o[p], c[p]) && Math.min(o[i], c[i]) >= Math.min(o[p], c[p])) {
    add(up(p) ? 'Harami baissier' : 'Harami haussier', up(p) ? -1 : 1, 1, 'petite bougie contenue dans la précédente : essoufflement');
  }
  if (down(p) && up(i) && o[i] < l[p] && c[i] > (o[p] + c[p]) / 2 && c[i] < o[p]) add('Pénétrante', 1, 2, 'rebond qui efface plus de la moitié de la baisse');
  if (up(p) && down(i) && o[i] > h[p] && c[i] < (o[p] + c[p]) / 2 && c[i] > o[p]) add('Couverture en nuage noir', -1, 2, 'repli qui efface plus de la moitié de la hausse');
  if (h[i] < h[p] && l[i] > l[p]) add('Inside bar', 0, 1, 'compression : cassure à surveiller');
  if (h[i] > h[p] && l[i] < l[p] && big(i)) add('Outside bar', up(i) ? 1 : -1, 1, 'expansion de volatilité');
  // trois bougies
  const q = i - 2;
  if (down(q) && big(q) && body(p) < 0.4 * body(q) && up(i) && c[i] > (o[q] + c[q]) / 2) add('Étoile du matin', 1, 3, 'retournement haussier en trois temps');
  if (up(q) && big(q) && body(p) < 0.4 * body(q) && down(i) && c[i] < (o[q] + c[q]) / 2) add('Étoile du soir', -1, 3, 'retournement baissier en trois temps');
  if (up(q) && up(p) && up(i) && c[p] > c[q] && c[i] > c[p] && big(p) && big(i) && upper(i) < 0.3 * b) add('Trois soldats blancs', 1, 3, 'trois hausses franches consécutives');
  if (down(q) && down(p) && down(i) && c[p] < c[q] && c[i] < c[p] && big(p) && big(i) && lower(i) < 0.3 * b) add('Trois corbeaux noirs', -1, 3, 'trois baisses franches consécutives');
  return out;
}

/** Regroupe des niveaux de prix proches (tolérance absolue) en zones pondérées. */
function cluster(levels, tol) {
  const s = [...levels].sort((a, b) => a.price - b.price), zones = [];
  for (const lv of s) {
    const z = zones.at(-1);
    // fusion seulement si le niveau est proche ET si la zone reste étroite (pas d'effet de chaîne)
    if (z && lv.price - z.hi <= tol && lv.price - z.lo <= 2 * tol) {
      z.items.push(lv);
      z.hi = lv.price;
      z.weight += lv.weight;
    } else zones.push({ lo: lv.price, hi: lv.price, weight: lv.weight, items: [lv] });
  }
  return zones.map((z) => {
    let w = 0, pw = 0;
    for (const it of z.items) { w += it.weight; pw += it.price * it.weight; }
    const kinds = [...new Set(z.items.map((it) => it.kind))];
    return { price: pw / w, lo: z.lo, hi: z.hi, strength: z.weight, touches: z.items.length, kinds };
  });
}

/**
 * Supports et résistances : sommets/creux (ZigZag), nœuds de volume, pivots, nombres ronds.
 * @param {{ price:number, atr:number, swings:{price:number, type:number, i:number}[], volumeNodes?:number[],
 *           pivots?:Record<string, number>, extraLevels?:{price:number, kind:string, weight:number}[] }} p
 */
export function supportResistance({ price, atr, swings = [], volumeNodes = [], pivots = {}, extraLevels = [] }) {
  const lv = [];
  const nSw = swings.length;
  swings.forEach((s, k) => lv.push({ price: s.price, kind: s.type > 0 ? 'sommet' : 'creux', weight: 1 + (k / Math.max(1, nSw)) }));
  for (const v of volumeNodes) lv.push({ price: v, kind: 'volume', weight: 1.5 });
  for (const [name, v] of Object.entries(pivots)) if (isNum(v)) lv.push({ price: v, kind: `pivot ${name}`, weight: name === 'P' ? 1 : 0.7 });
  for (const e of extraLevels) lv.push(e);
  // nombres ronds : multiples de 10^k proches du prix
  const mag = 10 ** Math.floor(Math.log10(price)) / (price / 10 ** Math.floor(Math.log10(price)) < 3 ? 10 : 2);
  for (let k = -3; k <= 3; k++) lv.push({ price: (Math.round(price / mag) + k) * mag, kind: 'chiffre rond', weight: 0.4 });
  const zones = cluster(lv.filter((x) => isNum(x.price) && x.price > 0), Math.max(atr * 0.25, price * 0.001));
  const supports = zones.filter((z) => z.price < price).sort((a, b) => b.price - a.price);
  const resistances = zones.filter((z) => z.price > price).sort((a, b) => a.price - b.price);
  return {
    supports: supports.slice(0, 6), resistances: resistances.slice(0, 6),
    nearestSupport: supports[0] ?? null, nearestResistance: resistances[0] ?? null,
  };
}

/** Double sommet / double creux sur les derniers swings. */
export function doubleTopBottom(swings, tolPct = 0.012) {
  const out = [];
  if (swings.length < 3) return out;
  const [a, b, c2] = swings.slice(-3);
  if (a.type === 1 && b.type === -1 && c2.type === 1 && Math.abs(a.price - c2.price) / a.price <= tolPct) {
    out.push({ name: 'Double sommet', bias: -1, neckline: b.price, text: `deux sommets à ${a.price.toFixed(2)} / ${c2.price.toFixed(2)}, ligne de cou ${b.price.toFixed(2)}` });
  }
  if (a.type === -1 && b.type === 1 && c2.type === -1 && Math.abs(a.price - c2.price) / a.price <= tolPct) {
    out.push({ name: 'Double creux', bias: 1, neckline: b.price, text: `deux creux à ${a.price.toFixed(2)} / ${c2.price.toFixed(2)}, ligne de cou ${b.price.toFixed(2)}` });
  }
  return out;
}

/** Règles des figures harmoniques (ratios de Fibonacci de Carney et al.). */
export const HARMONICS = [
  { name: 'Gartley', ab: [0.618, 0.618], bc: [0.382, 0.886], cd: [1.13, 1.618], ad: [0.786, 0.786] },
  { name: 'Chauve-souris (Bat)', ab: [0.382, 0.5], bc: [0.382, 0.886], cd: [1.618, 2.618], ad: [0.886, 0.886] },
  { name: 'Papillon (Butterfly)', ab: [0.786, 0.786], bc: [0.382, 0.886], cd: [1.618, 2.24], ad: [1.27, 1.618] },
  { name: 'Crabe (Crab)', ab: [0.382, 0.618], bc: [0.382, 0.886], cd: [2.24, 3.618], ad: [1.618, 1.618] },
  { name: 'Requin (Shark)', ab: [0.446, 0.618], bc: [1.13, 1.618], cd: [1.618, 2.24], ad: [0.886, 1.13] },
];

/**
 * Figures harmoniques sur les 5 derniers points (X, A, B, C, D), D pouvant être le point provisoire.
 * Tolérance relative sur chaque ratio. Renvoie la meilleure figure (erreur moyenne la plus faible).
 */
export function detectHarmonics(points, tol = 0.06) {
  if (points.length < 5) return null;
  const [X, A, B, C, D] = points.slice(-5);
  const XA = Math.abs(A.price - X.price), AB = Math.abs(B.price - A.price), BC = Math.abs(C.price - B.price), CD = Math.abs(D.price - C.price);
  if (!XA || !AB || !BC) return null;
  const r = { ab: AB / XA, bc: BC / AB, cd: CD / BC, ad: Math.abs(D.price - A.price) / XA };
  const err = (v, [lo, hi]) => (v < lo * (1 - tol) ? (lo - v) / lo : v > hi * (1 + tol) ? (v - hi) / hi : 0);
  let best = null;
  for (const pat of HARMONICS) {
    const e = [err(r.ab, pat.ab), err(r.bc, pat.bc), err(r.cd, pat.cd), err(r.ad, pat.ad)];
    if (e.some((x) => x > tol)) continue;
    const score = e.reduce((a, b) => a + b, 0) / 4;
    if (!best || score < best.error) {
      const bullish = D.type === -1; // D creux → figure haussière (achat dans la zone D)
      best = { name: pat.name, bias: bullish ? 1 : -1, error: score, ratios: r, points: [X, A, B, C, D],
        prz: { lo: Math.min(D.price, A.price - (A.price - X.price) * pat.ad[1]), hi: Math.max(D.price, A.price - (A.price - X.price) * pat.ad[0]) } };
    }
  }
  return best;
}

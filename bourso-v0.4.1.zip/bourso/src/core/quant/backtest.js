// ============================================================================
//  BOURSO :: quant/backtest.js — tests de stratégies SANS biais d'anticipation.
//
//  Règle d'or : la position décidée à la CLÔTURE de la bougie t n'est prise qu'à l'OUVERTURE de
//  t+1 (le gap de nuit revient à la position précédente). Frais : `costBps` par côté sur la
//  fraction échangée. Rendements logarithmiques additifs ; P&L par transaction.
//  Validation « walk-forward » : on optimise sur le passé, on mesure sur la période SUIVANTE,
//  jamais vue ; seul ce résultat hors échantillon dit si une stratégie est robuste.
//  Les mêmes règles sont réimplémentées en C++ (native/) et en WGSL (GPU) et vérifiées contre ce
//  module de référence.
// ============================================================================
import { isNum, meanVar } from './numeric.js';
import * as I from './indicators.js';

/** Stratégies paramétrées. `positions(d, p, short)` → Int8Array (cible décidée à la clôture). */
export const STRATEGIES = {
  ema_cross: {
    name: 'Croisement de moyennes exponentielles', short: 'Croisement EMA',
    explain: 'Acheteur quand la moyenne rapide passe au-dessus de la lente.',
    grid: { fast: [5, 8, 10, 12, 15, 20, 25, 30, 40, 50], slow: [20, 30, 40, 50, 60, 80, 100, 120, 150, 200] },
    valid: (p) => p.fast < p.slow,
    positions(d, p, short) {
      const f = I.ema(d.close, p.fast), s = I.ema(d.close, p.slow), N = d.close.length, pos = new Int8Array(N);
      for (let i = 0; i < N; i++) if (isNum(s[i])) pos[i] = f[i] > s[i] ? 1 : short ? -1 : 0;
      return pos;
    },
  },
  sma_cross: {
    name: 'Croisement de moyennes simples', short: 'Croisement SMA',
    explain: 'Version classique (ex. 50/200 « golden cross »).',
    grid: { fast: [5, 10, 20, 30, 50], slow: [50, 100, 150, 200] },
    valid: (p) => p.fast < p.slow,
    positions(d, p, short) {
      const f = I.sma(d.close, p.fast), s = I.sma(d.close, p.slow), N = d.close.length, pos = new Int8Array(N);
      for (let i = 0; i < N; i++) if (isNum(s[i])) pos[i] = f[i] > s[i] ? 1 : short ? -1 : 0;
      return pos;
    },
  },
  rsi_revert: {
    name: 'Retour à la moyenne RSI', short: 'RSI',
    explain: 'Achète un RSI survendu, revend quand il revient au-dessus du seuil de sortie.',
    grid: { n: [2, 3, 5, 7, 10, 14], lo: [10, 15, 20, 25, 30, 35], exit: [50, 55, 60, 65, 70] },
    valid: (p) => p.lo < p.exit,
    positions(d, p, short) {
      const r = I.rsi(d.close, p.n), N = d.close.length, pos = new Int8Array(N);
      let cur = 0;
      for (let i = 0; i < N; i++) {
        if (!isNum(r[i])) continue;
        if (cur === 0) cur = r[i] < p.lo ? 1 : short && r[i] > 100 - p.lo ? -1 : 0;
        else if (cur === 1 && r[i] > p.exit) cur = 0;
        else if (cur === -1 && r[i] < 100 - p.exit) cur = 0;
        pos[i] = cur;
      }
      return pos;
    },
  },
  boll_revert: {
    name: 'Retour dans les bandes de Bollinger', short: 'Bollinger',
    explain: 'Achète sous la bande basse, sort sur la moyenne.',
    grid: { n: [10, 15, 20, 30, 40], k: [1.5, 2, 2.5, 3] },
    positions(d, p, short) {
      const b = I.bollinger(d.close, p.n, p.k), c = d.close, N = c.length, pos = new Int8Array(N);
      let cur = 0;
      for (let i = 0; i < N; i++) {
        if (!isNum(b.mid[i])) continue;
        if (cur === 0) cur = c[i] < b.lo[i] ? 1 : short && c[i] > b.up[i] ? -1 : 0;
        else if (cur === 1 && c[i] > b.mid[i]) cur = 0;
        else if (cur === -1 && c[i] < b.mid[i]) cur = 0;
        pos[i] = cur;
      }
      return pos;
    },
  },
  donchian_break: {
    name: 'Cassure de canal (Donchian)', short: 'Donchian',
    explain: 'Achète la cassure du plus haut de n bougies, sort sous le plus bas de n/2 (« tortues »).',
    grid: { n: [10, 20, 30, 40, 55, 80, 100] },
    positions(d, p, short) {
      const c = d.close, N = c.length, hi = I.rollingMax(d.high, p.n), lo = I.rollingMin(d.low, Math.max(2, Math.round(p.n / 2)));
      const hiL = I.rollingMax(d.high, Math.max(2, Math.round(p.n / 2))), loL = I.rollingMin(d.low, p.n);
      const pos = new Int8Array(N);
      let cur = 0;
      for (let i = 1; i < N; i++) {
        if (!isNum(hi[i - 1]) || !isNum(loL[i - 1])) continue;
        if (cur <= 0 && c[i] > hi[i - 1]) cur = 1;
        else if (cur >= 0 && short && c[i] < loL[i - 1]) cur = -1;
        else if (cur === 1 && c[i] < lo[i - 1]) cur = 0;
        else if (cur === -1 && c[i] > hiL[i - 1]) cur = 0;
        pos[i] = cur;
      }
      return pos;
    },
  },
  macd_cross: {
    name: 'Croisement MACD / signal', short: 'MACD',
    explain: 'Acheteur quand le MACD est au-dessus de sa ligne de signal.',
    grid: { fast: [8, 12, 16], slow: [21, 26, 34], signal: [5, 9, 12] },
    valid: (p) => p.fast < p.slow,
    positions(d, p, short) {
      const m = I.macd(d.close, p.fast, p.slow, p.signal), N = d.close.length, pos = new Int8Array(N);
      for (let i = 0; i < N; i++) if (isNum(m.signal[i])) pos[i] = m.line[i] > m.signal[i] ? 1 : short ? -1 : 0;
      return pos;
    },
  },
  supertrend: {
    name: 'SuperTrend', short: 'SuperTrend',
    explain: 'Suit la tendance tant que le prix reste du bon côté de la ligne ATR.',
    grid: { n: [7, 10, 14, 20], factor: [1.5, 2, 2.5, 3, 4] },
    positions(d, p, short) {
      const st = I.supertrend(d.high, d.low, d.close, p.n, p.factor), N = d.close.length, pos = new Int8Array(N);
      for (let i = 0; i < N; i++) if (isNum(st.line[i])) pos[i] = st.dir[i] > 0 ? 1 : short ? -1 : 0;
      return pos;
    },
  },
  buy_hold: {
    name: 'Achat-conservation (référence)', short: 'Achat-conservation',
    explain: 'Toujours investi : la référence à battre.',
    grid: {},
    positions(d) {
      return new Int8Array(d.close.length).fill(1);
    },
  },
};

/** Toutes les combinaisons de paramètres valides d'une stratégie. */
export function paramGrid(strategy) {
  const keys = Object.keys(strategy.grid);
  let combos = [{}];
  for (const k of keys) combos = combos.flatMap((c) => strategy.grid[k].map((v) => ({ ...c, [k]: v })));
  return combos.filter((p) => !strategy.valid || strategy.valid(p));
}

/**
 * Rendements par bougie d'une suite de positions (exécution à l'ouverture suivante).
 * @returns {{ ret:Float64Array, trades:{entry:number, exit:number, dir:number, ret:number}[] }}
 */
export function simulate(d, pos, { costBps = 5, from = 1, to = d.close.length } = {}) {
  const { open: o, close: c } = d, cost = costBps / 1e4, N = c.length, ret = new Float64Array(N), trades = [];
  let cur = 0, open = null;
  for (let t = Math.max(1, from); t < to; t++) {
    const target = pos[t - 1];
    let r;
    if (target !== cur) {
      // gap de nuit avec l'ancienne position, puis la séance avec la nouvelle ; frais sur la variation
      r = cur * Math.log(o[t] / c[t - 1]) + target * Math.log(c[t] / o[t]) - cost * Math.abs(target - cur);
      if (open && cur !== 0) {
        open.ret += cur * Math.log(o[t] / c[t - 1]) - cost * Math.abs(cur);
        open.exit = t;
        trades.push(open);
        open = null;
      }
      if (target !== 0) open = { entry: t, exit: -1, dir: target, ret: target * Math.log(c[t] / o[t]) - cost * Math.abs(target) };
      cur = target;
    } else {
      r = cur * Math.log(c[t] / c[t - 1]);
      if (open) open.ret += r;
    }
    ret[t] = r;
  }
  if (open) {
    open.exit = to - 1;
    open.open = true;
    trades.push(open);
  }
  return { ret, trades };
}

/** Statistiques de performance (rendements log par bougie sur [from, to[). */
export function metrics(ret, trades, { barsPerYear = 252, from = 1, to = ret.length, pos = null } = {}) {
  const n = Math.max(1, to - from);
  let sum = 0, peak = 0, eq = 0, maxDD = 0, exposure = 0, downs = 0;
  for (let t = from; t < to; t++) {
    sum += ret[t];
    eq += ret[t];
    if (eq > peak) peak = eq;
    if (eq - peak < maxDD) maxDD = eq - peak;
    if (ret[t] < 0) downs += ret[t] * ret[t];
    if (pos && pos[t - 1] !== 0) exposure++;
  }
  const mv = meanVar(ret, { from, to });
  const annRet = Math.exp((sum / n) * barsPerYear) - 1, annVol = mv.sd * Math.sqrt(barsPerYear);
  const dsd = Math.sqrt(downs / n) * Math.sqrt(barsPerYear);
  const tr = trades.filter((x) => x.entry >= from && x.entry < to);
  const wins = tr.filter((x) => x.ret > 0), losses = tr.filter((x) => x.ret <= 0);
  const gw = wins.reduce((a, x) => a + x.ret, 0), gl = -losses.reduce((a, x) => a + x.ret, 0);
  const mdd = Math.exp(maxDD) - 1;
  return {
    totalReturn: Math.exp(sum) - 1, annReturn: annRet, annVol, sharpe: mv.sd > 0 ? (mv.mean / mv.sd) * Math.sqrt(barsPerYear) : 0,
    sortino: dsd > 0 ? ((sum / n) * barsPerYear) / dsd : 0, maxDD: mdd, calmar: mdd < 0 ? annRet / -mdd : 0,
    trades: tr.length, winRate: tr.length ? wins.length / tr.length : 0, profitFactor: gl > 0 ? gw / gl : gw > 0 ? Infinity : 0,
    avgTrade: tr.length ? Math.exp(tr.reduce((a, x) => a + x.ret, 0) / tr.length) - 1 : 0,
    exposure: pos ? exposure / n : NaN, bars: n,
  };
}

/** Backtest complet d'une stratégie pour un jeu de paramètres. */
export function backtest(d, strategyId, params, { costBps = 5, short = false, barsPerYear = 252, from = 1, to = d.close.length } = {}) {
  const st = STRATEGIES[strategyId], pos = st.positions(d, params, short);
  const { ret, trades } = simulate(d, pos, { costBps, from, to });
  return { params, pos, ret, trades, metrics: metrics(ret, trades, { barsPerYear, from, to, pos }) };
}

/**
 * Validation walk-forward ancrée : `folds` périodes de test successives ; pour chacune, les
 * paramètres sont choisis (meilleur Sharpe, au moins `minTrades` transactions) sur TOUT ce qui
 * précède, puis appliqués sur la période de test jamais vue.
 */
export function walkForward(d, strategyId, { folds = 4, costBps = 5, short = false, barsPerYear = 252, minTrades = 3, warmup = 210 } = {}) {
  const st = STRATEGIES[strategyId], grid = paramGrid(st), N = d.close.length;
  const start = Math.min(warmup, Math.floor(N / 3)), seg = Math.floor((N - start) / (folds + 1));
  if (seg < 20) return null;
  // positions de chaque jeu de paramètres calculées une seule fois sur toute la série (causales)
  const all = grid.map((p) => ({ p, pos: st.positions(d, p, short) }));
  const oosRet = new Float64Array(N), oosTrades = [], chosen = [];
  let isSharpeSum = 0;
  for (let f = 1; f <= folds; f++) {
    const trainTo = start + seg * f, testTo = f === folds ? N : trainTo + seg;
    let best = null;
    for (const g of all) {
      const sim = simulate(d, g.pos, { costBps, from: start, to: trainTo });
      const m = metrics(sim.ret, sim.trades, { barsPerYear, from: start, to: trainTo });
      if (m.trades < minTrades && strategyId !== 'buy_hold') continue;
      if (!best || m.sharpe > best.m.sharpe) best = { g, m };
    }
    if (!best) continue;
    isSharpeSum += best.m.sharpe;
    const sim = simulate(d, best.g.pos, { costBps, from: trainTo, to: testTo });
    for (let t = trainTo; t < testTo; t++) oosRet[t] = sim.ret[t];
    oosTrades.push(...sim.trades);
    chosen.push({ fold: f, from: trainTo, to: testTo, params: best.g.p, isSharpe: best.m.sharpe });
  }
  const from = start + seg;
  const oos = metrics(oosRet, oosTrades, { barsPerYear, from, to: N });
  const isAvg = chosen.length ? isSharpeSum / chosen.length : NaN;
  const stable = chosen.length > 1 && chosen.every((c) => JSON.stringify(c.params) === JSON.stringify(chosen[0].params));
  return {
    strategy: strategyId, name: st.name, oos, isSharpe: isAvg, robustness: isAvg > 0 ? oos.sharpe / isAvg : NaN,
    chosen, stableParams: stable, combos: grid.length, equity: cumulative(oosRet, from), from,
  };
}

/** Courbe de capital (base 1) à partir de rendements log. */
export function cumulative(ret, from = 0) {
  const out = new Float64Array(ret.length);
  let s = 0;
  for (let t = 0; t < ret.length; t++) {
    if (t >= from) s += ret[t];
    out[t] = Math.exp(s);
  }
  return out;
}

/** Signal ACTUEL de chaque stratégie avec ses paramètres par défaut (pour le dossier IA). */
export function currentSignals(d, { short = false } = {}) {
  const defaults = { ema_cross: { fast: 20, slow: 50 }, sma_cross: { fast: 50, slow: 200 }, rsi_revert: { n: 14, lo: 30, exit: 55 },
    boll_revert: { n: 20, k: 2 }, donchian_break: { n: 20 }, macd_cross: { fast: 12, slow: 26, signal: 9 }, supertrend: { n: 10, factor: 3 } };
  return Object.entries(defaults).map(([id, p]) => {
    const pos = STRATEGIES[id].positions(d, p, short);
    return { id, name: STRATEGIES[id].name, params: p, position: pos[pos.length - 1] };
  });
}

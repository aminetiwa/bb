// ============================================================================
//  BOURSO :: soa-ring.js — anneau SPSC lock-free sur SharedArrayBuffer (layout SoA)
//
//  1 producteur → 1 consommateur, zéro copie entre Worker Threads :
//   - colonnes Float64Array contiguës (Structure of Arrays) → les lots se passent
//     tels quels aux noyaux C++ (`kf.run(ring.col.ts.subarray(s, s+n), …)`)
//   - indices HEAD/TAIL sur des lignes de cache distinctes (pas de false sharing)
//   - publication par Atomics.store (release) / lecture par Atomics.load (acquire) :
//     garanti par le modèle mémoire JS, y compris sur ARM
//   - compteurs 32 bits « monotones » : (head - tail) >>> 0 gère le rebouclage 2^32
//
//  Octets 0..127 (Int32) : [0] HEAD  [1] DROPPED  | [16] TAIL  [17] WAITING
//  Puis une colonne Float64Array de `capacity` éléments par champ.
// ============================================================================

const HDR_BYTES = 128;
const HEAD = 0, DROPPED = 1, TAIL = 16, WAITING = 17;

export class SoARing {
  /** @param {number} capacity puissance de 2  @param {string[]} fields */
  static create(capacity, fields) {
    if (!Number.isInteger(capacity) || capacity < 2 || (capacity & (capacity - 1)) !== 0) {
      throw new RangeError('SoARing: capacity doit être une puissance de 2');
    }
    return new SoARing(new SharedArrayBuffer(HDR_BYTES + capacity * fields.length * 8), capacity, fields);
  }

  /** Reconstruit l'anneau dans un autre thread à partir de `ring.descriptor()`. */
  static from({ sab, capacity, fields }) {
    return new SoARing(sab, capacity, fields);
  }

  constructor(sab, capacity, fields) {
    this.sab = sab;
    this.capacity = capacity;
    this.mask = capacity - 1;
    this.fields = fields;
    this.hdr = new Int32Array(sab, 0, HDR_BYTES / 4);
    /** @type {Record<string, Float64Array>} colonnes partagées */
    this.col = {};
    fields.forEach((f, i) => {
      this.col[f] = new Float64Array(sab, HDR_BYTES + i * capacity * 8, capacity);
    });
    // caches locaux (chaque côté ne lit l'index de l'autre que si nécessaire)
    this._head = Atomics.load(this.hdr, HEAD);
    this._tail = Atomics.load(this.hdr, TAIL);
    this._tailCache = this._tail;
  }

  descriptor() {
    return { sab: this.sab, capacity: this.capacity, fields: this.fields };
  }

  // ------------------------------------------------------------- producteur
  /**
   * Réserve le prochain slot : renvoie son index physique, ou -1 si plein (compté dans `dropped`).
   * Écrire ensuite `ring.col.<champ>[i] = …` puis appeler `commit()`.
   */
  claim() {
    const head = this._head;
    if (((head - this._tailCache) >>> 0) >= this.capacity) {
      this._tailCache = Atomics.load(this.hdr, TAIL);
      if (((head - this._tailCache) >>> 0) >= this.capacity) {
        Atomics.add(this.hdr, DROPPED, 1);
        return -1;
      }
    }
    return head & this.mask;
  }

  /** Publie `n` slots réservés (1 par défaut). */
  commit(n = 1) {
    this._head = (this._head + n) | 0;
    Atomics.store(this.hdr, HEAD, this._head);
    if (Atomics.load(this.hdr, WAITING) !== 0) Atomics.notify(this.hdr, HEAD, 1);
  }

  /** Réservation contiguë (sans rebouclage) d'au plus `max` slots → { start, count }. */
  claimBatch(max) {
    this._tailCache = Atomics.load(this.hdr, TAIL);
    const free = this.capacity - ((this._head - this._tailCache) >>> 0);
    const start = this._head & this.mask;
    return { start, count: Math.min(max, free, this.capacity - start) };
  }

  // ----------------------------------------------------------- consommateur
  available() {
    return (Atomics.load(this.hdr, HEAD) - this._tail) >>> 0;
  }

  /**
   * Consomme jusqu'à `max` éléments. `fn(start, count)` est appelé 1 ou 2 fois (rebouclage) avec
   * des index physiques : les données sont lues directement dans `ring.col.*` (zéro copie).
   * @returns {number} éléments consommés
   */
  consume(max, fn) {
    let n = (Atomics.load(this.hdr, HEAD) - this._tail) >>> 0;
    if (n === 0) return 0;
    if (n > max) n = max;
    const start = this._tail & this.mask;
    const first = Math.min(n, this.capacity - start);
    fn(start, first);
    if (first < n) fn(0, n - first);
    this._tail = (this._tail + n) | 0;
    Atomics.store(this.hdr, TAIL, this._tail);
    return n;
  }

  /** Attente passive (futex) jusqu'à l'arrivée de données. Interdit sur le thread principal d'un navigateur. */
  wait(timeoutMs = 50) {
    Atomics.store(this.hdr, WAITING, 1);
    const head = Atomics.load(this.hdr, HEAD);
    const r = head === this._tail ? Atomics.wait(this.hdr, HEAD, head, timeoutMs) : 'not-equal';
    Atomics.store(this.hdr, WAITING, 0);
    return r;
  }

  get dropped() {
    return Atomics.load(this.hdr, DROPPED);
  }
}

// ============================================================================
//  ControlBlock — « sonnette » partagée : N producteurs / 1 consommateur multi-anneaux.
//  [0] BELL (compteur)  [1] STOP  | [16] SLEEPING
// ============================================================================
const BELL = 0, STOP = 1, SLEEPING = 16;

export class ControlBlock {
  static create() {
    return new ControlBlock(new SharedArrayBuffer(128));
  }
  constructor(sab) {
    this.sab = sab;
    this.i32 = new Int32Array(sab);
  }
  /** Producteur : signale de nouvelles données. Le notify (syscall) n'a lieu que si le consommateur dort. */
  ring() {
    Atomics.add(this.i32, BELL, 1);
    if (Atomics.load(this.i32, SLEEPING) !== 0) Atomics.notify(this.i32, BELL);
  }
  seq() {
    return Atomics.load(this.i32, BELL);
  }
  /** Consommateur : dort tant que BELL === seenSeq (aucun réveil perdu, cf. sémantique de Atomics.wait). */
  sleep(seenSeq, timeoutMs) {
    Atomics.store(this.i32, SLEEPING, 1);
    const r = Atomics.wait(this.i32, BELL, seenSeq, timeoutMs);
    Atomics.store(this.i32, SLEEPING, 0);
    return r;
  }
  stop() {
    Atomics.store(this.i32, STOP, 1);
    Atomics.add(this.i32, BELL, 1);
    Atomics.notify(this.i32, BELL);
  }
  get stopped() {
    return Atomics.load(this.i32, STOP) === 1;
  }
}

/** Champs d'un tick (rx = horloge monotone locale en ns, pour mesurer la latence interne). */
export const TICK_FIELDS = ['ts', 'rx', 'px', 'qty', 'side', 'bid', 'ask'];
/** Champs de sortie du worker maths. */
export const SIGNAL_FIELDS = ['ts', 'lane', 'px', 'level', 'slope', 'nis'];

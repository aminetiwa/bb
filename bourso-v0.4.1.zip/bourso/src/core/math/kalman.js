// ============================================================================
//  BOURSO :: kalman.js — miroir JS bit à bit de native/include/kalman.hpp
//  (même ordre des opérations flottantes ; l'addon est compilé avec
//   -ffp-contract=off → résultats identiques natif/JS, backtest = live).
//  Sans dépendance Node : tourne aussi dans le navigateur.
// ============================================================================

const TRADING_SECONDS_PER_YEAR = 252 * 8.5 * 3600; // Euronext/XETRA 09:00–17:30

export const KALMAN_DEFAULTS = Object.freeze({
  qLevel: 1e-4,   // [prix²/s]   diffusion du niveau
  qSlope: 1e-7,   // [prix²/s³]  diffusion de la pente
  r: 1e-4,        // [prix²]     bruit de microstructure initial
  rMin: 1e-12,    // [prix²]     plancher de R adaptatif
  adapt: 0.01,    // oubli exponentiel de R (0 = fixe)
  huberK: 3,      // robustesse (sigmas), <= 0 : désactivé
  maxDt: 30,      // [s] trou de cotation → pente remise à 0
  p0Level: 1e-2,
  p0Slope: 1e-4,
});

/** Paramètres dérivés du marché : prix, pas de cotation, volatilité annualisée, horizon de tendance. */
export function kalmanParamsFor({ price, tickSize, annualVol = 0.25, trendTauSec = 30 }) {
  const sigmaS = (price * annualVol) / Math.sqrt(TRADING_SECONDS_PER_YEAR);
  const tau = Math.max(trendTauSec, 1e-3);
  const qLevel = sigmaS * sigmaS;
  return {
    ...KALMAN_DEFAULTS,
    qLevel,
    qSlope: qLevel / (tau * tau),
    r: 0.25 * tickSize * tickSize,
    rMin: 1e-4 * tickSize * tickSize,
    p0Level: tickSize * tickSize,
    p0Slope: qLevel / tau,
  };
}

// Disposition de l'état (Float64Array → champs non « boxés » par V8, partageable en SAB)
const X0 = 0, X1 = 1, P00 = 2, P01 = 3, P11 = 4, R = 5, T = 6, INIT = 7, N = 8;

function stepCore(s, p, tUs, z, out) {
  if (!Number.isFinite(z) || !Number.isFinite(tUs)) {
    out[0] = s[X0]; out[1] = s[X1]; out[2] = 0; out[3] = 0; out[4] = 0;
    return;
  }
  s[N] += 1;
  if (s[INIT] === 0) {
    s[X0] = z; s[X1] = 0;
    s[P00] = s[R]; s[P01] = 0; s[P11] = p.p0Slope;
    s[T] = tUs; s[INIT] = 1;
    out[0] = z; out[1] = 0; out[2] = 0; out[3] = 0; out[4] = 1;
    return;
  }
  let dt = (tUs - s[T]) * 1e-6;
  if (tUs > s[T]) s[T] = tUs;
  if (!(dt > 0)) dt = 0;
  if (dt > p.maxDt) {
    s[P00] += p.qLevel * dt;
    s[X1] = 0; s[P01] = 0; s[P11] = p.p0Slope;
    dt = 0;
  }
  if (dt > 0) {
    const dt2 = dt * dt, dt3 = dt2 * dt;
    s[X0] += dt * s[X1];
    const a = s[P00], b = s[P01], c = s[P11];
    s[P00] = a + 2.0 * dt * b + dt2 * c + p.qLevel * dt + (p.qSlope * dt3) / 3.0;
    s[P01] = b + dt * c + 0.5 * p.qSlope * dt2;
    s[P11] = c + p.qSlope * dt;
  }
  const a = s[P00], b = s[P01], c = s[P11];
  const y = z - s[X0];
  let r = s[R];
  let S = a + r;
  const nis = (y * y) / S;
  let inlier = true;
  if (p.huberK > 0) {
    const m = Math.sqrt(nis);
    if (m > p.huberK) {
      const sEff = S * (m / p.huberK);
      r = sEff - a;
      S = sEff;
      inlier = false;
    }
  }
  const k0 = a / S, k1 = b / S;
  s[X0] += k0 * y;
  s[X1] += k1 * y;
  const g = 1.0 - k0;
  s[P00] = g * g * a + r * k0 * k0;
  s[P01] = g * (b - k1 * a) + r * k0 * k1;
  s[P11] = c - 2.0 * k1 * b + k1 * k1 * a + r * k1 * k1;
  if (inlier && p.adapt > 0) {
    const rHat = Math.max(y * y - a, p.rMin);
    s[R] = (1.0 - p.adapt) * s[R] + p.adapt * rHat;
  }
  out[0] = s[X0]; out[1] = s[X1]; out[2] = y; out[3] = nis; out[4] = k0;
}

/** Même API que l'addon natif `KalmanFilter`. */
export class KalmanFilterJS {
  constructor(params = {}) {
    const p = { ...KALMAN_DEFAULTS };
    for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null) p[k] = v;
    this.p = p;
    this.s = new Float64Array(9);
    this._o = new Float64Array(5);
    this.reset();
  }

  reset() {
    const s = this.s;
    s.fill(0);
    s[P00] = this.p.p0Level;
    s[P11] = this.p.p0Slope;
    s[R] = this.p.r;
  }

  /** @returns {number} niveau filtré */
  step(tUs, price) {
    stepCore(this.s, this.p, tUs, price, this._o);
    return this._o[0];
  }

  /** out[0..4] = [niveau, pente (prix/s), innovation, NIS, gain] */
  stepInto(tUs, price, out) {
    stepCore(this.s, this.p, tUs, price, out);
  }

  /** Lot : Float64Array en entrée (vues SAB acceptées), sorties optionnelles. → n */
  run(tUs, price, outLevel, outSlope, outNis) {
    const n = Math.min(tUs.length, price.length);
    for (const o of [outLevel, outSlope, outNis]) {
      if (o && o.length < n) throw new RangeError('bourso-js: tableau de sortie trop court');
    }
    const s = this.s, p = this.p, o = this._o;
    for (let i = 0; i < n; i++) {
      stepCore(s, p, tUs[i], price[i], o);
      if (outLevel) outLevel[i] = o[0];
      if (outSlope) outSlope[i] = o[1];
      if (outNis) outNis[i] = o[3];
    }
    return n;
  }

  state() {
    const s = this.s;
    return {
      level: s[X0], slope: s[X1], varLevel: s[P00], varSlope: s[P11], cov: s[P01],
      r: s[R], lastTUs: s[T], count: s[N], initialized: s[INIT] === 1,
    };
  }
}

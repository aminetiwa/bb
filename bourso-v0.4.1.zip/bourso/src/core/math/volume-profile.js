// ============================================================================
//  BOURSO :: volume-profile.js — miroir JS de native/include/volume_profile.hpp
//  + détection des nœuds HVN/LVN (commune aux deux backends).
//  Sans dépendance Node : tourne aussi dans le navigateur (profil « plage visible »).
// ============================================================================

/** Arrondi « half away from zero » (= std::llround / std::round). */
const roundHA = (x) => (x < 0 ? -Math.round(-x) : Math.round(x));

function decimalsOf(tick) {
  for (let d = 0; d <= 10; d++) {
    const s = tick * 10 ** d;
    if (Math.abs(s - roundHA(s)) < 1e-9 * Math.max(1, s)) return d;
  }
  return 10;
}

const INIT_CAP = 256;

/** Même API que l'addon natif `VolumeProfile`. */
export class VolumeProfileJS {
  constructor({ tickSize, ticksPerRow = 1, valueAreaPct = 0.7, vaStep = 2 } = {}) {
    if (!(tickSize > 0)) throw new RangeError('bourso-js: tickSize doit être > 0');
    this.tick = tickSize;
    this.tpr = Math.max(1, Math.trunc(ticksPerRow));
    this.vaPct = Math.min(1, Math.max(0, valueAreaPct));
    this.vaStep = Math.max(1, Math.trunc(vaStep));
    this.dec = decimalsOf(tickSize);
    this.reset();
  }

  reset() {
    this.cap = 0;
    this.total = new Float64Array(0);
    this.buy = new Float64Array(0);
    this.sell = new Float64Array(0);
    this.base = 0;
    this.lo = 1;
    this.hi = 0;
  }

  rowOf(price) {
    return Math.floor(roundHA(price / this.tick) / this.tpr);
  }
  rowLowPrice(row) {
    const m = 10 ** this.dec;
    return roundHA(row * this.tpr * this.tick * m) / m;
  }
  rowHighPrice(row) {
    const m = 10 ** this.dec;
    return roundHA((row * this.tpr + this.tpr - 1) * this.tick * m) / m;
  }

  addTrade(price, volume, side = 0) {
    if (!(volume > 0) || !Number.isFinite(price)) return;
    const i = this.#ensure(this.rowOf(price));
    this.total[i] += volume;
    if (side > 0) this.buy[i] += volume;
    else if (side < 0) this.sell[i] += volume;
  }

  /** Lot (Float64Array, vues SAB acceptées) → n */
  addTrades(px, vol, side) {
    let n = Math.min(px.length, vol.length);
    if (side) n = Math.min(n, side.length);
    for (let i = 0; i < n; i++) this.addTrade(px[i], vol[i], side ? side[i] : 0);
    return n;
  }

  /** Barre OHLCV : volume réparti uniformément sur chaque tick de [low, high]. */
  addBar(high, low, volume) {
    if (!(volume > 0) || !Number.isFinite(high) || !Number.isFinite(low)) return;
    if (high < low) [high, low] = [low, high];
    const th = roundHA(high / this.tick), tl = roundHA(low / this.tick);
    const perTick = volume / (th - tl + 1);
    const tpr = this.tpr;
    const r0 = Math.floor(tl / tpr), r1 = Math.floor(th / tpr);
    this.#ensure(r0);
    this.#ensure(r1);
    for (let r = r0; r <= r1; r++) {
      const a = Math.max(tl, r * tpr), b = Math.min(th, r * tpr + tpr - 1);
      this.total[r - this.base] += perTick * (b - a + 1);
    }
  }

  get rows() {
    return this.hi < this.lo ? 0 : this.hi - this.lo + 1;
  }

  snapshot() {
    const n = this.rows;
    const o = n ? this.lo - this.base : 0;
    return {
      tickSize: this.tick,
      ticksPerRow: this.tpr,
      firstRow: n ? this.lo : 0,
      lowPrice: n ? this.rowLowPrice(this.lo) : 0,
      rows: n,
      total: this.total.slice(o, o + n),
      buy: this.buy.slice(o, o + n),
      sell: this.sell.slice(o, o + n),
    };
  }

  stats() {
    const n = this.rows;
    if (!n) return { valid: false };
    const v = this.total, o = this.lo - this.base;
    const mid = 0.5 * (n - 1);
    let tot = 0, best = -1, poc = 0;
    for (let i = 0; i < n; i++) {
      const x = v[o + i];
      tot += x;
      if (x > best || (x === best && Math.abs(i - mid) < Math.abs(poc - mid))) {
        best = x;
        poc = i;
      }
    }
    if (!(tot > 0)) return { valid: false };
    const target = this.vaPct * tot, k = this.vaStep;
    let va = v[o + poc], up = poc + 1, dn = poc - 1, top = poc, bot = poc;
    while (va < target && (up < n || dn >= 0)) {
      let su = 0, sd = 0, nu = 0, nd = 0;
      for (let j = 0; j < k && up + j < n; j++) { su += v[o + up + j]; nu++; }
      for (let j = 0; j < k && dn - j >= 0; j++) { sd += v[o + dn - j]; nd++; }
      const takeUp = nu > 0 && (nd === 0 || su >= sd);
      const takeDn = nd > 0 && (nu === 0 || sd >= su);
      if (takeUp) { va += su; top = up + nu - 1; up += nu; }
      if (takeDn) { va += sd; bot = dn - nd + 1; dn -= nd; }
    }
    return {
      valid: true,
      poc: this.rowLowPrice(this.lo + poc),
      vah: this.rowHighPrice(this.lo + top),
      val: this.rowLowPrice(this.lo + bot),
      pocRow: this.lo + poc,
      vahRow: this.lo + top,
      valRow: this.lo + bot,
      pocVolume: best,
      totalVolume: tot,
      valueAreaVolume: va,
    };
  }

  #ensure(row) {
    if (this.cap === 0) {
      this.cap = INIT_CAP;
      this.base = row - INIT_CAP / 2;
      this.total = new Float64Array(INIT_CAP);
      this.buy = new Float64Array(INIT_CAP);
      this.sell = new Float64Array(INIT_CAP);
      this.lo = this.hi = row;
      return row - this.base;
    }
    if (row < this.base) {
      const grow = Math.max(this.cap, this.base - row + 64);
      this.#realloc(this.cap + grow, grow);
      this.base -= grow;
    } else if (row >= this.base + this.cap) {
      const grow = Math.max(this.cap, row - (this.base + this.cap) + 64);
      this.#realloc(this.cap + grow, 0);
    }
    if (row < this.lo) this.lo = row;
    if (row > this.hi) this.hi = row;
    return row - this.base;
  }

  #realloc(cap, shift) {
    for (const k of ['total', 'buy', 'sell']) {
      const a = new Float64Array(cap);
      a.set(this[k], shift);
      this[k] = a;
    }
    this.cap = cap;
  }
}

/**
 * Nœuds de volume sur un profil (Float64Array `total` d'un snapshot).
 *  HVN : maxima locaux du profil lissé (gaussien) ≥ minPeakFrac × max
 *  LVN : creux entre deux HVN consécutifs ≤ maxValleyFrac × min(HVN voisins)
 *  sigmaRows par défaut adaptatif (≈ n/80 lignes) : la structure, pas le bruit de tick.
 * @returns {{ hvn: number[], lvn: number[] }} index de lignes relatifs au snapshot
 */
export function findVolumeNodes(total, { sigmaRows, minPeakFrac = 0.15, maxValleyFrac = 0.6 } = {}) {
  const n = total.length;
  if (n < 3) return { hvn: [], lvn: [] };
  if (!(sigmaRows > 0)) sigmaRows = Math.max(1.5, n / 80);
  const rad = Math.max(1, Math.ceil(3 * sigmaRows));
  const ker = new Float64Array(2 * rad + 1);
  for (let j = -rad; j <= rad; j++) ker[j + rad] = Math.exp(-(j * j) / (2 * sigmaRows * sigmaRows));
  const sm = new Float64Array(n);
  let max = 0;
  for (let i = 0; i < n; i++) {
    let acc = 0, w = 0;
    for (let j = -rad; j <= rad; j++) {
      const k = i + j;
      if (k >= 0 && k < n) { acc += total[k] * ker[j + rad]; w += ker[j + rad]; }
    }
    sm[i] = acc / w;
    if (sm[i] > max) max = sm[i];
  }
  const hvn = [];
  for (let i = 1; i < n - 1; i++) {
    if (sm[i] >= sm[i - 1] && sm[i] > sm[i + 1] && sm[i] >= minPeakFrac * max) hvn.push(i);
  }
  const lvn = [];
  for (let h = 1; h < hvn.length; h++) {
    let m = hvn[h - 1];
    for (let i = hvn[h - 1]; i <= hvn[h]; i++) if (sm[i] < sm[m]) m = i;
    if (sm[m] <= maxValleyFrac * Math.min(sm[hvn[h - 1]], sm[hvn[h]])) lvn.push(m);
  }
  return { hvn, lvn };
}

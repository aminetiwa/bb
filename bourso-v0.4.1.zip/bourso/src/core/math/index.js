// ============================================================================
//  BOURSO :: math/index.js — charge l'addon C++ (N-API) ou bascule sur le miroir JS.
//  Même API, mêmes résultats (bit à bit) : le backend est transparent.
//  BOURSO_NO_NATIVE=1 force le JS (utile pour comparer / déboguer).
// ============================================================================
import { createRequire } from 'node:module';
import { KalmanFilterJS, kalmanParamsFor, KALMAN_DEFAULTS } from './kalman.js';
import { VolumeProfileJS, findVolumeNodes } from './volume-profile.js';

const require = createRequire(import.meta.url);

function loadNative() {
  if (process.env.BOURSO_NO_NATIVE === '1') return null;
  for (const rel of ['../../../build/Release/bourso_native.node', '../../../build/Debug/bourso_native.node']) {
    try {
      return require(rel);
    } catch {
      /* essai suivant */
    }
  }
  return null;
}

const native = loadNative();

/** 'native' (C++ -O3 -march=native) ou 'js' */
export const backend = native ? 'native' : 'js';
export const KalmanFilter = native ? native.KalmanFilter : KalmanFilterJS;
export const VolumeProfile = native ? native.VolumeProfile : VolumeProfileJS;
export { KalmanFilterJS, VolumeProfileJS, kalmanParamsFor, KALMAN_DEFAULTS, findVolumeNodes };

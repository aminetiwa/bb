// ============================================================================
//  BOURSO :: market/news-sim.js — actualités FICTIVES de la simulation (clairement étiquetées).
//
//  Trois portées : valeur, secteur, région/monde (banques centrales, macro). Chaque actualité a
//  une tonalité (−1…+1) et un IMPACT sur le simulateur : dérive du cours pendant quelques
//  minutes et regain de volume — l'IA peut donc vérifier si le marché « réagit ».
// ============================================================================
import { Rng } from '../core/quant/numeric.js';

const STOCK = [
  [0.62, '{n} : résultats trimestriels supérieurs aux attentes, marge en progression'],
  [-0.6, '{n} : résultats trimestriels inférieurs au consensus'],
  [0.7, '{n} relève ses objectifs annuels'],
  [-0.72, '{n} abaisse ses prévisions de chiffre d\'affaires'],
  [0.35, '{n} : un courtier relève sa recommandation à l\'achat'],
  [-0.35, '{n} : recommandation abaissée à « vendre » par un bureau d\'analyse'],
  [0.4, '{n} remporte un contrat pluriannuel majeur'],
  [-0.38, '{n} perd un contrat important au profit d\'un concurrent'],
  [0.55, '{n} : rumeurs d\'offre de rachat, le titre est recherché'],
  [-0.5, '{n} visé par une enquête des autorités de la concurrence'],
  [0.25, '{n} présente un nouveau produit bien accueilli'],
  [0.3, '{n} annonce un programme de rachat d\'actions'],
  [-0.3, '{n} : départ surprise du directeur général'],
  [-0.35, '{n} : incident de production sur un site clé'],
  [0.2, '{n} : la direction se montre confiante lors d\'une conférence investisseurs'],
  [-0.22, '{n} : un fonds activiste réduit sa participation'],
  [0.45, '{n} : feu vert réglementaire pour une acquisition stratégique'],
  [-0.45, '{n} : avertissement sur la trésorerie, dette en hausse'],
];
const SECTOR = {
  ENER: [[0.4, 'Pétrole : le Brent bondit après une baisse des stocks'], [-0.4, 'Pétrole : le Brent recule, craintes sur la demande']],
  SEMI: [[0.5, 'Semi-conducteurs : demande record liée à l\'IA'], [-0.45, 'Semi-conducteurs : nouvelles restrictions à l\'exportation']],
  BANK: [[0.3, 'Banques : la pente des taux soutient la marge d\'intérêt'], [-0.3, 'Banques : inquiétudes sur la qualité du crédit']],
  LUX: [[0.4, 'Luxe : rebond des ventes en Asie évoqué par plusieurs courtiers'], [-0.4, 'Luxe : la consommation chinoise ralentit encore']],
  AUTO: [[0.3, 'Automobile : immatriculations en hausse en Europe'], [-0.35, 'Automobile : menace de nouveaux droits de douane']],
  PHARMA: [[0.3, 'Pharmacie : l\'agence du médicament accélère les autorisations'], [-0.3, 'Pharmacie : pression politique sur le prix des médicaments']],
  AERO: [[0.35, 'Défense : hausse des budgets militaires européens'], [-0.2, 'Aéronautique : retards de livraison chez les motoristes']],
  UTIL: [[0.2, 'Énergie : baisse des prix de gros de l\'électricité'], [-0.25, 'Services publics : taxe exceptionnelle évoquée']],
  MAT: [[0.35, 'Métaux : le cuivre au plus haut sur la demande chinoise'], [-0.35, 'Métaux : chute du minerai de fer']],
  SOFT: [[0.3, 'Logiciels : accélération des dépenses informatiques des entreprises'], [-0.3, 'Logiciels : craintes de disruption par l\'IA']],
  NET: [[0.3, 'Internet : la publicité en ligne repart'], [-0.3, 'Internet : nouvelle régulation des plateformes']],
};
const MACRO = [
  ['Europe', 0.25, 'BCE : un membre du directoire juge la désinflation « en bonne voie »', 'BCE'],
  ['Europe', -0.25, 'BCE : ton prudent, pas de baisse de taux à court terme', 'BCE'],
  ['Europe', 0.2, 'Zone euro : l\'indice PMI composite repasse au-dessus de 50', 'Macro'],
  ['Europe', -0.2, 'Allemagne : la production industrielle recule plus que prévu', 'Macro'],
  ['Amérique du Nord', 0.3, 'États-Unis : l\'inflation ralentit, les marchés anticipent une baisse des taux', 'Fed'],
  ['Amérique du Nord', -0.3, 'Fed : le président écarte une baisse de taux rapide', 'Fed'],
  ['Amérique du Nord', 0.2, 'États-Unis : créations d\'emplois solides', 'Macro'],
  ['Asie-Pacifique', 0.3, 'Chine : nouveau plan de relance de la consommation', 'Macro'],
  ['Asie-Pacifique', -0.3, 'Chine : la croissance déçoit au trimestre', 'Macro'],
  ['Asie-Pacifique', 0.15, 'Japon : la Banque du Japon maintient sa politique', 'BoJ'],
  [null, -0.25, 'Marchés : regain de tensions géopolitiques', 'Monde'],
  [null, 0.2, 'Marchés : l\'appétit pour le risque revient', 'Monde'],
];

export class NewsEngine {
  constructor(sim, seed = 3) {
    this.sim = sim;
    this.rng = new Rng(seed ^ 0x2545f491);
    this.items = [];
    this.seq = 0;
  }

  /** Tire une actualité (pondération : favoris ×6, Europe ×3) et l'applique au marché. */
  generate(favs = []) {
    const r = this.rng, u = r.next(), all = this.sim.instruments;
    let item;
    if (u < 0.62) {
      const weights = all.map((x) => (favs.includes(x.meta.sym) ? 6 : 1) * (x.meta.region === 'Europe' ? 3 : 1));
      let t = r.next() * weights.reduce((a, b) => a + b, 0), k = 0;
      while (t > weights[k]) t -= weights[k++];
      const inst = all[Math.min(k, all.length - 1)], [score, tpl] = STOCK[r.int(STOCK.length)];
      item = { scope: 'valeur', sym: inst.meta.sym, title: tpl.replace('{n}', inst.meta.name), score: score * (0.8 + 0.4 * r.next()), tag: inst.meta.name, simDate: inst.clk.today, simSec: inst.clk.sec };
    } else if (u < 0.85) {
      const keys = Object.keys(SECTOR), key = keys[r.int(keys.length)], [score, title] = SECTOR[key][r.int(2)];
      item = { scope: 'secteur', sectorKey: key, title, score, tag: key };
    } else {
      const [region, score, title, tag] = MACRO[r.int(MACRO.length)];
      item = { scope: region ? 'région' : 'monde', region, title, score, tag };
    }
    item.id = `n${++this.seq}`;
    item.ts = Date.now();
    item.source = 'Simulation';
    this.items.push(item);
    if (this.items.length > 500) this.items.shift();
    this.sim.applyNews(item);
    return item;
  }

  /** Actualités concernant une valeur (directes, son secteur, sa région, le monde). */
  forSym(sym, limit = 30) {
    const m = this.sim.get(sym)?.meta;
    if (!m) return [];
    return this.items.filter((n) => n.sym === sym || (n.scope === 'secteur' && n.sectorKey === m.sectorKey) || (n.scope === 'région' && n.region === m.region) || n.scope === 'monde').slice(-limit);
  }
}

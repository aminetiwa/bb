// ============================================================================
//  BOURSO :: market/real.js — MARCHÉ RÉEL : même interface que le simulateur (WorldSim), alimentée
//  par des sources gratuites (Yahoo Finance, BCE, Google Actualités, GDELT, flux de presse, et en
//  option Finnhub / FMP / Twelve Data / Stooq avec une clé).
//
//  Ce qui est réel : cours (différés selon la place, ≈ 15 min en Europe), historiques quotidiens
//  sur 5 ans, bougies intraday (1 min sur 5 séances ; 5, 15, 30 min sur un mois ; 1 h sur 6 mois),
//  indices, taux de change, actualités, dividendes. Ce qui ne l'est pas (pas de source gratuite) :
//  carnet d'ordres, bande des transactions, bougies à la seconde — signalés « non disponibles ».
//  La fourchette achat/vente est ESTIMÉE (dernier cours ± demi-écart) pour la négociation fictive.
//
//  Politesse envers les sources : débit limité par site (data/net.js), cotations groupées par
//  paquets de 20, valeurs « chaudes » (favoris, valeur affichée, positions) rafraîchies plus
//  souvent, le reste à tour de rôle, et seulement quand leur place est ouverte. Tout est mis en
//  cache sur le disque (data/cache) : au redémarrage, les derniers cours connus s'affichent tout
//  de suite.
// ============================================================================
import { EventEmitter } from 'node:events';
import { readFile, writeFile, mkdir, readdir, rename } from 'node:fs/promises';
import { join } from 'node:path';
import { EXCHANGES, REGIONS, marketState, pastSessions, nextSessions, sessionSecondOf, STATE_LABEL, tickFor } from './exchanges.js';
import { UNIVERSE, SECTORS } from './universe.js';
import { Net } from '../data/net.js';
import { Yahoo, localParts } from '../data/yahoo.js';
import { RealFx, FX_FILE } from '../data/fx-real.js';
import { RealNews, DEFAULT_FEEDS } from '../data/news-real.js';
import { NET_LIMITS } from '../data/check.js';
import { KeyedSources } from '../data/keyed.js';
import { yahooSymbol, stooqSymbol, INDEX_SYMBOLS, micOfYahoo, codeOfYahoo, ccyOfYahoo } from '../data/symbols.js';
import { roundTick } from '../core/quant/numeric.js';

const DAY = 86_400_000;
const F = (a) => Float64Array.from(a);
const isNum = (x) => typeof x === 'number' && Number.isFinite(x);
const nextDay = (ymd) => new Date(Date.parse(`${ymd}T12:00:00Z`) + DAY).toISOString().slice(0, 10);

/**
 * Cadence des rafraîchissements selon l'intensité choisie dans Réglages. Ordres de grandeur pour
 * Yahoo en « normale » : ≈ 15 requêtes/min une fois les historiques en cache (≈ 30/min le premier
 * jour, le temps de charger 5 ans de séances pour chaque valeur). detailMs 0 = pas de détail
 * tournant (les cours viennent alors des seules cotations groupées).
 */
export const INTENSITY = {
  econome: { label: 'économe', quoteOpenSec: 600, quoteClosedSec: 7200, hotSec: 300, hotMax: 5, detailMs: 0, histMs: 8000, idxSec: 600, newsSymMin: 30 },
  normale: { label: 'normale', quoteOpenSec: 180, quoteClosedSec: 3600, hotSec: 90, hotMax: 8, detailMs: 20_000, histMs: 4000, idxSec: 300, newsSymMin: 20 },
  soutenue: { label: 'soutenue', quoteOpenSec: 90, quoteClosedSec: 1800, hotSec: 45, hotMax: 12, detailMs: 8000, histMs: 2000, idxSec: 120, newsSymMin: 10 },
};
const YH = 'query1.finance.yahoo.com';

/** Secteurs Yahoo (anglais) → secteurs de Bourso, pour les valeurs ajoutées par la recherche. */
const SECTOR_OF = {
  Technology: 'TECH', 'Financial Services': 'FIN', Financial: 'FIN', Healthcare: 'PHARMA', 'Consumer Cyclical': 'RETAIL', 'Consumer Defensive': 'CONS',
  Industrials: 'IND', Energy: 'ENER', Utilities: 'UTIL', 'Basic Materials': 'MAT', 'Communication Services': 'TEL', 'Real Estate': 'RE',
};

const emptyBars = (M) => ({ open: new Float64Array(M), high: new Float64Array(M), low: new Float64Array(M), close: new Float64Array(M), volume: new Float64Array(M), has: new Uint8Array(M) });

export class RealMarket extends EventEmitter {
  /**
   * @param {{ dataDir: string, store?: object, log?: Function, fetchImpl?: Function, rewrite?: Function, universe?: object[],
   *   intensity?: string, keys?: object, feeds?: object[], hot?: () => string[], now?: () => number }} o
   *   now : horloge (les tests simulent une séance ouverte)
   */
  constructor({ dataDir, store = null, log = () => {}, fetchImpl, rewrite = null, universe = UNIVERSE, intensity = 'normale', keys = {}, feeds = DEFAULT_FEEDS, hot = () => [], now = Date.now }) {
    super();
    this.now = now;
    this.setMaxListeners(50);
    this.real = true;
    this.demo = false;
    this.log = log;
    this.store = store;
    this.dir = join(dataDir, 'cache');
    this.hotFn = hot;
    this.cfg = INTENSITY[intensity] ?? INTENSITY.normale;
    this.intensity = INTENSITY[intensity] ? intensity : 'normale';
    this.net = new Net({ fetchImpl, rewrite, log, limits: structuredClone(NET_LIMITS) });
    this.yahoo = new Yahoo(this.net);
    this.keyed = new KeyedSources({ net: this.net, keys, log });
    this.fx = new RealFx({ net: this.net, yahoo: this.yahoo, file: FX_FILE(this.dir), log });
    this.clocks = {};
    this.instruments = [];
    this.bySym = new Map();
    this.byYahoo = new Map();
    this.byMic = new Map();
    for (const meta of universe) this.#addInst({ ...meta });
    this.news = new RealNews({ net: this.net, yahoo: this.yahoo, market: this, file: join(this.dir, 'news.json'), log, feeds });
    this.idx = new Map(); // clé d'indice → { name, symbol, last, prev, at, dates, close }
    for (const [key, d] of Object.entries(INDEX_SYMBOLS)) if (key === 'EUROPE' || key === 'MONDE' || this.byMic.has(key)) this.idx.set(key, { key, name: d.name, candidates: d.y, symbol: d.y[0], proxy: Boolean(d.proxy), last: NaN, prev: NaN, at: 0, dates: [], close: F([]), histAt: 0 });
    this.histQueue = [];
    this.detailCursor = 0;
    this.due = { quotes: {}, idx: 0, idxHist: 0, fxOff: 0, fxLive: 0, news: 0, newsSym: 0, save: 0 };
    this.busy = {};
    this.tickMs = 1000; // période de l'ordonnanceur (les tests l'accélèrent)
    this.started = false;
    this.errors = [];
    this.logSeen = new Map(); // cause d'erreur → dernière ligne de journal (anti-répétition)
    this.recent = new Map(); // valeurs consultées récemment (chaudes pendant 10 min)
  }

  // ---------------------------------------------------------------- univers, horloges
  #clock(mic) {
    if (this.clocks[mic]) return this.clocks[mic];
    const clk = { ex: EXCHANGES[mic], today: null, sec: 0, live: false, state: 'CLOSED', past: [], future: [], sub: 0 };
    this.#updateClock(clk);
    this.clocks[mic] = clk;
    return clk;
  }

  /** Met l'horloge d'une place à l'heure réelle ; renvoie l'ancienne séance si elle vient de changer. */
  #updateClock(clk) {
    const ex = clk.ex, ms = marketState(ex, this.now());
    const session = ms.trading && ms.state !== 'PRE' ? ms.localYmd : pastSessions(ex, ms.localYmd, 1)[0];
    clk.state = ms.state;
    clk.live = ms.state === 'OPEN';
    clk.localMin = ms.localMin;
    clk.localSec = ms.localSec;
    clk.sec = session === ms.localYmd && (ms.state === 'OPEN' || ms.state === 'BREAK') ? ms.sessionSec : ex.sessionSec;
    if (session === clk.today) return null;
    const old = clk.today;
    clk.today = session;
    clk.past = pastSessions(ex, session, 260);
    clk.future = nextSessions(ex, nextDay(session), 30);
    return old;
  }

  #addInst(meta) {
    const mic = meta.mic, ex = EXCHANGES[mic];
    if (!ex || this.bySym.has(meta.sym)) return this.bySym.get(meta.sym) ?? null;
    meta.yahoo = meta.yahoo ?? yahooSymbol(meta);
    const clk = this.#clock(mic), M = ex.sessionMin;
    const x = {
      meta, ex, clk, rank: (this.byMic.get(mic) ?? []).length, fund: this.#emptyFund(), capEur: null, adv: null, beta: null,
      h: { dates: [], open: [], high: [], low: [], close: [], volume: [] }, dividends: [], high52: null, low52: null,
      daily: { open: F([]), high: F([]), low: F([]), close: F([]), volume: F([]), dates: [], n: 0, cap: 0 },
      m: emptyBars(M), mN: 0, curM: { o: NaN, h: NaN, l: NaN, c: NaN, v: 0 }, s1: null, curS: null, tape: { n: 0 }, walls: [],
      intra: new Map(), // intervalle (min) → { days: Map(ymd → barres), at }
      last: NaN, prev: NaN, open: NaN, high: NaN, low: NaN, volume: 0, turnover: 0, trades: 0, buyVol: 0, sellVol: 0, largeBuys: 0, largeSells: 0,
      q: { at: 0, fetchedAt: 0, source: null, session: null, detailAt: 0, minuteAt: 0 }, hist: { at: 0, source: null, error: null, full: false },
      status: 'en attente', error: null, dead: false,
    };
    this.instruments.push(x);
    this.bySym.set(meta.sym, x);
    this.byYahoo.set(meta.yahoo, x);
    if (!this.byMic.has(mic)) this.byMic.set(mic, []);
    this.byMic.get(mic).push(x);
    return x;
  }

  #emptyFund() {
    return { simule: false, source: null, capitalisationMdEur: null, nombreActionsM: null, per: null, perAnneeProchaine: null, bpa: null, rendementDividendePct: null, dividendeParAction: null,
      tauxDistributionPct: null, croissanceCaPct: null, margeNettePct: null, detteNetteSurEbitda: null, roePct: null, prixSurValeurComptable: null, flottantPct: null,
      prochainePublication: null, consensus: null, objectifCoursMoyen: null, plusHaut52s: null, plusBas52s: null, beta: null };
  }

  get(sym) {
    return this.bySym.get(sym);
  }

  // ---------------------------------------------------------------- démarrage : caches disque
  async init() {
    const t0 = Date.now();
    await mkdir(join(this.dir, 'hist'), { recursive: true }).catch(() => {});
    // valeurs ajoutées par la recherche lors des sessions précédentes
    try {
      const extra = JSON.parse(await readFile(join(this.dir, 'universe-extra.json'), 'utf8'));
      for (const meta of extra) this.#addInst(meta);
    } catch { /* aucune */ }
    // derniers cours connus
    try {
      const snap = JSON.parse(await readFile(join(this.dir, 'quotes.json'), 'utf8'));
      for (const [sym, s] of Object.entries(snap.quotes ?? {})) {
        const x = this.get(sym);
        if (!x || !isNum(s.last)) continue;
        Object.assign(x, { last: s.last, prev: s.prev, open: s.open, high: s.high, low: s.low, volume: s.volume ?? 0, turnover: s.turnover ?? 0 });
        x.q = { ...x.q, at: s.at ?? 0, source: `${s.source ?? 'cache'} (enregistré)`, session: s.session ?? null };
        if (s.tick) x.meta.tick = s.tick;
        x.status = 'cache';
        // la séance a changé depuis : ce cours devient la veille
        if (s.session && s.session < x.clk.today) {
          x.prev = s.last;
          x.open = x.high = x.low = s.last;
          x.volume = x.turnover = 0;
        }
      }
    } catch { /* premier lancement */ }
    // historiques quotidiens
    let files = [];
    try { files = await readdir(join(this.dir, 'hist')); } catch { /* vide */ }
    await Promise.all(files.filter((f) => f.endsWith('.json')).map(async (f) => {
      try {
        const j = JSON.parse(await readFile(join(this.dir, 'hist', f), 'utf8'));
        const x = this.byYahoo.get(j.symbol);
        if (x) this.#setHistory(x, j, { fromCache: true });
        else if (j.index) {
          const ix = [...this.idx.values()].find((i) => i.candidates.includes(j.symbol));
          if (ix) Object.assign(ix, { symbol: j.symbol, dates: j.dates, close: F(j.close), histAt: j.at ?? 0 });
        }
      } catch { /* fichier abîmé : il sera retéléchargé */ }
    }));
    await Promise.all([this.fx.load(), this.news.load()]);
    for (const x of this.instruments) this.#syncDaily(x);
    this.initMs = Date.now() - t0;
    this.log(`données réelles : ${this.instruments.length} valeurs, ${this.instruments.filter((x) => x.h.dates.length).length} historiques et ${this.instruments.filter((x) => isNum(x.last)).length} cours en cache (${this.initMs} ms)`);
    return this;
  }

  start() {
    if (this.started) return;
    this.started = true;
    // file des historiques : favoris et positions d'abord, puis l'Europe, puis le reste du monde
    this.#queueHistories();
    const now = Date.now();
    // premières cotations : places ouvertes tout de suite (l'Europe d'abord) ; une place fermée dont
    // les cours sont déjà en cache attend un peu (étalé sur 10 min) — rien ne presse, Yahoo respire
    for (const [mic, clk] of Object.entries(this.clocks)) {
      const open = clk.state === 'OPEN' || clk.state === 'BREAK';
      const cached = (this.byMic.get(mic) ?? []).every((x) => x.dead || x.q.at > 0);
      this.due.quotes[mic] = open || !cached ? now + (EXCHANGES[mic].region === 'Europe' ? 0 : 3000) : now + 60_000 + Math.floor(Math.random() * 540_000);
    }
    this.timer = setInterval(() => this.#tick().catch((e) => this.log(`marché réel : ${e.message}`)), this.tickMs);
    this.timer.unref?.();
    this.#tick().catch(() => {});
  }

  stop() {
    clearInterval(this.timer);
    this.started = false;
    this.#saveQuotes().catch(() => {});
  }

  /** Réglages modifiés à chaud (intensité, clés, flux d'actualités). */
  configure({ intensity, keys, feeds } = {}) {
    if (intensity && INTENSITY[intensity]) {
      this.cfg = INTENSITY[intensity];
      this.intensity = intensity;
    }
    if (keys) this.keyed.setKeys(keys);
    if (Array.isArray(feeds)) this.news.feeds = feeds;
  }

  // ---------------------------------------------------------------- ordonnanceur (chaque seconde)
  async #tick() {
    const now = Date.now();
    for (const clk of Object.values(this.clocks)) {
      const old = this.#updateClock(clk);
      if (old) this.#rollover(clk, old);
    }
    const run = (name, fn) => {
      if (this.busy[name]) return;
      this.busy[name] = true;
      fn().catch((e) => this.#error(name, e)).finally(() => { this.busy[name] = false; });
    };
    // Yahoo a refusé des requêtes : RIEN ne lui est demandé avant la fin de la pause (le client réseau
    // annule de toute façon ce qui partirait). Les autres sources (BCE, actualités) continuent.
    const yPause = this.net.pausedUntil(YH);
    if (!yPause) {
      // cotations groupées : les places dues sont traitées l'une après l'autre, jamais en rafale
      const due = Object.entries(this.clocks).filter(([mic]) => (this.due.quotes[mic] ?? 0) <= now);
      if (due.length && !this.busy.quotes) {
        for (const [mic, clk] of due) {
          const open = clk.state === 'OPEN' || clk.state === 'BREAK';
          const justClosed = clk.state === 'POST' && clk.localMin - clk.ex.closeMin < 45;
          this.due.quotes[mic] = now + 1000 * (open ? this.cfg.quoteOpenSec : justClosed ? 300 : this.cfg.quoteClosedSec);
        }
        run('quotes', async () => {
          for (const [mic] of due) if ((await this.refreshQuotes(this.byMic.get(mic) ?? [])) === 'paused') break;
        });
      }
      // valeurs chaudes : bougies 1 min du jour
      if (!this.busy.hot && now - (this.lastHot ?? 0) > this.cfg.hotSec * 1000) {
        this.lastHot = now;
        run('hot', () => this.#refreshHot());
      }
      // détail à tour de rôle (plus haut, plus bas, volume du jour exacts)
      if (this.cfg.detailMs > 0 && now - (this.lastDetail ?? 0) > this.cfg.detailMs) {
        this.lastDetail = now;
        run('detail', () => this.#refreshDetail());
      }
      if (now > this.due.idx) {
        this.due.idx = now + this.cfg.idxSec * 1000;
        run('idx', () => this.refreshIndices());
      }
    }
    // historiques manquants ou à compléter (pendant une pause de Yahoo : seulement via une source à clé)
    if (this.histQueue.length && now - (this.lastHist ?? 0) > this.cfg.histMs && (!yPause || this.keyed.has('stooq') || this.keyed.has('twelvedata'))) {
      this.lastHist = now;
      run('hist', () => this.#nextHistory());
    }
    if (now > (this.due.histScan ?? 0)) {
      this.due.histScan = now + 15 * 60_000;
      this.#queueHistories();
    }
    if (now > this.due.idxHist) {
      this.due.idxHist = now + 6 * 3600_000;
      run('idxHist', () => this.#indexHistories());
    }
    if (now > this.due.fxOff) {
      this.due.fxOff = now + 6 * 3600_000;
      run('fxOff', () => this.fx.refreshOfficial());
    }
    if (now > this.due.fxLive && !yPause) {
      this.due.fxLive = now + 10 * 60_000;
      run('fxLive', () => this.fx.refreshLive());
    }
    if (now > this.due.news) {
      this.due.news = now + 10 * 60_000;
      run('news', () => this.news.refreshGeneral());
    }
    if (now > this.due.newsSym) {
      this.due.newsSym = now + 60_000;
      run('newsSym', () => this.#refreshFavoriteNews());
    }
    if (now > this.due.save) {
      this.due.save = now + 60_000;
      run('save', () => this.#saveQuotes());
    }
  }

  #error(where, e) {
    const msg = `${where} : ${e.message}`;
    this.errors.push({ at: Date.now(), message: msg });
    if (this.errors.length > 50) this.errors.shift();
    if (e.blocked) return; // coupe-circuit : déjà signalé une fois par le client réseau
    // même cause répétée (hors ligne, site en panne) : une ligne par minute, pas une par valeur
    const cause = `${e.host ?? ''}|${e.status ?? ''}|${/ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ECONNRESET|ETIMEDOUT|pas de réponse|HTTP \d+/.exec(e.message)?.[0] ?? e.message}`;
    const seen = this.logSeen.get(cause);
    if (seen && Date.now() - seen.at < 60_000) { seen.n++; return; }
    this.log(`données réelles — ${msg}${seen?.n ? ` (+ ${seen.n} erreur(s) de même cause depuis 1 min)` : ''}`);
    this.logSeen.set(cause, { at: Date.now(), n: 0 });
    if (this.logSeen.size > 200) this.logSeen.delete(this.logSeen.keys().next().value);
  }

  /** Valeurs « chaudes » : favoris, valeurs affichées, positions, alertes, consultées récemment. */
  hotSet() {
    const s = new Set(this.hotFn() ?? []);
    const now = Date.now();
    for (const [sym, t] of this.recent) {
      if (now - t > 10 * 60_000) this.recent.delete(sym);
      else s.add(sym);
    }
    return [...s].filter((sym) => this.bySym.has(sym)).slice(0, this.cfg.hotMax ?? 10);
  }

  touch(sym) {
    if (this.bySym.has(sym)) this.recent.set(sym, Date.now());
  }

  // ---------------------------------------------------------------- cotations
  /** Cotations groupées (spark) ; à défaut, graphique du jour valeur par valeur. */
  async refreshQuotes(list) {
    const alive = list.filter((x) => !x.dead);
    for (let i = 0; i < alive.length; i += 20) {
      const batch = alive.slice(i, i + 20);
      let blocked = false;
      const m = await this.yahoo.spark(batch.map((x) => x.meta.yahoo), { range: '1d', interval: '15m' }).catch((e) => { blocked = Boolean(e.blocked); this.#error('cotations', e); return undefined; });
      if (m === undefined) return blocked ? 'paused' : 'error'; // on réessaiera au prochain tour
      if (m === null) {
        // cotations groupées fermées : les 4 cours les plus anciens de la place, en détail (sobre) ;
        // le détail tournant et les valeurs chaudes font le reste
        const stale = alive.slice().sort((a, b) => a.q.fetchedAt - b.q.fetchedAt).slice(0, 4);
        for (const x of stale) {
          const r = await this.#refreshDay(x, '5m').then(() => 'ok', (e) => { this.#error(x.meta.sym, e); return e.blocked ? 'paused' : 'error'; });
          if (r === 'paused') return 'paused';
        }
        return 'degraded';
      }
      for (const x of batch) {
        const s = m.get(x.meta.yahoo);
        if (!s) continue;
        this.#applyQuote(x, { price: s.price, time: s.time, prevClose: s.prevClose, dayHigh: s.dayHigh, dayLow: s.dayLow, dayVolume: s.dayVolume, currency: s.currency }, 'Yahoo (groupé)', { approx: true, closes: s.closes });
      }
    }
  }

  /** Graphique du jour d'une valeur (1 ou 5 min) : cotation exacte + bougies du jour. */
  async #refreshDay(x, interval = '1m', priority = 1) {
    try {
      const r = await this.yahoo.chart(x.meta.yahoo, { range: '1d', interval, events: false }, { priority });
      this.#applyQuote(x, r.meta, 'Yahoo');
      if (r.bars.t.length) this.#ingestIntraday(x, interval === '1m' ? 1 : Number.parseInt(interval, 10), r.bars, { todayOnly: true });
      x.q.detailAt = Date.now();
      if (interval === '1m') x.q.minuteAt = Date.now();
    } catch (e) {
      if (e.status === 404 || /No data found|delisted|not found/i.test(e.message)) {
        x.dead = true;
        x.status = 'introuvable';
        x.error = `introuvable chez Yahoo (${x.meta.yahoo})`;
      }
      throw e;
    }
  }

  async #refreshHot() {
    for (const sym of this.hotSet()) {
      const x = this.get(sym);
      if (!x || x.dead) continue;
      const open = x.clk.state === 'OPEN' || x.clk.state === 'BREAK';
      // séance fermée : une mise à jour par heure suffit (et une juste après la clôture)
      if (!open && Date.now() - x.q.minuteAt < 3600_000 && x.q.session === x.clk.today) continue;
      await this.#refreshDay(x, '1m', 2).catch((e) => this.#error(sym, e));
    }
  }

  async #refreshDetail() {
    const hot = new Set(this.hotSet());
    const n = this.instruments.length;
    for (let k = 0; k < n; k++) {
      const x = this.instruments[(this.detailCursor++) % n];
      if (x.dead || hot.has(x.meta.sym)) continue;
      const open = x.clk.state === 'OPEN' || x.clk.state === 'BREAK';
      const stale = x.q.session !== x.clk.today || Date.now() - x.q.detailAt > (open ? 20 * 60_000 : 6 * 3600_000);
      if (!stale) continue;
      await this.#refreshDay(x, '5m', 0).catch((e) => this.#error(x.meta.sym, e));
      return;
    }
  }

  /** Applique une cotation (méta Yahoo ou équivalent) à une valeur. */
  #applyQuote(x, mt, source, { approx = false, closes = null } = {}) {
    if (!isNum(mt.price) || mt.price <= 0) return;
    const ccy = ccyOfYahoo(mt.currency);
    if (ccy && x.meta.added && !x.meta.currency) x.meta.currency = ccy;
    const qSession = mt.time ? localParts(mt.time, x.ex.tz).ymd : x.clk.today;
    const today = x.clk.today;
    // cours d'une séance précédente (place pas encore ouverte, données différées) : c'est la veille
    if (qSession < today) {
      x.last = mt.price;
      if (!isNum(x.prev) || x.q.session !== today) {
        x.prev = this.#prevClose(x) ?? mt.price;
        x.open = x.high = x.low = mt.price;
        x.volume = x.turnover = 0;
      }
    } else {
      const first = x.q.session !== qSession;
      x.last = mt.price;
      x.prev = this.#prevClose(x) ?? (isNum(mt.prevClose) ? mt.prevClose : x.prev);
      if (first || !isNum(x.open)) {
        x.open = isNum(closes?.[0]) && approx ? closes[0] : mt.price;
        x.high = x.low = x.open;
        x.volume = 0;
        x.turnover = 0;
      }
      if (isNum(mt.dayHigh)) x.high = approx ? Math.max(x.high, mt.dayHigh) : mt.dayHigh;
      if (isNum(mt.dayLow)) x.low = approx ? Math.min(x.low, mt.dayLow) : mt.dayLow;
      x.high = Math.max(x.high, x.last);
      x.low = Math.min(x.low, x.last);
      if (isNum(mt.dayVolume) && mt.dayVolume >= x.volume) {
        x.volume = mt.dayVolume;
        if (!x.turnoverFromBars) x.turnover = x.volume * (x.high + x.low + x.last) / 3;
      }
    }
    x.q.at = mt.time ?? Date.now();
    x.q.fetchedAt = Date.now();
    x.q.source = source;
    x.q.session = qSession < today ? x.q.session ?? qSession : qSession;
    x.status = 'ok';
    x.error = null;
    // pas de cotation selon le prix RÉEL (le prix indicatif de l'univers peut être d'une autre tranche)
    const t = tickFor(x.ex.tickRegime, x.last);
    if (t !== x.meta.tick) x.meta.tick = t;
    // la minute en cours suit le dernier cours (graphiques en direct)
    const c = x.curM;
    if (!isNum(c.o)) Object.assign(c, { o: x.last, h: x.last, l: x.last, c: x.last });
    c.c = x.last;
    if (x.last > c.h) c.h = x.last;
    if (x.last < c.l) c.l = x.last;
  }

  /** Clôture de la dernière séance terminée (historique), ou null. */
  #prevClose(x) {
    const d = x.daily;
    return d.n ? d.close[d.n - 1] : null;
  }

  /** Fin de séance d'une place : la journée rejoint l'historique quotidien. */
  #rollover(clk, oldDay) {
    for (const x of this.byMic.get(clk.ex.mic) ?? []) {
      if (isNum(x.last) && x.q.session === oldDay && !x.h.dates.includes(oldDay)) {
        this.#mergeBars(x, { dates: [oldDay], open: [x.open], high: [Math.max(x.high, x.open, x.last)], low: [Math.min(x.low, x.open, x.last)], close: [x.last], volume: [x.volume] });
      }
      this.#syncDaily(x);
      x.prev = isNum(x.last) ? x.last : x.prev;
      x.open = x.high = x.low = x.last;
      x.volume = x.turnover = 0;
      x.turnoverFromBars = false;
      x.m = emptyBars(x.ex.sessionMin);
      x.mN = 0;
      x.curM = { o: x.last, h: x.last, l: x.last, c: x.last, v: 0 };
      // l'historique officiel de la séance écoulée sera repris à la source (correction de la dernière barre)
      x.hist.at = 0;
    }
    this.#queueHistories();
    this.emit('rollover', clk.ex.mic);
  }

  // ---------------------------------------------------------------- historiques quotidiens
  #queueHistories() {
    const favs = new Set(this.hotSet());
    const need = this.instruments.filter((x) => !x.dead && !this.histQueue.includes(x) && (!x.h.dates.length || Date.now() - x.hist.at > 20 * 3600_000));
    const prio = (x) => (favs.has(x.meta.sym) ? 0 : x.meta.region === 'Europe' ? 1 : 2) * 1e6 + x.rank;
    this.histQueue.push(...need);
    this.histQueue.sort((a, b) => prio(a) - prio(b));
  }

  async #nextHistory() {
    const x = this.histQueue.shift();
    if (!x) return;
    await this.loadHistory(x).catch((e) => {
      // source en pause : la valeur reprend sa place en tête de file (elle n'est pas perdue)
      if (e.blocked) this.histQueue.unshift(x);
      this.#error(`historique ${x.meta.sym}`, e);
    });
  }

  /** Télécharge (5 ans) ou complète (1 mois) l'historique quotidien d'une valeur. */
  async loadHistory(x, { priority = 0 } = {}) {
    if (x.histLoading) return x.histLoading;
    const full = !x.h.dates.length || Date.now() - x.hist.at > 30 * DAY;
    x.histLoading = (async () => {
      try {
        const r = await this.yahoo.chart(x.meta.yahoo, { range: full ? '5y' : '1mo', interval: '1d', events: true }, { priority });
        const d = this.#dailyFromBars(x, r.bars);
        if (!d.dates.length) throw new Error('historique vide');
        if (full) x.h = { dates: [], open: [], high: [], low: [], close: [], volume: [] };
        this.#mergeBars(x, d);
        if (r.dividends.length) x.dividends = r.dividends.map((v) => ({ date: localParts(v.t * 1000, x.ex.tz).ymd, amount: v.amount }));
        if (r.meta.name && x.meta.added && !x.meta.nameFixed) { x.meta.name = r.meta.name; x.meta.nameFixed = true; }
        this.#applyQuote(x, r.meta, 'Yahoo');
        x.hist = { at: Date.now(), source: 'Yahoo Finance', error: null, full: true };
      } catch (e) {
        // secours : sources à clé (si configurées)
        const alt = await this.keyed.twelveDaily(x.meta).catch(() => null) ?? await this.keyed.stooqDaily(stooqSymbol(x.meta)).catch(() => null);
        if (!alt?.dates?.length) {
          x.hist.error = e.message;
          if (/introuvable|No data|not found/i.test(e.message) || e.status === 404) { x.dead = true; x.status = 'introuvable'; x.error = `introuvable chez Yahoo (${x.meta.yahoo})`; }
          throw e;
        }
        this.#mergeBars(x, alt);
        x.hist = { at: Date.now(), source: alt.source, error: null, full: true };
      }
      this.#syncDaily(x);
      await this.#saveHistory(x).catch(() => {});
    })().finally(() => { x.histLoading = null; });
    return x.histLoading;
  }

  /** Barres Yahoo → séances datées dans le fuseau de la place (doublons fusionnés). */
  #dailyFromBars(x, b) {
    const out = { dates: [], open: [], high: [], low: [], close: [], volume: [] };
    for (let i = 0; i < b.t.length; i++) {
      const d = localParts(b.t[i] * 1000, x.ex.tz).ymd;
      const j = out.dates.length - 1;
      if (j >= 0 && out.dates[j] === d) {
        out.high[j] = Math.max(out.high[j], b.high[i]);
        out.low[j] = Math.min(out.low[j], b.low[i]);
        out.close[j] = b.close[i];
        out.volume[j] = Math.max(out.volume[j], b.volume[i]);
        continue;
      }
      out.dates.push(d);
      out.open.push(b.open[i]);
      out.high.push(b.high[i]);
      out.low.push(b.low[i]);
      out.close.push(b.close[i]);
      out.volume.push(b.volume[i]);
    }
    return out;
  }

  /** Fusionne des séances (par date ; les nouvelles remplacent les anciennes). */
  #mergeBars(x, d) {
    const map = new Map(x.h.dates.map((t, i) => [t, i]));
    const H = x.h;
    for (let i = 0; i < d.dates.length; i++) {
      const j = map.get(d.dates[i]);
      if (j !== undefined) {
        H.open[j] = d.open[i]; H.high[j] = d.high[i]; H.low[j] = d.low[i]; H.close[j] = d.close[i]; H.volume[j] = d.volume[i];
      } else {
        H.dates.push(d.dates[i]); H.open.push(d.open[i]); H.high.push(d.high[i]); H.low.push(d.low[i]); H.close.push(d.close[i]); H.volume.push(d.volume[i]);
      }
    }
    const order = H.dates.map((t, i) => [t, i]).sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0)).map(([, i]) => i);
    if (order.some((v, k) => v !== k)) for (const f of ['dates', 'open', 'high', 'low', 'close', 'volume']) H[f] = order.map((i) => H[f][i]);
    // 5 ans et quelques séances au plus
    const extra = H.dates.length - 1300;
    if (extra > 0) for (const f of ['dates', 'open', 'high', 'low', 'close', 'volume']) H[f] = H[f].slice(extra);
  }

  #setHistory(x, j, { fromCache = false } = {}) {
    x.h = { dates: j.dates, open: j.open, high: j.high, low: j.low, close: j.close, volume: j.volume };
    x.dividends = j.dividends ?? [];
    x.hist = { at: j.at ?? 0, source: `${j.source ?? 'Yahoo Finance'}${fromCache ? ' (cache)' : ''}`, error: null, full: true };
    if (j.name && x.meta.added) x.meta.name = j.name;
  }

  /** Séances TERMINÉES (avant la séance en cours) en tableaux typés + statistiques dérivées. */
  #syncDaily(x) {
    const H = x.h, today = x.clk.today;
    let n = H.dates.length;
    while (n > 0 && H.dates[n - 1] >= today) n--;
    x.daily = { open: F(H.open.slice(0, n)), high: F(H.high.slice(0, n)), low: F(H.low.slice(0, n)), close: F(H.close.slice(0, n)), volume: F(H.volume.slice(0, n)), dates: H.dates.slice(0, n), n, cap: n };
    if (n && (!isNum(x.prev) || x.q.session === today || !x.q.session)) x.prev = x.daily.close[n - 1];
    if (!isNum(x.last) && n) {
      x.last = x.prev = x.daily.close[n - 1];
      x.open = x.high = x.low = x.last;
      x.status = 'historique';
    }
    // volume moyen, extrêmes sur un an, dividende des 12 derniers mois
    if (n >= 20) {
      let v = 0, cap = 0;
      for (let i = n - 20; i < n; i++) { v += x.daily.volume[i]; cap += x.daily.volume[i] * x.daily.close[i]; }
      x.adv = v / 20;
      // capitaux moyens échangés par jour (20 séances, en euros) : mesure de taille RÉELLE, faute de
      // capitalisation sans clé (sert à classer et à dimensionner la carte du marché)
      x.liqEur = (cap / 20) * this.fx.toEur(x.meta.currency);
      const from = Math.max(0, n - 252);
      x.high52 = Math.max(...x.daily.high.subarray(from, n));
      x.low52 = Math.min(...x.daily.low.subarray(from, n));
    }
    const yearAgo = new Date(Date.now() - 365 * DAY).toISOString().slice(0, 10);
    const ttm = x.dividends.filter((d) => d.date >= yearAgo).reduce((a, d) => a + d.amount, 0);
    const px = isNum(x.last) ? x.last : x.daily.close[n - 1];
    x.fund.plusHaut52s = x.high52;
    x.fund.plusBas52s = x.low52;
    x.fund.dividendeParAction = ttm > 0 ? Number(ttm.toFixed(4)) : x.dividends.length ? 0 : x.fund.dividendeParAction;
    if (ttm > 0 && px > 0 && !x.fund.rendementSource) x.fund.rendementDividendePct = Number(((ttm / px) * 100).toFixed(2));
    if (!x.fund.source) x.fund.source = 'cours et dividendes (Yahoo) ; autres données : clé Finnhub ou FMP';
  }

  async #saveHistory(x) {
    const H = x.h, file = join(this.dir, 'hist', `${x.meta.yahoo.replace(/[^\w.^=-]/g, '_')}.json`);
    await writeFile(`${file}.tmp`, JSON.stringify({ symbol: x.meta.yahoo, sym: x.meta.sym, at: x.hist.at, source: x.hist.source, name: x.meta.added ? x.meta.name : undefined, dates: H.dates, open: H.open, high: H.high, low: H.low, close: H.close, volume: H.volume, dividends: x.dividends }));
    await rename(`${file}.tmp`, file);
  }

  async #saveQuotes() {
    const quotes = {};
    for (const x of this.instruments) {
      if (!isNum(x.last) || !x.q.at) continue;
      quotes[x.meta.sym] = { last: x.last, prev: x.prev, open: x.open, high: x.high, low: x.low, volume: x.volume, turnover: x.turnover, at: x.q.at, session: x.q.session, source: x.q.source, tick: x.meta.tick };
    }
    await mkdir(this.dir, { recursive: true }).catch(() => {});
    await writeFile(join(this.dir, 'quotes.json.tmp'), JSON.stringify({ at: Date.now(), quotes }));
    await rename(join(this.dir, 'quotes.json.tmp'), join(this.dir, 'quotes.json'));
  }

  // ---------------------------------------------------------------- intraday
  /** Range une série intraday (horodatée) dans la grille des séances de la place (pauses exclues). */
  #ingestIntraday(x, k, b, { todayOnly = false } = {}) {
    const ex = x.ex, M = ex.sessionMin, P = Math.ceil(M / k);
    const slot = this.#slot(x, k);
    let turnover = 0, vol = 0;
    const today = x.clk.today;
    for (let i = 0; i < b.t.length; i++) {
      const lp = localParts(b.t[i] * 1000, ex.tz);
      if (todayOnly && lp.ymd !== today) continue;
      if (lp.min < ex.openMin || lp.min >= ex.closeMin + 20) continue;
      if (ex.breaks.some(([a, c]) => lp.min >= a && lp.min < c)) continue;
      const idx = lp.min >= ex.closeMin ? P - 1 : Math.min(P - 1, Math.floor(sessionSecondOf(ex, lp.min) / 60 / k));
      if (!slot.days.has(lp.ymd)) slot.days.set(lp.ymd, emptyBars(P));
      const g = slot.days.get(lp.ymd);
      if (!g.has[idx]) {
        g.open[idx] = b.open[i]; g.high[idx] = b.high[i]; g.low[idx] = b.low[i]; g.close[idx] = b.close[i]; g.volume[idx] = b.volume[i]; g.has[idx] = 1;
      } else {
        if (b.high[i] > g.high[idx]) g.high[idx] = b.high[i];
        if (b.low[i] < g.low[idx]) g.low[idx] = b.low[i];
        g.close[idx] = b.close[i];
        g.volume[idx] += b.volume[i];
      }
      if (lp.ymd === today) {
        vol += b.volume[i];
        turnover += b.volume[i] * (b.high[i] + b.low[i] + b.close[i]) / 3;
      }
    }
    // pas plus de 60 séances en mémoire par intervalle
    if (slot.days.size > 60) for (const d of [...slot.days.keys()].sort().slice(0, slot.days.size - 60)) slot.days.delete(d);
    slot.at = Date.now();
    // séance du jour : ouverture, plus haut, plus bas exacts d'après les bougies
    const gt = slot.days.get(today);
    if (gt && x.q.session === today) {
      const first = gt.has.indexOf(1);
      if (first >= 0) {
        x.open = gt.open[first];
        for (let i = first; i < gt.has.length; i++) {
          if (!gt.has[i]) continue;
          if (!(gt.high[i] <= x.high)) x.high = gt.high[i];
          if (!(gt.low[i] >= x.low)) x.low = gt.low[i];
        }
      }
    }
    if (k === 1) {
      const g = slot.days.get(today);
      if (g) this.#syncToday(x, g);
      if (vol > 0 && vol >= x.volume * 0.5) {
        x.turnover = turnover * (x.volume > vol ? x.volume / vol : 1);
        x.turnoverFromBars = true;
      }
    }
  }

  #slot(x, k) {
    if (!x.intra.has(k)) x.intra.set(k, { days: new Map(), at: 0 });
    return x.intra.get(k);
  }

  /** Bougies 1 min du jour → x.m / x.mN / x.curM (format du simulateur). */
  #syncToday(x, g) {
    const M = x.ex.sessionMin;
    let lastIdx = -1;
    for (let i = 0; i < M; i++) if (g.has[i]) lastIdx = i;
    if (lastIdx < 0) return;
    const open = x.clk.state === 'OPEN' || x.clk.state === 'BREAK';
    const cur = open ? Math.min(M - 1, Math.max(lastIdx, Math.floor(x.clk.sec / 60))) : M - 1;
    const m = emptyBars(M);
    let prevC = NaN;
    for (let i = 0; i <= cur; i++) {
      if (g.has[i]) {
        m.open[i] = g.open[i]; m.high[i] = g.high[i]; m.low[i] = g.low[i]; m.close[i] = g.close[i]; m.volume[i] = g.volume[i];
        prevC = g.close[i];
      } else {
        const p = isNum(prevC) ? prevC : g.open[g.has.indexOf(1)];
        m.open[i] = m.high[i] = m.low[i] = m.close[i] = p;
        m.volume[i] = 0;
      }
      m.has[i] = 1;
    }
    x.m = m;
    x.mN = cur;
    x.curM = { o: m.open[cur], h: m.high[cur], l: m.low[cur], c: isNum(x.last) && open ? x.last : m.close[cur], v: m.volume[cur] };
    if (!isNum(x.open) || x.q.session !== x.clk.today) x.open = m.open[0];
  }

  /** Charge les bougies intraday d'une valeur (1 min : 5 séances ; 5-30 min : 1 mois ; 60 min : 6 mois). */
  async loadIntraday(x, k = 1, { maxAgeMs = 60_000, priority = 2 } = {}) {
    const slot = this.#slot(x, k);
    // fullAt : dernier chargement de PLUSIEURS séances (les rafraîchissements du jour ne comptent pas)
    if (Date.now() - (slot.fullAt ?? 0) < maxAgeMs && slot.days.size > 1) return;
    const key = `intra${k}`;
    if (x[key]) return x[key];
    const range = k === 1 ? '5d' : k <= 30 ? '1mo' : '6mo';
    x[key] = (async () => {
      const r = await this.yahoo.chart(x.meta.yahoo, { range, interval: `${k}m`, events: false }, { priority });
      if (k === 1 || x.clk.state !== 'OPEN') this.#applyQuote(x, r.meta, 'Yahoo');
      this.#ingestIntraday(x, k, r.bars);
      slot.fullAt = Date.now();
    })().finally(() => { x[key] = null; });
    return x[key];
  }

  /** Séances intraday complètes (grilles remplies : minutes sans échange = bougie plate sans volume). */
  #filledDay(g, P, prevClose) {
    const out = { open: new Float64Array(P), high: new Float64Array(P), low: new Float64Array(P), close: new Float64Array(P), volume: new Float64Array(P) };
    let p = isNum(prevClose) ? prevClose : g.open[g.has.indexOf(1)];
    for (let i = 0; i < P; i++) {
      if (g.has[i]) {
        out.open[i] = g.open[i]; out.high[i] = g.high[i]; out.low[i] = g.low[i]; out.close[i] = g.close[i]; out.volume[i] = g.volume[i];
        p = g.close[i];
      } else {
        out.open[i] = out.high[i] = out.low[i] = out.close[i] = p;
      }
    }
    return out;
  }

  /**
   * Bougies 1 min : `days` séances passées (celles disponibles) + séance du jour (minutes closes + en cours).
   * Même format que le simulateur.
   */
  minutes(sym, days = 5) {
    const x = this.get(sym), M = x.ex.sessionMin, slot = x.intra.get(1);
    const pastDays = slot ? [...slot.days.keys()].filter((d) => d < x.clk.today).sort().slice(-days) : [];
    const hasToday = isNum(x.curM.c);
    const total = pastDays.length * M + (hasToday ? x.mN + 1 : 0);
    const out = { open: new Float64Array(total), high: new Float64Array(total), low: new Float64Array(total), close: new Float64Array(total), volume: new Float64Array(total) };
    const dates = [];
    let k = 0, prevC = NaN;
    for (const d of pastDays) {
      const b = this.#filledDay(slot.days.get(d), M, prevC);
      for (const f of ['open', 'high', 'low', 'close', 'volume']) out[f].set(b[f], k);
      prevC = b.close[M - 1];
      k += M;
      dates.push(d);
    }
    const todayFrom = k;
    if (hasToday) {
      for (const f of ['open', 'high', 'low', 'close', 'volume']) out[f].set(x.m[f].subarray(0, x.mN), k);
      k += x.mN;
      const c = x.curM;
      out.open[k] = c.o; out.high[k] = c.h; out.low[k] = c.l; out.close[k] = c.c; out.volume[k] = c.v;
      dates.push(x.clk.today);
    }
    return { ...out, sessionBars: M, todayFrom, dates, partial: true, sessionSec: x.ex.sessionSec };
  }

  /** Bougies intraday natives de `k` minutes (5, 15, 30, 60) : séances passées + séance du jour. */
  bars(sym, k) {
    const x = this.get(sym), M = x.ex.sessionMin, P = Math.ceil(M / k), slot = x.intra.get(k);
    const days = slot ? [...slot.days.keys()].sort() : [];
    const open = x.clk.state === 'OPEN' || x.clk.state === 'BREAK';
    const out = { open: [], high: [], low: [], close: [], volume: [] }, dates = [];
    let prevC = NaN, todayFrom = 0;
    for (const d of days) {
      const b = this.#filledDay(slot.days.get(d), P, prevC);
      let len = P;
      if (d === x.clk.today && open) len = Math.min(P, Math.floor(x.clk.sec / 60 / k) + 1);
      if (d === x.clk.today) todayFrom = out.close.length;
      for (const f of ['open', 'high', 'low', 'close', 'volume']) out[f].push(...b[f].subarray(0, len));
      prevC = b.close[len - 1];
      dates.push(d);
    }
    if (!days.includes(x.clk.today)) todayFrom = out.close.length;
    // dernière bougie : suit le dernier cours
    if (out.close.length && days.at(-1) === x.clk.today && isNum(x.last) && open) {
      const j = out.close.length - 1;
      out.close[j] = x.last;
      out.high[j] = Math.max(out.high[j], x.last);
      out.low[j] = Math.min(out.low[j], x.last);
    }
    return { open: F(out.open), high: F(out.high), low: F(out.low), close: F(out.close), volume: F(out.volume), sessionBars: P, todayFrom, dates, partial: true };
  }

  /** Pas de bougies à la seconde avec des sources gratuites. */
  seconds() {
    return null;
  }

  // ---------------------------------------------------------------- lecture (interface du simulateur)
  /** Demi-fourchette ESTIMÉE (aucune source gratuite ne donne le carnet) : 0,05 % du cours, au moins 1 pas. */
  #halfSpread(x) {
    return Math.max(x.meta.tick, roundTick(x.last * 0.0005, x.meta.tick));
  }

  quote(sym) {
    const x = this.get(sym);
    if (!x) return null;
    const tick = x.meta.tick, last = x.last, hs = isNum(last) ? this.#halfSpread(x) : NaN;
    const qt = x.q.at ? localParts(x.q.at, x.ex.tz) : null;
    return {
      sym, last, prev: x.prev, open: x.open, high: x.high, low: x.low, volume: x.volume, turnover: x.turnover, trades: 0,
      chg: last - x.prev, chgPct: (last / x.prev - 1) * 100, bid: isNum(last) ? roundTick(last - hs, tick) : NaN, ask: isNum(last) ? roundTick(last + hs, tick) : NaN, spreadEstimated: true,
      vwap: x.volume > 0 && x.turnover > 0 ? x.turnover / x.volume : last, buyVol: 0, sellVol: 0, largeBuys: 0, largeSells: 0,
      time: qt ? `${String(Math.floor(qt.min / 60)).padStart(2, '0')}:${String(qt.min % 60).padStart(2, '0')}` : '—', date: x.clk.today, live: x.clk.live, seq: 0,
      quoteAt: x.q.at || null, quoteSession: x.q.session ?? null, source: x.q.source, delayed: true, status: x.status,
    };
  }

  daily(sym) {
    const d = this.get(sym).daily;
    return { dates: d.dates, open: d.open, high: d.high, low: d.low, close: d.close, volume: d.volume };
  }

  tape() {
    return [];
  }

  book() {
    return null;
  }

  step() { /* pas de pas de simulation : les données arrivent des sources */ }

  clockInfo() {
    return Object.values(this.clocks).sort((a, b) => a.ex.order - b.ex.order).map((c) => {
      const hh = String(Math.floor((c.localMin ?? 0) / 60)).padStart(2, '0'), mm = String((c.localMin ?? 0) % 60).padStart(2, '0'), ss = String(c.localSec ?? 0).padStart(2, '0');
      return {
        mic: c.ex.mic, name: c.ex.name, short: c.ex.short, region: c.ex.region, tz: c.ex.tz, date: c.today, time: `${hh}:${mm}:${ss}`, sec: c.sec, sessionSec: c.ex.sessionSec,
        live: c.live, realState: c.state, realLabel: STATE_LABEL[c.state], label: STATE_LABEL[c.state], progress: c.sec / c.ex.sessionSec,
      };
    });
  }

  // ---------------------------------------------------------------- indices
  async refreshIndices() {
    const list = [...this.idx.values()];
    const syms = [...new Set(list.flatMap((i) => i.candidates))];
    for (let i = 0; i < syms.length; i += 20) {
      const m = await this.yahoo.spark(syms.slice(i, i + 20), { range: '1d', interval: '15m' }).catch(() => null);
      if (!m) {
        // spark indisponible : graphique du jour, indice par indice (les principaux)
        for (const ix of list.filter((x) => ['EUROPE', 'XPAR', 'XETR', 'XNYS', 'XNAS', 'XLON', 'MONDE'].includes(x.key))) {
          const r = await this.yahoo.chart(ix.symbol, { range: '1d', interval: '5m', events: false }).catch(() => null);
          if (r?.meta?.price) Object.assign(ix, { last: r.meta.price, prev: r.meta.prevClose ?? ix.prev, at: r.meta.time ?? Date.now() });
        }
        return;
      }
      for (const ix of list) {
        for (const s of ix.candidates) {
          const q = m.get(s);
          if (!q) continue;
          Object.assign(ix, { symbol: s, last: q.price, prev: q.prevClose ?? ix.prev, at: q.time ?? Date.now() });
          break;
        }
      }
    }
  }

  async #indexHistories() {
    for (const ix of this.idx.values()) {
      if (Date.now() - ix.histAt < 20 * 3600_000 && ix.dates.length) continue;
      for (const s of [ix.symbol, ...ix.candidates.filter((c) => c !== ix.symbol)]) {
        try {
          const r = await this.yahoo.chart(s, { range: '5y', interval: '1d', events: false }, { priority: 0 });
          const ref = EXCHANGES[INDEX_SYMBOLS[ix.key].ref ?? ix.key] ?? EXCHANGES.XPAR;
          const d = this.#dailyFromBars({ ex: ref }, r.bars);
          Object.assign(ix, { symbol: s, dates: d.dates, close: F(d.close), histAt: Date.now() });
          if (!isNum(ix.last) && r.meta.price) Object.assign(ix, { last: r.meta.price, prev: r.meta.prevClose ?? d.close.at(-2), at: r.meta.time });
          const file = join(this.dir, 'hist', `${s.replace(/[^\w.^=-]/g, '_')}.json`);
          await writeFile(file, JSON.stringify({ symbol: s, index: ix.key, at: ix.histAt, dates: d.dates, close: d.close })).catch(() => {});
          break;
        } catch (e) {
          this.#error(`indice ${ix.name}`, e);
          if (e.blocked) return;
        }
      }
    }
  }

  /** Indices réels (niveau, variation) + largeur de marché calculée sur les valeurs suivies. */
  indices() {
    const out = [];
    for (const ix of this.idx.values()) {
      const members = ix.key === 'EUROPE' ? this.instruments.filter((x) => x.meta.region === 'Europe') : ix.key === 'MONDE' ? this.instruments : this.byMic.get(ix.key) ?? [];
      const live = members.filter((x) => isNum(x.last) && isNum(x.prev));
      const last = isNum(ix.last) ? ix.last : ix.close.at(-1) ?? NaN, prev = isNum(ix.prev) ? ix.prev : ix.close.at(-2) ?? NaN;
      out.push({ key: ix.key, name: ix.name, symbol: ix.symbol, members: members.length, level: last, prev, chgPct: (last / prev - 1) * 100, up: live.filter((x) => x.last > x.prev).length, down: live.filter((x) => x.last < x.prev).length, real: true, proxy: ix.proxy, at: ix.at || null });
    }
    return out;
  }

  /** Série quotidienne d'un indice (séances terminées). */
  indexDaily(key) {
    const ix = this.idx.get(key) ?? this.idx.get('EUROPE');
    if (!ix) return { dates: [], close: F([]) };
    const ref = EXCHANGES[INDEX_SYMBOLS[ix.key]?.ref ?? ix.key];
    const today = ref ? this.#clock(ref.mic).today : null;
    let n = ix.dates.length;
    while (today && n > 0 && ix.dates[n - 1] >= today) n--;
    return { dates: ix.dates.slice(0, n), close: ix.close.subarray(0, n) };
  }

  // ---------------------------------------------------------------- actualités
  async #refreshFavoriteNews() {
    const hot = this.hotSet();
    const due = hot.find((s) => Date.now() - (this.news.lastSym.get(s) ?? 0) > this.cfg.newsSymMin * 60_000);
    if (due) await this.news.refreshSymbol(due);
  }

  // ---------------------------------------------------------------- préparation à la demande
  /**
   * Garantit les données nécessaires à un écran ou à un calcul : historique quotidien, et bougies
   * intraday si l'unité de temps le demande. Sans effet si tout est déjà frais.
   */
  async prepare(sym, { tf = null, history = true, news = false } = {}) {
    const x = this.get(sym);
    if (!x) return;
    this.touch(sym);
    const jobs = [];
    if (history && (!x.h.dates.length || (Date.now() - x.hist.at > 20 * 3600_000 && !x.dead))) jobs.push(this.loadHistory(x, { priority: 3 }).catch((e) => { if (!x.h.dates.length) throw e; }));
    const k = tf === '1m' || tf === '2m' ? 1 : tf === '5m' ? 5 : tf === '15m' ? 15 : tf === '30m' ? 30 : tf === '1h' || tf === '4h' ? 60 : tf === 'intraday' ? 1 : null;
    if (k) jobs.push(this.loadIntraday(x, k, { maxAgeMs: k === 1 ? 45_000 : 5 * 60_000, priority: 3 }).catch((e) => this.#error(sym, e)));
    if (news) jobs.push(this.news.refreshSymbol(sym).catch(() => 0));
    if (x.q.fetchedAt === 0 && !k) jobs.push(this.#refreshDay(x, '5m', 3).catch(() => {}));
    await Promise.all(jobs);
  }

  /** Fondamentaux à la demande : sources à clé si configurées (sinon données dérivées des cours). */
  async fundamentals(sym) {
    const x = this.get(sym);
    if (!x) return null;
    if (Date.now() - (x.fundAt ?? 0) < 6 * 3600_000) return x.fund;
    x.fundAt = Date.now();
    const parts = [];
    for (const get of [() => this.keyed.finnhubFundamentals(x.meta.yahoo), () => this.keyed.fmpFundamentals(x.meta.yahoo)]) {
      const r = await get().catch((e) => { this.#error(`fondamentaux ${sym}`, e); return null; });
      if (r) parts.push(r);
    }
    for (const r of parts) {
      for (const [k, v] of Object.entries(r)) {
        if (v === null || v === undefined || k === 'source') continue;
        if (k === 'capitalisationM') {
          const ccy = r.devise ?? x.meta.currency;
          const eur = this.fx.toEur(ccy === 'GBP' ? 'GBP' : ccy);
          x.fund.capitalisationMdEur ??= Number(((v * 1e6 * eur) / 1e9).toFixed(1));
          x.capEur ??= v * 1e6 * eur;
        } else if (k === 'rendementDividendePct') {
          x.fund.rendementDividendePct = Number(v.toFixed(2));
          x.fund.rendementSource = r.source;
        } else if (x.fund[k] === null || x.fund[k] === undefined) x.fund[k] = typeof v === 'number' ? Number(v.toFixed(3)) : v;
      }
    }
    if (parts.length) x.fund.source = `${parts.map((p) => p.source).join(' + ')} ; cours et dividendes : Yahoo`;
    if (isNum(x.fund.per) && isNum(x.fund.rendementDividendePct)) x.fund.tauxDistributionPct = Math.round(x.fund.per * x.fund.rendementDividendePct);
    if (isNum(x.fund.beta)) x.beta = x.fund.beta;
    return x.fund;
  }

  // ---------------------------------------------------------------- recherche mondiale
  /** Recherche Yahoo (toutes places) : valeurs non suivies, ajoutables à Bourso. */
  async searchExternal(q) {
    const r = await this.yahoo.search(q, { quotes: 12, news: 0 });
    return r.quotes.filter((s) => ['EQUITY', 'ETF'].includes(s.type)).map((s) => {
      const mic = micOfYahoo(s.symbol, s.exchange);
      const known = this.byYahoo.get(s.symbol);
      return { yahoo: s.symbol, name: s.name, exchange: s.exchDisp ?? s.exchange, mic, supported: Boolean(mic && EXCHANGES[mic]), sym: known?.meta.sym ?? null, type: s.typeDisp ?? s.type, sector: s.sector };
    });
  }

  /** Ajoute une valeur trouvée par la recherche (symbole Yahoo) ; renvoie son symbole Bourso. */
  async addSymbol({ yahoo, name = null, exchange = null, sector = null }) {
    const ys = String(yahoo ?? '').trim().toUpperCase();
    if (!/^[A-Z0-9^.=&-]{1,20}$/.test(ys)) throw new Error('symbole invalide');
    if (this.byYahoo.has(ys)) return this.byYahoo.get(ys).meta.sym;
    const mic = micOfYahoo(ys, exchange);
    if (!mic || !EXCHANGES[mic]) throw new Error(`place non prise en charge pour ${ys}`);
    // vérification : la valeur existe et cote
    const r = await this.yahoo.chart(ys, { range: '5d', interval: '1d', events: false }, { priority: 3 });
    if (!r.meta.price) throw new Error(`${ys} : aucune cotation chez Yahoo`);
    const ex = EXCHANGES[mic], code = codeOfYahoo(ys, mic);
    const sectorKey = SECTOR_OF[sector] ?? 'HOLD';
    const meta = {
      sym: `${code.replace(/\s+/g, '-')}:${mic}`, code, name: name || r.meta.name || ys, mic, exchange: ex.name, exShort: ex.short, country: ex.country, countryName: ex.countryName,
      region: ex.region, currency: ccyOfYahoo(r.meta.currency) ?? ex.ccy, sector: SECTORS[sectorKey][0], sectorKey, price: r.meta.price, vol: SECTORS[sectorKey][1],
      tick: tickFor(ex.tickRegime, r.meta.price), isin: '', yahoo: ys, added: true,
    };
    if (this.bySym.has(meta.sym)) meta.sym = `${code}-${ys.replace(/[^A-Z0-9]/g, '')}:${mic}`;
    const x = this.#addInst(meta);
    this.#applyQuote(x, r.meta, 'Yahoo');
    await this.#saveExtra();
    this.loadHistory(x, { priority: 3 }).catch((e) => this.#error(`historique ${meta.sym}`, e));
    this.emit('universe', meta.sym);
    return meta.sym;
  }

  async #saveExtra() {
    const extra = this.instruments.filter((x) => x.meta.added).map((x) => ({ ...x.meta }));
    await mkdir(this.dir, { recursive: true }).catch(() => {});
    await writeFile(join(this.dir, 'universe-extra.json'), JSON.stringify(extra, null, 1));
  }

  // ---------------------------------------------------------------- état des sources
  status() {
    const n = this.instruments.length;
    const withQuote = this.instruments.filter((x) => x.q.fetchedAt > 0).length, cached = this.instruments.filter((x) => isNum(x.last)).length;
    const withHist = this.instruments.filter((x) => x.daily.n >= 60).length, dead = this.instruments.filter((x) => x.dead);
    const fresh = this.instruments.filter((x) => x.q.fetchedAt > Date.now() - 15 * 60_000).length;
    return {
      modeLabel: 'réel', intensity: this.intensity, intensityLabel: this.cfg.label, instruments: n, quotesLive: withQuote, quotesKnown: cached, quotesFresh15min: fresh, histories: withHist,
      historyQueue: this.histQueue.length, notFound: dead.map((x) => ({ sym: x.meta.sym, yahoo: x.meta.yahoo, error: x.error })), hot: this.hotSet(),
      indices: [...this.idx.values()].map((i) => ({ key: i.key, name: i.name, symbol: i.symbol, ok: isNum(i.last), history: i.dates.length })),
      fx: this.fx.info(), news: this.news.info(), keys: this.keyed.info(), sources: this.net.info(), errors: this.errors.slice(-15).reverse(),
      spark: this.yahoo.sparkBroken ? 'indisponible (cotations une par une)' : this.yahoo.sparkPath,
      yahooPausedUntil: this.net.pausedUntil(YH) || null,
    };
  }
}

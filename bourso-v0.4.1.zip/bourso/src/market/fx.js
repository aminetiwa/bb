// ============================================================================
//  BOURSO :: market/fx.js — taux de change SIMULÉS (conversion des portefeuilles en euros).
//  Niveaux de départ indicatifs (ordre de grandeur), marche aléatoire à faible volatilité.
// ============================================================================
import { Rng } from '../core/quant/numeric.js';

/** Unités de devise pour 1 euro (indicatif). */
const PER_EUR = { EUR: 1, USD: 1.1, GBP: 0.85, CHF: 0.94, SEK: 11.3, DKK: 7.46, NOK: 11.6, PLN: 4.3, CAD: 1.5, JPY: 160, HKD: 8.6, CNY: 7.9,
  KRW: 1500, TWD: 35, INR: 92, AUD: 1.65, SGD: 1.46, BRL: 6, MXN: 20, ZAR: 20 };
const VOL = { DKK: 0.005, CHF: 0.05, GBP: 0.06, HKD: 0.07 };

export class FxEngine {
  constructor(seed = 1) {
    this.rng = new Rng(seed ^ 0x5bd1e995);
    this.rates = { ...PER_EUR };
    this.open = { ...PER_EUR };
  }
  /** Une seconde de marché des changes. */
  tick() {
    for (const k of Object.keys(this.rates)) {
      if (k === 'EUR') continue;
      const sd = (VOL[k] ?? 0.08) / Math.sqrt(252 * 86_400);
      this.rates[k] *= Math.exp(sd * this.rng.normal());
    }
  }
  /** Valeur en euros d'1 unité de cotation (GBX, ZAC : centièmes). */
  toEur(ccy) {
    if (ccy === 'GBX') return 1 / this.rates.GBP / 100;
    if (ccy === 'ZAC') return 1 / this.rates.ZAR / 100;
    return 1 / (this.rates[ccy] ?? 1);
  }
  list() {
    return Object.keys(this.rates).filter((k) => k !== 'EUR').map((k) => ({ pair: `EUR/${k}`, rate: this.rates[k], chgPct: (this.rates[k] / this.open[k] - 1) * 100 }));
  }
}

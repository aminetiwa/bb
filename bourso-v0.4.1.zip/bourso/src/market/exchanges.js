// ============================================================================
//  BOURSO :: market/exchanges.js — places boursières mondiales : fuseau, horaires, pauses,
//  devise, jours fériés (calendriers simplifiés mais fidèles aux règles principales),
//  pas de cotation et indice phare. Europe en tête (ordre d'affichage).
// ============================================================================

/** Ordre des régions dans l'interface : l'Europe d'abord. */
export const REGIONS = ['Europe', 'Amérique du Nord', 'Asie-Pacifique', 'Amérique latine', 'Afrique & Moyen-Orient'];

// [mic, nom, nom court, pays, nom du pays, région, fuseau, devise, ouverture, clôture, pauses, calendrier, pas, indice]
const RAW = [
  ['XPAR', 'Euronext Paris', 'Paris', 'FR', 'France', 'Europe', 'Europe/Paris', 'EUR', '09:00', '17:30', [], 'euronext', 'mifid', 'CAC 40'],
  ['XETR', 'Xetra (Francfort)', 'Francfort', 'DE', 'Allemagne', 'Europe', 'Europe/Berlin', 'EUR', '09:00', '17:30', [], 'xetra', 'mifid', 'DAX'],
  ['XAMS', 'Euronext Amsterdam', 'Amsterdam', 'NL', 'Pays-Bas', 'Europe', 'Europe/Amsterdam', 'EUR', '09:00', '17:30', [], 'euronext', 'mifid', 'AEX'],
  ['XBRU', 'Euronext Bruxelles', 'Bruxelles', 'BE', 'Belgique', 'Europe', 'Europe/Brussels', 'EUR', '09:00', '17:30', [], 'euronext', 'mifid', 'BEL 20'],
  ['XMIL', 'Euronext Milan', 'Milan', 'IT', 'Italie', 'Europe', 'Europe/Rome', 'EUR', '09:00', '17:30', [], 'italy', 'mifid', 'FTSE MIB'],
  ['XMAD', 'BME Madrid', 'Madrid', 'ES', 'Espagne', 'Europe', 'Europe/Madrid', 'EUR', '09:00', '17:30', [], 'euronext', 'mifid', 'IBEX 35'],
  ['XLIS', 'Euronext Lisbonne', 'Lisbonne', 'PT', 'Portugal', 'Europe', 'Europe/Lisbon', 'EUR', '08:00', '16:30', [], 'euronext', 'mifid', 'PSI'],
  ['XDUB', 'Euronext Dublin', 'Dublin', 'IE', 'Irlande', 'Europe', 'Europe/Dublin', 'EUR', '08:00', '16:30', [], 'lse', 'mifid', 'ISEQ 20'],
  ['XSWX', 'SIX Swiss Exchange', 'Zurich', 'CH', 'Suisse', 'Europe', 'Europe/Zurich', 'CHF', '09:00', '17:30', [], 'six', 'mifid', 'SMI'],
  ['XLON', 'London Stock Exchange', 'Londres', 'GB', 'Royaume-Uni', 'Europe', 'Europe/London', 'GBX', '08:00', '16:30', [], 'lse', 'mifid', 'FTSE 100'],
  ['XSTO', 'Nasdaq Stockholm', 'Stockholm', 'SE', 'Suède', 'Europe', 'Europe/Stockholm', 'SEK', '09:00', '17:30', [], 'nordic', 'mifid', 'OMXS30'],
  ['XCSE', 'Nasdaq Copenhague', 'Copenhague', 'DK', 'Danemark', 'Europe', 'Europe/Copenhagen', 'DKK', '09:00', '17:00', [], 'nordic', 'mifid', 'OMXC25'],
  ['XHEL', 'Nasdaq Helsinki', 'Helsinki', 'FI', 'Finlande', 'Europe', 'Europe/Helsinki', 'EUR', '10:00', '18:30', [], 'nordic', 'mifid', 'OMXH25'],
  ['XOSL', 'Oslo Børs', 'Oslo', 'NO', 'Norvège', 'Europe', 'Europe/Oslo', 'NOK', '09:00', '16:20', [], 'nordic', 'mifid', 'OBX'],
  ['XWBO', 'Wiener Börse', 'Vienne', 'AT', 'Autriche', 'Europe', 'Europe/Vienna', 'EUR', '09:00', '17:30', [], 'xetra', 'mifid', 'ATX'],
  ['XWAR', 'Bourse de Varsovie', 'Varsovie', 'PL', 'Pologne', 'Europe', 'Europe/Warsaw', 'PLN', '09:00', '17:00', [], 'euronext', 'mifid', 'WIG20'],
  ['XATH', 'Bourse d\'Athènes', 'Athènes', 'GR', 'Grèce', 'Europe', 'Europe/Athens', 'EUR', '10:00', '17:20', [], 'euronext', 'mifid', 'ATHEX'],
  ['XNYS', 'New York Stock Exchange', 'New York', 'US', 'États-Unis', 'Amérique du Nord', 'America/New_York', 'USD', '09:30', '16:00', [], 'us', 'cent', 'S&P 500'],
  ['XNAS', 'Nasdaq', 'Nasdaq', 'US', 'États-Unis', 'Amérique du Nord', 'America/New_York', 'USD', '09:30', '16:00', [], 'us', 'cent', 'Nasdaq 100'],
  ['XTSE', 'Bourse de Toronto', 'Toronto', 'CA', 'Canada', 'Amérique du Nord', 'America/Toronto', 'CAD', '09:30', '16:00', [], 'canada', 'cent', 'S&P/TSX 60'],
  ['XTKS', 'Bourse de Tokyo', 'Tokyo', 'JP', 'Japon', 'Asie-Pacifique', 'Asia/Tokyo', 'JPY', '09:00', '15:30', [['11:30', '12:30']], 'japan', 'tokyo', 'Nikkei 225'],
  ['XHKG', 'Bourse de Hong Kong', 'Hong Kong', 'HK', 'Hong Kong', 'Asie-Pacifique', 'Asia/Hong_Kong', 'HKD', '09:30', '16:00', [['12:00', '13:00']], 'hk', 'hk', 'Hang Seng'],
  ['XSHG', 'Bourse de Shanghai / Shenzhen', 'Shanghai', 'CN', 'Chine', 'Asie-Pacifique', 'Asia/Shanghai', 'CNY', '09:30', '15:00', [['11:30', '13:00']], 'china', 'cent', 'CSI 300'],
  ['XKRX', 'Korea Exchange', 'Séoul', 'KR', 'Corée du Sud', 'Asie-Pacifique', 'Asia/Seoul', 'KRW', '09:00', '15:30', [], 'default', 'korea', 'KOSPI'],
  ['XTAI', 'Bourse de Taïwan', 'Taipei', 'TW', 'Taïwan', 'Asie-Pacifique', 'Asia/Taipei', 'TWD', '09:00', '13:30', [], 'default', 'taiwan', 'TAIEX'],
  ['XNSE', 'National Stock Exchange of India', 'Bombay', 'IN', 'Inde', 'Asie-Pacifique', 'Asia/Kolkata', 'INR', '09:15', '15:30', [], 'default', 'india', 'Nifty 50'],
  ['XASX', 'Australian Securities Exchange', 'Sydney', 'AU', 'Australie', 'Asie-Pacifique', 'Australia/Sydney', 'AUD', '10:00', '16:00', [], 'australia', 'asx', 'S&P/ASX 200'],
  ['XSES', 'Singapore Exchange', 'Singapour', 'SG', 'Singapour', 'Asie-Pacifique', 'Asia/Singapore', 'SGD', '09:00', '17:00', [['12:00', '13:00']], 'default', 'cent', 'STI'],
  ['BVMF', 'B3 (São Paulo)', 'São Paulo', 'BR', 'Brésil', 'Amérique latine', 'America/Sao_Paulo', 'BRL', '10:00', '17:00', [], 'default', 'cent', 'Ibovespa'],
  ['XMEX', 'Bourse de Mexico', 'Mexico', 'MX', 'Mexique', 'Amérique latine', 'America/Mexico_City', 'MXN', '08:30', '15:00', [], 'default', 'cent', 'S&P/BMV IPC'],
  ['XJSE', 'Bourse de Johannesburg', 'Johannesburg', 'ZA', 'Afrique du Sud', 'Afrique & Moyen-Orient', 'Africa/Johannesburg', 'ZAC', '09:00', '17:00', [], 'default', 'unit', 'JSE Top 40'],
];

const minutes = (hhmm) => {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
};

export const EXCHANGES = Object.fromEntries(RAW.map(([mic, name, short, country, countryName, region, tz, ccy, open, close, breaks, cal, tick, index], order) => {
  const o = minutes(open), c = minutes(close);
  const br = breaks.map(([a, b]) => [minutes(a), minutes(b)]);
  const sessionMin = c - o - br.reduce((s, [a, b]) => s + (b - a), 0);
  return [mic, { mic, name, short, country, countryName, region, tz, ccy, open, close, openMin: o, closeMin: c, breaks: br, sessionMin, sessionSec: sessionMin * 60, calendar: cal, tickRegime: tick, index, order }];
}));

/** Devise d'affichage (GBX = pence, ZAC = cents sud-africains). */
export const CURRENCY = {
  EUR: { label: '€', name: 'euro', perUnit: 1 }, USD: { label: '$', name: 'dollar US', perUnit: 1 }, GBX: { label: 'p', name: 'pence', perUnit: 100, base: 'GBP' },
  CHF: { label: 'CHF', name: 'franc suisse', perUnit: 1 }, SEK: { label: 'SEK', name: 'couronne suédoise', perUnit: 1 }, DKK: { label: 'DKK', name: 'couronne danoise', perUnit: 1 },
  NOK: { label: 'NOK', name: 'couronne norvégienne', perUnit: 1 }, PLN: { label: 'PLN', name: 'zloty', perUnit: 1 }, CAD: { label: 'CA$', name: 'dollar canadien', perUnit: 1 },
  JPY: { label: '¥', name: 'yen', perUnit: 1 }, HKD: { label: 'HK$', name: 'dollar de Hong Kong', perUnit: 1 }, CNY: { label: 'CNY', name: 'yuan', perUnit: 1 },
  KRW: { label: '₩', name: 'won', perUnit: 1 }, TWD: { label: 'NT$', name: 'dollar de Taïwan', perUnit: 1 }, INR: { label: '₹', name: 'roupie', perUnit: 1 },
  AUD: { label: 'A$', name: 'dollar australien', perUnit: 1 }, SGD: { label: 'S$', name: 'dollar de Singapour', perUnit: 1 }, BRL: { label: 'R$', name: 'réal', perUnit: 1 },
  MXN: { label: 'MX$', name: 'peso mexicain', perUnit: 1 }, ZAC: { label: 'ZAc', name: 'cents sud-africains', perUnit: 100, base: 'ZAR' },
};

// ---------------------------------------------------------------- pas de cotation

const MIFID = [[1, 0.0005], [2, 0.0005], [5, 0.001], [10, 0.002], [20, 0.002], [50, 0.005], [100, 0.01], [200, 0.02], [500, 0.05], [1000, 0.1], [2000, 0.2], [5000, 0.5], [Infinity, 1]];
const TABLES = {
  mifid: MIFID,
  cent: [[Infinity, 0.01]],
  unit: [[Infinity, 1]],
  tokyo: [[1000, 0.1], [3000, 0.5], [10000, 1], [30000, 5], [100000, 10], [Infinity, 50]],
  hk: [[0.5, 0.005], [10, 0.01], [20, 0.02], [100, 0.05], [200, 0.1], [500, 0.2], [1000, 0.5], [2000, 1], [Infinity, 2]],
  korea: [[2000, 1], [5000, 5], [20000, 10], [50000, 50], [200000, 100], [500000, 500], [Infinity, 1000]],
  taiwan: [[10, 0.01], [50, 0.05], [100, 0.1], [500, 0.5], [1000, 1], [Infinity, 5]],
  india: [[Infinity, 0.05]],
  asx: [[0.1, 0.001], [2, 0.005], [Infinity, 0.01]],
};
/** Pas de cotation selon le prix (tables simplifiées : MiFID II bande la plus liquide, TSE TOPIX100, HKEX…). */
export function tickFor(regime, price) {
  for (const [lim, t] of TABLES[regime] ?? TABLES.cent) if (price < lim) return t;
  return 0.01;
}

// ---------------------------------------------------------------- jours fériés

/** Dimanche de Pâques (algorithme de Meeus/Jones/Butcher), calendrier grégorien. */
export function easter(year) {
  const a = year % 19, b = Math.floor(year / 100), c = year % 100, d = Math.floor(b / 4), e = b % 4;
  const f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31), day = ((h + l - 7 * m + 114) % 31) + 1;
  return Date.UTC(year, month - 1, day);
}
const DAY = 86_400_000;
const ymd = (t) => new Date(t).toISOString().slice(0, 10);
const fixed = (y, m, d) => Date.UTC(y, m - 1, d);
/** n-ième jour de semaine `wd` (0 = dimanche) du mois ; n = −1 : le dernier. */
function nthWeekday(y, m, wd, n) {
  if (n > 0) {
    const first = new Date(Date.UTC(y, m - 1, 1)).getUTCDay();
    return Date.UTC(y, m - 1, 1 + ((wd - first + 7) % 7) + (n - 1) * 7);
  }
  const lastDay = new Date(Date.UTC(y, m, 0)), dw = lastDay.getUTCDay();
  return lastDay.getTime() - ((dw - wd + 7) % 7) * DAY;
}
/** Report d'un férié tombant un week-end (samedi → vendredi, dimanche → lundi). */
const observedUS = (t) => {
  const dw = new Date(t).getUTCDay();
  return dw === 6 ? t - DAY : dw === 0 ? t + DAY : t;
};
const observedUK = (t) => {
  const dw = new Date(t).getUTCDay();
  return dw === 6 ? t + 2 * DAY : dw === 0 ? t + DAY : t;
};

const RULES = {
  euronext: (y) => { const e = easter(y); return [fixed(y, 1, 1), e - 2 * DAY, e + DAY, fixed(y, 5, 1), fixed(y, 12, 25), fixed(y, 12, 26)]; },
  xetra: (y) => { const e = easter(y); return [fixed(y, 1, 1), e - 2 * DAY, e + DAY, fixed(y, 5, 1), fixed(y, 12, 24), fixed(y, 12, 25), fixed(y, 12, 26), fixed(y, 12, 31)]; },
  italy: (y) => { const e = easter(y); return [fixed(y, 1, 1), e - 2 * DAY, e + DAY, fixed(y, 5, 1), fixed(y, 8, 15), fixed(y, 12, 24), fixed(y, 12, 25), fixed(y, 12, 26), fixed(y, 12, 31)]; },
  six: (y) => { const e = easter(y); return [fixed(y, 1, 1), fixed(y, 1, 2), e - 2 * DAY, e + DAY, e + 39 * DAY, e + 50 * DAY, fixed(y, 5, 1), fixed(y, 8, 1), fixed(y, 12, 24), fixed(y, 12, 25), fixed(y, 12, 26), fixed(y, 12, 31)]; },
  lse: (y) => {
    const e = easter(y);
    const xmas = fixed(y, 12, 25), dw = new Date(xmas).getUTCDay();
    const boxing = dw === 5 ? xmas + 3 * DAY : dw === 6 ? xmas + 3 * DAY : dw === 0 ? xmas + 2 * DAY : xmas + DAY;
    return [observedUK(fixed(y, 1, 1)), e - 2 * DAY, e + DAY, nthWeekday(y, 5, 1, 1), nthWeekday(y, 5, 1, -1), nthWeekday(y, 8, 1, -1), observedUK(xmas), boxing];
  },
  nordic: (y) => { const e = easter(y); return [fixed(y, 1, 1), e - 2 * DAY, e + DAY, e + 39 * DAY, fixed(y, 5, 1), fixed(y, 6, 6), fixed(y, 12, 24), fixed(y, 12, 25), fixed(y, 12, 26), fixed(y, 12, 31)]; },
  us: (y) => {
    const e = easter(y);
    return [observedUS(fixed(y, 1, 1)), nthWeekday(y, 1, 1, 3), nthWeekday(y, 2, 1, 3), e - 2 * DAY, nthWeekday(y, 5, 1, -1), observedUS(fixed(y, 6, 19)),
      observedUS(fixed(y, 7, 4)), nthWeekday(y, 9, 1, 1), nthWeekday(y, 11, 4, 4), observedUS(fixed(y, 12, 25))];
  },
  canada: (y) => {
    const e = easter(y), may25 = fixed(y, 5, 25), dw = new Date(may25).getUTCDay();
    const victoria = may25 - ((dw + 6) % 7 || 7) * DAY;
    return [observedUS(fixed(y, 1, 1)), nthWeekday(y, 2, 1, 3), e - 2 * DAY, victoria, observedUS(fixed(y, 7, 1)), nthWeekday(y, 8, 1, 1),
      nthWeekday(y, 9, 1, 1), nthWeekday(y, 10, 1, 2), observedUS(fixed(y, 12, 25)), observedUK(fixed(y, 12, 26))];
  },
  japan: (y) => [fixed(y, 1, 1), fixed(y, 1, 2), fixed(y, 1, 3), nthWeekday(y, 1, 1, 2), fixed(y, 2, 11), fixed(y, 2, 23), fixed(y, 3, 20), fixed(y, 4, 29),
    fixed(y, 5, 3), fixed(y, 5, 4), fixed(y, 5, 5), nthWeekday(y, 7, 1, 3), fixed(y, 8, 11), nthWeekday(y, 9, 1, 3), fixed(y, 9, 23), nthWeekday(y, 10, 1, 2),
    fixed(y, 11, 3), fixed(y, 11, 23), fixed(y, 12, 31)],
  hk: (y) => { const e = easter(y); return [fixed(y, 1, 1), e - 2 * DAY, e + DAY, fixed(y, 5, 1), fixed(y, 7, 1), fixed(y, 10, 1), fixed(y, 12, 25), fixed(y, 12, 26)]; },
  china: (y) => [fixed(y, 1, 1), ...[1, 2, 3, 4, 5].map((d) => fixed(y, 5, d)), ...[1, 2, 3, 4, 5, 6, 7].map((d) => fixed(y, 10, d))],
  australia: (y) => { const e = easter(y); return [fixed(y, 1, 1), fixed(y, 1, 26), e - 2 * DAY, e + DAY, fixed(y, 4, 25), nthWeekday(y, 6, 1, 2), fixed(y, 12, 25), fixed(y, 12, 26)]; },
  default: (y) => [fixed(y, 1, 1), fixed(y, 12, 25)],
};

const holidayCache = new Map();
/** Ensemble des jours fériés (AAAA-MM-JJ) d'un calendrier pour une année. */
export function holidays(cal, year) {
  const key = `${cal}:${year}`;
  if (!holidayCache.has(key)) holidayCache.set(key, new Set((RULES[cal] ?? RULES.default)(year).map(ymd)));
  return holidayCache.get(key);
}

/** Jour ouvré pour une place (date UTC à midi). */
export function isTradingDay(ex, t) {
  const d = new Date(t), dw = d.getUTCDay();
  if (dw === 0 || dw === 6) return false;
  return !holidays(ex.calendar, d.getUTCFullYear()).has(ymd(t));
}

/** Les `count` dernières séances (dates AAAA-MM-JJ) jusqu'à `todayYmd` exclu. */
export function pastSessions(ex, todayYmd, count) {
  const out = [];
  let t = Date.parse(`${todayYmd}T12:00:00Z`) - DAY;
  while (out.length < count) {
    if (isTradingDay(ex, t)) out.push(ymd(t));
    t -= DAY;
  }
  return out.reverse();
}
/** Les `count` prochaines séances à partir de `fromYmd` inclus. */
export function nextSessions(ex, fromYmd, count) {
  const out = [];
  let t = Date.parse(`${fromYmd}T12:00:00Z`);
  while (out.length < count) {
    if (isTradingDay(ex, t)) out.push(ymd(t));
    t += DAY;
  }
  return out;
}

// ---------------------------------------------------------------- heure locale, état de séance

const fmtCache = new Map();
function partsIn(tz, ms) {
  if (!fmtCache.has(tz)) {
    fmtCache.set(tz, new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }));
  }
  const p = Object.fromEntries(fmtCache.get(tz).formatToParts(new Date(ms)).map((x) => [x.type, x.value]));
  return { ymd: `${p.year}-${p.month}-${p.day}`, min: +p.hour * 60 + +p.minute, sec: +p.second };
}

/** Seconde de séance (0 … sessionSec) correspondant à une minute locale (pauses exclues). */
export function sessionSecondOf(ex, localMin, localSec = 0) {
  let m = Math.min(Math.max(localMin, ex.openMin), ex.closeMin);
  let off = m - ex.openMin;
  for (const [a, b] of ex.breaks) {
    if (m >= b) off -= b - a;
    else if (m > a) off -= m - a;
  }
  return Math.max(0, Math.min(ex.sessionSec, off * 60 + (localMin >= ex.openMin && localMin < ex.closeMin ? localSec : 0)));
}

/** Heure locale « HH:MM(:SS) » d'une seconde de séance (pauses réinsérées). */
export function localTimeOf(ex, sec, withSeconds = true) {
  let m = ex.openMin + Math.floor(sec / 60);
  for (const [a, b] of ex.breaks) if (m >= a) m += b - a;
  const s = Math.floor(sec % 60);
  const hh = String(Math.floor(m / 60)).padStart(2, '0'), mm = String(m % 60).padStart(2, '0');
  return withSeconds ? `${hh}:${mm}:${String(s).padStart(2, '0')}` : `${hh}:${mm}`;
}

/**
 * État réel d'une place à l'instant `ms` : 'OPEN', 'BREAK', 'PRE' (avant ouverture), 'POST' (après
 * clôture), 'CLOSED' (week-end / férié), avec l'heure locale et la seconde de séance.
 */
export function marketState(ex, ms = Date.now()) {
  const p = partsIn(ex.tz, ms);
  const trading = isTradingDay(ex, Date.parse(`${p.ymd}T12:00:00Z`));
  let state = 'CLOSED';
  if (trading) {
    if (p.min < ex.openMin) state = 'PRE';
    else if (p.min >= ex.closeMin) state = 'POST';
    else state = ex.breaks.some(([a, b]) => p.min >= a && p.min < b) ? 'BREAK' : 'OPEN';
  }
  return { state, localYmd: p.ymd, localMin: p.min, localSec: p.sec, trading, sessionSec: sessionSecondOf(ex, p.min, p.sec) };
}

export const STATE_LABEL = { OPEN: 'Séance continue', BREAK: 'Pause déjeuner', PRE: 'Avant l\'ouverture', POST: 'Clôturée', CLOSED: 'Fermée (week-end / férié)' };

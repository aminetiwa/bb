// ============================================================================
//  BOURSO :: market/gen.js — générateurs d'historiques DÉTERMINISTES et COHÉRENTS.
//
//  Hiérarchie : quotidien (5 ans) → minutes → secondes. Chaque niveau fin est construit À
//  L'INTÉRIEUR des bougies du niveau supérieur (même ouverture, plus haut, plus bas, clôture,
//  volume total) par une marche aléatoire « remappée » : passer d'une unité à l'autre ne crée
//  jamais d'incohérence. Les graines dépendent du titre et de la date, pas de l'ordre des appels.
//
//  Quotidien : modèle à facteurs (monde → région → secteur) + bruit propre GARCH(1,1) + sauts
//  de publications : corrélations, bêtas et grappes de volatilité réalistes.
// ============================================================================
import { Rng, hash32, roundTick, floorTick, ceilTick, decimalsOf } from '../core/quant/numeric.js';

/** Profil en U de l'activité intraday (fraction de séance x ∈ [0, 1]). */
export const uShape = (x) => 1 + 1.6 * Math.exp(-x * 9) + 1.1 * Math.exp(-(1 - x) * 11);

/** Jours de semaine (lundi-vendredi) entre deux dates incluses, en AAAA-MM-JJ. */
export function weekdays(fromYmd, toYmd) {
  const out = [];
  for (let t = Date.parse(`${fromYmd}T12:00:00Z`), end = Date.parse(`${toYmd}T12:00:00Z`); t <= end; t += 86_400_000) {
    const dw = new Date(t).getUTCDay();
    if (dw !== 0 && dw !== 6) out.push(new Date(t).toISOString().slice(0, 10));
  }
  return out;
}

/**
 * Séries de facteurs quotidiennes (rendements log) sur le calendrier des jours de semaine :
 * monde (GARCH), régions (monde + propre), secteurs. Partagées par toutes les valeurs.
 */
/**
 * Dérive annuelle (log) visée par région sur l'historique simulé. La moyenne empirique du facteur
 * monde et des bruits régionaux est retirée puis remplacée par cette dérive : sans cela, le hasard
 * d'une graine peut produire un marché mondial en chute de 40 % sur 5 ans, peu plausible.
 * La volatilité, les grappes de volatilité (GARCH) et les krachs sont, eux, conservés.
 */
// Facteurs communs (écarts-types quotidiens) : monde (GARCH), régions = 0,75 × monde + bruit régional,
// secteurs (GARCH). Variance d'un facteur régional ≈ 0,75²·1,05² + 0,55² ≈ (0,96 %)² par séance (≈ 15 %/an).
const WORLD_SD = 0.0105, WORLD_LOAD = 0.75, REGION_SD = 0.0055, SECTOR_SD = 0.006;
const REGION_VAR = WORLD_LOAD ** 2 * WORLD_SD ** 2 + REGION_SD ** 2;
export const REGION_DRIFT = { Europe: 0.065, 'Amérique du Nord': 0.09, 'Asie-Pacifique': 0.05, 'Amérique latine': 0.055, 'Afrique & Moyen-Orient': 0.05 };

const demean = (a) => {
  let m = 0;
  for (let i = 0; i < a.length; i++) m += a[i];
  m /= a.length || 1;
  for (let i = 0; i < a.length; i++) a[i] -= m;
  return a;
};

export function buildFactors(days, regions, sectors, seed) {
  const n = days.length, idx = new Map(days.map((d, i) => [d, i]));
  const rg = new Rng(hash32(`monde:${seed}`)), world = new Float64Array(n);
  let h = WORLD_SD ** 2;
  for (let i = 0; i < n; i++) {
    const e = Math.sqrt(h) * rg.normal();
    world[i] = e;
    h = WORLD_SD ** 2 * 0.03 + 0.09 * e * e + 0.88 * h;
  }
  demean(world);
  const region = {}, sector = {};
  for (const r of regions) {
    const rr = new Rng(hash32(`region:${r}:${seed}`)), a = new Float64Array(n);
    for (let i = 0; i < n; i++) a[i] = WORLD_LOAD * world[i] + REGION_SD * rr.normal();
    demean(a);
    const drift = (REGION_DRIFT[r] ?? 0.06) / 252;
    for (let i = 0; i < n; i++) a[i] += drift;
    region[r] = a;
  }
  for (const s of sectors) {
    const rs = new Rng(hash32(`secteur:${s}:${seed}`)), a = new Float64Array(n);
    let hs = SECTOR_SD ** 2;
    for (let i = 0; i < n; i++) {
      const e = Math.sqrt(hs) * rs.normal();
      a[i] = e;
      hs = SECTOR_SD ** 2 * 0.04 + 0.08 * e * e + 0.88 * hs;
    }
    demean(a);
    const tilt = (0.03 * rs.normal()) / 252; // écart de performance propre au secteur (±3 %/an)
    for (let i = 0; i < n; i++) a[i] += tilt;
    sector[s] = a;
  }
  return { days, idx, world, region, sector };
}

/** Somme des rendements de facteur sur les jours de semaine ]prev, cur] (les fériés s'accumulent). */
function factorSum(series, F, prevYmd, curYmd) {
  const a = prevYmd ? F.idx.get(prevYmd) + 1 : F.idx.get(curYmd), b = F.idx.get(curYmd);
  let s = 0;
  for (let i = Math.max(0, a); i <= b; i++) s += series[i];
  return s;
}

/**
 * Historique quotidien d'une valeur sur ses dates de séance (les plus anciennes d'abord).
 * La dernière clôture tombe sur `lastClose` (déjà sur la grille du pas de cotation).
 * O et C sont toujours STRICTEMENT à l'intérieur de [L, H] (au moins 1 pas) : condition
 * nécessaire pour reconstruire les minutes à l'intérieur de la bougie.
 */
export function genDaily(meta, dates, F, { seed, lastClose, adv }) {
  const n = dates.length, rng = new Rng(hash32(`quotidien:${meta.sym}:${seed}`)), tick = meta.tick;
  const sd = meta.vol / Math.sqrt(252);
  // Bêta cohérent avec la volatilité (comme sur les vrais marchés : les valeurs agitées ont des bêtas
  // élevés) : part de variance expliquée par la région R² ∈ [0,28 ; 0,52] → β = √R² · σ / σ_région.
  const r2 = 0.28 + 0.24 * rng.next(), beta = Math.min(2.2, Math.max(0.3, (Math.sqrt(r2) * sd) / Math.sqrt(REGION_VAR)));
  let gamma = 0.6 + 0.6 * rng.next();
  // la part systématique totale reste ≤ 80 % de la variance (le reste : spécifique à la valeur)
  const regVar = beta ** 2 * REGION_VAR, room = Math.max(0, 0.8 * sd * sd - regVar);
  if (gamma ** 2 * SECTOR_SD ** 2 > room) gamma = Math.sqrt(room) / SECTOR_SD;
  const sysVar = regVar + gamma ** 2 * SECTOR_SD ** 2;
  // variance apportée par les ~4 publications annuelles (sauts de 2,6 σ) : déduite du spécifique
  const jumpVar = (4 / 252) * (2.6 * sd) ** 2;
  const idio = Math.sqrt(Math.max(0.2 * sd * sd, sd * sd - sysVar - jumpVar));
  const reg = F.region[meta.region], sec = F.sector[meta.sectorKey];
  const r = new Float64Array(n), gap = new Float64Array(n), jump = new Uint8Array(n);
  let h = idio * idio;
  // ~4 publications par an : sauts
  const earnPhase = rng.int(63);
  // Écart d'ouverture (nuit) indépendant de la séance : pour une part f de la variance prise la nuit,
  // g = f·x + √(f(1−f)·Var x)·z donne Var g = f·Var x et Cov(g, x − g) = 0 (comme sur les vrais marchés).
  const F_NIGHT = 0.25, F_JUMP = 0.85;
  for (let i = 0; i < n; i++) {
    const hUsed = h, e = Math.sqrt(h) * rng.normal();
    h = idio * idio * 0.03 + 0.06 * e * e + 0.91 * h;
    let x = beta * factorSum(reg, F, dates[i - 1], dates[i]) + gamma * factorSum(sec, F, dates[i - 1], dates[i]) + e;
    let g = F_NIGHT * x + Math.sqrt(F_NIGHT * (1 - F_NIGHT) * (sysVar + hUsed)) * rng.normal();
    if ((i + earnPhase) % 63 === 0 && i > 0) {
      const J = rng.normal() * sd * 2.6; // publication de résultats : surtout avant l'ouverture
      x += J;
      g += F_JUMP * J + Math.sqrt(F_JUMP * (1 - F_JUMP)) * sd * 2.6 * rng.normal();
      jump[i] = 1;
    }
    r[i] = x;
    gap[i] = g;
  }
  // niveau : on remonte depuis la dernière clôture
  const logC = new Float64Array(n);
  logC[n - 1] = Math.log(lastClose);
  for (let i = n - 1; i > 0; i--) logC[i - 1] = logC[i] - r[i];
  const o = new Float64Array(n), hi = new Float64Array(n), lo = new Float64Array(n), c = new Float64Array(n), v = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const C = Math.exp(logC[i]), O = i ? Math.exp(logC[i - 1] + gap[i]) : C * Math.exp(-r[i] * 0.7);
    c[i] = Math.max(tick, roundTick(C, tick));
    o[i] = Math.max(tick, roundTick(O, tick));
    const intra = Math.abs(r[i] - gap[i]) + sd * 0.55;
    hi[i] = roundTick(Math.max(o[i], c[i]) * Math.exp(Math.abs(rng.normal()) * intra * 0.55), tick);
    lo[i] = roundTick(Math.min(o[i], c[i]) * Math.exp(-Math.abs(rng.normal()) * intra * 0.55), tick);
    if (hi[i] < Math.max(o[i], c[i]) + tick) hi[i] = roundTick(Math.max(o[i], c[i]) + tick, tick);
    if (lo[i] > Math.min(o[i], c[i]) - tick) lo[i] = roundTick(Math.min(o[i], c[i]) - tick, tick);
    if (lo[i] < tick) lo[i] = tick;
    const surprise = Math.abs(r[i]) / sd;
    v[i] = Math.round(adv * Math.exp(0.32 * rng.normal() - 0.05) * (0.7 + 0.35 * surprise) * (jump[i] ? 2.6 : 1));
  }
  c[n - 1] = lastClose;
  return { open: o, high: hi, low: lo, close: c, volume: v, jump, beta, gamma };
}

/**
 * Marche aléatoire de M pas remappée exactement sur (O, H, L, C) ; volume total V réparti.
 * `steps` : pondération de la variance de chaque pas (profil intraday). Résultat : M bougies.
 */
export function fillInside(bar, M, tick, rng, { weights = null, volWeights = null } = {}) {
  const { o: O, h: H, l: L, c: C, v: V } = bar;
  const o = new Float64Array(M), h = new Float64Array(M), l = new Float64Array(M), c = new Float64Array(M), vol = new Float64Array(M);
  const dec = decimalsOf(tick);
  if (!(H > L) || M < 2) {
    o.fill(O); c.fill(C); h.fill(H); l.fill(L);
    distribute(vol, V, volWeights, rng);
    c[M - 1] = C;
    return { open: o, high: h, low: l, close: c, volume: vol };
  }
  let W = null;
  for (let attempt = 0; attempt < 40; attempt++) {
    const w = new Float64Array(M + 1);
    let gk = 1;
    for (let k = 1; k <= M; k++) {
      gk = 0.04 + 0.92 * gk + 0.04 * (rng.normal() ** 2);
      w[k] = w[k - 1] + rng.normal() * Math.sqrt((weights ? weights[k - 1] : 1) * gk);
    }
    if ((C > O) !== (w[M] > w[0]) && C !== O) for (let k = 0; k <= M; k++) w[k] = -w[k];
    let mn = Infinity, mx = -Infinity;
    for (const x of w) { if (x < mn) mn = x; if (x > mx) mx = x; }
    const ok = (O === L) === (w[0] === mn) && (O === H) === (w[0] === mx) && (C === L) === (w[M] === mn) && (C === H) === (w[M] === mx) && (C === O || w[0] !== w[M]);
    if (ok) { W = { w, mn, mx }; break; }
  }
  if (!W) {
    // repli : chemin linéaire O → H → L → C (ou O → L → H → C)
    const w = new Float64Array(M + 1), up = C >= O, k1 = Math.floor(M / 3), k2 = Math.floor((2 * M) / 3);
    for (let k = 0; k <= M; k++) {
      const a = up ? [O, L, H, C] : [O, H, L, C];
      const seg = k <= k1 ? [0, k1, a[0], a[1]] : k <= k2 ? [k1, k2, a[1], a[2]] : [k2, M, a[2], a[3]];
      w[k] = seg[2] + ((seg[3] - seg[2]) * (k - seg[0])) / Math.max(1, seg[1] - seg[0]);
    }
    W = { w, mn: L, mx: H, direct: true };
  }
  const { w, mn, mx } = W;
  let P;
  if (W.direct) P = w;
  else {
    // fonction affine par morceaux croissante : mn→L, w0→O, wM→C, mx→H
    const knots = [[mn, L], [w[0], O], [w[M], C], [mx, H]].sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    const map = (x) => {
      for (let k = 1; k < knots.length; k++) {
        const [x0, y0] = knots[k - 1], [x1, y1] = knots[k];
        if (x <= x1) return x1 > x0 ? y0 + ((y1 - y0) * (x - x0)) / (x1 - x0) : y1;
      }
      return H;
    };
    P = Float64Array.from(w, map);
  }
  const rt = (x) => Number((Math.round(x / tick) * tick).toFixed(dec));
  for (let k = 0; k < M; k++) {
    const a = rt(P[k]), b = rt(P[k + 1]);
    o[k] = a;
    c[k] = b;
    const ex = Math.abs(rng.normal()) * Math.abs(P[k + 1] - P[k]) * 0.35;
    h[k] = Math.min(H, rt(Math.max(a, b) + ex));
    l[k] = Math.max(L, rt(Math.min(a, b) - ex));
  }
  o[0] = O;
  c[M - 1] = C;
  for (let k = 1; k < M; k++) o[k] = c[k - 1];
  // extrêmes exacts : la bougie qui contient le point le plus haut / bas touche H / L
  let ih = 0, il = 0;
  for (let k = 0; k <= M; k++) { if (P[k] > P[ih]) ih = k; if (P[k] < P[il]) il = k; }
  h[Math.min(M - 1, ih === M ? M - 1 : ih)] = H;
  l[Math.min(M - 1, il === M ? M - 1 : il)] = L;
  for (let k = 0; k < M; k++) {
    h[k] = Math.max(h[k], o[k], c[k]);
    l[k] = Math.min(l[k], o[k], c[k]);
  }
  distribute(vol, V, volWeights, rng);
  return { open: o, high: h, low: l, close: c, volume: vol };
}

/** Répartit un volume entier V sur `out` (pondérations + bruit), somme EXACTE. */
export function distribute(out, V, weights, rng) {
  const M = out.length;
  let tot = 0;
  const raw = new Float64Array(M);
  for (let k = 0; k < M; k++) {
    raw[k] = (weights ? weights[k] : 1) * Math.exp(0.5 * rng.normal());
    tot += raw[k];
  }
  let acc = 0;
  for (let k = 0; k < M; k++) {
    out[k] = Math.floor((raw[k] / tot) * V);
    acc += out[k];
  }
  let rest = Math.round(V - acc);
  for (let k = 0; rest > 0; k = (k + 1) % M, rest--) out[(k * 7919) % M]++;
}

/** Pondérations de variance / volume pour M minutes d'une séance (profil en U). */
export function sessionWeights(M) {
  const w = new Float64Array(M);
  for (let k = 0; k < M; k++) w[k] = uShape((k + 0.5) / M);
  return w;
}

export { floorTick, ceilTick };

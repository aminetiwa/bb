// ============================================================================
//  BOURSO :: market/sim.js — SIMULATEUR DE MARCHÉ MONDIAL (données fictives mais cohérentes).
//
//  ~680 actions sur 31 places, chacune avec son fuseau, ses horaires, sa pause déjeuner et ses
//  jours fériés. Pour chaque valeur :
//   - 5 ans de bougies quotidiennes (modèle à facteurs monde/région/secteur + GARCH + sauts) ;
//   - la séance du jour en bougies 1 min, puis vivante : transactions toutes les 50 ms
//     (acheteur/vendeur agresseur, fourchette, blocs), carnet d'ordres, flux ;
//   - à la demande : 1 min des séances passées et 1 s, reconstruites EXACTEMENT à l'intérieur
//     des bougies de niveau supérieur (passer d'une unité de temps à l'autre reste cohérent).
//  Mode démo (par défaut) : chaque place est maintenue en séance continue ; mode « horaires
//  réels » : seules les places ouvertes à l'heure actuelle bougent.
//  Module isomorphe (Node et navigateur), sans dépendance.
// ============================================================================
import { EXCHANGES, REGIONS, pastSessions, nextSessions, marketState, localTimeOf, STATE_LABEL } from './exchanges.js';
import { UNIVERSE, SECTORS } from './universe.js';
import { buildFactors, genDaily, fillInside, sessionWeights, weekdays, uShape } from './gen.js';
import { Rng, hash32, roundTick, decimalsOf } from '../core/quant/numeric.js';
import { FxEngine } from './fx.js';
import { NewsEngine } from './news-sim.js';

export const STEPS_PER_SEC = 20;
const TAPE = 512;
const DAY = 86_400_000;
const BASE_CAP = { XNAS: 2.6e12, XNYS: 7e11, XPAR: 3e11, XETR: 2.4e11, XAMS: 2.6e11, XBRU: 9e10, XMIL: 9e10, XMAD: 1.4e11, XLIS: 1.6e10, XDUB: 2.5e10,
  XSWX: 2.4e11, XLON: 2e11, XSTO: 8e10, XCSE: 1.8e11, XHEL: 4e10, XOSL: 6e10, XWBO: 2.5e10, XWAR: 2e10, XATH: 1.2e10, XTSE: 1.6e11, XTKS: 2.6e11,
  XHKG: 4e11, XSHG: 2.4e11, XKRX: 3e11, XTAI: 8e11, XNSE: 2.1e11, XASX: 1.5e11, XSES: 9e10, BVMF: 7e10, XMEX: 4e10, XJSE: 3e10 };

/** Mini émetteur d'événements (isomorphe). */
class Emitter {
  constructor() { this.h = new Map(); }
  on(e, f) { (this.h.get(e) ?? this.h.set(e, []).get(e)).push(f); return this; }
  emit(e, x) { for (const f of this.h.get(e) ?? []) f(x); }
}

const PER = { BANK: 9, INS: 12, FIN: 18, LUX: 24, CONS: 22, FOOD: 19, RETAIL: 18, AUTO: 7, IND: 21, AERO: 25, CHEM: 18, MAT: 11, ENER: 9, UTIL: 15,
  TEL: 14, PHARMA: 17, BIO: 30, MED: 28, TECH: 26, SEMI: 30, SOFT: 32, NET: 28, PAY: 25, MEDIA: 20, RE: 16, CONST: 14, TRANS: 16, TRAVEL: 20, HOLD: 14, CRYPTO: 45 };
const DIV = { BANK: 6, INS: 5.5, UTIL: 5, TEL: 5, ENER: 5.5, RE: 5, CONS: 2.8, FOOD: 3, AUTO: 5, MAT: 4, CHEM: 3, PHARMA: 3, IND: 2, LUX: 1.8 };
// profils sectoriels : [marge nette %, ROE %, croissance du CA %, dette nette / EBITDA (null : non pertinent, ex. banques)]
const PROFILE = {
  BANK: [25, 10, 3, null], INS: [8, 12, 4, null], FIN: [22, 14, 6, null], LUX: [18, 22, 6, 0.6], CONS: [12, 20, 4, 2], FOOD: [10, 15, 4, 2.2],
  RETAIL: [3, 14, 3, 1.8], AUTO: [6, 10, 3, 1], IND: [9, 16, 5, 1.5], AERO: [8, 16, 7, 1.2], CHEM: [9, 13, 3, 2], MAT: [12, 12, 2, 1.3],
  ENER: [9, 13, 1, 1], UTIL: [9, 9, 3, 3.5], TEL: [9, 9, 1, 2.8], PHARMA: [18, 18, 5, 1.5], BIO: [5, 6, 12, 0.5], MED: [14, 14, 6, 1.8],
  TECH: [15, 22, 8, 0.4], SEMI: [22, 25, 12, 0.2], SOFT: [20, 28, 11, 0.5], NET: [18, 20, 12, 0.2], PAY: [25, 30, 10, 1], MEDIA: [10, 12, 3, 2.5],
  RE: [30, 6, 3, 8], CONST: [6, 13, 4, 1.8], TRANS: [7, 12, 4, 2.2], TRAVEL: [8, 15, 6, 2.5], HOLD: [12, 9, 4, 1.5], CRYPTO: [5, 10, 15, 0.5],
};

/**
 * Fondamentaux SIMULÉS (ordres de grandeur sectoriels) — étiquetés comme tels dans l'interface.
 * Cohérents entre eux : BPA = cours / PER ; cours / valeur comptable = PER × ROE ; taux de
 * distribution = rendement × PER ; PER à un an = PER / (1 + croissance des bénéfices).
 */
function fundamentals(meta, capEur, price, rng) {
  const [mg, roe0, gr0, nd0] = PROFILE[meta.sectorKey] ?? [10, 13, 4, 1.8];
  const per = Math.max(4, (PER[meta.sectorKey] ?? 18) * Math.exp(0.25 * rng.normal()));
  const payoutMax = 0.95;
  let dy = Math.max(0, (DIV[meta.sectorKey] ?? 1.6) * Math.exp(0.35 * rng.normal()));
  if ((dy * per) / 100 > payoutMax) dy = (payoutMax * 100) / per;
  const roe = Math.min(60, Math.max(2, roe0 * Math.exp(0.25 * rng.normal())));
  const margin = meta.sectorKey === 'BIO' ? Math.max(-60, Math.min(40, mg + 20 * rng.normal())) : Math.max(-5, mg * Math.exp(0.3 * rng.normal()));
  const growth = gr0 + 0.6 * Math.max(3, gr0) * rng.normal();
  const epsGrowth = growth / 100 * (0.8 + 0.6 * rng.next());
  const netDebt = nd0 === null ? null : Math.max(-1.5, nd0 + 0.6 * Math.max(0.5, nd0) * rng.normal());
  const shares = capEur / (price || 1);
  const nextEarn = new Date(Date.now() + (5 + rng.int(85)) * DAY).toISOString().slice(0, 10);
  const buy = rng.int(18), hold = rng.int(10), sell = rng.int(5);
  return {
    simule: true, capitalisationMdEur: Number((capEur / 1e9).toFixed(1)), nombreActionsM: Number((shares / 1e6).toFixed(1)),
    per: Number(per.toFixed(1)), perAnneeProchaine: Number((per / Math.max(0.5, 1 + epsGrowth)).toFixed(1)), bpa: Number((price / per).toFixed(3)),
    rendementDividendePct: Number(dy.toFixed(2)), dividendeParAction: Number(((price * dy) / 100).toFixed(3)), tauxDistributionPct: Number((dy * per).toFixed(0)),
    croissanceCaPct: Number(growth.toFixed(1)), margeNettePct: Number(margin.toFixed(1)),
    detteNetteSurEbitda: netDebt === null ? null : Number(netDebt.toFixed(2)), roePct: Number(roe.toFixed(1)),
    prixSurValeurComptable: Number(((per * roe) / 100).toFixed(2)), flottantPct: Number(Math.min(100, 55 + 35 * rng.next()).toFixed(0)),
    prochainePublication: nextEarn, consensus: { achat: buy, neutre: hold, vente: sell },
    objectifCoursMoyen: Number((price * Math.exp(0.07 + 0.1 * rng.normal())).toFixed(decimalsOf(meta.tick))),
  };
}

export class WorldSim extends Emitter {
  /**
   * @param {{ seed?:number, demo?:boolean, dailyDays?:number, intraDays?:number, secDays?:number, now?:number, universe?:object[] }} o
   */
  constructor({ seed = 20261027, demo = true, dailyDays = 1260, intraDays = 20, secDays = 5, now = Date.now(), universe = UNIVERSE } = {}) {
    super();
    const t0 = Date.now();
    this.seed = seed;
    this.demo = demo;
    this.dailyDays = dailyDays;
    this.intraDays = intraDays;
    this.secDays = secDays;
    this.rng = new Rng(seed ^ 0x1234567);
    this.fx = new FxEngine(seed);
    this.step_ = 0;
    this.subStep = 0;
    this.seq = 0;
    this.idxCache = new Map();
    this.weightCache = new Map();
    this.ifacCache = new Map();
    const mics = [...new Set(universe.map((m) => m.mic))];
    this.clocks = Object.fromEntries(mics.map((mic) => [mic, this.#initClock(EXCHANGES[mic], now)]));
    const firstDay = mics.map((m) => this.clocks[m].past[0]).sort()[0], lastDay = mics.map((m) => this.clocks[m].future.at(-1)).sort().at(-1);
    this.F = buildFactors(weekdays(firstDay, lastDay), REGIONS, Object.keys(SECTORS), seed);
    const rankOf = new Map();
    for (const mic of mics) universe.filter((m) => m.mic === mic).forEach((m, k) => rankOf.set(m.sym, k));
    this.instruments = universe.map((meta) => this.#initInstrument(meta, rankOf.get(meta.sym)));
    this.bySym = new Map(this.instruments.map((x) => [x.meta.sym, x]));
    this.byMic = new Map(mics.map((mic) => [mic, this.instruments.filter((x) => x.meta.mic === mic)]));
    this.news = new NewsEngine(this, seed);
    this.initMs = Date.now() - t0;
  }

  // ---------------------------------------------------------------- horloges de séance
  #initClock(ex, now) {
    const ms = marketState(ex, now);
    let today, sec;
    const prevDay = (ymd) => pastSessions(ex, ymd, 1)[0];
    if (this.demo) {
      today = ms.trading ? ms.localYmd : prevDay(ms.localYmd);
      const s = ms.trading ? ms.sessionSec : ex.sessionSec;
      sec = Math.min(ex.sessionSec - 1800, Math.max(1800, s));
    } else if (ms.trading && ms.state !== 'PRE') {
      today = ms.localYmd;
      sec = ms.sessionSec;
    } else {
      today = prevDay(ms.localYmd);
      sec = ex.sessionSec;
    }
    const next = new Date(Date.parse(`${today}T12:00:00Z`) + DAY).toISOString().slice(0, 10);
    return { ex, today, sec: Math.floor(sec), past: pastSessions(ex, today, this.dailyDays), future: nextSessions(ex, next, 60), live: this.demo || ms.state === 'OPEN', sub: 0 };
  }

  /** États des places (pour l'en-tête, la page Marchés). */
  clockInfo() {
    return Object.values(this.clocks).sort((a, b) => a.ex.order - b.ex.order).map((c) => {
      const real = marketState(c.ex);
      return {
        mic: c.ex.mic, name: c.ex.name, short: c.ex.short, region: c.ex.region, tz: c.ex.tz, date: c.today, time: localTimeOf(c.ex, c.sec),
        sec: c.sec, sessionSec: c.ex.sessionSec, live: c.live, realState: real.state, realLabel: STATE_LABEL[real.state],
        label: this.demo ? 'Séance simulée (démo)' : STATE_LABEL[real.state], progress: c.sec / c.ex.sessionSec,
      };
    });
  }

  // ---------------------------------------------------------------- valeurs
  #weights(M) {
    if (!this.weightCache.has(M)) this.weightCache.set(M, sessionWeights(M));
    return this.weightCache.get(M);
  }

  /** Chocs de facteur intraday d'une place pour une date (partagés : corrélation intraday). */
  #ifac(mic, ymd) {
    const k = `${mic}:${ymd}`;
    if (!this.ifacCache.has(k)) {
      const M = EXCHANGES[mic].sessionMin, r = new Rng(hash32(`ifac:${k}:${this.seed}`)), a = new Float64Array(M);
      for (let i = 0; i < M; i++) a[i] = r.normal();
      this.ifacCache.set(k, a);
    }
    return this.ifacCache.get(k);
  }

  #initInstrument(meta, rank) {
    const clk = this.clocks[meta.mic], ex = clk.ex, tick = meta.tick;
    const rng = new Rng(hash32(`init:${meta.sym}:${this.seed}`));
    const prev = roundTick(meta.price * Math.exp(0.012 * rng.normal()), tick);
    const toEur = this.fx.toEur(meta.currency);
    const capEur = (BASE_CAP[meta.mic] ?? 3e10) * 0.9 ** rank * Math.exp(0.2 * rng.normal());
    const adv = Math.max(2000, Math.round((capEur * 0.0035) / (prev * toEur)));
    const d = genDaily(meta, clk.past, this.F, { seed: this.seed, lastClose: prev, adv });
    const n = d.close.length, cap = n + 128;
    const grow = (a) => { const b = new Float64Array(cap); b.set(a); return b; };
    // transactions par pas de 50 ms : ~3,6/s pour les plus grosses valeurs, < 1/s pour les petites
    const lambda = 0.03 + 0.15 * 0.9 ** rank;
    const inst = {
      meta, ex, clk, rank, adv, capEur, fund: fundamentals(meta, capEur, prev, rng),
      daily: { open: grow(d.open), high: grow(d.high), low: grow(d.low), close: grow(d.close), volume: grow(d.volume), n, cap },
      beta: d.beta, gamma: d.gamma, lambda, avgTrade: Math.max(1, adv / (lambda * STEPS_PER_SEC * ex.sessionSec)),
      spreadTicks: rank < 20 && prev > 5 * tick * 100 ? 1 : 2,
      sdSec: meta.vol / Math.sqrt(252 * ex.sessionSec), hv: 1,
      prev, open: 0, high: 0, low: 0, last: 0, volume: 0, turnover: 0, trades: 0, buyVol: 0, sellVol: 0, largeBuys: 0, largeSells: 0,
      F: 0, drift: 0, driftLeft: 0, burst: 1,
      m: null, mN: 0, curM: null, s1: null, curS: null, liveMin: new Map(), liveSec: new Map(), minCache: new Map(), secCache: new Map(),
      tape: { px: new Float64Array(TAPE), qty: new Float64Array(TAPE), side: new Int8Array(TAPE), ts: new Float64Array(TAPE), sec: new Int32Array(TAPE), seq: new Float64Array(TAPE), n: 0 },
      walls: [], seqTrade: 0,
    };
    const idio = Math.sqrt(Math.max(0.3, 1 - (inst.beta * 0.55) ** 2 - (inst.gamma * 0.45) ** 2));
    inst.idioW = idio;
    this.#startSession(inst, true);
    return inst;
  }

  /** Ouvre la séance du jour d'une valeur ; `replay` : reconstitue les minutes déjà écoulées. */
  #startSession(inst, replay) {
    const { meta, clk, ex } = inst, tick = meta.tick, M = ex.sessionMin;
    const rng = new Rng(hash32(`jour:${meta.sym}:${clk.today}:${this.seed}`));
    const sd = meta.vol / Math.sqrt(252);
    const prevYmd = clk.past.at(-1);
    let fac = 0;
    const reg = this.F.region[meta.region];
    if (reg && this.F.idx.has(clk.today)) {
      for (let i = (this.F.idx.get(prevYmd) ?? this.F.idx.get(clk.today) - 1) + 1; i <= this.F.idx.get(clk.today); i++) fac += reg[i];
    }
    const gap = 0.3 * inst.beta * fac + rng.normal() * sd * 0.22;
    inst.open = Math.max(tick, roundTick(inst.prev * Math.exp(gap), tick));
    inst.high = inst.low = inst.last = inst.open;
    inst.volume = inst.turnover = inst.trades = inst.buyVol = inst.sellVol = inst.largeBuys = inst.largeSells = 0;
    inst.m = { open: new Float64Array(M), high: new Float64Array(M), low: new Float64Array(M), close: new Float64Array(M), volume: new Float64Array(M) };
    inst.mN = 0;
    inst.s1 = null;
    inst.curS = null;
    inst.secCache.clear();
    if (replay) {
      const done = Math.floor(clk.sec / 60), ifac = this.#ifac(meta.mic, clk.today), sdMin = meta.vol / Math.sqrt(252 * M);
      let p = Math.log(inst.open), hv = 1;
      const dec = decimalsOf(tick), rt = (x) => Number((Math.round(x / tick) * tick).toFixed(dec));
      for (let k = 0; k < done; k++) {
        const u = uShape(k / M);
        hv = 0.05 + 0.9 * hv + 0.05 * rng.normal() ** 2;
        const s = sdMin * Math.sqrt(u * hv);
        const o = rt(Math.exp(p));
        p += s * (inst.beta * 0.55 * ifac[k] + inst.idioW * rng.normal());
        const c = Math.max(tick, rt(Math.exp(p)));
        const ex2 = Math.abs(rng.normal()) * s * 0.45 * c;
        const h = Math.max(o, c, rt(Math.max(o, c) + ex2)), l = Math.max(tick, Math.min(o, c, rt(Math.min(o, c) - ex2)));
        const v = Math.round((inst.adv / M) * u * Math.exp(0.45 * rng.normal() - 0.1));
        this.#pushMinute(inst, k === 0 ? inst.open : inst.m.close[k - 1], h, l, c, v);
        inst.volume += v;
        inst.turnover += v * (h + l + c) / 3;
        const bs = 0.5 + 0.08 * rng.normal();
        inst.buyVol += v * bs;
        inst.sellVol += v * (1 - bs);
        if (h > inst.high) inst.high = h;
        if (l < inst.low) inst.low = l;
        inst.last = c;
      }
      inst.trades = Math.round(inst.volume / inst.avgTrade);
    }
    inst.F = Math.log(inst.last);
    inst.curM = { o: inst.last, h: inst.last, l: inst.last, c: inst.last, v: 0 };
  }

  #pushMinute(inst, o, h, l, c, v) {
    const k = inst.mN;
    if (k >= inst.m.close.length) return;
    inst.m.open[k] = o; inst.m.high[k] = h; inst.m.low[k] = l; inst.m.close[k] = c; inst.m.volume[k] = v;
    inst.mN++;
  }

  get(sym) {
    return this.bySym.get(sym);
  }

  // ---------------------------------------------------------------- temps réel
  /** Un pas de 50 ms sur toutes les places vivantes. Toutes les 20 itérations : seconde suivante. */
  step() {
    const r = this.rng;
    this.step_++;
    const zW = r.normal(), zR = {}, zS = {};
    for (const reg of REGIONS) zR[reg] = 0.75 * zW + 0.66 * r.normal();
    for (const s of Object.keys(SECTORS)) zS[s] = r.normal();
    for (const inst of this.instruments) {
      const clk = inst.clk;
      if (!clk.live) continue;
      const x = clk.sec / clk.ex.sessionSec, u = uShape(x);
      const sd = (inst.sdSec / Math.sqrt(STEPS_PER_SEC)) * Math.sqrt(u * inst.hv);
      let dF = sd * (inst.beta * 0.55 * zR[inst.meta.region] + inst.gamma * 0.45 * zS[inst.meta.sectorKey] + inst.idioW * r.normal());
      if (inst.driftLeft > 0) {
        dF += inst.drift;
        inst.driftLeft--;
        if (!inst.driftLeft) inst.burst = 1;
      }
      inst.F += dF;
      // nombre de transactions (Poisson) — profil en U et regain après une actualité
      const lam = inst.lambda * u * inst.burst;
      let k = 0, p = r.next();
      const L = Math.exp(-lam);
      while (p > L) { k++; p *= r.next(); }
      if (!k) continue;
      const tick = inst.meta.tick, fair = Math.exp(inst.F);
      const bid = Math.max(tick, Math.floor(fair / tick - inst.spreadTicks / 2 + 0.5) * tick), ask = bid + inst.spreadTicks * tick;
      const pBuy = Math.min(0.85, Math.max(0.15, 0.5 + (sd > 0 ? (6 * dF) / sd / 10 : 0)));
      for (let j = 0; j < k; j++) {
        const side = r.next() < pBuy ? 1 : -1;
        const px = roundTick(side > 0 ? ask : bid, tick);
        let qty = Math.max(1, Math.round(inst.avgTrade * Math.exp(0.9 * r.normal() - 0.405)));
        const large = r.next() < 0.002;
        if (large) qty *= 25;
        this.#trade(inst, px, qty, side, large);
      }
    }
    if (++this.subStep >= STEPS_PER_SEC) this.#second();
  }

  #trade(inst, px, qty, side, large) {
    inst.last = px;
    if (px > inst.high) inst.high = px;
    if (px < inst.low) inst.low = px;
    inst.volume += qty;
    inst.turnover += qty * px;
    inst.trades++;
    if (side > 0) { inst.buyVol += qty; if (large) inst.largeBuys++; } else { inst.sellVol += qty; if (large) inst.largeSells++; }
    const c = inst.curM;
    c.c = px; if (px > c.h) c.h = px; if (px < c.l) c.l = px; c.v += qty;
    const s = inst.curS;
    if (s) { s.c = px; if (px > s.h) s.h = px; if (px < s.l) s.l = px; s.v += qty; }
    const t = inst.tape, i = t.n % TAPE;
    t.px[i] = px; t.qty[i] = qty; t.side[i] = side; t.ts[i] = Date.now(); t.sec[i] = inst.clk.sec; t.seq[i] = ++this.seq;
    t.n++;
  }

  #second() {
    this.subStep = 0;
    this.fx.tick();
    const now = Date.now();
    for (const clk of Object.values(this.clocks)) {
      if (!this.demo) {
        const ms = marketState(clk.ex, now);
        const newDay = ms.localYmd > clk.today && ms.trading && ms.state !== 'PRE';
        if (newDay) this.#rollover(clk, ms.localYmd);
        clk.live = ms.state === 'OPEN' && ms.localYmd === clk.today;
        if (!clk.live) continue;
        const target = ms.sessionSec;
        while (clk.sec < target) this.#advance(clk);
      } else {
        this.#advance(clk);
        if (clk.sec >= clk.ex.sessionSec) this.#rollover(clk);
      }
    }
  }

  /** Une seconde de séance pour une place : bougies 1 s matérialisées, minute close, volatilité. */
  #advance(clk) {
    clk.sec++;
    const list = this.byMic.get(clk.ex.mic);
    const minuteDone = clk.sec % 60 === 0;
    for (const inst of list) {
      inst.hv = 0.02 + 0.97 * inst.hv + 0.01 * this.rng.normal() ** 2;
      if (inst.s1 && inst.curS) {
        const s = inst.s1, c = inst.curS, k = s.n;
        if (k < s.close.length) { s.open[k] = c.o; s.high[k] = c.h; s.low[k] = c.l; s.close[k] = c.c; s.volume[k] = c.v; s.n++; }
        inst.curS = { o: inst.last, h: inst.last, l: inst.last, c: inst.last, v: 0 };
      }
      if (minuteDone) {
        const c = inst.curM;
        this.#pushMinute(inst, c.o, c.h, c.l, c.c, c.v);
        inst.curM = { o: inst.last, h: inst.last, l: inst.last, c: inst.last, v: 0 };
      }
    }
    if (minuteDone) this.emit('minute', clk.ex.mic);
  }

  /** Fin de séance : la journée rejoint l'historique quotidien, nouvelle séance. */
  #rollover(clk, newDay = null) {
    const list = this.byMic.get(clk.ex.mic), ymd = clk.today;
    for (const inst of list) {
      if (inst.curM.v > 0 && inst.mN < clk.ex.sessionMin) this.#pushMinute(inst, inst.curM.o, inst.curM.h, inst.curM.l, inst.curM.c, inst.curM.v);
      const d = inst.daily;
      if (d.n >= d.cap) {
        for (const k of ['open', 'high', 'low', 'close', 'volume']) { const b = new Float64Array(d.cap * 2); b.set(d[k]); d[k] = b; }
        d.cap *= 2;
      }
      const j = d.n++;
      d.open[j] = inst.open; d.high[j] = Math.max(inst.high, inst.open); d.low[j] = Math.min(inst.low, inst.open); d.close[j] = inst.last; d.volume[j] = inst.volume;
      const M = inst.mN, m = inst.m;
      inst.liveMin.set(ymd, { open: m.open.slice(0, M), high: m.high.slice(0, M), low: m.low.slice(0, M), close: m.close.slice(0, M), volume: m.volume.slice(0, M) });
      if (inst.liveMin.size > this.intraDays + 2) inst.liveMin.delete(inst.liveMin.keys().next().value);
      if (inst.s1) {
        const s = inst.s1, N = s.n;
        inst.liveSec.set(ymd, { open: s.open.slice(0, N), high: s.high.slice(0, N), low: s.low.slice(0, N), close: s.close.slice(0, N), volume: s.volume.slice(0, N) });
        if (inst.liveSec.size > this.secDays + 1) inst.liveSec.delete(inst.liveSec.keys().next().value);
      }
      inst.prev = inst.last;
    }
    clk.past.push(ymd);
    clk.today = newDay ?? clk.future.shift();
    while (clk.future.length && clk.future[0] <= clk.today) clk.future.shift();
    if (clk.future.length < 10) clk.future.push(...nextSessions(clk.ex, new Date(Date.parse(`${clk.future.at(-1) ?? clk.today}T12:00:00Z`) + DAY).toISOString().slice(0, 10), 30));
    clk.sec = 0;
    for (const inst of list) this.#startSession(inst, false);
    this.idxCache.clear();
    this.emit('rollover', clk.ex.mic);
  }

  /** Actualité : dérive du cours pendant quelques minutes et regain de volume. */
  applyNews(item) {
    const targets = item.scope === 'valeur' ? [this.get(item.sym)]
      : item.scope === 'secteur' ? this.instruments.filter((x) => x.meta.sectorKey === item.sectorKey)
        : item.scope === 'région' ? this.instruments.filter((x) => x.meta.region === item.region) : this.instruments;
    const k = item.scope === 'valeur' ? 0.9 : item.scope === 'secteur' ? 0.45 : 0.3;
    for (const inst of targets) {
      if (!inst) continue;
      const sdDay = inst.meta.vol / Math.sqrt(252), steps = (90 + this.rng.int(300)) * STEPS_PER_SEC;
      inst.drift = (item.score * k * sdDay * (0.6 + 0.8 * this.rng.next())) / steps;
      inst.driftLeft = steps;
      inst.burst = item.scope === 'valeur' ? 2.5 : 1.4;
    }
  }

  // ---------------------------------------------------------------- lecture des données
  /** Cotation instantanée. */
  quote(sym) {
    const x = this.get(sym);
    if (!x) return null;
    const tick = x.meta.tick, fair = Math.exp(x.F);
    const bid = Math.max(tick, Math.floor(fair / tick - x.spreadTicks / 2 + 0.5) * tick);
    return {
      sym, last: x.last, prev: x.prev, open: x.open, high: x.high, low: x.low, volume: x.volume, turnover: x.turnover, trades: x.trades,
      chg: x.last - x.prev, chgPct: (x.last / x.prev - 1) * 100, bid: roundTick(bid, tick), ask: roundTick(bid + x.spreadTicks * tick, tick),
      vwap: x.volume > 0 ? x.turnover / x.volume : x.last, buyVol: x.buyVol, sellVol: x.sellVol, largeBuys: x.largeBuys, largeSells: x.largeSells,
      time: localTimeOf(x.ex, x.clk.sec), date: x.clk.today, live: x.clk.live, seq: x.tape.n ? x.tape.seq[(x.tape.n - 1) % TAPE] : 0,
    };
  }

  /** Historique quotidien (séances terminées). */
  daily(sym) {
    const x = this.get(sym), d = x.daily, n = d.n;
    return { dates: x.clk.past.slice(-n), open: d.open.subarray(0, n), high: d.high.subarray(0, n), low: d.low.subarray(0, n), close: d.close.subarray(0, n), volume: d.volume.subarray(0, n) };
  }

  #minutesOfDay(x, j, ymd) {
    if (x.liveMin.has(ymd)) return x.liveMin.get(ymd);
    if (x.minCache.has(ymd)) return x.minCache.get(ymd);
    const d = x.daily, W = this.#weights(x.ex.sessionMin);
    const bars = fillInside({ o: d.open[j], h: d.high[j], l: d.low[j], c: d.close[j], v: d.volume[j] }, x.ex.sessionMin, x.meta.tick,
      new Rng(hash32(`min:${x.meta.sym}:${ymd}:${this.seed}`)), { weights: W, volWeights: W });
    x.minCache.set(ymd, bars);
    if (x.minCache.size > this.intraDays + 4) x.minCache.delete(x.minCache.keys().next().value);
    return bars;
  }

  /**
   * Bougies 1 min : `days` séances passées complètes + séance du jour (minutes closes + minute en cours).
   * @returns {{ open, high, low, close, volume, sessionBars, todayFrom, dates, partial:boolean }}
   */
  minutes(sym, days = this.intraDays) {
    const x = this.get(sym), M = x.ex.sessionMin, d = x.daily, nd = Math.min(days, d.n);
    const total = nd * M + x.mN + 1;
    const out = { open: new Float64Array(total), high: new Float64Array(total), low: new Float64Array(total), close: new Float64Array(total), volume: new Float64Array(total) };
    const dates = [];
    let k = 0;
    for (let j = d.n - nd; j < d.n; j++) {
      const ymd = x.clk.past[x.clk.past.length - (d.n - j)];
      const b = this.#minutesOfDay(x, j, ymd), len = Math.min(M, b.close.length);
      for (const f of ['open', 'high', 'low', 'close', 'volume']) out[f].set(b[f].subarray(0, len), k);
      // séance vécue incomplète (serveur arrêté en cours de route) : minutes restantes plates, sans volume
      for (let i = len; i < M; i++) for (const f of ['open', 'high', 'low', 'close']) out[f][k + i] = len ? b.close[len - 1] : d.close[j];
      k += M;
      dates.push(ymd);
    }
    const todayFrom = k;
    for (const f of ['open', 'high', 'low', 'close', 'volume']) out[f].set(x.m[f].subarray(0, x.mN), k);
    k += x.mN;
    const c = x.curM;
    out.open[k] = c.o; out.high[k] = c.h; out.low[k] = c.l; out.close[k] = c.c; out.volume[k] = c.v;
    dates.push(x.clk.today);
    return { ...out, sessionBars: M, todayFrom, dates, partial: true, sessionSec: x.ex.sessionSec };
  }

  #secondsOfDay(x, j, ymd) {
    if (x.liveSec.has(ymd)) return x.liveSec.get(ymd);
    if (x.secCache.has(ymd)) return x.secCache.get(ymd);
    const mb = this.#minutesOfDay(x, j, ymd), M = x.ex.sessionMin, S = M * 60;
    const out = { open: new Float64Array(S), high: new Float64Array(S), low: new Float64Array(S), close: new Float64Array(S), volume: new Float64Array(S) };
    for (let k = 0; k < M; k++) {
      const b = fillInside({ o: mb.open[k], h: mb.high[k], l: mb.low[k], c: mb.close[k], v: mb.volume[k] }, 60, x.meta.tick, new Rng(hash32(`sec:${x.meta.sym}:${ymd}:${k}:${this.seed}`)));
      for (const f of ['open', 'high', 'low', 'close', 'volume']) out[f].set(b[f], k * 60);
    }
    x.secCache.set(ymd, out);
    if (x.secCache.size > this.secDays + 1) x.secCache.delete(x.secCache.keys().next().value);
    return out;
  }

  /** Matérialise les bougies 1 s de la séance du jour (puis elles vivent en temps réel). */
  #ensureToday1s(x) {
    if (x.s1) return x.s1;
    const S = x.ex.sessionSec, s = { open: new Float64Array(S), high: new Float64Array(S), low: new Float64Array(S), close: new Float64Array(S), volume: new Float64Array(S), n: 0 };
    for (let k = 0; k < x.mN; k++) {
      const b = fillInside({ o: x.m.open[k], h: x.m.high[k], l: x.m.low[k], c: x.m.close[k], v: x.m.volume[k] }, 60, x.meta.tick, new Rng(hash32(`sec:${x.meta.sym}:${x.clk.today}:${k}:${this.seed}`)));
      for (const f of ['open', 'high', 'low', 'close', 'volume']) s[f].set(b[f], k * 60);
      s.n += 60;
    }
    const e = x.clk.sec - x.mN * 60, c = x.curM;
    if (e > 0) {
      const b = e >= 2 ? fillInside({ o: c.o, h: c.h, l: c.l, c: c.c, v: c.v }, e, x.meta.tick, new Rng(hash32(`secp:${x.meta.sym}:${x.clk.sec}`))) : null;
      for (let i = 0; i < e; i++) {
        s.open[s.n] = b ? b.open[i] : c.o; s.high[s.n] = b ? b.high[i] : c.h; s.low[s.n] = b ? b.low[i] : c.l; s.close[s.n] = b ? b.close[i] : c.c; s.volume[s.n] = b ? b.volume[i] : c.v;
        s.n++;
      }
    }
    x.s1 = s;
    x.curS = { o: x.last, h: x.last, l: x.last, c: x.last, v: 0 };
    return s;
  }

  /** Bougies 1 s : `days` séances passées + séance du jour (secondes closes + seconde en cours). */
  seconds(sym, days = this.secDays) {
    const x = this.get(sym), S = x.ex.sessionSec, d = x.daily, nd = Math.min(days, d.n), s1 = this.#ensureToday1s(x);
    const total = nd * S + s1.n + 1;
    const out = { open: new Float64Array(total), high: new Float64Array(total), low: new Float64Array(total), close: new Float64Array(total), volume: new Float64Array(total) };
    const dates = [];
    let k = 0;
    for (let j = d.n - nd; j < d.n; j++) {
      const ymd = x.clk.past[x.clk.past.length - (d.n - j)];
      const b = this.#secondsOfDay(x, j, ymd);
      const len = Math.min(S, b.close.length);
      for (const f of ['open', 'high', 'low', 'close', 'volume']) out[f].set(b[f].subarray(0, len), k);
      if (len < S) for (let i = len; i < S; i++) for (const f of ['open', 'high', 'low', 'close']) out[f][k + i] = b.close[len - 1];
      k += S;
      dates.push(ymd);
    }
    const todayFrom = k;
    for (const f of ['open', 'high', 'low', 'close', 'volume']) out[f].set(s1[f].subarray(0, s1.n), k);
    k += s1.n;
    const c = x.curS;
    out.open[k] = c.o; out.high[k] = c.h; out.low[k] = c.l; out.close[k] = c.c; out.volume[k] = c.v;
    dates.push(x.clk.today);
    return { ...out, sessionBars: S, todayFrom, dates, partial: true, sessionSec: S };
  }

  /** Dernières transactions (les plus récentes en dernier), éventuellement depuis un n° de séquence. */
  tape(sym, limit = 100, sinceSeq = 0) {
    const t = this.get(sym).tape, out = [];
    for (let i = Math.max(0, t.n - Math.min(limit, TAPE)); i < t.n; i++) {
      const j = i % TAPE;
      if (t.seq[j] > sinceSeq) out.push({ px: t.px[j], qty: t.qty[j], side: t.side[j], ts: t.ts[j], seq: t.seq[j], time: localTimeOf(this.get(sym).ex, t.sec[j]) });
    }
    return out;
  }

  /** Carnet d'ordres simulé (depth limites de chaque côté), avec « murs » persistants. */
  book(sym, depth = 20) {
    const x = this.get(sym), q = this.quote(sym), tick = x.meta.tick, base = Math.max(1, x.avgTrade * 3);
    if (this.rng.next() < 0.04) {
      const side = this.rng.next() < 0.5 ? -1 : 1;
      x.walls.push({ price: roundTick(q.last + side * (3 + this.rng.int(depth)) * tick, tick), size: base * (8 + this.rng.next() * 30), until: this.step_ + 2000 + this.rng.int(20000), side });
    }
    x.walls = x.walls.filter((w) => w.until > this.step_ && (w.side > 0 ? w.price > q.bid : w.price < q.ask));
    const wall = (p) => x.walls.filter((w) => Math.abs(w.price - p) < tick / 2).reduce((a, w) => a + w.size, 0);
    const lvl = (p, k) => Math.round(base * (0.5 + this.rng.next()) * (1 + k * 0.12) + wall(p));
    return {
      bids: Array.from({ length: depth }, (_, k) => { const p = roundTick(q.bid - k * tick, tick); return [p, lvl(p, k)]; }),
      asks: Array.from({ length: depth }, (_, k) => { const p = roundTick(q.ask + k * tick, tick); return [p, lvl(p, k)]; }),
    };
  }

  // ---------------------------------------------------------------- indices (paniers simulés)
  /** Paniers équipondérés : par place, Europe, Monde (base 1000 il y a 5 ans). */
  indices() {
    const out = [];
    const basket = (key, name, members) => {
      const live = members.reduce((a, x) => a + x.last / x.daily.close[0], 0) / members.length;
      const prev = members.reduce((a, x) => a + x.prev / x.daily.close[0], 0) / members.length;
      out.push({ key, name, members: members.length, level: 1000 * live, prev: 1000 * prev, chgPct: (live / prev - 1) * 100,
        up: members.filter((x) => x.last > x.prev).length, down: members.filter((x) => x.last < x.prev).length });
    };
    for (const [mic, list] of [...this.byMic.entries()].sort((a, b) => EXCHANGES[a[0]].order - EXCHANGES[b[0]].order)) basket(mic, `${EXCHANGES[mic].index} (panier sim.)`, list);
    basket('EUROPE', 'Europe (panier sim.)', this.instruments.filter((x) => x.meta.region === 'Europe'));
    basket('MONDE', 'Monde (panier sim.)', this.instruments);
    return out;
  }

  /** Série quotidienne d'un panier (sur le calendrier de sa place ; Europe/Monde : calendrier de Paris). */
  indexDaily(key) {
    if (this.idxCache.has(key)) return this.idxCache.get(key);
    const ref = key === 'EUROPE' || key === 'MONDE' ? 'XPAR' : key;
    const members = key === 'EUROPE' ? this.instruments.filter((x) => x.meta.region === 'Europe') : key === 'MONDE' ? this.instruments : this.byMic.get(key);
    const clk = this.clocks[ref], dates = clk.past.slice(-this.clocks[ref].past.length), n = dates.length;
    const close = new Float64Array(n);
    const pos = new Map(dates.map((d, i) => [d, i]));
    const cnt = new Float64Array(n);
    for (const x of members) {
      const xd = x.clk.past, base = x.daily.close[0];
      let last = NaN;
      const own = new Map();
      for (let j = 0; j < x.daily.n; j++) own.set(xd[xd.length - x.daily.n + j], x.daily.close[j] / base);
      for (let i = 0; i < n; i++) {
        const v = own.get(dates[i]);
        if (v !== undefined) last = v;
        if (Number.isFinite(last)) { close[i] += last; cnt[i]++; }
      }
    }
    for (let i = 0; i < n; i++) close[i] = cnt[i] ? (1000 * close[i]) / cnt[i] : NaN;
    const res = { dates, close };
    this.idxCache.set(key, res);
    return res;
  }
}

// ============================================================================
//  BOURSO :: math.worker.js — consomme les anneaux de ticks (1 par instrument),
//  applique Kalman robuste + Volume Profile en lots zero-copy, publie les signaux.
//
//  workerData = {
//    control: SharedArrayBuffer,
//    lanes: [{ id, symbol, tickSize, refPrice, annualVol, ring: descriptor }],
//    out: descriptor (SIGNAL_FIELDS), nisAlert: 9, vpPublishMs: 250, statsMs: 1000, spin: 2000
//  }
//  Messages sortants : { type:'vp', lane, stats, snapshot } | { type:'stats', … }
// ============================================================================
import { parentPort, workerData } from 'node:worker_threads';
import { SoARing, ControlBlock } from '../core/shm/soa-ring.js';
import { KalmanFilter, VolumeProfile, kalmanParamsFor, backend } from '../core/math/index.js';

const BATCH = 4096;
const cfg = { nisAlert: 9, vpPublishMs: 250, statsMs: 1000, spin: 20000, ...workerData };
const control = new ControlBlock(cfg.control);
const out = SoARing.from(cfg.out);

const lanes = cfg.lanes.map((l) => ({
  id: l.id,
  symbol: l.symbol,
  ring: SoARing.from(l.ring),
  kf: new KalmanFilter(kalmanParamsFor({ price: l.refPrice, tickSize: l.tickSize, annualVol: l.annualVol ?? 0.25 })),
  vp: new VolumeProfile({ tickSize: l.tickSize }),
  level: new Float64Array(BATCH),
  slope: new Float64Array(BATCH),
  nis: new Float64Array(BATCH),
  processed: 0,
}));

// Histogramme de latence tick→signal : pas de 100 ns jusqu'à 10 ms (+ débordement)
const LAT_BUCKETS = 100_001;
let latHist = new Uint32Array(LAT_BUCKETS);
let latMax = 0;
const hrNs = () => Number(process.hrtime.bigint());

function publish(lane, ts, px, level, slope, nis) {
  const i = out.claim();
  if (i < 0) return;
  const c = out.col;
  c.ts[i] = ts; c.lane[i] = lane; c.px[i] = px; c.level[i] = level; c.slope[i] = slope; c.nis[i] = nis;
  out.commit();
}

function processLane(L) {
  const { ring } = L, col = ring.col;
  return ring.consume(BATCH, (s, n) => {
    const ts = col.ts.subarray(s, s + n), px = col.px.subarray(s, s + n);
    L.kf.run(ts, px, L.level, L.slope, L.nis);                       // C++ zero-copy
    L.vp.addTrades(px, col.qty.subarray(s, s + n), col.side.subarray(s, s + n));
    const done = hrNs();
    const rx = col.rx;
    for (let i = 0; i < n; i++) {
      const b = Math.min(LAT_BUCKETS - 1, Math.max(0, Math.floor((done - rx[s + i]) / 100)));
      latHist[b]++;
      if (L.nis[i] > cfg.nisAlert) publish(L.id, ts[i], px[i], L.level[i], L.slope[i], L.nis[i]); // anomalies
    }
    const lat = done - rx[s];
    if (lat > latMax) latMax = lat;
    publish(L.id, ts[n - 1], px[n - 1], L.level[n - 1], L.slope[n - 1], L.nis[n - 1]);       // dernier état
    L.processed += n;
  });
}

function percentile(h, total, q) {
  const target = Math.ceil(total * q);
  let acc = 0;
  for (let i = 0; i < h.length; i++) {
    acc += h[i];
    if (acc >= target) return i * 0.1; // µs
  }
  return Infinity;
}

let lastVp = hrNs(), lastStats = lastVp, lastProcessed = 0;

function housekeeping(now, force = false) {
  if (force || now - lastVp >= cfg.vpPublishMs * 1e6) {
    lastVp = now;
    for (const L of lanes) {
      const stats = L.vp.stats();
      if (stats.valid) parentPort.postMessage({ type: 'vp', lane: L.id, symbol: L.symbol, stats, snapshot: L.vp.snapshot() });
    }
  }
  if (force || now - lastStats >= cfg.statsMs * 1e6) {
    const processed = lanes.reduce((a, L) => a + L.processed, 0);
    const total = latHist.reduce((a, b) => a + b, 0);
    parentPort.postMessage({
      type: 'stats',
      backend,
      processed,
      rate: ((processed - lastProcessed) * 1e9) / (now - lastStats),
      latencyUs: total
        ? { p50: percentile(latHist, total, 0.5), p99: percentile(latHist, total, 0.99), p999: percentile(latHist, total, 0.999), max: latMax / 1000 }
        : null,
      dropped: lanes.reduce((a, L) => a + L.ring.dropped, 0),
    });
    lastStats = now;
    lastProcessed = processed;
    latHist = new Uint32Array(LAT_BUCKETS);
    latMax = 0;
  }
}

// Boucle chaude : polling des voies, spin court, puis sommeil futex sur la sonnette.
for (;;) {
  const seen = control.seq();
  let got = 0;
  for (const L of lanes) got += processLane(L);
  housekeeping(hrNs());
  if (control.stopped) break;
  if (got > 0) continue;
  let spun = 0;
  while (spun++ < cfg.spin && control.seq() === seen) { /* spin */ }
  if (control.seq() === seen) control.sleep(seen, 5);
}
for (const L of lanes) processLane(L); // vidange finale
housekeeping(hrNs(), true);
parentPort.postMessage({ type: 'done', processed: lanes.map((L) => L.processed) });

// ============================================================================
//  BOURSO :: server/state.js — persistance locale (dossier data/) : réglages, favoris, alertes,
//  portefeuille simulé, historique des signaux de l'IA (JSONL), conversations de l'agent.
//  Écritures atomiques (fichier temporaire puis renommage) et regroupées (anti-rafale).
// ============================================================================
import { mkdir, readFile, writeFile, rename, appendFile, readdir, unlink } from 'node:fs/promises';
import { join } from 'node:path';

export const DEFAULT_SETTINGS = {
  compute: { level: 'equilibre', mode: 'auto' },
  ai: {
    // model null = automatique : le meilleur modèle installé (« bourso » s'il existe, sinon le modèle ~30B)
    model: process.env.BOURSO_MODEL_NAME ?? null, host: null, keepAlive: '30m', numPredict: 2500, temperature: 0.15, numCtx: 32768, think: false, auto: true,
    policy: { movePct: 0.5, nisAlert: 9, maxAgeMs: 30 * 60_000, minGapMs: 2 * 60_000, onlyDuringSession: false },
    mcPaths: null, horizonDays: 10,
    complete: true, // redemander au modèle, par un appel court, les champs manquants de sa réponse
    // anti-boucle : budget de réflexion, délai de 1re réponse, silence toléré, durée maximale d'un appel
    loop: { maxThinkTokens: 6000, firstTokenSec: 240, stallSec: 120, maxMinutes: 10 },
  },
  agent: { model: null, temperature: 0.3, think: false },
  // données : 'real' (sources gratuites : Yahoo Finance, BCE, actualités) ou 'demo' (simulateur)
  data: { mode: 'real', intensity: 'normale', keys: { finnhub: '', fmp: '', twelvedata: '', stooq: '' }, feeds: [] },
  trading: { initialCash: 100_000, commissionPct: 0.1, commissionMin: 1, ttfPct: 0.4, allowShort: true },
  ui: { theme: 'light' },
};

const merge = (a, b) => {
  if (!b || typeof b !== 'object' || Array.isArray(b)) return b ?? a;
  const out = { ...a };
  for (const [k, v] of Object.entries(b)) out[k] = a?.[k] && typeof a[k] === 'object' && !Array.isArray(a[k]) ? merge(a[k], v) : v;
  return out;
};

export class StateStore {
  constructor(dir = 'data') {
    this.dir = dir;
    this.file = join(dir, 'state.json');
    this.state = { settings: structuredClone(DEFAULT_SETTINGS), favorites: ['MC:XPAR', 'ASML:XAMS', 'SAP:XETR', 'TTE:XPAR', 'AAPL:XNAS'], alerts: [], drawings: {}, layouts: {}, portfolio: null };
    this.timer = null;
    this.signals = [];
  }

  async load() {
    await mkdir(join(this.dir, 'conversations'), { recursive: true });
    try {
      const j = JSON.parse(await readFile(this.file, 'utf8'));
      this.state = { ...this.state, ...j, settings: merge(structuredClone(DEFAULT_SETTINGS), j.settings) };
      // 0.4 : « bourso » n'est plus le modèle par défaut (il est facultatif) → choix automatique
      if (!(j.version >= 4) && this.state.settings.ai.model === 'bourso' && !process.env.BOURSO_MODEL_NAME) this.state.settings.ai.model = null;
    } catch { /* premier lancement */ }
    this.state.version = 4;
    try {
      const lines = (await readFile(join(this.dir, 'signals.jsonl'), 'utf8')).trim().split('\n').slice(-1000);
      this.signals = lines.filter(Boolean).map((l) => JSON.parse(l));
    } catch { /* aucun signal encore */ }
    return this;
  }

  get settings() { return this.state.settings; }
  get favorites() { return this.state.favorites; }

  setSettings(patch) {
    this.state.settings = merge(this.state.settings, patch);
    this.save();
    return this.state.settings;
  }

  /** Tracés du graphique d'une valeur (points en temps/prix : valables à toutes les unités de temps). */
  getDrawings(sym) {
    return this.state.drawings?.[sym] ?? [];
  }
  setDrawings(sym, list) {
    if (!this.state.drawings) this.state.drawings = {};
    if (list.length) this.state.drawings[sym] = list;
    else delete this.state.drawings[sym];
    this.save();
    return this.getDrawings(sym);
  }

  setFavorites(list) {
    this.state.favorites = [...new Set(list)];
    this.save();
    return this.state.favorites;
  }

  save() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.flush().catch(() => {}), 400);
  }

  async flush() {
    const tmp = `${this.file}.tmp`;
    await writeFile(tmp, JSON.stringify(this.state, null, 1));
    await rename(tmp, this.file);
  }

  async addSignal(sig) {
    this.signals.push(sig);
    if (this.signals.length > 2000) this.signals.splice(0, this.signals.length - 2000);
    await appendFile(join(this.dir, 'signals.jsonl'), `${JSON.stringify(sig)}\n`).catch(() => {});
  }

  /** Met à jour un signal (suivi de son issue) et réécrit l'historique de façon groupée. */
  updateSignal(id, patch) {
    const s = this.signals.find((x) => x.id === id);
    if (!s) return;
    Object.assign(s, patch);
    clearTimeout(this.sigTimer);
    this.sigTimer = setTimeout(() => writeFile(join(this.dir, 'signals.jsonl'), `${this.signals.map((x) => JSON.stringify(x)).join('\n')}\n`).catch(() => {}), 2000);
  }

  // ---------------------------------------------------------------- conversations
  async listConversations() {
    const files = await readdir(join(this.dir, 'conversations')).catch(() => []);
    const out = [];
    for (const f of files.filter((x) => x.endsWith('.json'))) {
      try {
        const c = JSON.parse(await readFile(join(this.dir, 'conversations', f), 'utf8'));
        out.push({ id: c.id, title: c.title, updatedAt: c.updatedAt, messages: c.messages.filter((m) => m.role === 'user' || m.role === 'assistant').length, sym: c.sym ?? null });
      } catch { /* fichier illisible */ }
    }
    return out.sort((a, b) => b.updatedAt - a.updatedAt);
  }
  async getConversation(id) {
    if (!/^[\w-]+$/.test(id)) return null;
    try { return JSON.parse(await readFile(join(this.dir, 'conversations', `${id}.json`), 'utf8')); } catch { return null; }
  }
  async saveConversation(c) {
    c.updatedAt = Date.now();
    const f = join(this.dir, 'conversations', `${c.id}.json`);
    await writeFile(`${f}.tmp`, JSON.stringify(c));
    await rename(`${f}.tmp`, f);
  }
  async deleteConversation(id) {
    if (/^[\w-]+$/.test(id)) await unlink(join(this.dir, 'conversations', `${id}.json`)).catch(() => {});
  }
}

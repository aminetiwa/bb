// ============================================================================
//  BOURSO :: server/system.js — état de la machine : charge par cœur, mémoire, GPU
//  (nvidia-smi pour NVIDIA, rocm-smi pour AMD), mémoire du processus.
// ============================================================================
import os from 'node:os';
import { execFile } from 'node:child_process';

let prev = os.cpus().map((c) => c.times);
let gpuCache = { at: 0, data: null, tool: null };

function run(cmd, args) {
  return new Promise((resolve) => {
    execFile(cmd, args, { timeout: 2500 }, (err, out) => resolve(err ? null : out));
  });
}

async function gpuStats() {
  if (Date.now() - gpuCache.at < 1500) return gpuCache;
  let data = null, tool = null;
  const nv = await run('nvidia-smi', ['--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw,power.limit,clocks.sm', '--format=csv,noheader,nounits']);
  if (nv) {
    tool = 'nvidia-smi';
    data = nv.trim().split('\n').map((l) => {
      const [name, util, used, total, temp, power, plimit, clock] = l.split(',').map((s) => s.trim());
      return { name, util: Number(util), memUsedMb: Number(used), memTotalMb: Number(total), tempC: Number(temp), powerW: Number(power), powerLimitW: Number(plimit), clockMhz: Number(clock) };
    });
  } else {
    const rocm = await run('rocm-smi', ['--showuse', '--showmemuse', '--showtemp', '--json']);
    if (rocm) {
      tool = 'rocm-smi';
      try {
        const j = JSON.parse(rocm);
        data = Object.entries(j).filter(([k]) => k.startsWith('card')).map(([k, v]) => ({
          name: k, util: Number(v['GPU use (%)'] ?? NaN), memPct: Number(v['GPU Memory Allocated (VRAM%)'] ?? v['GPU memory use (%)'] ?? NaN),
          tempC: Number(v['Temperature (Sensor edge) (C)'] ?? NaN),
        }));
      } catch { data = null; }
    }
  }
  gpuCache = { at: Date.now(), data, tool };
  return gpuCache;
}

/** Instantané système (CPU par cœur depuis le dernier appel). */
export async function systemSnapshot() {
  const cpus = os.cpus(), now = cpus.map((c) => c.times);
  const perCore = now.map((t, i) => {
    const p = prev[i] ?? t;
    const idle = t.idle - p.idle, total = Object.values(t).reduce((a, b) => a + b, 0) - Object.values(p).reduce((a, b) => a + b, 0);
    return total > 0 ? Math.max(0, Math.min(1, 1 - idle / total)) : 0;
  });
  prev = now;
  const mem = process.memoryUsage(), g = await gpuStats();
  return {
    host: os.hostname(), platform: `${os.type()} ${os.release()} (${os.arch()})`, node: process.version, uptime: os.uptime(), processUptime: process.uptime(),
    cpu: { model: cpus[0]?.model ?? '—', cores: cpus.length, speedMhz: cpus[0]?.speed ?? null, load: os.loadavg(), perCore, avg: perCore.reduce((a, b) => a + b, 0) / Math.max(1, perCore.length) },
    ram: { totalMb: Math.round(os.totalmem() / 2 ** 20), freeMb: Math.round(os.freemem() / 2 ** 20), processRssMb: Math.round(mem.rss / 2 ** 20), heapUsedMb: Math.round(mem.heapUsed / 2 ** 20), externalMb: Math.round((mem.external + (mem.arrayBuffers ?? 0)) / 2 ** 20) },
    gpu: { tool: g.tool, devices: g.data ?? [] },
  };
}

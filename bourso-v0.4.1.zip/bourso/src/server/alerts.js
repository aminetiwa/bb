// ============================================================================
//  BOURSO :: server/alerts.js — alertes de cours (au-dessus / en dessous d'un seuil) et de
//  variation du jour. Vérifiées deux fois par seconde ; une alerte déclenchée se désarme
//  (on peut la réarmer). Diffusées en direct à l'interface (WebSocket « alert »).
// ============================================================================
import { EventEmitter } from 'node:events';

export class AlertService extends EventEmitter {
  constructor({ market, store }) {
    super();
    this.market = market;
    this.store = store;
    if (!Array.isArray(store.state.alerts)) store.state.alerts = [];
  }

  get list() {
    return this.store.state.alerts;
  }

  add({ sym, op, value, note = '' }) {
    const x = this.market.get(sym);
    if (!x) throw new Error('valeur inconnue');
    if (!['above', 'below', 'chg_above', 'chg_below'].includes(op)) throw new Error('condition inconnue');
    const v = Number(value);
    if (!Number.isFinite(v) || (op.startsWith('chg') ? Math.abs(v) > 100 : v <= 0)) throw new Error('seuil invalide');
    const q = this.market.sim.quote(sym);
    const a = { id: `al${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`, sym, name: x.meta.name, ccy: x.meta.currency, op, value: v,
      note: String(note).slice(0, 200), created: Date.now(), priceAtCreation: q.last, active: true, triggeredAt: null, triggerPrice: null };
    this.list.unshift(a);
    if (this.list.length > 300) this.list.length = 300;
    this.store.save();
    this.emit('change');
    return a;
  }

  remove(id) {
    const i = this.list.findIndex((a) => a.id === id);
    if (i >= 0) this.list.splice(i, 1);
    this.store.save();
    this.emit('change');
    return i >= 0;
  }

  rearm(id) {
    const a = this.list.find((x) => x.id === id);
    if (!a) throw new Error('alerte introuvable');
    Object.assign(a, { active: true, triggeredAt: null, triggerPrice: null });
    this.store.save();
    this.emit('change');
    return a;
  }

  check() {
    let changed = false;
    for (const a of this.list) {
      if (!a.active) continue;
      const q = this.market.sim.quote(a.sym);
      if (!q) continue;
      const hit = a.op === 'above' ? q.last >= a.value : a.op === 'below' ? q.last <= a.value : a.op === 'chg_above' ? q.chgPct >= a.value : q.chgPct <= a.value;
      if (!hit) continue;
      Object.assign(a, { active: false, triggeredAt: Date.now(), triggerPrice: q.last, triggerChgPct: q.chgPct });
      changed = true;
      this.emit('trigger', a);
    }
    if (changed) {
      this.store.save();
      this.emit('change');
    }
  }
}

// ============================================================================
//  BOURSO :: server/portfolio.js — compte de NÉGOCIATION FICTIVE (aucun ordre ne quitte la machine).
//
//  Deux comptes séparés : un sur les données réelles, un sur la démonstration (jamais mélangés).
//  Données réelles : un ordre n'est exécuté que pendant la séance de sa place, au dernier cours
//  connu (différé) ± une demi-fourchette estimée ; hors séance, il attend l'ouverture.
//
//  Ordres : marché, limite, stop, stop-limite ; validité jour ou à révocation. Exécution sur la
//  fourchette (achat au prix vendeur, vente au prix acheteur), frais : courtage
//  (% avec minimum) + taxe sur les transactions financières française (0,4 % à l'achat de titres
//  de sociétés françaises de plus d'1 Md€ de capitalisation, depuis le 1er avril 2025).
//  Valorisation en euros (taux de change simulés), P&L latent / réalisé, historique de valeur.
// ============================================================================
import { ttfStatus } from '../data/ttf.js';
import { EventEmitter } from 'node:events';
import { quantile, meanVar } from '../core/quant/numeric.js';

export class Portfolio extends EventEmitter {
  constructor({ market, store }) {
    super();
    this.market = market;
    this.store = store;
    this.load();
  }

  /** Compte du mode de données en cours (portfolioReal / portfolio). */
  get key() {
    return this.market.real ? 'portfolioReal' : 'portfolio';
  }

  /** (Re)charge le compte du mode en cours (au démarrage et au changement de mode). */
  load() {
    const init = this.store.settings.trading.initialCash;
    this.s = this.store.state[this.key] ?? { cash: init, initial: init, positions: {}, orders: [], executions: [], equity: [], seq: 0, fees: 0 };
    this.emit('update');
  }

  #save() {
    this.store.state[this.key] = this.s;
    this.store.save();
  }

  reset(cash = this.store.settings.trading.initialCash) {
    this.s = { cash, initial: cash, positions: {}, orders: [], executions: [], equity: [], seq: 0, fees: 0 };
    this.#save();
    this.emit('update');
  }

  #fx(sym) {
    return this.market.sim.fx.toEur(this.market.get(sym).meta.currency);
  }

  /** Frais d'une exécution en euros (courtage + TTF éventuelle). */
  fees(sym, side, qty, px, at = Date.now()) {
    const t = this.store.settings.trading, x = this.market.get(sym), notionalEur = qty * px * this.#fx(sym);
    const commission = Math.max(t.commissionMin, (notionalEur * t.commissionPct) / 100);
    // TTF : liste officielle de l'année (BOFiP), pas une capitalisation estimée
    const tt = ttfStatus(x.meta.isin, x.capEur, at);
    const ttf = side === 'BUY' && tt.eligible ? (notionalEur * t.ttfPct) / 100 : 0;
    return { commission, ttf, total: commission + ttf, notionalEur, ttfEligible: tt.eligible, ttfReason: tt.reason };
  }

  /** @param {{ sym, side:'BUY'|'SELL', type:'MKT'|'LMT'|'STP'|'STL', qty, limit?, stop?, tif?:'DAY'|'GTC' }} o */
  place(o) {
    const x = this.market.get(o.sym);
    if (!x) throw new Error('valeur inconnue');
    const qty = Math.floor(Number(o.qty));
    if (!(qty > 0)) throw new Error('quantité invalide');
    if (!['BUY', 'SELL'].includes(o.side)) throw new Error('sens invalide');
    const type = o.type ?? 'MKT';
    if ((type === 'LMT' || type === 'STL') && !(o.limit > 0)) throw new Error('prix limite requis');
    if ((type === 'STP' || type === 'STL') && !(o.stop > 0)) throw new Error('prix de déclenchement requis');
    const pos = this.s.positions[o.sym]?.qty ?? 0;
    if (o.side === 'SELL' && !this.store.settings.trading.allowShort && qty > pos) throw new Error('vente à découvert désactivée');
    const order = {
      id: `o${++this.s.seq}`, sym: o.sym, name: x.meta.name, side: o.side, type, qty, limit: o.limit ?? null, stop: o.stop ?? null, tif: o.tif ?? 'DAY',
      status: 'WORKING', created: Date.now(), triggered: type === 'MKT' || type === 'LMT', filledQty: 0, avgPx: null, fees: 0, ccy: x.meta.currency,
      source: o.source ?? 'manuel',
    };
    this.s.orders.unshift(order);
    if (this.s.orders.length > 300) this.s.orders.length = 300;
    this.#match(order);
    this.#save();
    this.emit('update');
    return order;
  }

  cancel(id) {
    const o = this.s.orders.find((x) => x.id === id);
    if (o && o.status === 'WORKING') {
      o.status = 'CANCELLED';
      o.closed = Date.now();
      this.#save();
      this.emit('update');
    }
    return o;
  }

  #match(o) {
    if (o.status !== 'WORKING') return;
    const q = this.market.sim.quote(o.sym), buy = o.side === 'BUY', clk = this.market.get(o.sym)?.clk;
    // validité « jour » : l'ordre vaut pour la séance où il a pu être exécuté, puis expire
    if (o.tif === 'DAY' && o.day && clk && clk.today !== o.day) {
      Object.assign(o, { status: 'EXPIRED', closed: Date.now(), waiting: null, note: `validité « jour » échue (séance du ${o.day})` });
      return;
    }
    if (!Number.isFinite(q?.last)) return;
    if (this.market.real) {
      // données réelles : exécution seulement pendant la séance de la place, sur un cours du jour
      if (clk.state !== 'OPEN') {
        o.waiting = `en attente de l'ouverture (${clk.ex.short})`;
        return;
      }
      if (q.quoteSession !== clk.today) {
        o.waiting = `en attente d'un cours de la séance (${clk.ex.short})`;
        return;
      }
      o.waiting = null;
    }
    if (o.tif === 'DAY' && clk) o.day ??= clk.today;
    if (!o.triggered) {
      const hit = buy ? q.last >= o.stop : q.last <= o.stop;
      if (!hit) return;
      o.triggered = true;
      o.triggeredAt = Date.now();
    }
    const px = buy ? q.ask : q.bid;
    if (o.type === 'LMT' || o.type === 'STL') {
      if (buy ? px > o.limit : px < o.limit) return;
    }
    this.#fill(o, o.qty, o.type === 'LMT' || o.type === 'STL' ? (buy ? Math.min(px, o.limit) : Math.max(px, o.limit)) : px);
  }

  #fill(o, qty, px) {
    const fee = this.fees(o.sym, o.side, qty, px), fx = this.#fx(o.sym), sgn = o.side === 'BUY' ? 1 : -1;
    const p = this.s.positions[o.sym] ?? { qty: 0, avg: 0, realizedEur: 0, ccy: o.ccy, name: o.name };
    let realized = 0;
    if (p.qty === 0 || Math.sign(p.qty) === sgn) {
      p.avg = (p.avg * Math.abs(p.qty) + px * qty) / (Math.abs(p.qty) + qty);
      p.qty += sgn * qty;
    } else {
      const close = Math.min(qty, Math.abs(p.qty));
      realized = (px - p.avg) * close * Math.sign(p.qty) * fx;
      p.qty += sgn * qty;
      if (Math.sign(p.qty) === sgn && p.qty !== 0) p.avg = px; // retournement : nouveau prix de revient
      if (p.qty === 0) p.avg = 0;
    }
    p.realizedEur += realized - fee.total;
    this.s.positions[o.sym] = p;
    if (p.qty === 0 && Math.abs(p.realizedEur) < 1e-9) delete this.s.positions[o.sym];
    this.s.cash += -sgn * qty * px * fx - fee.total;
    this.s.fees += fee.total;
    Object.assign(o, { status: 'FILLED', filledQty: qty, avgPx: px, fees: fee.total, closed: Date.now() });
    const clk = this.market.get(o.sym).clk;
    const ex = { id: `x${Date.now().toString(36)}${this.s.seq}`, order: o.id, sym: o.sym, name: o.name, side: o.side, qty, px, ccy: o.ccy, fees: fee, realizedEur: realized, at: Date.now(), simDate: clk.today, simSec: clk.sec,
      real: this.market.real, note: this.market.real ? 'exécution fictive au dernier cours connu (différé) ± demi-fourchette estimée' : null };
    this.s.executions.unshift(ex);
    if (this.s.executions.length > 500) this.s.executions.length = 500;
    this.emit('fill', ex);
  }

  /** Contrôle des ordres en attente (appelé ~4×/s). */
  tick() {
    let changed = false;
    for (const o of this.s.orders) {
      if (o.status !== 'WORKING') continue;
      const before = `${o.status}|${o.waiting ?? ''}`;
      this.#match(o);
      if (`${o.status}|${o.waiting ?? ''}` !== before) changed = true;
    }
    if (changed) {
      this.#save();
      this.emit('update');
    }
  }

  /** Point de valeur du portefeuille (appelé chaque minute). */
  sample() {
    const v = this.valuation();
    this.s.equity.push([Date.now(), Number(v.totalEur.toFixed(2))]);
    if (this.s.equity.length > 5000) this.s.equity.shift();
  }

  valuation() {
    const rows = [];
    let mv = 0, unreal = 0, realized = 0;
    for (const [sym, p] of Object.entries(this.s.positions)) {
      const q0 = this.market.sim.quote(sym), fx = this.#fx(sym);
      // cours pas encore chargé (données réelles, premier lancement) : valorisé au prix de revient
      const q = Number.isFinite(q0?.last) ? q0 : { ...q0, last: p.avg, prev: p.avg, chgPct: 0 };
      const valueEur = p.qty * q.last * fx, upnl = (q.last - p.avg) * p.qty * fx;
      mv += valueEur;
      unreal += p.qty ? upnl : 0;
      realized += p.realizedEur;
      const x = this.market.get(sym);
      rows.push({ sym, name: p.name, qty: p.qty, avg: p.avg, last: q.last, ccy: p.ccy, chgPct: q.chgPct, valueEur, upnlEur: p.qty ? upnl : 0, upnlPct: p.avg ? ((q.last / p.avg - 1) * 100 * Math.sign(p.qty)) : 0,
        realizedEur: p.realizedEur, dayPnlEur: (q.last - q.prev) * p.qty * fx, sector: x.meta.sector, region: x.meta.region });
    }
    const totalEur = this.s.cash + mv;
    for (const r of rows) r.weight = totalEur ? r.valueEur / totalEur : 0;
    return { cashEur: this.s.cash, marketValueEur: mv, totalEur, unrealizedEur: unreal, realizedEur: realized, feesEur: this.s.fees, perfPct: (totalEur / this.s.initial - 1) * 100, initial: this.s.initial, positions: rows };
  }

  /**
   * Risque du portefeuille sur un an : rendements quotidiens des positions alignés par date
   * (séances communes), pondérés par leur poids actuel (liquidités incluses, à rendement nul).
   * Hors effet de change (pas d'historique de change dans la simulation).
   */
  risk() {
    const v = this.valuation(), pos = v.positions.filter((p) => p.qty !== 0), total = v.totalEur;
    if (!pos.length || !(total > 0)) return { positions: 0, totalEur: total };
    const maps = pos.map((p) => {
      const d = this.market.sim.daily(p.sym), m = new Map();
      for (let i = Math.max(1, d.close.length - 252); i < d.close.length; i++) m.set(d.dates[i], d.close[i] / d.close[i - 1] - 1);
      return m;
    });
    const idx = this.market.sim.indexDaily('EUROPE'), im = new Map();
    for (let i = 1; i < idx.close.length; i++) im.set(idx.dates[i], idx.close[i] / idx.close[i - 1] - 1);
    const dates = [...maps[0].keys()].filter((t) => maps.every((m) => m.has(t)) && im.has(t));
    const T = dates.length, k = pos.length;
    if (T < 30) return { positions: k, totalEur: total, error: 'historique commun insuffisant' };
    const R = maps.map((m) => Float64Array.from(dates, (t) => m.get(t))), I = Float64Array.from(dates, (t) => im.get(t));
    const w = pos.map((p) => p.valueEur / total);
    const rp = new Float64Array(T);
    for (let t = 0; t < T; t++) for (let j = 0; j < k; j++) rp[t] += w[j] * R[j][t];
    const mu = R.map((r) => meanVar(r).mean), C = Array.from({ length: k }, () => new Float64Array(k));
    for (let a = 0; a < k; a++) for (let b = a; b < k; b++) {
      let s = 0;
      for (let t = 0; t < T; t++) s += (R[a][t] - mu[a]) * (R[b][t] - mu[b]);
      C[a][b] = C[b][a] = s / (T - 1);
    }
    const Cw = C.map((row) => row.reduce((acc, c, j) => acc + c * w[j], 0));
    const varP = w.reduce((acc, wi, i) => acc + wi * Cw[i], 0), sdP = Math.sqrt(Math.max(0, varP));
    const sd = C.map((row, i) => Math.sqrt(row[i]));
    const mv = meanVar(rp), q05 = quantile(rp, 0.05), q01 = quantile(rp, 0.01);
    let es = 0, ne = 0;
    for (const x of rp) if (x <= q05) { es += x; ne++; }
    const im2 = meanVar(I);
    let cov = 0;
    for (let t = 0; t < T; t++) cov += (rp[t] - mv.mean) * (I[t] - im2.mean);
    cov /= T - 1;
    let eq = 1, peak = 1, mdd = 0;
    for (const x of rp) { eq *= 1 + x; peak = Math.max(peak, eq); mdd = Math.min(mdd, eq / peak - 1); }
    return {
      positions: k, days: T, totalEur: total, investedPct: (v.marketValueEur / total) * 100,
      volAnnPct: sdP * Math.sqrt(252) * 100, var95Eur: -q05 * total, var99Eur: -q01 * total, es95Eur: ne ? (-es / ne) * total : null,
      var95Pct: -q05 * 100, betaEurope: im2.variance > 0 ? cov / im2.variance : null, maxDrawdown1aPct: mdd * 100, return1aPct: (eq - 1) * 100,
      diversificationRatio: sdP > 0 ? w.reduce((acc, wi, i) => acc + Math.abs(wi) * sd[i], 0) / sdP : null,
      rows: pos.map((p, i) => ({ sym: p.sym, name: p.name, weightPct: w[i] * 100, volAnnPct: sd[i] * Math.sqrt(252) * 100, riskContribPct: varP > 0 ? ((w[i] * Cw[i]) / varP) * 100 : null })),
      corr: C.map((row, a) => Array.from(row, (c, b) => Number((c / (sd[a] * sd[b] || 1)).toFixed(3)))),
    };
  }

  summary() {
    const v = this.valuation(), bySector = {}, byRegion = {};
    for (const r of v.positions) {
      bySector[r.sector] = (bySector[r.sector] ?? 0) + r.valueEur;
      byRegion[r.region] = (byRegion[r.region] ?? 0) + r.valueEur;
    }
    return { ...v, bySector, byRegion, orders: this.s.orders.slice(0, 100), executions: this.s.executions.slice(0, 100), equity: this.s.equity.slice(-1000) };
  }
}

// ============================================================================
//  BOURSO :: server/market-service.js — le marché côté serveur : DONNÉES RÉELLES (sources gratuites,
//  market/real.js) ou simulateur mondial (mode démonstration), même interface ; actualités,
//  historiques à toutes les unités de temps (format binaire compact), screener calculé en tâche de
//  fond sur tous les cœurs, vues d'ensemble (indices, secteurs, largeur de marché), données
//  d'entrée du dossier IA. Le mode se change à chaud dans Réglages.
// ============================================================================
import { EventEmitter } from 'node:events';
import { WorldSim, STEPS_PER_SEC } from '../market/sim.js';
import { RealMarket } from '../market/real.js';
import { INDEX_SYMBOLS } from '../data/symbols.js';
import { EXCHANGES, REGIONS, localTimeOf } from '../market/exchanges.js';
import { SECTORS } from '../market/universe.js';

export const TIMEFRAMES = {
  '1s': { base: 's', k: 1, label: '1 s' }, '5s': { base: 's', k: 5, label: '5 s' }, '15s': { base: 's', k: 15, label: '15 s' },
  '1m': { base: 'm', k: 1, label: '1 min' }, '2m': { base: 'm', k: 2, label: '2 min' }, '5m': { base: 'm', k: 5, label: '5 min' }, '15m': { base: 'm', k: 15, label: '15 min' },
  '30m': { base: 'm', k: 30, label: '30 min' }, '1h': { base: 'm', k: 60, label: '1 h' }, '4h': { base: 'm', k: 240, label: '4 h' },
  '1D': { base: 'd', k: 1, label: 'Jour' }, '1W': { base: 'w', k: 1, label: 'Semaine' }, '1M': { base: 'mo', k: 1, label: 'Mois' },
};

/** Regroupe des barres de base (par séance de `perSession` barres) par paquets de k, sans franchir les séances. */
function aggregateSessions(b, perSession, k, todayFrom) {
  if (k === 1) return { ...b, perSession, todayFromAgg: todayFrom };
  const N = b.close.length, per = Math.ceil(perSession / k), days = Math.ceil(N / perSession);
  const cap = days * per, o = new Float64Array(cap), h = new Float64Array(cap), l = new Float64Array(cap), c = new Float64Array(cap), v = new Float64Array(cap);
  let n = 0, cur = -1;
  for (let i = 0; i < N; i++) {
    const day = Math.floor(i / perSession), key = day * per + Math.floor((i % perSession) / k);
    if (key !== cur) {
      cur = key;
      n = key + 1;
      o[key] = b.open[i]; h[key] = b.high[i]; l[key] = b.low[i]; c[key] = b.close[i]; v[key] = b.volume[i];
    } else {
      if (b.high[i] > h[key]) h[key] = b.high[i];
      if (b.low[i] < l[key]) l[key] = b.low[i];
      c[key] = b.close[i];
      v[key] += b.volume[i];
    }
  }
  return { open: o.subarray(0, n), high: h.subarray(0, n), low: l.subarray(0, n), close: c.subarray(0, n), volume: v.subarray(0, n), perSession: per, todayFromAgg: Math.floor(todayFrom / perSession) * per };
}

/** Regroupe des bougies quotidiennes par semaine ISO ou par mois. */
function aggregateCalendar(d, dates, mode) {
  const keyOf = (s) => {
    if (mode === 'mo') return s.slice(0, 7);
    const t = new Date(`${s}T12:00:00Z`), day = (t.getUTCDay() + 6) % 7;
    return new Date(t.getTime() - day * 86_400_000).toISOString().slice(0, 10);
  };
  const o = [], h = [], l = [], c = [], v = [], ds = [];
  let cur = null;
  for (let i = 0; i < d.close.length; i++) {
    const k = keyOf(dates[i]);
    if (k !== cur) {
      cur = k;
      o.push(d.open[i]); h.push(d.high[i]); l.push(d.low[i]); c.push(d.close[i]); v.push(d.volume[i]); ds.push(dates[i]);
    } else {
      const j = c.length - 1;
      if (d.high[i] > h[j]) h[j] = d.high[i];
      if (d.low[i] < l[j]) l[j] = d.low[i];
      c[j] = d.close[i];
      v[j] += d.volume[i];
    }
  }
  const F = (a) => Float64Array.from(a);
  return { open: F(o), high: F(h), low: F(l), close: F(c), volume: F(v), dates: ds };
}

export class MarketService extends EventEmitter {
  /**
   * @param {{ mode?: 'real'|'demo', store, compute, log?: Function, dataDir?: string, fetchImpl?: Function, rewrite?: Function }} o
   *   rewrite : redirection des URL des sources (tests : faux internet local)
   */
  constructor({ mode = 'demo', store, compute, log = () => {}, dataDir = 'data', fetchImpl, rewrite = null }) {
    super();
    this.setMaxListeners(50);
    Object.assign(this, { log, store, compute, dataDir, fetchImpl, rewrite });
    this.mode = mode === 'real' ? 'real' : 'demo';
    this.watchers = new Map(); // valeurs affichées dans un navigateur (rafraîchies plus souvent)
    this.extraHot = () => [];
    this.#create();
  }

  get real() {
    return this.mode === 'real';
  }

  #create() {
    const t0 = Date.now();
    this.lastSent = new Map();
    this.screen = new Map();
    this.screenAt = 0;
    this.stepMs = 0;
    if (this.real) {
      const d = this.store?.settings?.data ?? {};
      this.sim = new RealMarket({ dataDir: this.dataDir, store: this.store, log: this.log, fetchImpl: this.fetchImpl, rewrite: this.rewrite, intensity: d.intensity, keys: d.keys ?? {}, feeds: d.feeds?.length ? d.feeds : undefined, hot: () => this.hotSymbols() });
      this.sim.news.on('news', (item) => this.emit('news', item));
      this.sim.on('universe', (sym) => this.emit('universe', sym));
    } else {
      this.sim = new WorldSim({ demo: true });
      this.log(`marché simulé (démonstration) : ${this.sim.instruments.length} valeurs, ${Object.keys(this.sim.clocks).length} places, ${Date.now() - t0} ms`);
    }
    this.sim.on('minute', (mic) => this.emit('minute', mic));
    this.sim.on('rollover', (mic) => this.emit('rollover', mic));
  }

  /** Chargement des caches disque (données réelles) : à attendre avant start(). */
  async init() {
    if (this.real) await this.sim.init();
    return this;
  }

  /** Valeurs « chaudes » : favoris, valeurs affichées, positions et alertes. */
  hotSymbols() {
    return [...new Set([...(this.store?.favorites ?? []), ...this.watchers.keys(), ...(this.extraHot() ?? [])])];
  }

  /** Une valeur est affichée (+1) ou ne l'est plus (−1) dans un navigateur. */
  watch(sym, delta = 1) {
    const n = (this.watchers.get(sym) ?? 0) + delta;
    if (n > 0) this.watchers.set(sym, n);
    else this.watchers.delete(sym);
    if (delta > 0 && this.real) this.sim.touch(sym);
  }

  /** Passe des données réelles à la démonstration (ou l'inverse) sans redémarrer le serveur. */
  async setMode(mode) {
    const m = mode === 'real' ? 'real' : 'demo';
    if (m === this.mode) return this.mode;
    this.stop();
    this.mode = m;
    this.#create();
    await this.init();
    this.start();
    this.emit('mode', this.mode);
    return this.mode;
  }

  /** Données nécessaires à un écran ou à un calcul (historique, intraday) : à attendre en mode réel. */
  async prepare(sym, tf = null, { news = false } = {}) {
    if (this.real) await this.sim.prepare(sym, { tf, news });
  }

  /** Ce que la source de données sait faire (l'interface s'adapte). */
  dataInfo() {
    if (!this.real) return { mode: 'demo', real: false, label: 'Démonstration (données simulées)', capabilities: { book: true, tape: true, seconds: true, flow: true }, sources: ['Simulation'] };
    return {
      mode: 'real', real: true, label: 'Données réelles (différées)', capabilities: { book: false, tape: false, seconds: false, flow: false },
      intensity: this.sim.intensity, sources: ['Yahoo Finance (cours, historiques, intraday)', 'BCE (change)', 'Google Actualités, GDELT, presse (actualités)'],
      delay: 'Cours différés selon la place (≈ 15 min en Europe, temps réel ou différé aux États-Unis selon la source).',
    };
  }

  status() {
    return this.real ? this.sim.status() : { modeLabel: 'démonstration', instruments: this.sim.instruments.length };
  }

  start() {
    if (this.real) {
      this.sim.start();
      this.screenFirst = setTimeout(() => this.refreshScreener().catch((e) => this.log(`screener : ${e.message}`)), 4000);
      this.screenTimer = setInterval(() => this.refreshScreener().catch(() => {}), 90_000);
      return;
    }
    let next = performance.now();
    const loop = () => {
      const now = performance.now();
      let n = 0;
      while (next <= now && n < 20) {
        const t = performance.now();
        this.sim.step();
        this.stepMs = this.stepMs * 0.98 + (performance.now() - t) * 0.02;
        next += 1000 / STEPS_PER_SEC;
        n++;
      }
      if (next < now - 1000) next = now; // retard trop grand (machine en veille) : on ne rattrape pas
      this.timer = setTimeout(loop, Math.max(1, next - performance.now()));
    };
    loop();
    const news = () => {
      const item = this.sim.news.generate(this.store.favorites);
      this.emit('news', item);
      this.newsTimer = setTimeout(news, 9000 + Math.random() * 22_000);
    };
    for (let i = 0; i < 12; i++) this.sim.news.generate(this.store.favorites);
    this.newsTimer = setTimeout(news, 6000);
    this.refreshScreener().catch((e) => this.log(`screener : ${e.message}`));
    this.screenTimer = setInterval(() => this.refreshScreener().catch(() => {}), 60_000);
  }

  stop() {
    clearTimeout(this.timer);
    clearTimeout(this.newsTimer);
    clearTimeout(this.screenFirst);
    clearInterval(this.screenTimer);
    if (this.real) this.sim.stop();
  }

  get(sym) {
    return this.sim.get(sym);
  }

  /**
   * Rendements logarithmiques quotidiens ALIGNÉS PAR DATE (séances communes à toutes les valeurs) :
   * indispensable dès que les places diffèrent (calendriers de fériés différents) — sinon les séries
   * se décalent de quelques jours et les corrélations s'effondrent artificiellement vers 0.
   * Un férié propre à une place est absorbé dans le rendement de la séance commune suivante.
   * @returns {{ dates:string[], returns:Float64Array[] }}
   */
  alignedReturns(syms, win = 252) {
    const series = syms.map((s) => this.sim.daily(s));
    if (!series.length) return { dates: [], returns: [] };
    const span = Math.ceil(win * 1.6) + 30;
    let common = null;
    for (const d of series) {
      const set = new Set(d.dates.slice(-span));
      common = common ? common.filter((t) => set.has(t)) : [...set];
    }
    common.sort();
    const dates = common.slice(-(win + 1));
    const returns = series.map((d) => {
      const at = new Map();
      for (let i = Math.max(0, d.dates.length - span); i < d.dates.length; i++) at.set(d.dates[i], d.close[i]);
      const out = new Float64Array(Math.max(0, dates.length - 1));
      for (let i = 1; i < dates.length; i++) out[i - 1] = Math.log(at.get(dates[i]) / at.get(dates[i - 1]));
      return out;
    });
    return { dates: dates.slice(1), returns };
  }

  // ---------------------------------------------------------------- métadonnées, cotations
  meta(sym) {
    const x = this.sim.get(sym);
    if (!x) return null;
    const m = x.meta, ex = x.ex;
    return {
      ...m, exchange: ex.name, exShort: ex.short, tz: ex.tz, index: this.real ? INDEX_SYMBOLS[m.mic]?.name ?? ex.index : ex.index, openTime: ex.open, closeTime: ex.close, breaks: ex.breaks,
      openMin: ex.openMin, sessionSec: ex.sessionSec, sessionMin: ex.sessionMin, fundamentals: x.fund, capEur: x.capEur, adv: x.adv, beta: x.beta,
      real: this.real, dataStatus: this.real ? x.status : 'simulé', dataError: this.real ? x.error : null, quoteSource: this.real ? x.q.source : 'simulation', quoteAt: this.real ? x.q.at || null : Date.now(),
      historySource: this.real ? x.hist.source : 'simulation', historyDays: x.daily.n,
    };
  }

  universe() {
    return this.sim.instruments.map((x) => {
      const m = x.meta;
      return { sym: m.sym, code: m.code, name: m.name, mic: m.mic, ex: x.ex.short, country: m.country, region: m.region, sector: m.sector, sectorKey: m.sectorKey, ccy: m.currency, isin: m.isin, tick: m.tick, cap: Number.isFinite(x.capEur) ? Math.round(x.capEur / 1e8) / 10 : null };
    });
  }

  /** Cotation compacte : [sym, dernier, var %, volume, achat, vente, haut, bas, ouverture, veille, capitaux]. */
  compact(x) {
    const q = this.sim.quote(x.meta.sym);
    return [x.meta.sym, q.last, Number(q.chgPct.toFixed(3)), Math.round(q.volume), q.bid, q.ask, q.high, q.low, q.open, q.prev, Math.round(q.turnover)];
  }

  allQuotes() {
    return this.sim.instruments.map((x) => this.compact(x));
  }

  /** Cotations modifiées depuis le dernier appel (diffusion WebSocket). */
  changedQuotes() {
    const out = [];
    for (const x of this.sim.instruments) {
      const key = `${x.last}|${x.volume}`;
      if (this.lastSent.get(x.meta.sym) === key) continue;
      this.lastSent.set(x.meta.sym, key);
      out.push(this.compact(x));
    }
    return out;
  }

  quote(sym) {
    const x = this.sim.get(sym);
    if (!x) return null;
    const q = this.sim.quote(sym);
    return { ...q, name: x.meta.name, ccy: x.meta.currency, state: this.real ? x.clk.state : x.clk.live ? 'OPEN' : 'CLOSED' };
  }

  // ---------------------------------------------------------------- historiques
  /**
   * Historique à l'unité `tf`. @returns {{ header: object, arrays: Float64Array[] }}
   */
  history(sym, tf = '1m', days) {
    const x = this.sim.get(sym), T = TIMEFRAMES[tf];
    if (!x || !T) return null;
    const ex = x.ex;
    const head = { sym, tf, label: T.label, tick: x.meta.tick, ccy: x.meta.currency, name: x.meta.name, ex: { mic: ex.mic, openMin: ex.openMin, breaks: ex.breaks, sessionSec: ex.sessionSec, tz: ex.tz } };
    let b;
    if (this.real && (T.base === 's' || T.base === 'm')) {
      // données réelles : 1-2 min depuis les bougies 1 min (5 séances) ; au-delà, bougies natives de
      // la source (5, 15, 30 min sur un mois ; 1 h sur six mois), regroupées si besoin (4 h)
      const k = T.base === 's' ? 1 : T.k;
      const base = k <= 2 ? 1 : k >= 60 ? 60 : k;
      const raw = base === 1 ? this.sim.minutes(sym, days ?? 7) : this.sim.bars(sym, base);
      const agg = aggregateSessions(raw, raw.sessionBars, base === 1 ? k : k / base, raw.todayFrom);
      b = agg;
      Object.assign(head, { intraday: true, barSeconds: 60 * k, perSession: agg.perSession, todayFrom: agg.todayFromAgg, dates: raw.dates, real: true, substituted: T.base === 's' ? '1m' : null });
    } else if (T.base === 's' || T.base === 'm') {
      const nd = days ?? (T.base === 's' ? (T.k === 1 ? 2 : 5) : T.k <= 2 ? 5 : T.k <= 15 ? 20 : 20);
      const raw = T.base === 's' ? this.sim.seconds(sym, Math.min(nd, this.sim.secDays)) : this.sim.minutes(sym, Math.min(nd, this.sim.intraDays));
      const per = raw.sessionBars, agg = aggregateSessions(raw, per, T.k, raw.todayFrom);
      b = agg;
      Object.assign(head, { intraday: true, barSeconds: (T.base === 's' ? 1 : 60) * T.k, perSession: agg.perSession, todayFrom: agg.todayFromAgg, dates: raw.dates });
    } else {
      const d = this.sim.daily(sym), q = this.sim.quote(sym), n = d.close.length;
      const all = { open: new Float64Array(n + 1), high: new Float64Array(n + 1), low: new Float64Array(n + 1), close: new Float64Array(n + 1), volume: new Float64Array(n + 1) };
      for (const f of ['open', 'high', 'low', 'close', 'volume']) all[f].set(d[f]);
      all.open[n] = q.open; all.high[n] = Math.max(q.high, q.last); all.low[n] = Math.min(q.low, q.last); all.close[n] = q.last; all.volume[n] = q.volume;
      const dates = [...d.dates, q.date];
      if (T.base === 'd') {
        b = all;
        head.dates = dates;
      } else {
        const agg = aggregateCalendar(all, dates, T.base);
        b = agg;
        head.dates = agg.dates;
      }
      Object.assign(head, { intraday: false, barSeconds: 86_400 * (T.base === 'd' ? 1 : T.base === 'w' ? 5 : 21) });
    }
    head.count = b.close.length;
    return { header: head, arrays: [b.open, b.high, b.low, b.close, b.volume] };
  }

  /** Encodage binaire : [u32 longueur][en-tête JSON][bourrage → 8][5 × count float64]. */
  static encode({ header, arrays }) {
    const h = Buffer.from(JSON.stringify(header), 'utf8');
    const off = Math.ceil((4 + h.length) / 8) * 8, n = header.count;
    const buf = Buffer.alloc(off + 5 * n * 8);
    buf.writeUInt32LE(h.length, 0);
    h.copy(buf, 4);
    arrays.forEach((a, k) => {
      const view = new Float64Array(buf.buffer, buf.byteOffset + off + k * n * 8, n);
      view.set(a.subarray(0, n));
    });
    return buf;
  }

  /**
   * Bougie EN COURS à l'unité de temps `tf` (exacte : agrégée côté serveur à partir des minutes /
   * secondes closes du jour + la minute / seconde en cours), avec la bougie précédente complète.
   * `i` : rang de la bougie dans la séance du jour (minutes / secondes), ou date de période.
   */
  liveBar(x, tf) {
    const T = TIMEFRAMES[tf];
    if (!T) return null;
    const agg = (A, from, to, cur) => {
      let o = from < to ? A.open[from] : cur.o, h = cur.h, l = cur.l, v = cur.v;
      for (let i = from; i < to; i++) { if (A.high[i] > h) h = A.high[i]; if (A.low[i] < l) l = A.low[i]; v += A.volume[i]; }
      return { o, h, l, c: cur.c, v };
    };
    const full = (A, from, to) => {
      let h = -Infinity, l = Infinity, v = 0;
      for (let i = from; i < to; i++) { if (A.high[i] > h) h = A.high[i]; if (A.low[i] < l) l = A.low[i]; v += A.volume[i]; }
      return { o: A.open[from], h, l, c: A.close[to - 1], v };
    };
    if (T.base === 'm' || T.base === 's') {
      const A = T.base === 'm' ? x.m : x.s1, cur = T.base === 'm' ? x.curM : x.curS;
      if (!A || !cur) return null;
      const n = T.base === 'm' ? x.mN : A.n, k = T.k, start = Math.floor(n / k) * k;
      const bar = { i: Math.floor(n / k), ...agg(A, start, n, cur) };
      if (start >= k) bar.prev = { i: bar.i - 1, ...full(A, start - k, start) };
      return bar;
    }
    const q = this.sim.quote(x.meta.sym), today = { o: q.open, h: Math.max(q.high, q.last), l: Math.min(q.low, q.last), c: q.last, v: q.volume };
    if (T.base === 'd') return { date: x.clk.today, ...today };
    const d = this.sim.daily(x.meta.sym), dates = d.dates, nd = d.close.length, keyOf = (s) => {
      if (T.base === 'mo') return s.slice(0, 7);
      const t = new Date(`${s}T12:00:00Z`), wd = (t.getUTCDay() + 6) % 7;
      return new Date(t.getTime() - wd * 86_400_000).toISOString().slice(0, 10);
    };
    const key = keyOf(x.clk.today);
    let j = nd - 1;
    const bar = { date: key, ...today };
    while (j >= 0 && keyOf(dates[j]) === key) {
      bar.o = d.open[j];
      if (d.high[j] > bar.h) bar.h = d.high[j];
      if (d.low[j] < bar.l) bar.l = d.low[j];
      bar.v += d.volume[j];
      j--;
    }
    return bar;
  }

  /** État temps réel d'une valeur suivie : dernières transactions + bougies en cours. */
  live(sym, sinceSeq = 0, tf = null) {
    const x = this.sim.get(sym);
    if (!x) return null;
    const tr = this.sim.tape(sym, 200, sinceSeq);
    const c = x.curM, s = x.curS;
    return {
      sym, q: this.compact(x), trades: tr.map((t) => [t.px, t.qty, t.side, t.time, t.seq]), seq: tr.length ? tr.at(-1).seq : sinceSeq,
      m: [c.o, c.h, c.l, c.c, c.v], mN: x.mN, s: s ? [s.o, s.h, s.l, s.c, s.v] : null, sN: x.s1?.n ?? null, sec: x.clk.sec,
      pm: x.mN > 0 ? [x.m.open[x.mN - 1], x.m.high[x.mN - 1], x.m.low[x.mN - 1], x.m.close[x.mN - 1], x.m.volume[x.mN - 1]] : null,
      ps: x.s1 && x.s1.n > 0 ? [x.s1.open[x.s1.n - 1], x.s1.high[x.s1.n - 1], x.s1.low[x.s1.n - 1], x.s1.close[x.s1.n - 1], x.s1.volume[x.s1.n - 1]] : null,
      time: this.real ? this.sim.quote(sym).time : localTimeOf(x.ex, x.clk.sec), date: x.clk.today, flow: this.real ? null : { buy: Math.round(x.buyVol), sell: Math.round(x.sellVol), lb: x.largeBuys, ls: x.largeSells },
      vwap: x.volume > 0 ? x.turnover / x.volume : x.last, tf, bar: tf ? this.liveBar(x, tf) : null,
    };
  }

  // ---------------------------------------------------------------- screener (tâche de fond, tous les cœurs)
  async refreshScreener() {
    if (this.screening) return;
    this.screening = true;
    const t0 = Date.now();
    try {
      // données réelles : seules les valeurs dont l'historique est chargé (les autres suivront)
      const list = this.sim.instruments.filter((x) => x.daily.n >= 60 && Number.isFinite(this.sim.quote(x.meta.sym).last)), batch = 24, jobs = [];
      for (let i = 0; i < list.length; i += batch) {
        const items = list.slice(i, i + batch).map((x) => {
          const d = this.sim.daily(x.meta.sym), q = this.sim.quote(x.meta.sym);
          return { sym: x.meta.sym, daily: { open: d.open.slice(), high: d.high.slice(), low: d.low.slice(), close: d.close.slice(), volume: d.volume.slice(), n: d.close.length },
            quote: q, dates: d.dates.slice(-252), sessionFrac: Math.min(1, x.clk.sec / x.ex.sessionSec) };
        });
        jobs.push(this.compute.task('screen', { items }, { priority: 0 }));
      }
      for (const rows of await Promise.all(jobs)) for (const r of rows) if (!r.error) this.screen.set(r.sym, r);
      this.screenAt = Date.now();
      this.screenMs = Date.now() - t0;
      this.emit('screener', { at: this.screenAt, ms: this.screenMs });
    } finally {
      this.screening = false;
    }
  }

  /**
   * Taille d'une valeur (pour classer, choisir « les plus grosses », dimensionner la carte) :
   * démonstration → capitalisation ; données réelles → capitaux moyens échangés par jour sur
   * 20 séances (mesure réelle et homogène : la capitalisation n'est connue qu'avec une clé).
   */
  sizeOf(x) {
    const v = this.real ? x.liqEur : x.capEur;
    return Number.isFinite(v) ? v : 0;
  }

  /** Lignes du tableau des marchés / screener (cotation en direct + indicateurs calculés). */
  screener() {
    const r2 = (v, d = 3) => (Number.isFinite(v) ? Number(v.toFixed(d)) : null);
    return this.sim.instruments.map((x) => {
      const q = this.sim.quote(x.meta.sym), m = x.meta, s = this.screen.get(m.sym) ?? {};
      return {
        ...s, sym: m.sym, code: m.code, name: m.name, mic: m.mic, ex: x.ex.short, region: m.region, country: m.country, sector: m.sector, sectorKey: m.sectorKey, ccy: m.currency,
        last: q.last, chgPct: r2(q.chgPct), volume: Math.round(q.volume), turnover: Math.round(q.turnover), capEur: Number.isFinite(x.capEur) ? Math.round(x.capEur / 1e6) : null,
        liqEur: Number.isFinite(x.liqEur) ? r2(x.liqEur / 1e6, 2) : null, size: r2(this.sizeOf(x) / 1e6, 2),
        vwapDist: r2((q.last / q.vwap - 1) * 100), per: x.fund.per ?? null, dy: x.fund.rendementDividendePct ?? null, high: q.high, low: q.low,
      };
    });
  }

  // ---------------------------------------------------------------- vues d'ensemble
  sectors() {
    // données réelles : seules les valeurs déjà cotées comptent (les autres arrivent au fil des chargements)
    const rows = this.screener().filter((r) => Number.isFinite(r.chgPct)), by = new Map();
    for (const r of rows) {
      const k = r.sectorKey;
      if (!by.has(k)) by.set(k, { key: k, name: SECTORS[k]?.[0] ?? r.sector ?? 'Autres', n: 0, chg: 0, up: 0, down: 0, perf1m: 0, n1m: 0, best: null, worst: null, cap: 0, size: 0, capKnown: 0 });
      const s = by.get(k);
      s.n++; s.chg += r.chgPct; s.size += r.size ?? 0;
      if (Number.isFinite(r.capEur)) { s.cap += r.capEur; s.capKnown++; }
      if (r.chgPct > 0) s.up++; else if (r.chgPct < 0) s.down++;
      if (Number.isFinite(r.perf1m)) { s.perf1m += r.perf1m; s.n1m++; }
      if (!s.best || r.chgPct > s.best.chgPct) s.best = { sym: r.sym, name: r.name, chgPct: r.chgPct };
      if (!s.worst || r.chgPct < s.worst.chgPct) s.worst = { sym: r.sym, name: r.name, chgPct: r.chgPct };
    }
    return [...by.values()].map((s) => ({ ...s, cap: s.capKnown ? s.cap : null, chg: s.chg / s.n, perf1m: s.n1m ? s.perf1m / s.n1m : null })).sort((a, b) => b.chg - a.chg);
  }

  overview() {
    const rows = this.screener().filter((r) => Number.isFinite(r.chgPct)), byRegion = {};
    for (const reg of REGIONS) {
      const r = rows.filter((x) => x.region === reg);
      if (!r.length) continue;
      byRegion[reg] = {
        n: r.length, up: r.filter((x) => x.chgPct > 0).length, down: r.filter((x) => x.chgPct < 0).length,
        aboveSma200: r.filter((x) => x.aboveSma200).length, aboveVwap: r.filter((x) => x.vwapDist > 0).length, avgChg: r.reduce((a, x) => a + x.chgPct, 0) / r.length,
      };
    }
    const sorted = [...rows].sort((a, b) => b.chgPct - a.chgPct);
    for (const r of rows) r.turnoverEur = r.turnover * this.sim.fx.toEur(r.ccy);
    const eu = rows.filter((x) => x.region === 'Europe');
    const pick = (a) => a.map((x) => ({ sym: x.sym, name: x.name, ex: x.ex, last: x.last, chgPct: x.chgPct, ccy: x.ccy, volume: x.volume, turnoverEur: Math.round(x.turnoverEur), relVol: x.relVol ?? null }));
    const byTurnover = (a) => [...a].sort((x, y) => y.turnoverEur - x.turnoverEur).slice(0, 10);
    const byRelVol = (a) => a.filter((x) => Number.isFinite(x.relVol)).sort((x, y) => y.relVol - x.relVol).slice(0, 10);
    return {
      indices: this.sim.indices(), breadth: byRegion, sectors: this.sectors(),
      gainers: pick(sorted.slice(0, 10)), losers: pick(sorted.slice(-10).reverse()),
      gainersEu: pick(sorted.filter((x) => x.region === 'Europe').slice(0, 10)), losersEu: pick(sorted.filter((x) => x.region === 'Europe').slice(-10).reverse()),
      active: pick(byTurnover(rows)), activeEu: pick(byTurnover(eu)),
      relVol: pick(byRelVol(rows)), relVolEu: pick(byRelVol(eu)),
      clocks: this.sim.clockInfo(), fx: this.sim.fx.list(), screenAt: this.screenAt,
    };
  }

  indexSeries(key) {
    const s = this.sim.indexDaily(key);
    return { key, dates: s.dates, close: Array.from(s.close, (v) => Number(v.toFixed(2))) };
  }

  // ---------------------------------------------------------------- dossier IA : données d'entrée
  dossierInput(sym, { news = [], position = null, mc = null, mcLevels = null, backtests = null, ageMs = 0, memory = null } = {}) {
    const x = this.sim.get(sym), m = x.meta, ex = x.ex, q = this.sim.quote(sym);
    const d = this.sim.daily(sym), mins = this.sim.minutes(sym, 10), idx = this.sim.indexDaily(m.mic);
    // indice aligné sur les DATES de la valeur (fériés et séances manquantes : dernier niveau connu)
    const at = new Map(idx.dates.map((t, i) => [t, idx.close[i]]));
    let lastIdx = NaN;
    const idxArr = d.dates.map((t) => { const v = at.get(t); if (v !== undefined) lastIdx = v; return lastIdx; });
    const firstOk = idxArr.findIndex(Number.isFinite);
    const idxClose = firstOk >= 0 ? Float64Array.from(idxArr.slice(firstOk)) : new Float64Array(0);
    const idxName = this.real ? `${INDEX_SYMBOLS[m.mic]?.name ?? ex.index}${INDEX_SYMBOLS[m.mic]?.proxy ? ' (fonds)' : ''}` : `${ex.index} (panier simulé)`;
    const qd = this.real ? { ...q, bid: null, ask: null } : { ...q };
    const sectorRows = this.screener().filter((r) => r.sectorKey === m.sectorKey);
    const sectorRank = [...sectorRows].sort((a, b) => (b.perf1m ?? -1e9) - (a.perf1m ?? -1e9)).findIndex((r) => r.sym === sym) + 1;
    const nowNews = Date.now();
    return {
      meta: { ...m, exchangeName: ex.name }, now: { session: x.clk.live ? 'CONTINUOUS' : 'CLOSED', time: this.real ? q.time : localTimeOf(ex, x.clk.sec), date: x.clk.today },
      quote: qd, daily: { open: d.open.slice(), high: d.high.slice(), low: d.low.slice(), close: d.close.slice(), volume: d.volume.slice() }, dailyDates: d.dates.slice(),
      intraday: mins.close.length > 30 ? { open: mins.open, high: mins.high, low: mins.low, close: mins.close, volume: mins.volume } : null, sessionBars: mins.sessionBars, todayFrom: mins.todayFrom,
      index: idxClose.length > 60 ? { name: idxName, daily: idxClose } : null,
      sector: { nom: m.sector, rangSur1Mois: sectorRank || null, nombre: sectorRows.length, variationMoyenneJourPct: Number((sectorRows.reduce((a, r) => a + r.chgPct, 0) / Math.max(1, sectorRows.length)).toFixed(2)) },
      book: this.sim.book(sym, 10), flow: this.real ? null : { buyVol: x.buyVol, sellVol: x.sellVol, largeBuys: x.largeBuys, largeSells: x.largeSells },
      news: news.map((it) => ({ title: it.title, score: it.score, minutesAgo: Math.round((nowNews - it.ts) / 60_000), source: it.source })),
      data: this.real ? { mode: 'réel', coursA: q.quoteAt ? new Date(q.quoteAt).toISOString() : null, source: q.source, differe: true } : { mode: 'simulé' },
      fundamentals: x.fund, position, mc, mcLevels, backtests, ageMs, memory,
    };
  }
}

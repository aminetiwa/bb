// ============================================================================
//  BOURSO :: server/ws.js — diffusion temps réel (WebSocket, paquet « ws »).
//
//  Serveur → navigateur :
//   q        cotations modifiées (tableau compact) toutes les 250 ms
//   live     transactions + bougies en cours des valeurs suivies par l'onglet (graphique, carnet)
//   news     nouvelle actualité          ai     événements de l'IA d'analyse (jetons en direct…)
//   agent    événements de l'agent Bourso Pro (jetons, appels d'outils…)
//   pf/fill  portefeuille simulé           sys    état machine (CPU/GPU/RAM) si demandé
//   clock    horloges des places (5 s)     screener / stress / settings / favorites
//  Navigateur → serveur : { t:'sub', sym } { t:'unsub', sym } { t:'topics', list:[…] } { t:'ping' }
//  Contre-pression : un client trop lent ne reçoit plus les flux haute fréquence jusqu'à ce qu'il rattrape.
// ============================================================================
import { WebSocketServer } from 'ws';
import { systemSnapshot } from './system.js';
import { hostAllowed } from './http.js';

const SLOW = 4 * 2 ** 20;

export function createHub({ server, market, portfolio, analysis, agent, alerts, compute, log = () => {}, allowHosts = [] }) {
  const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024, perMessageDeflate: false });
  const clients = new Set();
  const stats = { connections: 0, sent: 0, bytes: 0, dropped: 0 };

  server.on('upgrade', (req, socket, head) => {
    const url = new URL(req.url, 'http://localhost');
    const origin = req.headers.origin;
    if (url.pathname !== '/ws' || !hostAllowed(req.headers.host, allowHosts) || (origin && !hostAllowed(new URL(origin).host, allowHosts))) {
      socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
      socket.destroy();
      return;
    }
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
  });

  const sendTo = (c, msg, { fast = false } = {}) => {
    if (c.ws.readyState !== 1) return;
    if (fast && c.ws.bufferedAmount > SLOW) { stats.dropped++; return; }
    const s = typeof msg === 'string' ? msg : JSON.stringify(msg);
    c.ws.send(s);
    stats.sent++;
    stats.bytes += s.length;
  };
  const broadcast = (msg, filter = null, fast = false) => {
    const s = JSON.stringify(msg);
    for (const c of clients) if (!filter || filter(c)) sendTo(c, s, { fast });
  };

  wss.on('connection', (ws) => {
    const c = { ws, subs: new Map(), topics: new Set(), alive: true };
    clients.add(c);
    stats.connections++;
    ws.on('pong', () => { c.alive = true; });
    ws.on('message', (data) => {
      let m;
      try { m = JSON.parse(data); } catch { return; }
      if (m.t === 'sub' && market.get(m.sym)) {
        if (c.subs.size >= 12 && !c.subs.has(m.sym)) {
          const old = c.subs.keys().next().value;
          c.subs.delete(old);
          market.watch?.(old, -1);
        }
        const tf = typeof m.tf === 'string' ? m.tf : c.subs.get(m.sym)?.tf ?? null;
        const live = market.live(m.sym, 0, tf);
        if (!c.subs.has(m.sym)) market.watch?.(m.sym, 1);
        c.subs.set(m.sym, { seq: live.seq, tf });
        sendTo(c, { t: 'live', ...live, reset: true });
      } else if (m.t === 'unsub') {
        if (c.subs.delete(m.sym)) market.watch?.(m.sym, -1);
      }
      else if (m.t === 'topics' && Array.isArray(m.list)) c.topics = new Set(m.list.slice(0, 10).map(String));
      else if (m.t === 'ping') sendTo(c, { t: 'pong', ts: m.ts, server: Date.now() });
    });
    const bye = () => {
      if (!clients.delete(c)) return;
      for (const sym of c.subs.keys()) market.watch?.(sym, -1);
      c.subs.clear();
    };
    ws.on('close', bye);
    ws.on('error', bye);
    sendTo(c, { t: 'hello', server: Date.now(), quotes: market.allQuotes(), clocks: market.sim.clockInfo(), ai: analysis.queue(), ollama: analysis.ollama, model: analysis.model() });
  });

  // cotations + flux des valeurs suivies (4 fois par seconde)
  const tQuotes = setInterval(() => {
    if (!clients.size) { market.changedQuotes(); return; }
    const d = market.changedQuotes();
    if (d.length) broadcast({ t: 'q', d }, null, true);
    for (const c of clients) {
      for (const [sym, sub] of c.subs) {
        const live = market.live(sym, sub.seq, sub.tf);
        if (!live) continue;
        sub.seq = live.seq;
        sendTo(c, { t: 'live', ...live }, { fast: true });
      }
    }
  }, 250);
  const tClock = setInterval(() => broadcast({ t: 'clock', clocks: market.sim.clockInfo() }), 5000);
  const tSys = setInterval(async () => {
    if (![...clients].some((c) => c.topics.has('sys'))) return;
    const snap = await systemSnapshot();
    broadcast({ t: 'sys', snapshot: snap, compute: { busy: compute.gpu?.busy ?? 0, pool: compute.pool.info(), stressing: Boolean(compute.stressing) }, stepMs: market.stepMs }, (c) => c.topics.has('sys'));
  }, 1500);
  const tPing = setInterval(() => {
    for (const c of clients) {
      if (!c.alive) {
        c.ws.terminate();
        if (clients.delete(c)) for (const sym of c.subs.keys()) market.watch?.(sym, -1);
        continue;
      }
      c.alive = false;
      try { c.ws.ping(); } catch { /* fermé */ }
    }
  }, 30_000);

  market.on('news', (item) => broadcast({ t: 'news', item: { ...item, name: item.sym ? market.get(item.sym)?.meta.name : null } }));
  market.on('screener', (x) => broadcast({ t: 'screener', ...x }));
  market.on('rollover', (mic) => broadcast({ t: 'rollover', mic }));
  market.on('universe', (sym) => broadcast({ t: 'universe', sym }));
  analysis.on('event', (e) => broadcast({ t: 'ai', ...e }, null, e.ev === 'token' || e.ev === 'thinking'));
  agent.on('event', (e) => broadcast({ t: 'agent', ...e }));
  analysis.on('ollama', (e) => broadcast({ t: 'ollama', ...e }));
  let pfTimer = null;
  portfolio.on('update', () => {
    if (pfTimer) return;
    pfTimer = setTimeout(() => { pfTimer = null; broadcast({ t: 'pf' }); }, 300);
  });
  portfolio.on('fill', (ex) => broadcast({ t: 'fill', ex }));
  alerts?.on('trigger', (a) => broadcast({ t: 'alert', alert: a }));
  alerts?.on('change', () => broadcast({ t: 'alerts' }));

  return {
    broadcast,
    info: () => ({ clients: clients.size, ...stats }),
    close() {
      for (const t of [tQuotes, tClock, tSys, tPing]) clearInterval(t);
      for (const c of clients) c.ws.close(1001, 'arrêt du serveur');
      wss.close();
    },
  };
}

#!/usr/bin/env node
// ============================================================================
//  BOURSO :: pipeline-bench.js — banc d'essai du chemin chaud
//    feed worker ──SoARing (SAB, zero-copy)──▶ math worker (Kalman + VP C++) ──▶ anneau de signaux
//
//  node src/bench/pipeline-bench.js [--lanes 8] [--seconds 5] [--rate 0] [--cap 65536]
//    --rate 0      débit maximal (mesure le throughput)
//    --rate 500000 cadence fixe en ticks/s (mesure la latence tick → signal)
// ============================================================================
import { Worker } from 'node:worker_threads';
import { once } from 'node:events';
import { SoARing, ControlBlock, TICK_FIELDS, SIGNAL_FIELDS } from '../core/shm/soa-ring.js';
import { backend } from '../core/math/index.js';

const arg = (name, def) => {
  const i = process.argv.indexOf(`--${name}`);
  return i > 0 ? Number(process.argv[i + 1]) : def;
};
const nLanes = arg('lanes', 8), seconds = arg('seconds', 5), rate = arg('rate', 0), cap = arg('cap', 1 << 16);

const control = ControlBlock.create();     // sonnette + arrêt du consommateur
const feedStop = ControlBlock.create();    // arrêt du producteur (en premier)
const lanes = Array.from({ length: nLanes }, (_, id) => ({
  id,
  symbol: `SIM${id}`,
  tickSize: id % 2 ? 0.05 : 0.01,
  refPrice: 20 + id * 37.5,
  annualVol: 0.3,
  ring: SoARing.create(cap, TICK_FIELDS).descriptor(),
}));
const out = SoARing.create(1 << 16, SIGNAL_FIELDS);

console.log(`BOURSO bench — backend=${backend} voies=${nLanes} cadence=${rate ? `${rate.toLocaleString('fr-FR')} ticks/s` : 'MAX'} durée=${seconds}s`);

const math = new Worker(new URL('../workers/math.worker.js', import.meta.url), {
  workerData: { control: control.sab, lanes, out: out.descriptor() },
});
const feed = new Worker(new URL('./feed-sim.worker.js', import.meta.url), {
  workerData: { control: control.sab, stop: feedStop.sab, lanes, rate },
});

let signals = 0, last = null;
const drain = setInterval(() => { signals += out.consume(1 << 16, () => {}); }, 5);
const fmt = (x) => (x === Infinity ? '>10000' : x.toFixed(1));
let resolveMath;
const mathDone = new Promise((r) => (resolveMath = r));
math.on('message', (m) => {
  if (m.type === 'done') return resolveMath(m);
  if (m.type !== 'stats') return;
  last = m;
  const l = m.latencyUs;
  console.log(
    `  ${(m.rate / 1e6).toFixed(2).padStart(6)} M ticks/s | latence µs p50 ${l ? fmt(l.p50) : '-'}  p99 ${l ? fmt(l.p99) : '-'}  p99.9 ${l ? fmt(l.p999) : '-'}  max ${l ? fmt(l.max) : '-'}`,
  );
});

const feedDone = once(feed, 'message').then(([m]) => m);
await new Promise((r) => setTimeout(r, seconds * 1000));
feedStop.stop();
const f = await feedDone;   // le producteur a fini d'écrire…
control.stop();             // …le consommateur peut vidanger puis s'arrêter
const m = await mathDone;
clearInterval(drain);
signals += out.consume(1 << 16, () => {});
const processed = m.processed.reduce((a, b) => a + b, 0);
console.log(
  `\nproduits=${f.produced.toLocaleString('fr-FR')}  traités=${processed.toLocaleString('fr-FR')}  ` +
    `anneau plein=${f.full.toLocaleString('fr-FR')}  signaux=${signals.toLocaleString('fr-FR')}  ` +
    `débit moyen=${(processed / seconds / 1e6).toFixed(2)} M ticks/s  (backend ${last?.backend ?? backend})`,
);
await Promise.all([math.terminate(), feed.terminate()]);

// ============================================================================
//  BOURSO :: feed-sim.worker.js — producteur de ticks synthétiques (bench / démo).
//  Remplace le décodeur de flux réel (EOBI / Optiq / passerelle broker) : même anneau, même format.
//  workerData = { control, stop, lanes:[{ id, tickSize, refPrice, ring }], rate (ticks/s, 0 = max) }
//  `stop` est un ControlBlock distinct : arrêt ordonné producteur → consommateur (aucun tick perdu).
// ============================================================================
import { parentPort, workerData } from 'node:worker_threads';
import { SoARing, ControlBlock } from '../core/shm/soa-ring.js';

const { rate = 0 } = workerData;
const ctl = new ControlBlock(workerData.control);
const stopCtl = new ControlBlock(workerData.stop);
const lanes = workerData.lanes.map((l) => ({ ...l, ring: SoARing.from(l.ring), px: l.refPrice }));

let seed = 0x9e3779b9;
const u = () => {
  seed = (seed + 0x6d2b79f5) >>> 0;
  let t = seed;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const hrNs = () => Number(process.hrtime.bigint());

const BURST = 64;
const intervalNs = rate > 0 ? 1e9 / rate : 0;
const t0 = hrNs();
const epochUs = Date.now() * 1000;
let next = t0, produced = 0, full = 0, k = 0;

while (!stopCtl.stopped) {
  let now = hrNs();
  for (let b = 0; b < BURST; b++) {
    if (intervalNs) {
      while ((now = hrNs()) < next) { /* attente active : cadence précise */ }
      next += intervalNs;
    }
    const L = lanes[k++ % lanes.length];
    const i = L.ring.claim();
    if (i < 0) { full++; continue; }
    L.px += (u() - 0.5) * 2 * L.tickSize;
    const px = Math.round(L.px / L.tickSize) * L.tickSize;
    const c = L.ring.col;
    c.ts[i] = epochUs + (now - t0) / 1000; // horodatage « bourse » en µs
    c.rx[i] = now;                         // réception locale (ns, monotone)
    c.px[i] = px;
    c.qty[i] = 1 + ((u() * 300) | 0);
    c.side[i] = u() < 0.5 ? 1 : -1;
    c.bid[i] = px - L.tickSize;
    c.ask[i] = px;
    L.ring.commit();
    produced++;
    if (intervalNs) ctl.ring(); // cadencé : réveil immédiat du consommateur
  }
  if (!intervalNs) ctl.ring(); // débit max : une sonnette par rafale
}
parentPort.postMessage({ type: 'done', produced, full });

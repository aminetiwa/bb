// ============================================================================
//  BOURSO :: ai/loop-guard.js — anti-boucle des modèles de langage.
//
//  Un modèle local peut « tourner en rond » : il répète la même phrase ou le même paragraphe,
//  réfléchit sans fin, aligne des retours à la ligne (défaut connu du mode JSON), ou cesse
//  d'émettre sans rendre la main. LoopGuard surveille le flux au fil de l'eau et dit QUAND couper
//  et JUSQU'OÙ garder le texte (la première occurrence est conservée) ; watchdog() coupe une
//  génération trop longue ou muette. Les appelants (analyse, agent) relancent alors le modèle
//  autrement (sans réflexion, pénalité de répétition) ou exploitent la partie utile.
// ============================================================================

const normSentence = (s) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\d+([.,]\d+)?/g, '#').replace(/[^a-z#]+/g, ' ').trim();

/**
 * Cherche une boucle à la FIN d'un texte.
 * @param {string} s
 * @param {{ maxPeriod?: number, sentences?: boolean }} opts sentences : aussi les phrases répétées
 *   presque à l'identique (pas pour du JSON, dont les lignes se ressemblent légitimement)
 * @returns {null | { reason: string, keep: number }} keep = nombre de caractères à garder
 */
export function detectLoop(s, { maxPeriod = 800, sentences = true } = {}) {
  const n = s.length;
  if (n < 60) return null;
  // 1) blancs en rafale (défaut connu du mode JSON de certains modèles)
  const ws = /\s+$/.exec(s);
  if (ws && ws[0].length >= 160) return { reason: `${ws[0].length} espaces ou retours à la ligne d'affilée`, keep: n - ws[0].length };
  // 2) motif exactement répété en fin de texte (période p)
  const maxP = Math.min(maxPeriod, n >> 1);
  for (let p = 1; p <= maxP; p++) {
    let L = 0;
    while (L < n - p && s.charCodeAt(n - 1 - L) === s.charCodeAt(n - 1 - L - p)) L++;
    if (L < p) continue;
    const span = L + p, copies = span / p;
    const enough = p < 12 ? copies >= 10 && span >= 80 : p < 40 ? copies >= 4 && span >= 160 : copies >= 3 && span >= 240;
    if (!enough || !s.slice(n - p).trim()) continue;
    const unit = s.slice(n - L - p, n - L).replace(/^[\s.,;:!?…"]+/, '').trim();
    return { reason: `même passage répété ${Math.floor(copies)} fois (« ${unit.slice(0, 60)}${unit.length > 60 ? '…' : ''} »)`, keep: n - L };
  }
  if (!sentences) return null;
  // 3) phrases répétées presque à l'identique (chiffres ignorés)
  const parts = [];
  const re = /[^.!?…\n]+[.!?…]*\n*/g;
  for (let m = re.exec(s); m; m = re.exec(s)) {
    const k = normSentence(m[0]);
    if (k.length >= 28) parts.push({ k, at: m.index });
  }
  if (parts.length >= 4) {
    const seen = new Map();
    for (let i = 0; i < parts.length; i++) {
      const arr = seen.get(parts[i].k) ?? [];
      arr.push(i);
      seen.set(parts[i].k, arr);
    }
    for (const idx of seen.values()) {
      // ≥ 4 fois, et la dernière occurrence est récente (la boucle est en cours)
      if (idx.length >= 4 && idx.at(-1) >= parts.length - 4) {
        return { reason: `phrase répétée ${idx.length} fois (« ${parts[idx[0]].k.slice(0, 60)} »)`, keep: parts[idx[1]].at };
      }
    }
  }
  // 4) paragraphe réécrit en boucle : la majorité des groupes de 8 mots des 300 derniers mots
  //    sont déjà apparus plus haut
  const words = [];
  const wre = /\S+/g;
  for (let m = wre.exec(s); m; m = wre.exec(s)) words.push({ w: m[0].toLowerCase().replace(/\d+([.,]\d+)?/g, '#'), at: m.index });
  if (words.length >= 450) {
    const K = 8, first = new Map();
    let rep = 0, tot = 0, zone = -1;
    for (let i = 0; i + K <= words.length; i++) {
      const key = words.slice(i, i + K).map((x) => x.w).join(' ');
      const f = first.get(key);
      if (i >= words.length - 300) {
        tot++;
        if (f !== undefined && f + K <= i) {
          rep++;
          if (zone < 0) zone = i;
        }
      }
      if (f === undefined) first.set(key, i);
    }
    if (tot && rep / tot >= 0.6) return { reason: `le texte se répète (${Math.round((rep / tot) * 100)} % des derniers passages déjà écrits)`, keep: words[Math.max(0, zone)].at };
  }
  return null;
}

/** Surveille un flux (réflexion et réponse séparément) ; push() renvoie la boucle détectée, sinon null. */
export class LoopGuard {
  /**
   * @param {{ maxThinkChars?: number, maxContentChars?: number, json?: boolean, every?: number, window?: number }} o
   *   json : la réponse est du JSON (pas de contrôle des phrases répétées sur la réponse)
   */
  constructor({ maxThinkChars = 32_000, maxContentChars = 48_000, json = false, every = 48, window = 6000 } = {}) {
    this.o = { maxThinkChars, maxContentChars, json, every, window };
    this.text = { content: '', thinking: '' };
    this.base = { content: 0, thinking: 0 }; // position (dans le flux complet) du début de la fenêtre
    this.total = { content: 0, thinking: 0 };
    this.since = { content: 0, thinking: 0 };
    this.hit = null;
  }

  /**
   * @param {'content'|'thinking'} kind
   * @returns {null | { kind, reason, keep }} keep = caractères du flux `kind` à conserver
   */
  push(kind, piece) {
    if (this.hit) return this.hit;
    if (!piece) return null;
    this.total[kind] += piece.length;
    let t = this.text[kind] + piece;
    if (t.length > this.o.window * 2) {
      const cut = t.length - this.o.window;
      this.base[kind] += cut;
      t = t.slice(cut);
    }
    this.text[kind] = t;
    if (kind === 'thinking' && this.total.thinking > this.o.maxThinkChars) {
      return this.#trip(kind, `réflexion trop longue (plus de ${Math.round(this.o.maxThinkChars / 4).toLocaleString('fr-FR')} jetons environ)`, this.total.thinking, 'long');
    }
    if (kind === 'content' && this.total.content > this.o.maxContentChars) {
      return this.#trip(kind, `réponse anormalement longue (plus de ${this.o.maxContentChars.toLocaleString('fr-FR')} caractères)`, this.total.content, 'long');
    }
    this.since[kind] += piece.length;
    if (this.since[kind] < this.o.every) return null;
    this.since[kind] = 0;
    const r = detectLoop(t, { sentences: kind === 'thinking' || !this.o.json });
    return r ? this.#trip(kind, r.reason, this.base[kind] + r.keep, 'loop') : null;
  }

  #trip(kind, reason, keep, type) {
    this.hit = { kind, reason, keep, type };
    return this.hit;
  }
}

/**
 * Chien de garde d'une génération : coupe (AbortController) si le modèle ne répond pas,
 * s'arrête d'émettre, ou dépasse la durée maximale. tick() à chaque morceau reçu.
 */
export function watchdog(ac, { firstMs = 240_000, stallMs = 120_000, totalMs = 600_000 } = {}) {
  const t0 = Date.now();
  let last = 0, reason = null;
  const trip = (why) => {
    if (reason) return;
    reason = why;
    const e = new Error(why);
    e.name = 'AbortError';
    e.watchdog = true;
    ac.abort(e);
  };
  const s = (ms) => `${Math.round(ms / 1000)} s`;
  const timer = setInterval(() => {
    const now = Date.now();
    if (now - t0 > totalMs) trip(`durée maximale dépassée (${s(totalMs)})`);
    else if (!last && now - t0 > firstMs) trip(`aucune réponse du modèle après ${s(firstMs)}`);
    else if (last && now - last > stallMs) trip(`le modèle n'envoie plus rien depuis ${s(stallMs)}`);
  }, 500);
  timer.unref?.();
  return {
    tick() { last = Date.now(); },
    stop() { clearInterval(timer); },
    get reason() { return reason; },
    get started() { return last > 0; },
  };
}

/** Signature stable d'un appel d'outil (nom + arguments triés), pour repérer les appels identiques. */
export function callKey(name, args) {
  let a = args;
  if (typeof a === 'string') {
    try { a = JSON.parse(a); } catch { /* chaîne brute */ }
  }
  const canon = (v) => (Array.isArray(v) ? v.map(canon) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canon(v[k])])) : typeof v === 'string' ? v.trim().toLowerCase() : v);
  return `${name}:${JSON.stringify(canon(a ?? {}))}`;
}

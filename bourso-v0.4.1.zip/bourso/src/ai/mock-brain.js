// ============================================================================
//  BOURSO :: ai/mock-brain.js — « cerveau » de SIMULATION quand aucun modèle Ollama n'est joignable.
//  Toujours étiqueté comme tel dans l'interface. Il ne « réfléchit » pas : il relit les scores et
//  niveaux calculés par le moteur et les met en forme selon le contrat JSON / les outils.
//  Sert aussi au faux serveur Ollama des tests (src/ai/mock-ollama-server.js).
// ============================================================================

const num = (re, text, d = NaN) => {
  const m = text.match(re);
  return m ? Number(m[1]) : d;
};
const round = (x, tick = 0.01) => Number((Math.round(x / tick) * tick).toFixed(Math.max(0, Math.ceil(-Math.log10(tick)))));

/** Réponse JSON (schéma ANALYSE) cohérente avec le dossier texte. */
export function mockAnalysis(dossierText) {
  const g = num(/global: (-?[\d.]+)/, dossierText, 0), px = num(/\ndernier: ([\d.]+)/, dossierText, 100);
  const atr = num(/atr14: ([\d.]+)/, dossierText, px * 0.02), tick = num(/pasCotation: ([\d.]+)/, dossierText, 0.01);
  const news = num(/actualites: (-?[\d.]+)/, dossierText, 0), trend = num(/tendance: (-?[\d.]+)/, dossierText, 0), mom = num(/momentum: (-?[\d.]+)/, dossierText, 0);
  const pT = num(/probaObjectifAvantStop: ([\d.]+)/, dossierText, NaN), pS = num(/probaStopAvantObjectif: ([\d.]+)/, dossierText, NaN);
  const edge = Number.isFinite(pT) ? pT - pS : 0;
  const score = 0.75 * g + 0.25 * edge;
  const decision = score > 0.45 ? 'STRONG_BUY' : score > 0.15 ? 'BUY' : score < -0.45 ? 'STRONG_SELL' : score < -0.15 ? 'SELL' : 'HOLD';
  const dir = decision.includes('BUY') ? 1 : decision.includes('SELL') ? -1 : 0;
  const conf = Math.min(0.88, 0.5 + Math.abs(score) * 0.7);
  const faits = [...dossierText.matchAll(/^\d+\. \[([+−=])\] (.+)$/gm)].slice(0, 6);
  const stop = dir ? round(px - dir * 1.2 * atr, tick) : 0;
  const t1 = dir ? round(px + dir * 2 * atr, tick) : 0, t2 = dir ? round(px + dir * 3.2 * atr, tick) : 0;
  const pUp = Math.min(0.7, Math.max(0.15, 0.33 + score * 0.4)), pDn = Math.min(0.7, Math.max(0.15, 0.33 - score * 0.4));
  return {
    decision, confidence: Number(conf.toFixed(2)), horizon: 'SWING',
    summary: dir === 0 ? 'Les calculs ne dégagent pas d\'avantage net : tendance, momentum et probabilités se compensent. Mieux vaut attendre un signal plus clair.'
      : `${dir > 0 ? 'Biais acheteur' : 'Biais vendeur'} : score quantitatif ${g.toFixed(2)}, tendance ${trend.toFixed(2)}, momentum ${mom.toFixed(2)}${Number.isFinite(pT) ? `, objectif avant stop ${Math.round(pT * 100)} %` : ''}.`,
    news: { score: Math.max(-1, Math.min(1, news)), confidence: news ? 0.6 : 0.2, summary: news ? `Tonalité des actualités ${news > 0 ? 'positive' : 'négative'} (${news.toFixed(2)}).` : 'Pas d\'actualité marquante.' },
    market: { bias: Math.max(-1, Math.min(1, 0.6 * trend + 0.4 * mom)), confidence: Math.min(0.85, 0.45 + Math.abs(trend) * 0.4), regime: trend > 0.4 ? 'TREND_UP' : trend < -0.4 ? 'TREND_DOWN' : 'RANGE', summary: `Tendance ${trend.toFixed(2)}, momentum ${mom.toFixed(2)}.` },
    entry: dir ? { low: round(dir > 0 ? px - 0.2 * atr : px, tick), high: round(dir > 0 ? px : px + 0.2 * atr, tick) } : { low: 0, high: 0 },
    stop, targets: dir ? [t1, t2] : [], size_fraction: dir ? Number((0.15 + 0.35 * conf).toFixed(2)) : 0,
    scenarios: [
      { name: 'HAUSSIER', probability: Number(pUp.toFixed(2)), target: round(px + 2.5 * atr, tick), description: 'Poursuite du mouvement si les acheteurs gardent le contrôle.' },
      { name: 'CENTRAL', probability: Number((1 - pUp - pDn).toFixed(2)), target: round(px, tick), description: 'Consolidation autour des niveaux actuels.' },
      { name: 'BAISSIER', probability: Number(pDn.toFixed(2)), target: round(px - 2.5 * atr, tick), description: 'Repli vers les supports si le marché se retourne.' },
    ],
    key_factors: faits.map(([, s, t]) => ({ factor: t.slice(0, 190), impact: s === '+' ? 'POSITIF' : s === '−' ? 'NEGATIF' : 'NEUTRE', weight: 2 })),
    risks: ['Retournement du marché général', 'Actualité imprévue sur la valeur', 'Volatilité supérieure à la normale'],
    invalidation: dir ? `Clôture ${dir > 0 ? 'sous' : 'au-dessus de'} ${stop}.` : 'Sortie franche de la zone actuelle avec volume.',
  };
}

const KNOWN = /\b([A-Z]{2,6}(?::[A-Z]{4})?)\b/g;

/**
 * Un tour d'agent simulé : décide des outils à appeler, puis rédige une réponse à partir de leurs résultats.
 * @returns {{ content?:string, tool_calls?:{function:{name:string, arguments:object}}[] }}
 */
export function mockAgentTurn(messages, tools = []) {
  const names = new Set(tools.map((t) => t.function?.name ?? t.name));
  const lastUser = [...messages].reverse().find((m) => m.role === 'user')?.content ?? '';
  const toolMsgs = [];
  for (let i = messages.length - 1; i >= 0 && messages[i].role === 'tool'; i--) toolMsgs.unshift(messages[i]);
  if (!toolMsgs.length) {
    const words = lastUser.match(/[A-Za-zÀ-ÿ'&.-]{2,}/g) ?? [];
    const codes = [...lastUser.matchAll(KNOWN)].map((m) => m[1]).filter((c) => !['RSI', 'MACD', 'ATR', 'VWAP', 'IA', 'CAC', 'DAX', 'ETF', 'PER', 'BPA', 'TTF', 'PEA', 'CTO'].includes(c));
    // valeur affichée à l'écran (contexte) quand la question y fait référence (« cette action », « elle »…)
    const ctxSym = (messages.find((m) => m.role === 'system')?.content ?? '').match(/VALEUR AFFICHÉE[^(]*\(([^)\s]+)\)/)?.[1];
    const refers = /\b(cette|cet|ce|la|le|l')\s*(action|valeur|titre|soci[ée]t[ée])|\belle\b|\bacheter\b|\bvendre\b|\banaly/i.test(lastUser);
    const STOP = ['Que', 'Quel', 'Quelle', 'Quels', 'Peux', 'Est', 'Donne', 'Analyse', 'Bonjour', 'Comment', 'Pourquoi', 'Faut', 'Dois', 'Fais', 'Montre', 'Explique', 'Salut', 'Merci'];
    const query = codes[0] ?? words.find((w) => /^[A-ZÀ-Ý]/.test(w) && w.length > 2 && !STOP.includes(w)) ?? (refers ? ctxSym : null);
    if (/march[ée]|indice|tendance g[ée]n[ée]rale|secteur/i.test(lastUser) && names.has('vue_marche')) return { tool_calls: [{ function: { name: 'vue_marche', arguments: {} } }] };
    if (/portefeuille|positions?/i.test(lastUser) && names.has('portefeuille')) return { tool_calls: [{ function: { name: 'portefeuille', arguments: {} } }] };
    if (query && names.has('rechercher_valeur')) {
      const calls = [{ function: { name: 'cotation', arguments: { symbole: query } } }, { function: { name: 'analyse_technique', arguments: { symbole: query } } }];
      if (/probabilit|monte|objectif|risque/i.test(lastUser)) calls.push({ function: { name: 'monte_carlo', arguments: { symbole: query, horizon_jours: 10 } } });
      return { tool_calls: calls };
    }
    return { content: `Je suis l'agent **Bourso Pro** (mode simulé : aucun modèle Ollama n'est joignable, je ne fais que relire les calculs).\n\nPosez-moi une question sur une valeur (ex. « Que penses-tu de LVMH ? »), sur le marché (« Comment va le marché européen ? ») ou sur votre portefeuille.` };
  }
  const lines = ['*(Réponse simulée — lancez Ollama pour l\'analyse du modèle 30B.)*', ''];
  for (const m of toolMsgs) {
    let data;
    try { data = JSON.parse(m.content); } catch { data = null; }
    if (!data || data.erreur) { lines.push(`- ${m.tool_name ?? 'outil'} : ${data?.erreur ?? 'pas de résultat'}`); continue; }
    if (data.cours !== undefined && data.nom) lines.push(`### ${data.nom} (${data.code})`, `Cours **${data.cours} ${data.devise}** (${data.variationPct >= 0 ? '+' : ''}${data.variationPct} %), plus haut ${data.plusHaut}, plus bas ${data.plusBas}.`);
    if (data.resume) lines.push(`**Résumé technique** : ${data.resume.verdict} (note ${data.resume.note}) — RSI 14 : ${data.rsi14}, ADX : ${data.adx}, tendance de fond : ${data.alignement}.`);
    if (data.faits) lines.push('', '**Ce que disent les calculs :**', ...data.faits.slice(0, 5).map((f) => `- ${f}`));
    if (data.probaObjectif !== undefined) lines.push(`**Monte Carlo** (${data.trajectoires} trajectoires) : objectif avant stop ${Math.round(data.probaObjectif * 100)} %, stop avant objectif ${Math.round(data.probaStop * 100)} %.`);
    if (data.indices) lines.push('### Marché', ...data.indices.slice(0, 6).map((i) => `- ${i.nom} : ${i.variationPct >= 0 ? '+' : ''}${i.variationPct} %`));
    if (data.positions) lines.push('### Portefeuille', `Valeur ${data.valeurTotaleEur} €, ${data.positions.length} position(s).`);
  }
  lines.push('', '_À vérifier avec le modèle complet ; aucune garantie de performance._');
  return { content: lines.join('\n') };
}

/** Découpe un texte en morceaux de taille « jeton » pour simuler le flux. */
export function* chunks(text, size = 6) {
  for (let i = 0; i < text.length; i += size) yield text.slice(i, i + size);
}

// ============================================================================
//  BOURSO :: ai/agent.js — l'agent conversationnel « Bourso Pro » (un pro de la bourse à qui parler).
//
//  Boucle d'appels d'outils en flux continu : le modèle demande des données (cotation, dossier
//  complet, Monte Carlo GPU/CPU, backtests, screener, actualités, portefeuille…), les outils les
//  calculent sur la machine, le modèle rédige sa réponse en citant ces chiffres.
//  - priorité maximale sur le modèle : la discussion passe avant les analyses de fond ;
//  - même modèle et même taille de contexte que l'analyse → aucun rechargement du modèle 30B ;
//  - conversations enregistrées (data/conversations) ;
//  - repli SIMULÉ clairement étiqueté si Ollama est absent, et mode « sans outils » si le
//    modèle choisi ne sait pas appeler de fonctions (les données sont alors pré-calculées) ;
//  - anti-boucle : répétitions et réflexion sans fin coupées au fil de l'eau, appels d'outils
//    identiques non relancés (résultat déjà obtenu rappelé au modèle), nombre d'appels plafonné,
//    durée d'un échange plafonnée.
// ============================================================================
import { EventEmitter } from 'node:events';
import { AGENT_PRO } from './prompts.js';
import { buildTools, toOllamaTools } from './tools.js';
import { mockAgentTurn, chunks } from './mock-brain.js';
import { LoopGuard, watchdog, callKey } from './loop-guard.js';

const MAX_ROUNDS = 6;
const MAX_TOOL_CALLS = 16; // appels d'outils par question, au plus
const MAX_DUPLICATES = 2; // appels identiques tolérés avant de forcer la réponse finale
const RESULT_CAP = 14_000; // caractères max d'un résultat d'outil transmis au modèle
const OLD_RESULT_CAP = 2_500; // résultats d'outils des tours précédents (résumés)
const HISTORY_CAP = 64_000; // ≈ 18 k jetons d'historique pour un contexte de 32 k
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const offline = (e) => e?.offline || /injoignable|ECONNREFUSED|fetch failed|ENOTFOUND|EHOSTUNREACH/i.test(e?.message ?? '');

export class AgentService extends EventEmitter {
  constructor({ client, analysis, market, compute, portfolio, store, log = () => {} }) {
    super();
    Object.assign(this, { client, analysis, market, compute, portfolio, store, log });
    this.tools = buildTools({ market, compute, analysis, portfolio, store });
    this.byName = new Map(this.tools.map((t) => [t.name, t]));
    this.ollamaTools = toOllamaTools(this.tools);
    this.active = new Map();
    this.noTools = new Set();
    this.stats = { messages: 0, toolCalls: 0, simulated: 0, errors: 0 };
  }

  toolList() {
    return this.tools.map((t) => ({ name: t.name, description: t.description, parameters: t.parameters }));
  }

  busy(id) {
    return this.active.has(id);
  }

  async create({ sym = null, title = null } = {}) {
    const c = { id: `c${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`, title: title ?? 'Nouvelle discussion', sym, createdAt: Date.now(), messages: [] };
    await this.store.saveConversation(c);
    return c;
  }

  abort(id) {
    const a = this.active.get(id);
    if (a) a.abort();
    return Boolean(a);
  }

  #emit(conv, type, data = {}) {
    this.emit('event', { conv, type, ...data });
  }

  /** Exécute un outil ; une erreur est renvoyée au modèle sous la forme { erreur }. */
  async runTool(name, args) {
    const t = this.byName.get(name), t0 = performance.now();
    if (!t) return { ok: false, ms: 0, result: { erreur: `outil inconnu : ${name}` } };
    let a = args;
    if (typeof a === 'string') {
      try { a = JSON.parse(a); } catch { a = {}; }
    }
    try {
      const result = await t.run(a ?? {});
      return { ok: true, ms: performance.now() - t0, result };
    } catch (e) {
      return { ok: false, ms: performance.now() - t0, result: { erreur: e.message } };
    }
  }

  /** Contexte de la séance injecté au début de chaque échange (date, valeur affichée, favoris, places ouvertes). */
  context(conv) {
    const now = new Date();
    const date = now.toLocaleString('fr-FR', { timeZone: 'Europe/Paris', weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    const lines = [`CONTEXTE — ${date} (heure de Paris)`];
    lines.push(this.market.real
      ? `- Données : RÉELLES (${this.market.sim.instruments.length} actions sur ${Object.keys(this.market.sim.clocks).length} places, Europe en priorité ; d'autres valeurs du monde entier peuvent être ajoutées avec rechercher_valeur puis ajouter_valeur). Cours DIFFÉRÉS (≈ 15 min en Europe) de sources publiques gratuites (Yahoo Finance) ; actualités réelles (Google Actualités, presse, GDELT) ; pas de carnet d'ordres. Portefeuille FICTIF : aucun ordre réel.`
      : `- Données : marché SIMULÉ en mode démonstration (${this.market.sim.instruments.length} actions sur ${Object.keys(this.market.sim.clocks).length} places, Europe en priorité). Les cours, actualités et fondamentaux sont fictifs ; les calculs, eux, sont exacts.`);
    lines.push('- Symboles au format CODE:PLACE (ex. MC:XPAR = LVMH à Paris, SAP:XETR = SAP à Francfort). Utilise rechercher_valeur si tu n\'es pas sûr du symbole.');
    if (conv.sym && this.market.get(conv.sym)) {
      const q = this.market.sim.quote(conv.sym), m = this.market.get(conv.sym).meta;
      const px = Number.isFinite(q.last) ? `cours ${q.last} ${m.currency} (${q.chgPct >= 0 ? '+' : ''}${Number.isFinite(q.chgPct) ? q.chgPct.toFixed(2) : '?'} %)` : 'cours pas encore chargé';
      lines.push(`- VALEUR AFFICHÉE par l'utilisateur : ${m.name} (${conv.sym}) — ${px}. « Cette action », « elle », « le titre » désignent cette valeur.`);
    }
    const favs = this.store.favorites.filter((s) => this.market.get(s));
    if (favs.length) lines.push(`- Favoris de l'utilisateur (ordre de priorité) : ${favs.map((s) => `${this.market.get(s).meta.name} (${s})`).join(', ')}.`);
    const open = this.market.sim.clockInfo().filter((c) => c.live).map((c) => `${c.short} ${c.time}`);
    lines.push(`- Places ouvertes : ${open.length ? open.slice(0, 12).join(', ') : 'aucune'}.`);
    const v = this.portfolio.valuation();
    lines.push(`- Portefeuille fictif : ${Math.round(v.totalEur).toLocaleString('fr-FR')} € (${v.perfPct >= 0 ? '+' : ''}${v.perfPct.toFixed(2)} %), ${v.positions.length} position(s), ${Math.round(v.cashEur).toLocaleString('fr-FR')} € de liquidités.`);
    return lines.join('\n');
  }

  /** Messages envoyés au modèle : système + historique récent (résultats d'outils anciens résumés). */
  #modelMessages(conv, { toolsAvailable = true } = {}) {
    const msgs = conv.messages, lastUser = msgs.findLastIndex((m) => m.role === 'user');
    const out = [];
    let size = 0, start = msgs.length;
    for (let i = msgs.length - 1; i >= 0; i--) {
      const m = msgs[i], len = (m.content?.length ?? 0) + (m.tool_calls ? JSON.stringify(m.tool_calls).length : 0);
      const cost = m.role === 'tool' && i < lastUser ? Math.min(len, OLD_RESULT_CAP) : len;
      if (size + cost > HISTORY_CAP && i < lastUser) break;
      size += cost;
      start = i;
    }
    while (start < msgs.length && msgs[start].role !== 'user') start++; // commence sur une question
    for (let i = start; i < msgs.length; i++) {
      const m = msgs[i];
      if (m.role === 'user') out.push({ role: 'user', content: m.content });
      else if (m.role === 'assistant') {
        const o = { role: 'assistant', content: m.content ?? '' };
        if (m.tool_calls?.length && toolsAvailable) o.tool_calls = m.tool_calls.map((c) => ({ function: { name: c.name, arguments: c.arguments } }));
        if (o.content || o.tool_calls) out.push(o);
      } else if (m.role === 'tool' && toolsAvailable) {
        const c = i < lastUser && m.content.length > OLD_RESULT_CAP ? `${m.content.slice(0, OLD_RESULT_CAP)}… (résultat ancien tronqué)` : m.content;
        out.push({ role: 'tool', tool_name: m.name, content: c });
      }
    }
    return [{ role: 'system', content: `${AGENT_PRO}\n\n${this.context(conv)}` }, ...out];
  }

  /**
   * Envoie un message et fait répondre l'agent (événements diffusés au fil de l'eau).
   * @returns {Promise<object>} le message final de l'agent
   */
  async send(id, text, { sym } = {}) {
    const conv = (await this.store.getConversation(id)) ?? (await this.create({ sym }));
    if (this.active.has(conv.id)) throw new Error('une réponse est déjà en cours dans cette discussion');
    const question = String(text ?? '').trim().slice(0, 8000);
    if (!question) throw new Error('message vide');
    if (sym !== undefined && (sym === null || this.market.get(sym))) conv.sym = sym;
    if (conv.title === 'Nouvelle discussion') conv.title = question.length > 70 ? `${question.slice(0, 67)}…` : question;
    conv.messages.push({ role: 'user', content: question, at: Date.now() });
    const ac = new AbortController();
    this.active.set(conv.id, ac);
    this.stats.messages++;
    this.#emit(conv.id, 'start', { title: conv.title, sym: conv.sym });
    await this.store.saveConversation(conv);

    const set = this.store.settings, model = this.analysis.model('agent');
    const L = { maxThinkTokens: 6000, firstTokenSec: 240, stallSec: 120, maxMinutes: 10, ...(set.ai.loop ?? {}) };
    const options = { temperature: set.agent.temperature, num_ctx: set.ai.numCtx, num_predict: 3000 + (set.agent.think ? L.maxThinkTokens : 0) };
    let simulated = false, final = null, think = set.agent.think, forceFinal = false;
    const seen = new Map(); // appels d'outils déjà faits pendant cette question (anti-boucle)
    let toolCalls = 0, duplicates = 0, retried = false;
    const loopNotes = [];
    const t0 = Date.now();
    // chien de garde de l'échange complet (tous les tours) : coupe proprement au-delà de la durée maximale
    const turnTimer = setTimeout(() => { if (!ac.signal.aborted) { loopNotes.push(`durée maximale d'un échange atteinte (${L.maxMinutes} min)`); ac.abort(Object.assign(new Error('durée maximale'), { name: 'AbortError', watchdog: true })); } }, L.maxMinutes * 60_000);
    turnTimer.unref?.();
    try {
      if (!this.analysis.ollama.up && Date.now() - this.analysis.ollama.checkedAt > 5000) await this.analysis.checkOllama();
      simulated = !this.analysis.ollama.up;
      let prefetched = false;
      for (let round = 0; round <= MAX_ROUNDS; round++) {
        if (ac.signal.aborted) throw Object.assign(new Error('interrompu'), { aborted: true });
        const toolsOn = round < MAX_ROUNDS && !forceFinal && !this.noTools.has(model);
        // modèle sans appels de fonctions : on pré-calcule les données probablement utiles
        if (!simulated && this.noTools.has(model) && !prefetched) {
          prefetched = true;
          await this.#prefetch(conv);
        }
        const messages = this.#modelMessages(conv, { toolsAvailable: toolsOn || simulated || forceFinal });
        if (round === MAX_ROUNDS || forceFinal) messages.push({ role: 'user', content: 'Rédige maintenant ta réponse finale à partir des données déjà obtenues (plus d\'appel d\'outil).' });
        let content = '', thinking = '', calls = [], stats = null;
        if (simulated) {
          const turn = mockAgentTurn(messages, toolsOn ? this.ollamaTools : []);
          if (turn.tool_calls) calls = turn.tool_calls.map((c) => ({ name: c.function.name, arguments: c.function.arguments }));
          else {
            for (const piece of chunks(turn.content, 18)) {
              if (ac.signal.aborted) break;
              content += piece;
              this.#emit(conv.id, 'token', { text: piece });
              await sleep(10);
            }
            stats = { model: 'simulation (Ollama non joignable)' };
          }
        } else {
          // anti-boucle : flux surveillé (répétitions, réflexion sans fin) + chien de garde (silence)
          const rc = new AbortController(), guard = new LoopGuard({ maxThinkChars: L.maxThinkTokens * 4 });
          const wd = watchdog(rc, { firstMs: L.firstTokenSec * 1000, stallMs: L.stallSec * 1000, totalMs: L.maxMinutes * 60_000 });
          let loop = null;
          try {
            for await (const c of this.client.chatStream({ model, messages, tools: toolsOn ? this.ollamaTools : undefined, think, options, signal: AbortSignal.any([ac.signal, rc.signal]), priority: 3 })) {
              wd.tick();
              if (c.thinking) { thinking += c.thinking; this.#emit(conv.id, 'thinking', { text: c.thinking }); loop = guard.push('thinking', c.thinking); }
              if (c.content && !loop) { content += c.content; this.#emit(conv.id, 'token', { text: c.content }); loop = guard.push('content', c.content); }
              if (c.tool_calls?.length) calls.push(...c.tool_calls.map((t) => ({ name: t.function?.name, arguments: t.function?.arguments ?? {} })));
              if (c.done) stats = c.stats;
              if (loop) break;
            }
            if (loop) rc.abort();
          } catch (e) {
            if (ac.signal.aborted) throw Object.assign(new Error('interrompu'), { aborted: true, watchdog: ac.signal.reason?.watchdog });
            if (rc.signal.aborted && wd.reason) loop = { kind: content ? 'content' : 'thinking', reason: wd.reason, type: 'watchdog' };
            else if (toolsOn && e.status === 400 && /tool/i.test(e.message)) {
              this.noTools.add(model);
              this.log(`agent : le modèle ${model} ne gère pas les outils → mode données pré-calculées`);
              this.#emit(conv.id, 'notice', { text: `Le modèle ${model} ne sait pas appeler d'outils : données pré-calculées à la place.` });
              round--;
              continue;
            } else {
              if (!offline(e) || content) throw e;
              simulated = true;
              this.#emit(conv.id, 'notice', { text: 'Ollama injoignable : réponse simulée à partir des calculs.' });
              round--;
              continue;
            }
          } finally {
            wd.stop();
          }
          if (loop) {
            const where = loop.kind === 'thinking' ? 'réflexion' : 'réponse';
            loopNotes.push(`${where} : ${loop.reason}`);
            this.analysis.stats.loops = (this.analysis.stats.loops ?? 0) + 1;
            if (loop.type !== 'watchdog') {
              if (loop.kind === 'content') content = content.slice(0, loop.keep);
              else thinking = thinking.slice(0, loop.keep);
            }
            const useful = content.trim().length >= 200 && !calls.length;
            if (!useful && !retried && !(loop.type === 'watchdog' && !content && !thinking)) {
              // une relance : sans réflexion, avec pénalité de répétition
              retried = true;
              think = false;
              Object.assign(options, { repeat_penalty: 1.15, repeat_last_n: 512, temperature: Math.max(0.4, options.temperature ?? 0), num_predict: 3000 });
              this.#emit(conv.id, 'notice', { text: `Anti-boucle (${where}) : ${loop.reason}. Relance sans réflexion, avec pénalité de répétition.` });
              round--;
              continue;
            }
            this.#emit(conv.id, 'notice', { text: `Anti-boucle (${where}) : ${loop.reason}. ${useful ? 'La partie utile de la réponse est gardée.' : 'Génération arrêtée.'}` });
            if (!useful && loop.type === 'watchdog' && !content) throw new Error(`le modèle ne répond pas (${loop.reason})`);
            calls = [];
            content = `${content.trim()}\n\n_(réponse coupée par l'anti-boucle : ${loop.reason})_`;
          }
        }
        if (calls.length) {
          const call = { role: 'assistant', content, tool_calls: calls, thinking: thinking || undefined, at: Date.now() };
          conv.messages.push(call);
          for (const c of calls) {
            const key = callKey(c.name, c.arguments);
            // anti-boucle : un appel identique n'est pas relancé, le modèle est renvoyé au résultat déjà obtenu
            if (seen.has(key)) {
              duplicates++;
              const note = { note: `Appel identique déjà effectué (tour ${seen.get(key).round + 1}) : son résultat est plus haut dans la discussion. Utilise-le au lieu de relancer l'outil.` };
              conv.messages.push({ role: 'tool', name: c.name, content: JSON.stringify(note), ok: true, ms: 0, at: Date.now(), duplicate: true });
              this.#emit(conv.id, 'tool_result', { name: c.name, ok: true, ms: 0, result: note, duplicate: true });
              continue;
            }
            if (toolCalls >= MAX_TOOL_CALLS) {
              const note = { note: `Limite de ${MAX_TOOL_CALLS} appels d'outils atteinte pour cette question : réponds avec les données déjà obtenues.` };
              conv.messages.push({ role: 'tool', name: c.name, content: JSON.stringify(note), ok: false, ms: 0, at: Date.now() });
              this.#emit(conv.id, 'tool_result', { name: c.name, ok: false, ms: 0, result: note });
              forceFinal = true;
              continue;
            }
            toolCalls++;
            this.stats.toolCalls++;
            this.#emit(conv.id, 'tool', { name: c.name, arguments: c.arguments });
            const r = await this.runTool(c.name, c.arguments);
            seen.set(key, { round });
            let json = JSON.stringify(r.result);
            const full = json.length;
            if (json.length > RESULT_CAP) json = `${json.slice(0, RESULT_CAP)}… (tronqué, ${full} caractères)`;
            conv.messages.push({ role: 'tool', name: c.name, content: json, ok: r.ok, ms: Math.round(r.ms), at: Date.now() });
            this.#emit(conv.id, 'tool_result', { name: c.name, ok: r.ok, ms: Math.round(r.ms), result: full <= 60_000 ? r.result : { tronque: true, taille: full } });
          }
          if (duplicates >= MAX_DUPLICATES && !forceFinal) {
            forceFinal = true;
            loopNotes.push(`${duplicates} appels d'outils répétés à l'identique`);
            this.#emit(conv.id, 'notice', { text: `Anti-boucle : le modèle redemande les mêmes données (${duplicates} appels identiques). Il doit maintenant répondre avec ce qu'il a.` });
          }
          await this.store.saveConversation(conv);
          continue;
        }
        final = { role: 'assistant', content: content.trim() || '_(réponse vide du modèle)_', thinking: thinking || undefined, at: Date.now(), ms: Date.now() - t0, simulated, antiLoop: loopNotes.length ? loopNotes : undefined,
          stats: stats ? { model: stats.model ?? model, outputTokens: stats.outputTokens ?? null, promptTokens: stats.promptTokens ?? null, tokPerSec: stats.tokPerSec ?? null } : null };
        break;
      }
      if (!final) final = { role: 'assistant', content: '_(pas de réponse finale)_', at: Date.now(), ms: Date.now() - t0, simulated };
      if (simulated) this.stats.simulated++;
      conv.messages.push(final);
      await this.store.saveConversation(conv);
      this.#emit(conv.id, 'done', { message: final, title: conv.title });
      return final;
    } catch (e) {
      if (e.aborted && e.watchdog) e.aborted = false, e.message = `durée maximale d'un échange atteinte (${L.maxMinutes} min) : réponse arrêtée par l'anti-boucle`;
      const msg = e.aborted ? 'Réponse interrompue.' : `Erreur : ${e.message}`;
      if (!e.aborted) { this.stats.errors++; this.log(`agent : ${e.message}`); }
      final = { role: 'assistant', content: `_${msg}_`, at: Date.now(), error: !e.aborted, aborted: Boolean(e.aborted) };
      conv.messages.push(final);
      await this.store.saveConversation(conv).catch(() => {});
      this.#emit(conv.id, e.aborted ? 'done' : 'error', { message: final, error: e.aborted ? null : e.message });
      return final;
    } finally {
      clearTimeout(turnTimer);
      this.active.delete(conv.id);
    }
  }

  /** Mode « sans outils » : lance les outils les plus probables et donne leurs résultats au modèle. */
  async #prefetch(conv) {
    const sys = { role: 'system', content: this.context(conv) };
    const msgs = [sys, ...conv.messages.filter((m) => m.role === 'user').slice(-1).map((m) => ({ role: 'user', content: m.content }))];
    const turn = mockAgentTurn(msgs, this.ollamaTools);
    const calls = turn.tool_calls ?? (conv.sym ? [{ function: { name: 'cotation', arguments: { symbole: conv.sym } } }, { function: { name: 'analyse_technique', arguments: { symbole: conv.sym } } }] : [{ function: { name: 'vue_marche', arguments: {} } }]);
    const parts = [];
    for (const c of calls) {
      this.#emit(conv.id, 'tool', { name: c.function.name, arguments: c.function.arguments });
      const r = await this.runTool(c.function.name, c.function.arguments);
      this.#emit(conv.id, 'tool_result', { name: c.function.name, ok: r.ok, ms: Math.round(r.ms), result: r.result });
      parts.push(`### ${c.function.name}\n${JSON.stringify(r.result).slice(0, RESULT_CAP)}`);
    }
    conv.messages.splice(conv.messages.length - 1, 0, { role: 'user', content: `DONNÉES CALCULÉES PAR L'APPLICATION (à citer, ne pas inventer d'autres chiffres) :\n${parts.join('\n\n')}`, at: Date.now(), prefetch: true });
  }
}

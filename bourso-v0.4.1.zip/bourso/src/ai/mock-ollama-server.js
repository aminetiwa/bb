#!/usr/bin/env node
// ============================================================================
//  BOURSO :: ai/mock-ollama-server.js — FAUX serveur Ollama (tests, démonstration sans GPU).
//  Implémente /api/version, /api/tags, /api/ps, /api/show (capacités, contexte), /api/chat (flux
//  NDJSON, format JSON, outils, réflexion), /api/embed, /api/pull et /api/create (progression
//  simulée), /api/delete. Lancement : node src/ai/mock-ollama-server.js [port] (défaut 11435).
//  Les réponses sont SIMULÉES (dérivées des calculs) et le nom de version l'indique.
//
//  Comme le vrai Ollama, la réponse JSON respecte la GRAMMAIRE reçue (`format`) : un champ absent
//  du schéma envoyé ne peut pas être écrit. Option quirks (tests) : modèles volontairement
//  défaillants — boucle:test (réflexion en boucle), radote:test (réponse en boucle), brouillon:test
//  (JSON approximatif, sans grammaire), muet:test (ne répond jamais) — et création refusée
//  (« chtimes … operation not permitted ») à partir de perm:test.
// ============================================================================
import { createServer } from 'node:http';
import { pathToFileURL } from 'node:url';
import { mockAnalysis, mockAgentTurn, chunks } from './mock-brain.js';

const CHAT = ['completion', 'tools', 'thinking'];
const INITIAL = [
  { name: 'bourso:latest', size: 18_556_700_000, details: { family: 'qwen3moe', parameter_size: '30.5B', quantization_level: 'Q4_K_M', parent_model: 'qwen3:30b' }, caps: CHAT, ctx: 262_144 },
  { name: 'qwen3:30b', size: 18_556_700_000, details: { family: 'qwen3moe', parameter_size: '30.5B', quantization_level: 'Q4_K_M' }, caps: CHAT, ctx: 262_144 },
  { name: 'gpt-oss:20b', size: 13_780_000_000, details: { family: 'gptoss', parameter_size: '20.9B', quantization_level: 'MXFP4' }, caps: CHAT, ctx: 131_072, levels: ['low', 'medium', 'high'] },
  { name: 'gemma3:27b', size: 17_400_000_000, details: { family: 'gemma3', parameter_size: '27.4B', quantization_level: 'Q4_K_M' }, caps: ['completion', 'vision'], ctx: 131_072 },
  { name: 'bge-m3:latest', size: 1_157_000_000, details: { family: 'bert', parameter_size: '566.70M', quantization_level: 'F16' }, caps: ['embedding'], ctx: 8192 },
];

const QUIRKS = ['boucle:test', 'radote:test', 'brouillon:test', 'muet:test', 'perm:test'].map((name) => ({ name, size: 1_000_000_000, details: { family: 'test', parameter_size: '1B', quantization_level: 'Q4_0' }, caps: CHAT, ctx: 32_768 }));

/** Ce que la grammaire d'Ollama laisse passer : seulement les champs décrits par le schéma reçu. */
function enforce(schema, v) {
  if (!schema || typeof schema !== 'object') return v;
  if (schema.type === 'object' && v && typeof v === 'object' && !Array.isArray(v)) {
    const out = {};
    for (const [k, sub] of Object.entries(schema.properties ?? {})) if (k in v) out[k] = enforce(sub, v[k]);
    return out;
  }
  if (schema.type === 'array' && Array.isArray(v)) return v.map((x) => enforce(schema.items, x));
  return v;
}

/** Réponse conforme à un schéma quelconque (ex. complément de champs manquants). */
function fill(schema, key = '') {
  switch (schema?.type) {
    case 'object': return Object.fromEntries(Object.entries(schema.properties ?? {}).map(([k, s]) => [k, fill(s, k)]));
    case 'array': return [fill(schema.items, key)];
    case 'number': case 'integer': return 0.5;
    case 'boolean': return false;
    case 'string': return schema.enum ? schema.enum[0] : `Complément simulé (${key.replace(/_/g, ' ')}).`;
    default: return null;
  }
}

/** JSON « à la main » d'un modèle qui ne suit pas la grammaire : clés françaises, %, virgules décimales. */
function sloppy(a) {
  return {
    analyse: {
      Recommandation: { STRONG_BUY: 'Achat fort', BUY: 'Acheter', HOLD: 'Conserver / attendre', SELL: 'Vendre', STRONG_SELL: 'Vente forte' }[a.decision],
      Confiance: `${Math.round(a.confidence * 100)} %`, horizon: 'court terme', résumé: a.summary,
      actualités: { score: String(a.news.score).replace('.', ','), confidence: Math.round(a.news.confidence * 100), summary: a.news.summary },
      marché: a.market, entrée: a.entry, stoploss: `${String(a.stop).replace('.', ',')} €`, objectifs: a.targets.map((t) => String(t).replace('.', ',')).join(' et '), taille: a.size_fraction,
      scénarios: a.scenarios.map((x) => ({ nom: x.name.toLowerCase(), proba: `${Math.round(x.probability * 100)}%`, objectif: x.target })), // descriptions oubliées
      facteurs_clés: a.key_factors.map((k) => ({ description: k.factor, effet: k.impact.toLowerCase(), poids: k.weight })), risques: a.risks.join(' ; '), invalidation: a.invalidation,
    },
  };
}

export function startMockOllama({ port = 11435, tokenDelayMs = 4, quirks = Boolean(process.env.MOCK_OLLAMA_QUIRKS) } = {}) {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let models = [...INITIAL, ...(quirks ? QUIRKS : [])].map((m) => ({ ...m, modified_at: new Date(Date.now() - 86_400_000).toISOString(), digest: Math.random().toString(16).slice(2).padEnd(64, '0') }));
  const tag = (m) => ({ name: m.name, model: m.name, size: m.size, digest: m.digest, modified_at: m.modified_at, details: m.details });
  const find = (n) => models.find((m) => m.name === n || m.name === `${n}:latest`);
  const srv = createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    const json = (o, code = 200) => res.writeHead(code, { 'content-type': 'application/json' }).end(JSON.stringify(o));
    const nd = () => res.writeHead(200, { 'content-type': 'application/x-ndjson' });
    if (req.method === 'GET' && url.pathname === '/api/version') return json({ version: '0.12.6-simulé' });
    if (req.method === 'GET' && url.pathname === '/api/tags') return json({ models: models.map(tag) });
    if (req.method === 'GET' && url.pathname === '/api/ps') {
      const m = models[0];
      return json({ models: m ? [{ ...tag(m), size_vram: m.size, context_length: 32768, expires_at: new Date(Date.now() + 1.8e6).toISOString() }] : [] });
    }
    let body = '';
    for await (const c of req) body += c;
    const q = body ? JSON.parse(body) : {};
    if (url.pathname === '/api/show') {
      const m = find(q.model ?? q.name);
      if (!m) return json({ error: `model '${q.model}' not found` }, 404);
      return json({ details: m.details, capabilities: m.caps, ...(m.levels ? { thinking: { values: m.levels, default: 'medium' } } : {}), model_info: { 'general.architecture': m.details.family, [`${m.details.family}.context_length`]: m.ctx }, parameters: 'temperature 0.1', modified_at: m.modified_at });
    }
    if (url.pathname === '/api/delete' && req.method === 'DELETE') {
      const m = find(q.model);
      if (!m) return json({ error: 'not found' }, 404);
      models = models.filter((x) => x !== m);
      return json({});
    }
    if (url.pathname === '/api/pull') {
      if (/inexistant|nope/.test(q.model)) return json({ error: 'pull model manifest: file does not exist' }, 404);
      nd();
      const total = 5_000_000_000, digest = `sha256:${Math.random().toString(16).slice(2)}`;
      res.write(`${JSON.stringify({ status: 'pulling manifest' })}\n`);
      for (let k = 1; k <= 12; k++) { await sleep(120); res.write(`${JSON.stringify({ status: `pulling ${digest.slice(7, 19)}`, digest, total, completed: Math.round((total * k) / 12) })}\n`); }
      for (const st of ['verifying sha256 digest', 'writing manifest', 'success']) { await sleep(80); res.write(`${JSON.stringify({ status: st })}\n`); }
      if (!find(q.model)) models.push({ name: q.model.includes(':') ? q.model : `${q.model}:latest`, size: total, details: { family: 'qwen3', parameter_size: '14.8B', quantization_level: 'Q4_K_M' }, caps: CHAT, ctx: 40_960, modified_at: new Date().toISOString(), digest });
      return res.end();
    }
    if (url.pathname === '/api/create') {
      const base = find(q.from);
      if (!base) return json({ error: `base model '${q.from}' not found` }, 404);
      if (base.name === 'perm:test') return json({ error: 'chtimes /home/test/.ollama/models/blobs/sha256-aeda25e63ebd698fab8638ffb778e68bed908b960d39d0becc650fa981609d25: operation not permitted' }, 500);
      nd();
      for (const st of ['using existing layer', 'creating new layer', 'writing manifest', 'success']) { await sleep(150); res.write(`${JSON.stringify({ status: st })}\n`); }
      models = models.filter((x) => x.name !== `${q.model}:latest` && x.name !== q.model);
      models.unshift({ ...base, name: q.model.includes(':') ? q.model : `${q.model}:latest`, details: { ...base.details, parent_model: base.name }, modified_at: new Date().toISOString() });
      return res.end();
    }
    if (url.pathname === '/api/embed') {
      const inputs = Array.isArray(q.input) ? q.input : [q.input];
      return json({ embeddings: inputs.map((t) => Array.from({ length: 64 }, (_, i) => Math.sin((String(t).length + 1) * (i + 1) * 0.37))) });
    }
    if (url.pathname !== '/api/chat') return json({ error: 'introuvable' }, 404);
    const model = find(q.model);
    if (!model) return json({ error: `model "${q.model}" not found, try pulling it first` }, 404);
    if (q.tools?.length && !model.caps.includes('tools')) return json({ error: `registry.ollama.ai/library/${q.model} does not support tools` }, 400);
    if (q.think && !model.caps.includes('thinking')) return json({ error: `"${q.model}" does not support thinking` }, 400);
    const t0 = Date.now();
    let closed = false;
    res.on('close', () => { closed = true; });
    // modèles défaillants (tests de l'anti-boucle et de la lecture tolérante)
    if (model.name === 'muet:test') { // ne répond jamais : le client doit couper (chien de garde)
      while (!closed) await sleep(50);
      return undefined;
    }
    const dossier = q.messages.find((m) => m.role === 'user' && /DOSSIER/.test(m.content))?.content ?? q.messages.at(-1)?.content ?? '';
    const isAnalysis = Boolean(q.format?.properties?.decision);
    let content = '', toolCalls = null;
    if (q.format && !isAnalysis) content = JSON.stringify(fill(q.format)); // complément : seulement les champs demandés
    else if (q.format && model.name === 'brouillon:test') content = JSON.stringify(sloppy(mockAnalysis(dossier)), null, 1);
    else if (q.format) content = JSON.stringify(enforce(q.format, mockAnalysis(dossier)), null, 1);
    else if (q.tools?.length && model.name === 'radote:test') toolCalls = [{ function: { name: 'cotation', arguments: { symbole: 'MC:XPAR' } } }]; // redemande toujours la même chose
    else if (q.tools?.length) {
      const turn = mockAgentTurn(q.messages, q.tools);
      content = turn.content ?? '';
      toolCalls = turn.tool_calls ?? null;
    } else if (/Test de vitesse/.test(q.messages.at(-1)?.content ?? '')) content = 'Le RSI mesure la force relative des hausses et des baisses récentes (réponse simulée).';
    else content = mockAgentTurn(q.messages, []).content ?? 'Réponse simulée.';
    const stats = (n) => ({ total_duration: (Date.now() - t0) * 1e6 + 3e8, load_duration: 2.5e8, prompt_eval_count: Math.round(JSON.stringify(q.messages).length / 4), eval_count: n, eval_duration: Math.max(1, n * 22) * 1e6 });
    if (q.stream === false) return json({ model: q.model, message: { role: 'assistant', content, tool_calls: toolCalls ?? undefined }, done: true, ...stats(Math.round(content.length / 4)) });
    nd();
    let n = 0;
    const loopForever = async (field, text) => { // répète le même passage jusqu'à ce que le client coupe
      for (let k = 0; k < 20_000 && !closed; k++) {
        for (const piece of chunks(text, 7)) {
          if (closed) break;
          res.write(`${JSON.stringify({ model: q.model, message: { role: 'assistant', content: field === 'content' ? piece : '', thinking: field === 'thinking' ? piece : '' }, done: false })}\n`);
          await sleep(1);
        }
      }
    };
    if (model.name === 'boucle:test' && q.think) {
      await loopForever('thinking', 'Attendons, je dois revérifier le calcul du stop et de l\'ATR avant de conclure. ');
      return res.end();
    }
    if (model.name === 'radote:test' && isAnalysis) {
      const head = content.slice(0, content.indexOf('"summary"') + 12);
      for (const piece of chunks(head, 5)) res.write(`${JSON.stringify({ model: q.model, message: { role: 'assistant', content: piece }, done: false })}\n`);
      await loopForever('content', 'le titre reste dans son range ');
      return res.end();
    }
    if (q.think) for (const piece of chunks('Je relis les calculs du dossier, je compare la tendance, le momentum et les probabilités du Monte Carlo… ', 6)) { res.write(`${JSON.stringify({ model: q.model, message: { role: 'assistant', content: '', thinking: piece }, done: false })}\n`); await sleep(tokenDelayMs); }
    for (const piece of chunks(content, 5)) {
      res.write(`${JSON.stringify({ model: q.model, message: { role: 'assistant', content: piece }, done: false })}\n`);
      n++;
      await sleep(tokenDelayMs);
    }
    if (toolCalls) res.write(`${JSON.stringify({ model: q.model, message: { role: 'assistant', content: '', tool_calls: toolCalls }, done: false })}\n`);
    res.end(`${JSON.stringify({ model: q.model, message: { role: 'assistant', content: '' }, done: true, done_reason: 'stop', ...stats(n) })}\n`);
  });
  return new Promise((resolve) => srv.listen(port, '127.0.0.1', () => resolve(srv)));
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  const port = Number(process.argv[2] ?? 11435);
  startMockOllama({ port, tokenDelayMs: 12 }).then(() => console.log(`Faux Ollama (simulation) → http://127.0.0.1:${port}  ·  OLLAMA_HOST=127.0.0.1:${port} npm start`));
}

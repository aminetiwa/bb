// ============================================================================
//  BOURSO :: ai/repair.js — lecture TOLÉRANTE des réponses d'un modèle de langage.
//
//  Le schéma JSON est imposé à Ollama (grammaire), mais certains modèles ou modes (réflexion,
//  serveur ancien…) ne le respectent pas à la lettre : clés renommées (« desc », « proba »),
//  pourcentages (30 au lieu de 0,3), nombres à la française (« 56,20 € »), énumérations en clair
//  (« Acheter », « haussier »), objet enveloppé ({"analyse": {…}}), réponse coupée en plein milieu.
//
//  Principe : on récupère TOUT ce qui est exploitable, on ne bloque que sur les champs ESSENTIELS
//  (pour une analyse : la décision), et on liste précisément les champs manquants pour les
//  redemander au modèle par un appel court (voir analysis.js). Chaque correction est tracée.
// ============================================================================
import { parseJsonLoose } from './schemas.js';

/** Forme normalisée d'une clé ou d'une valeur : minuscules, sans accents ni ponctuation. */
export const norm = (s) => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '');

/** Autres noms qu'un modèle donne souvent à un champ (formes normalisées). */
const KEY_ALIASES = {
  decision: ['recommandation', 'recommendation', 'action', 'signal', 'verdict', 'avis', 'conseil', 'decisionfinale'],
  confidence: ['confiance', 'conf', 'certitude', 'conviction', 'confidencescore', 'niveaudeconfiance'],
  horizon: ['timeframe', 'horizontemporel', 'duree', 'echeance', 'horizondetemps'],
  summary: ['resume', 'synthese', 'conclusion', 'commentaire', 'analyse', 'analysis', 'texte', 'text', 'avisglobal'],
  news: ['actualites', 'actus', 'sentiment', 'newssentiment', 'nouvelles', 'presse', 'actualite'],
  market: ['marche', 'quant', 'technique', 'technical', 'marketview', 'lecturemarche'],
  score: ['note', 'sentimentscore', 'valeur', 'tonalite'],
  bias: ['biais', 'direction', 'orientation', 'pression'],
  regime: ['regimedemarche', 'etat', 'state', 'phase', 'tendance'],
  entry: ['entree', 'zoneentree', 'zonedentree', 'entryzone', 'entryrange', 'pointdentree', 'entrypoint'],
  low: ['bas', 'min', 'from', 'de', 'basse', 'lower', 'borneinf', 'minimum'],
  high: ['haut', 'max', 'to', 'a', 'haute', 'upper', 'bornesup', 'maximum'],
  stop: ['stoploss', 'sl', 'invalidationprice', 'prixinvalidation', 'stopprice', 'prixstop', 'stopdeprotection'],
  targets: ['objectifs', 'cibles', 'target', 'takeprofit', 'tp', 'objectif', 'cible', 'pricetargets', 'objectifsdecours'],
  size_fraction: ['taille', 'sizefraction', 'size', 'positionsize', 'fraction', 'tailleposition', 'tailledeposition'],
  scenarios: ['scenario', 'scenarii', 'cas', 'hypotheses'],
  name: ['nom', 'type', 'label', 'libelle', 'scenario', 'cas', 'titre', 'title'],
  probability: ['probabilite', 'proba', 'prob', 'p', 'chance', 'chances', 'likelihood', 'pct', 'pourcentage'],
  target: ['objectif', 'cible', 'prix', 'price', 'niveau', 'targetprice', 'level', 'prixcible', 'cours'],
  description: ['desc', 'details', 'detail', 'explication', 'commentaire', 'comment', 'texte', 'text', 'narratif', 'narrative', 'rationale', 'justification', 'resume', 'summary', 'hypothese', 'contexte', 'scenariodescription'],
  key_factors: ['facteurs', 'facteurscles', 'keyfactors', 'factors', 'drivers', 'elements', 'arguments', 'elementscles'],
  factor: ['facteur', 'element', 'raison', 'reason', 'texte', 'text', 'description', 'argument', 'nom', 'name', 'detail'],
  impact: ['effet', 'sens', 'direction', 'polarite', 'signe', 'effect', 'influence'],
  weight: ['poids', 'importance', 'ponderation', 'w', 'force'],
  risks: ['risques', 'risque', 'risk', 'menaces', 'dangers', 'pointsdevigilance'],
  invalidation: ['conditioninvalidation', 'invalidationcondition', 'conditiondinvalidation', 'scenariodinvalidation'],
  answer: ['reponse', 'response', 'texte', 'text'],
};

/** Valeurs d'énumération dites autrement (formes normalisées), par valeur canonique. */
const ENUM_ALIASES = {
  STRONG_BUY: ['strongbuy', 'achatfort', 'fortachat', 'acheterfort', 'forteachat', 'achatmassif', 'tresachat', 'acheterfranchement'],
  BUY: ['buy', 'achat', 'acheter', 'achete', 'long', 'acquerir', 'renforcer', 'accumuler', 'acheteur', 'haussier'],
  HOLD: ['hold', 'conserver', 'garder', 'attendre', 'neutre', 'neutral', 'wait', 'attente', 'conservation', 'aucune', 'none', 'rester', 'patienter', 'conserverattendre'],
  SELL: ['sell', 'vente', 'vendre', 'short', 'alleger', 'reduire', 'sortir', 'vendeur', 'baissier'],
  STRONG_SELL: ['strongsell', 'ventefort', 'fortevente', 'vendrefort', 'ventemassive', 'vendrefranchement'],
  INTRADAY: ['intraday', 'intrajournalier', 'journee', 'jour', 'day', 'daytrading', 'tresourtterme'],
  SWING: ['swing', 'swingdays', 'quelquesseances', 'courtterme', 'shortterm', 'jours', 'days', 'quelquesjours'],
  POSITION: ['position', 'positionweeks', 'moyenterme', 'longterme', 'mediumterm', 'longterm', 'weeks', 'semaines', 'mois'],
  HAUSSIER: ['haussier', 'hausse', 'bull', 'bullish', 'optimiste', 'favorable', 'positif', 'up', 'upside', 'bullcase'],
  CENTRAL: ['central', 'neutre', 'base', 'basecase', 'median', 'neutral', 'lateral', 'range', 'stable', 'consolidation', 'principal'],
  BAISSIER: ['baissier', 'baisse', 'bear', 'bearish', 'pessimiste', 'defavorable', 'negatif', 'down', 'downside', 'bearcase'],
  POSITIF: ['positif', 'positive', 'haussier', 'favorable', 'bullish', 'plus', 'pos', 'up', 'soutien'],
  NEGATIF: ['negatif', 'negative', 'baissier', 'defavorable', 'bearish', 'moins', 'neg', 'down', 'frein'],
  NEUTRE: ['neutre', 'neutral', 'mixte', 'mixed', 'neu', 'ambigu'],
  TREND_UP: ['trendup', 'tendancehaussiere', 'hausse', 'uptrend', 'haussier', 'bullish'],
  TREND_DOWN: ['trenddown', 'tendancebaissiere', 'baisse', 'downtrend', 'baissier', 'bearish'],
  RANGE: ['range', 'lateral', 'tradingrange', 'neutre', 'sanstendance', 'consolidation', 'stable', 'sideways', 'horizontal'],
  VOLATILE: ['volatile', 'volatil', 'agite', 'chaotique', 'choppy', 'nerveux'],
  BREAKOUT_UP: ['breakoutup', 'cassurehaussiere', 'sortiehaussiere', 'cassureparlehaut'],
  BREAKOUT_DOWN: ['breakoutdown', 'cassurebaissiere', 'sortiebaissiere', 'cassureparlebas'],
};

function lev(a, b) {
  if (Math.abs(a.length - b.length) > 2) return 3;
  const d = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    let prev = d[0];
    d[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const t = d[j];
      d[j] = Math.min(d[j] + 1, d[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = t;
    }
  }
  return d[b.length];
}

/** Valeur canonique d'une énumération, ou null. */
export function matchEnum(v, allowed) {
  const n = norm(v);
  if (!n) return null;
  for (const e of allowed) if (norm(e) === n) return e;
  for (const e of allowed) if ((ENUM_ALIASES[e] ?? []).includes(n)) return e;
  for (const e of allowed) {
    const m = norm(e);
    if (m.length >= 4 && (n.startsWith(m) || (n.length >= 5 && m.startsWith(n)))) return e;
  }
  for (const e of allowed) for (const a of ENUM_ALIASES[e] ?? []) if (a.length >= 5 && n.startsWith(a)) return e;
  const close = allowed.filter((e) => norm(e).length >= 5 && lev(n, norm(e)) <= 2);
  return close.length === 1 ? close[0] : null;
}

// un nombre : milliers séparés par des espaces (groupes de 3 chiffres) ou chiffres et séparateurs
const NUM_RE = /[-+−]?(?:\d{1,3}(?:[   ]\d{3})+(?:[.,]\d+)?|\d+(?:[.,]\d+)*)/;

/**
 * Nombre écrit n'importe comment : 0.3 · "0,3" · "30 %" · "56,20 €" · "1 234,5" · "1,234.5" · "+2.1".
 * @returns {{ value: number, percent: boolean } | null}
 */
export function parseNumber(v) {
  if (typeof v === 'number') return Number.isFinite(v) ? { value: v, percent: false } : null;
  if (typeof v === 'boolean' || v === null || v === undefined) return null;
  if (typeof v === 'object' && !Array.isArray(v)) {
    for (const k of ['value', 'valeur', 'prix', 'price', 'level', 'niveau']) if (k in v) return parseNumber(v[k]);
    const first = Object.values(v).find((x) => typeof x === 'number' || typeof x === 'string');
    return first === undefined ? null : parseNumber(first);
  }
  if (Array.isArray(v)) return v.length ? parseNumber(v[0]) : null;
  const s = String(v).replace(/[  ]/g, ' ').trim();
  const m = NUM_RE.exec(s);
  if (!m) return null;
  let t = m[0].replace(/\s/g, '').replace('−', '-');
  const percent = /^\s*%/.test(s.slice(m.index + m[0].length));
  const lastComma = t.lastIndexOf(','), lastDot = t.lastIndexOf('.');
  if (lastComma >= 0 && lastDot >= 0) {
    // le dernier séparateur est le séparateur décimal, l'autre sépare les milliers
    t = lastComma > lastDot ? t.replace(/\./g, '').replace(',', '.') : t.replace(/,/g, '');
  } else if (lastComma >= 0) {
    t = (t.match(/,/g).length > 1) ? t.replace(/,/g, '') : t.replace(',', '.');
  } else if ((t.match(/\./g) ?? []).length > 1) t = t.replace(/\./g, '');
  const x = Number(t);
  return Number.isFinite(x) ? { value: x, percent } : null;
}

/** Tous les nombres d'un texte (« 60,5 et 62 » → [60.5, 62] ; « 1 234,5 » → [1234.5]). */
function numbersIn(s) {
  return [...String(s).replace(/[  ]/g, ' ').matchAll(new RegExp(NUM_RE.source, 'g'))].map((m) => parseNumber(m[0])?.value).filter(Number.isFinite);
}

/** Texte lisible tiré de n'importe quelle valeur. */
function textOf(v) {
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  if (Array.isArray(v)) return v.map(textOf).filter(Boolean).join(' ; ');
  if (v && typeof v === 'object') {
    const strs = Object.values(v).filter((x) => typeof x === 'string' && x.trim());
    return strs.length ? strs.sort((a, b) => b.length - a.length)[0] : '';
  }
  return '';
}

/** Trouve la clé source correspondant au champ `k` du schéma (exacte, normalisée, alias, proche). */
function findKey(obj, k, used) {
  if (Object.hasOwn(obj, k) && obj[k] !== undefined && obj[k] !== null) return k;
  const keys = Object.keys(obj).filter((x) => !used.has(x) && obj[x] !== undefined && obj[x] !== null);
  const nk = norm(k);
  const byNorm = keys.find((x) => norm(x) === nk);
  if (byNorm) return byNorm;
  for (const a of KEY_ALIASES[k] ?? []) {
    const hit = keys.find((x) => norm(x) === a);
    if (hit) return hit;
  }
  if (nk.length >= 6) {
    const close = keys.filter((x) => lev(norm(x), nk) <= 2);
    if (close.length === 1) return close[0];
  }
  return null;
}

const PCT_RANGES = (s) => s.minimum !== undefined && s.maximum !== undefined && ((s.minimum === 0 && s.maximum === 1) || (s.minimum === -1 && s.maximum === 1));

function walk(s, v, path, ctx) {
  switch (s.type) {
    case 'object': {
      if (typeof v === 'string') {
        const p = parseJsonLoose(v);
        if (p.ok && p.value && typeof p.value === 'object') v = p.value;
      }
      if (Array.isArray(v) && v.length === 1 && v[0] && typeof v[0] === 'object') v = v[0];
      if (v === null || typeof v !== 'object' || Array.isArray(v)) return { bad: true };
      const out = {}, used = new Set();
      for (const [k, sub] of Object.entries(s.properties ?? {})) {
        const src = findKey(v, k, used);
        if (src === null) {
          if (s.required?.includes(k)) ctx.missing.push(`${path}.${k}`);
          continue;
        }
        used.add(src);
        if (src !== k) ctx.renamed.add(`${src} → ${k}`);
        const r = walk(sub, v[src], `${path}.${k}`, ctx);
        if (r.bad) {
          if (s.required?.includes(k)) ctx.missing.push(`${path}.${k}`);
          ctx.invalid.push(`${path}.${k}`);
          continue;
        }
        out[k] = r.value;
      }
      return { value: out };
    }
    case 'array': {
      let a = v;
      if (typeof a === 'string') {
        const p = parseJsonLoose(a.trim().startsWith('[') ? `{"x":${a}}` : '');
        if (p.ok && Array.isArray(p.value?.x)) a = p.value.x;
        else if (s.items?.type === 'number') a = numbersIn(a);
        else if (s.items?.type === 'string') a = a.split(/\n+|;\s*|\s+[-•]\s+/).map((x) => x.replace(/^\s*[-•*\d.)]+\s*/, '').trim()).filter(Boolean);
        else a = [a];
      } else if (a && typeof a === 'object' && !Array.isArray(a)) {
        // {"HAUSSIER": {...}, "CENTRAL": {...}} ou {"0": …, "1": …}
        const ent = Object.entries(a);
        a = ent.map(([k, x]) => (x && typeof x === 'object' && !Array.isArray(x) && s.items?.type === 'object' ? { name: k, ...x } : x));
      } else if (typeof a === 'number') a = [a];
      if (!Array.isArray(a)) return { bad: true };
      const out = [];
      a.forEach((x, i) => {
        const before = ctx.missing.length;
        const r = walk(s.items, x, `${path}[${out.length}]`, ctx);
        if (r.bad) {
          ctx.dropped.push(`${path}[${i}]`);
          return;
        }
        // un élément d'objet dont TOUS les champs manquent n'apporte rien
        if (s.items?.type === 'object' && r.value && !Object.keys(r.value).length) {
          ctx.missing.length = before;
          ctx.dropped.push(`${path}[${i}]`);
          return;
        }
        out.push(r.value);
      });
      if (s.maxItems && out.length > s.maxItems) {
        ctx.truncated.push(`${path} (${out.length} → ${s.maxItems})`);
        out.length = s.maxItems;
        // les manques des éléments retirés ne comptent plus
        const keep = new RegExp(`^${escapeRe(path)}\\[(\\d+)\\]`);
        ctx.missing = ctx.missing.filter((p) => !(keep.test(p) && Number(keep.exec(p)[1]) >= s.maxItems));
      }
      return { value: out };
    }
    case 'number':
    case 'integer': {
      const p = parseNumber(v);
      if (!p) return { bad: true };
      let y = p.value;
      if (PCT_RANGES(s) && (p.percent || (Math.abs(y) > 1 && Math.abs(y) <= 100))) {
        y /= 100;
        ctx.percent.add(path.replace(/\[\d+\]/g, '[]'));
      }
      if (s.type === 'integer') y = Math.round(y);
      if (s.minimum !== undefined && y < s.minimum) y = s.minimum;
      if (s.maximum !== undefined && y > s.maximum) y = s.maximum;
      return { value: y };
    }
    case 'string': {
      if (s.enum) {
        const raw = typeof v === 'string' ? v : textOf(v);
        const e = matchEnum(raw, s.enum);
        if (!e) {
          ctx.badEnum.push(`${path} « ${String(raw).slice(0, 40)} »`);
          return { bad: true };
        }
        if (norm(e) !== norm(raw)) ctx.mapped.add(`« ${String(raw).slice(0, 30)} » → ${e}`);
        return { value: e };
      }
      const t = textOf(v).trim();
      if (!t) return { bad: true };
      return { value: s.maxLength && t.length > s.maxLength ? `${t.slice(0, s.maxLength - 1)}…` : t };
    }
    case 'boolean': {
      if (typeof v === 'boolean') return { value: v };
      const n = norm(v);
      if (['true', 'oui', 'yes', 'vrai', '1'].includes(n)) return { value: true };
      if (['false', 'non', 'no', 'faux', '0'].includes(n)) return { value: false };
      return { bad: true };
    }
    default:
      return { value: v };
  }
}

const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/**
 * Récupère d'une réponse tout ce qui est conforme au schéma.
 * @param {object} schema  schéma (sous-ensemble JSON Schema, cf. schemas.js)
 * @param {any} input      objet lu dans la réponse du modèle
 * @param {{ essential?: string[] }} opts  champs de 1er niveau sans lesquels la réponse est inutilisable
 * @returns {{ ok:boolean, value:object|null, errors:string[], missing:string[], notes:string[] }}
 *   missing : chemins des champs requis absents ou illisibles (ex. "scenarios[0].description")
 */
export function salvage(schema, input, { essential = [] } = {}) {
  const ctx = { missing: [], invalid: [], dropped: [], truncated: [], badEnum: [], renamed: new Set(), mapped: new Set(), percent: new Set() };
  const notes = [];
  let v = input;
  // objet enveloppé : {"analyse": {decision…}} ou {"response": "{…}"}
  if (schema.type === 'object' && v && typeof v === 'object' && !Array.isArray(v)) {
    const own = Object.keys(schema.properties ?? {});
    const hits = (o) => (o && typeof o === 'object' ? own.filter((k) => findKey(o, k, new Set()) !== null).length : 0);
    if (hits(v) < 2) {
      for (const [k, x] of Object.entries(v)) {
        const inner = typeof x === 'string' ? parseJsonLoose(x).value : x;
        if (hits(inner) >= 2) {
          v = inner;
          notes.push(`réponse enveloppée dans « ${k} » : contenu extrait`);
          break;
        }
      }
    }
  }
  const r = walk(schema, v, '$', ctx);
  if (r.bad) return { ok: false, value: null, errors: ['$: objet JSON attendu'], missing: [], notes };
  const value = r.value;
  const strip = (p) => p.replace(/^\$\./, '');
  const errors = [];
  for (const k of essential) {
    if (value[k] !== undefined) continue;
    const bad = ctx.badEnum.find((b) => b.startsWith(`$.${k} `));
    errors.push(bad ? `${k} : valeur non reconnue ${bad.slice(k.length + 3)}` : `${k} : absent`);
  }
  const missing = [...new Set(ctx.missing.map(strip))].filter((p) => !essential.includes(p));
  if (ctx.renamed.size) notes.push(`clés renommées par le modèle reconnues : ${[...ctx.renamed].slice(0, 6).join(', ')}${ctx.renamed.size > 6 ? '…' : ''}`);
  if (ctx.mapped.size) notes.push(`valeurs ramenées au vocabulaire attendu : ${[...ctx.mapped].slice(0, 5).join(', ')}${ctx.mapped.size > 5 ? '…' : ''}`);
  if (ctx.percent.size) notes.push(`valeurs données en pourcentage converties : ${[...ctx.percent].map(strip).join(', ')}`);
  if (ctx.dropped.length) notes.push(`éléments inutilisables écartés : ${ctx.dropped.map(strip).join(', ')}`);
  if (ctx.truncated.length) notes.push(`listes trop longues raccourcies : ${ctx.truncated.map(strip).join(', ')}`);
  const unknownEnums = ctx.badEnum.filter((b) => !essential.some((k) => b.startsWith(`$.${k} `)));
  if (unknownEnums.length) notes.push(`valeurs non reconnues : ${unknownEnums.map(strip).slice(0, 4).join(', ')}`);
  return { ok: errors.length === 0, value, errors, missing, notes };
}

// ---------------------------------------------------------------- JSON coupé
/**
 * Referme un objet JSON coupé (limite de jetons atteinte, génération interrompue par l'anti-boucle) :
 * garde tout ce qui est complet, referme une chaîne en cours, retire une clé sans valeur ou un
 * nombre peut-être tronqué, puis ferme tableaux et objets.
 * @returns {{ text: string, truncated: boolean } | null}
 */
export function closeJson(text) {
  if (typeof text !== 'string') return null;
  const a = text.indexOf('{');
  if (a < 0) return null;
  const s = text.slice(a);
  const stack = [];
  const closers = () => stack.map((f) => (f.type === 'obj' ? '}' : ']')).reverse().join('');
  let safe = null, i = 0;
  const valueDone = (end) => {
    const top = stack.at(-1);
    if (top) top.state = 'comma';
    safe = { pos: end, close: closers() };
  };
  while (i < s.length) {
    const c = s[i];
    if (c === ' ' || c === '\n' || c === '\r' || c === '\t') { i++; continue; }
    const top = stack.at(-1);
    if (c === '"') {
      let j = i + 1, esc = false;
      for (; j < s.length; j++) {
        const d = s[j];
        if (esc) esc = false;
        else if (d === '\\') esc = true;
        else if (d === '"') break;
      }
      const closed = j < s.length;
      if (top?.type === 'obj' && top.state === 'key') {
        if (!closed) break; // clé coupée : on revient à la dernière coupe sûre
        top.state = 'colon';
        i = j + 1;
        continue;
      }
      if (!closed) {
        // chaîne de valeur coupée : on garde le début et on la referme
        let str = s.slice(i, j);
        if (esc) str = str.slice(0, -1);
        str = str.replace(/\\u[0-9a-fA-F]{0,3}$/, '');
        return { text: `${s.slice(0, i)}${str}…"${closers()}`, truncated: true };
      }
      i = j + 1;
      valueDone(i);
      continue;
    }
    if (c === '{' || c === '[') {
      stack.push({ type: c === '{' ? 'obj' : 'arr', state: c === '{' ? 'key' : 'value' });
      i++;
      safe = { pos: i, close: closers() };
      continue;
    }
    if (c === '}' || c === ']') {
      stack.pop();
      i++;
      if (!stack.length) return { text: s.slice(0, i), truncated: false };
      valueDone(i);
      continue;
    }
    if (c === ':') { if (top) top.state = 'value'; i++; continue; }
    if (c === ',') { if (top) top.state = top.type === 'obj' ? 'key' : 'value'; i++; continue; }
    const m = /^(?:-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|true|false|null)/.exec(s.slice(i, i + 64));
    if (!m) break;
    const end = i + m[0].length;
    if (end >= s.length) break; // nombre peut-être coupé : on ne le garde pas
    i = end;
    valueDone(i);
  }
  if (!safe) return null;
  return { text: s.slice(0, safe.pos) + safe.close, truncated: true };
}

/**
 * Lit l'objet JSON d'une réponse, au besoin en refermant une réponse coupée.
 * @returns {{ ok:boolean, value?:any, error?:string, closed?:boolean }}
 */
export function readJson(text) {
  const p = parseJsonLoose(text);
  if (p.ok) return p;
  const c = closeJson(text);
  if (c?.truncated) {
    const q = parseJsonLoose(c.text);
    if (q.ok) return { ...q, closed: true };
  }
  return p;
}

// ---------------------------------------------------------------- chemins
const tokens = (path) => [...String(path).replace(/^\$\.?/, '').matchAll(/[^.[\]]+|\[(\d+)\]/g)].map((m) => (m[1] !== undefined ? Number(m[1]) : m[0]));

/** Sous-schéma au chemin donné (ex. "scenarios[1].description"), ou null. */
export function schemaAt(schema, path) {
  let s = schema;
  for (const t of tokens(path)) {
    if (!s) return null;
    s = typeof t === 'number' ? (s.type === 'array' ? s.items : null) : s.type === 'object' ? s.properties?.[t] : null;
  }
  return s ?? null;
}

export function getAt(obj, path) {
  let o = obj;
  for (const t of tokens(path)) {
    if (o === null || o === undefined) return undefined;
    o = o[t];
  }
  return o;
}

export function setAt(obj, path, value) {
  const ts = tokens(path);
  let o = obj;
  ts.forEach((t, i) => {
    if (i === ts.length - 1) o[t] = value;
    else {
      if (o[t] === null || typeof o[t] !== 'object') o[t] = typeof ts[i + 1] === 'number' ? [] : {};
      o = o[t];
    }
  });
  return obj;
}

/**
 * Schéma d'un « complément » : un objet plat dont chaque clé désigne un champ manquant
 * (« scenarios[0].description » → clé "scenarios_0_description", sans crochets ni points pour la
 * grammaire d'Ollama), typé par le sous-schéma correspondant.
 * @returns {{ schema: object, keys: Map<string, string> }} keys : clé du complément → chemin
 */
export function patchSchema(schema, paths) {
  const properties = {}, keys = new Map();
  for (const p of paths) {
    const sub = schemaAt(schema, p);
    if (!sub) continue;
    let k = p.replace(/\[(\d+)\]/g, '_$1').replace(/\./g, '_');
    while (keys.has(k)) k += '_';
    keys.set(k, p);
    properties[k] = sub;
  }
  return { schema: { type: 'object', properties, required: Object.keys(properties), additionalProperties: false }, keys };
}

/** Fusionne un complément validé dans la réponse ; renvoie les chemins effectivement remplis. */
export function applyPatch(target, patch, keys) {
  const filled = [];
  for (const [k, v] of Object.entries(patch ?? {})) {
    const p = keys?.get(k) ?? k;
    if (v === undefined || v === null || (typeof v === 'string' && !v.trim())) continue;
    setAt(target, p, v);
    filled.push(p);
  }
  return filled;
}

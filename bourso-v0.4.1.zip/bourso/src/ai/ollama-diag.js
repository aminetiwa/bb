// ============================================================================
//  BOURSO :: ai/ollama-diag.js — explique les erreurs d'Ollama en français, avec la solution.
//
//  Cas principal : « chtimes …/blobs/sha256-…: operation not permitted » à la création d'un modèle.
//  Ollama veut mettre à jour la date des fichiers du modèle de base ; il en est empêché parce que
//  ces fichiers appartiennent à un autre utilisateur que celui qui fait tourner le serveur Ollama
//  (ex. modèles téléchargés quand `ollama serve` tournait sous ton compte, serveur relancé ensuite
//  par le service système sous l'utilisateur « ollama », ou l'inverse), ou parce que le disque ne
//  permet pas de changer les dates (NTFS, exFAT, partage réseau). Quand Ollama tourne sur cette
//  machine, on lit le propriétaire du fichier et l'utilisateur du serveur pour donner LA commande.
// ============================================================================
import { readFile, readdir, stat } from 'node:fs/promises';

let passwd = null;
async function userName(uid) {
  try {
    passwd ??= await readFile('/etc/passwd', 'utf8');
    const line = passwd.split('\n').find((l) => l.split(':')[2] === String(uid));
    if (line) return line.split(':')[0];
  } catch { /* pas de /etc/passwd */ }
  return `uid ${uid}`;
}

/** Utilisateur du processus « ollama serve » local (Linux), ou null. */
export async function ollamaServerUser() {
  if (process.platform !== 'linux') return null;
  let pids = [];
  try { pids = (await readdir('/proc')).filter((d) => /^\d+$/.test(d)); } catch { return null; }
  for (const pid of pids) {
    try {
      const comm = (await readFile(`/proc/${pid}/comm`, 'utf8')).trim();
      if (comm !== 'ollama') continue;
      const cmd = (await readFile(`/proc/${pid}/cmdline`, 'utf8')).split('\0');
      if (!cmd.includes('serve')) continue;
      const uid = /^Uid:\s+(\d+)/m.exec(await readFile(`/proc/${pid}/status`, 'utf8'))?.[1];
      if (uid !== undefined) return { pid: Number(pid), uid: Number(uid), user: await userName(uid) };
    } catch { /* processus disparu ou illisible */ }
  }
  return null;
}

const isLocal = (host) => /^(https?:\/\/)?(127\.\d+\.\d+\.\d+|localhost|\[::1\])(:|\/|$)/i.test(String(host ?? ''));

/**
 * @param {string} message message d'erreur brut d'Ollama
 * @param {{ host?: string, op?: string, model?: string, from?: string }} ctx
 * @returns {Promise<null | { title: string, lines: string[], commands: { label: string, code: string }[], useBase?: string }>}
 */
export async function explainOllamaError(message, { host, op, from } = {}) {
  const m = String(message ?? '');
  if (/chtimes|operation not permitted|permission denied|read-only file system/i.test(m)) {
    const path = /(?:chtimes|open|mkdir|rename|remove|unlinkat|write|chmod)\s+(\/[^:\s]+)/i.exec(m)?.[1] ?? null;
    const dir = path ? path.replace(/\/(blobs|manifests)(\/.*)?$/, '') : null;
    const where = dir ?? '<dossier des modèles>';
    let owner = null, server = null;
    if (path && isLocal(host)) {
      try { owner = await userName((await stat(path)).uid); } catch { /* fichier invisible pour Bourso */ }
      server = await ollamaServerUser();
    }
    const lines = [
      `Ce n'est pas une erreur de Bourso : le serveur Ollama n'a pas le droit de modifier ses propres fichiers${path ? ` (${path})` : ''}.`,
    ];
    const commands = [];
    if (owner && server && owner !== server.user) {
      lines.push(`Ce fichier appartient à « ${owner} », mais le serveur Ollama tourne sous l'utilisateur « ${server.user} » (processus ${server.pid}). Il peut lire les modèles (ils fonctionnent), mais pas changer la date de leurs fichiers, ce qu'exige la création d'un modèle.`);
      commands.push({ label: `Solution 1 : rendre les modèles à l'utilisateur du serveur (« ${server.user} »)`, code: `sudo systemctl stop ollama\nsudo chown -R ${server.user}:${server.user} ${where}\nsudo systemctl start ollama` });
      commands.push({ label: `Solution 2 : faire tourner le service Ollama sous ton compte (« ${owner} »)`, code: `sudo systemctl edit ollama\n# ajoute ces 3 lignes dans l'éditeur, enregistre et ferme :\n[Service]\nUser=${owner}\nGroup=${owner}\n\nsudo systemctl daemon-reload\nsudo systemctl restart ollama` });
    } else if (owner && server && owner === server.user) {
      lines.push(`Le fichier appartient bien à l'utilisateur du serveur (« ${owner} ») : c'est donc le disque qui refuse le changement de date. Cela arrive avec un dossier de modèles sur une partition NTFS ou exFAT, un partage réseau, ou un fichier rendu immuable.`);
      commands.push({ label: 'Vérifier le type de disque et les attributs', code: `df -T ${where}\nlsattr -d ${where}/blobs | head -3` });
      commands.push({ label: 'Si le disque est NTFS/exFAT : déplacer les modèles sur une partition Linux (ext4)', code: `# exemple : dans le service Ollama, OLLAMA_MODELS=/var/lib/ollama/models\nsudo systemctl edit ollama   # Environment="OLLAMA_MODELS=/chemin/ext4"\nsudo systemctl restart ollama` });
    } else {
      lines.push('Cause habituelle : les fichiers des modèles appartiennent à un autre utilisateur que celui qui fait tourner le serveur Ollama. Par exemple, les modèles ont été téléchargés pendant que `ollama serve` tournait sous ton compte, puis le service système a relancé Ollama sous l\'utilisateur « ollama » (ou l\'inverse, ou après un `sudo ollama …`).');
      commands.push({ label: 'Voir qui fait tourner Ollama et à qui sont les fichiers', code: `ps -o user=,pid=,cmd= -C ollama\nls -ln ${where}/blobs | head -5` });
      commands.push({ label: 'Si le serveur tourne sous « ollama » (service systemd)', code: `sudo systemctl stop ollama\nsudo chown -R ollama:ollama ${where}\nsudo systemctl start ollama` });
      commands.push({ label: 'Si tu lances `ollama serve` toi-même sous ton compte', code: `sudo chown -R "$USER":"$USER" ${where}` });
    }
    lines.push('Le modèle « bourso » est FACULTATIF : Bourso envoie déjà ses consignes et ses réglages (température, contexte…) à chaque analyse. Tu peux utiliser directement le modèle de base, avec exactement le même résultat.');
    return { title: 'Ollama n\'a pas le droit de modifier ses fichiers', lines, commands, useBase: op === 'create' ? from ?? null : null };
  }
  if (/no space left on device/i.test(m)) {
    return { title: 'Disque plein', lines: ['Le disque qui contient les modèles d\'Ollama est plein. Supprime un modèle inutile (bouton ✕ dans la liste) ou libère de la place.'], commands: [{ label: 'Place restante et taille des modèles', code: 'df -h ~/.ollama /usr/share/ollama 2>/dev/null\nollama list' }] };
  }
  if (/file does not exist|manifest.*not found|pull model manifest/i.test(m)) {
    return { title: 'Modèle introuvable dans la bibliothèque d\'Ollama', lines: ['Ce nom n\'existe pas (ou plus) sur ollama.com. Vérifie l\'orthographe et l\'étiquette (ex. qwen3:30b, gemma4:26b).'], commands: [] };
  }
  if (/requires a newer version|unsupported model|unknown model architecture/i.test(m)) {
    return { title: 'Ollama trop ancien pour ce modèle', lines: ['Ce modèle demande une version plus récente d\'Ollama.'], commands: [{ label: 'Mettre Ollama à jour (Linux)', code: 'curl -fsSL https://ollama.com/install.sh | sh' }] };
  }
  if (/injoignable|ECONNREFUSED|fetch failed/i.test(m)) {
    return { title: 'Ollama ne répond pas', lines: ['Le serveur Ollama n\'est pas lancé, ou écoute à une autre adresse que celle des réglages.'], commands: [{ label: 'Lancer ou vérifier Ollama', code: 'systemctl status ollama --no-pager\n# ou, sans service :\nollama serve' }] };
  }
  if (/out of memory|cudaMalloc|unable to allocate|insufficient memory/i.test(m)) {
    return { title: 'Mémoire insuffisante pour charger le modèle', lines: ['Le modèle (ou le contexte demandé) ne tient pas en mémoire. Réduis le contexte dans Réglages, ou choisis un modèle plus petit / plus quantifié.'], commands: [] };
  }
  return null;
}

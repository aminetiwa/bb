// ============================================================================
//  BOURSO :: ollama-client.js — client REST Ollama sans dépendance (fetch natif).
//   - structured outputs : `format` = schéma JSON (grammaire contrainte côté Ollama)
//   - `think: false` : coupe la réflexion des modèles « thinking » (Qwen3…) → réponse directe, bien plus rapide
//   - embeddings sur CPU par défaut (num_gpu 0) : toute la VRAM reste au modèle de 30B
//   - timeouts, retries réseau/5xx avec backoff, une requête à la fois par défaut (1 GPU)
//   - keep_alive : le modèle reste chargé entre deux analyses
// ============================================================================

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function normalizeHost(h) {
  let s = (h ?? '').trim() || 'http://127.0.0.1:11434';
  if (!/^https?:\/\//i.test(s)) s = `http://${s}`;
  const u = new URL(s);
  if (u.hostname === '0.0.0.0') u.hostname = '127.0.0.1';
  if (!u.port && u.protocol === 'http:') u.port = '11434';
  return u.origin;
}

// Mots-clés JSON Schema que la grammaire d'Ollama n'a pas besoin de voir
// (on les garde pour notre propre validation, cf. schemas.js).
const STRIP = new Set(['minimum', 'maximum', 'minItems', 'maxItems', 'maxLength', 'description']);
/**
 * Schéma envoyé à Ollama (grammaire contrainte). On retire les MOTS-CLÉS ci-dessus, jamais les NOMS
 * de champs : sous `properties`, toutes les clés sont des champs, même si l'une s'appelle
 * « description » (bug de la 0.3 : le champ scenarios[].description était retiré de la grammaire,
 * le modèle ne pouvait donc pas l'écrire et toutes les réponses étaient rejetées).
 */
export function toOllamaFormat(schema) {
  if (Array.isArray(schema)) return schema.map(toOllamaFormat);
  if (!schema || typeof schema !== 'object') return schema;
  const out = {};
  for (const [k, v] of Object.entries(schema)) {
    if (STRIP.has(k)) continue;
    if ((k === 'properties' || k === '$defs' || k === 'definitions') && v && typeof v === 'object' && !Array.isArray(v)) {
      out[k] = Object.fromEntries(Object.entries(v).map(([name, sub]) => [name, toOllamaFormat(sub)]));
    } else out[k] = toOllamaFormat(v);
  }
  return out;
}

export class OllamaError extends Error {
  constructor(message, { status, retryable } = {}) {
    super(message);
    this.name = 'OllamaError';
    this.status = status;
    this.retryable = retryable;
  }
}

export class OllamaClient {
  constructor({
    host = process.env.OLLAMA_HOST,
    timeoutMs = 180_000,
    maxConcurrent = 1,
    keepAlive = '30m',
    retries = 2,
    fetchImpl = globalThis.fetch,
  } = {}) {
    this.base = normalizeHost(host);
    this.timeoutMs = timeoutMs;
    this.keepAlive = keepAlive;
    this.retries = retries;
    this.fetch = fetchImpl;
    this.max = maxConcurrent;
    this.active = 0;
    this.queue = [];
    this.seq = 0;
    this.noThink = new Set();
  }

  /**
   * @param {{model:string, messages:{role:string,content:string}[], format?:object, options?:object, signal?:AbortSignal}} req
   * @returns {Promise<{content:string, stats:object, raw:object}>}
   */
  async chat({ model, messages, format, options, think, signal, priority = 1 }) {
    const body = { model, messages, stream: false, keep_alive: this.keepAlive };
    if (format) body.format = toOllamaFormat(format);
    if (options) body.options = options;
    if (think !== undefined && think !== null && !this.noThink.has(model)) body.think = think;
    const res = await this.#limit(async () => {
      try {
        return await this.#post('/api/chat', body, signal);
      } catch (e) {
        // Modèle sans mode « réflexion » : on retire le paramètre et on s'en souvient.
        if (body.think !== undefined && e.status === 400 && /think/i.test(e.message)) {
          this.noThink.add(model);
          delete body.think;
          return this.#post('/api/chat', body, signal);
        }
        throw e;
      }
    }, priority);
    return { content: res?.message?.content ?? '', stats: statsOf(res), raw: res };
  }

  /**
   * @param {{ model:string, input:string|string[], options?:object, signal?:AbortSignal }} req
   *   options par défaut { num_gpu: 0 } : embeddings calculés sur CPU (petit modèle, VRAM préservée).
   * @returns {Promise<number[][]>}
   */
  async embed({ model, input, options = { num_gpu: 0 }, signal }) {
    const res = await this.#limit(() => this.#post('/api/embed', { model, input, options, keep_alive: this.keepAlive }, signal));
    if (!Array.isArray(res?.embeddings)) throw new OllamaError('réponse /api/embed sans embeddings');
    return res.embeddings;
  }

  async version() {
    const r = await this.fetch(`${this.base}/api/version`, { signal: AbortSignal.timeout(3000) });
    if (!r.ok) throw new OllamaError(`HTTP ${r.status}`, { status: r.status });
    return (await r.json()).version;
  }

  async listModels() {
    const r = await this.fetch(`${this.base}/api/tags`, { signal: AbortSignal.timeout(5000) });
    if (!r.ok) throw new OllamaError(`HTTP ${r.status}`, { status: r.status });
    return ((await r.json()).models ?? []).map((m) => m.name);
  }

  /** Prend un « jeton » d'accès au modèle (file à priorités : la discussion passe avant les analyses de fond). */
  async #acquire(priority = 1) {
    if (this.active >= this.max) {
      await new Promise((resolve) => {
        this.queue.push({ resolve, priority, seq: ++this.seq });
        this.queue.sort((a, b) => b.priority - a.priority || a.seq - b.seq);
      });
    }
    this.active++;
    let done = false;
    return () => {
      if (done) return;
      done = true;
      this.active--;
      this.queue.shift()?.resolve();
    };
  }

  async #limit(fn, priority = 1) {
    const release = await this.#acquire(priority);
    try {
      return await fn();
    } finally {
      release();
    }
  }

  /** Nombre de requêtes en attente du modèle. */
  get waiting() {
    return this.queue.length;
  }

  /**
   * Discussion en continu (NDJSON) : générateur de morceaux
   * { content, thinking, tool_calls, done, stats }. Gère `tools` (appels d'outils) et `format`.
   */
  async *chatStream({ model, messages, format, options, think, tools, signal, priority = 1 }) {
    const body = { model, messages, stream: true, keep_alive: this.keepAlive };
    if (format) body.format = toOllamaFormat(format);
    if (options) body.options = options;
    if (tools?.length) body.tools = tools;
    if (think !== undefined && think !== null && !this.noThink.has(model)) body.think = think;
    const release = await this.#acquire(priority);
    try {
      const open = () => this.fetch(`${this.base}/api/chat`, {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body),
        signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(this.timeoutMs * 3)]) : AbortSignal.timeout(this.timeoutMs * 3),
      });
      let res;
      try {
        res = await open();
      } catch (e) {
        // coupé par l'appelant (anti-boucle, chien de garde, bouton « arrêter ») : ce n'est pas une panne d'Ollama
        if (signal?.aborted) throw signal.reason ?? e;
        throw new OllamaError(`Ollama injoignable sur ${this.base} (ollama serve lancé ?) — ${e.cause?.code ?? e.message}`);
      }
      if (!res.ok) {
        const text = await res.text().catch(() => '');
        if (body.think !== undefined && res.status === 400 && /think/i.test(text)) {
          this.noThink.add(model);
          delete body.think;
          res = await open();
        }
        if (!res.ok) throw new OllamaError(`Ollama /api/chat HTTP ${res.status}: ${text.slice(0, 300)}`, { status: res.status });
      }
      const reader = res.body.getReader(), dec = new TextDecoder();
      let buf = '';
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim();
          buf = buf.slice(i + 1);
          if (!line) continue;
          const j = JSON.parse(line);
          if (j.error) throw new OllamaError(`Ollama : ${j.error}`);
          yield { content: j.message?.content ?? '', thinking: j.message?.thinking ?? '', tool_calls: j.message?.tool_calls ?? null, done: Boolean(j.done), stats: j.done ? statsOf(j) : null };
        }
      }
    } finally {
      release();
    }
  }

  /** Change de serveur Ollama à chaud (réglages). */
  setHost(host) {
    this.base = normalizeHost(host);
    return this.base;
  }

  /**
   * Fiche d'un modèle : capacités (« completion », « tools », « thinking », « vision », « embedding »),
   * niveaux de réflexion éventuels, longueur de contexte maximale, détails (famille, paramètres, quantification).
   */
  async show(model) {
    const r = await this.fetch(`${this.base}/api/show`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ model }), signal: AbortSignal.timeout(8000) });
    if (!r.ok) throw new OllamaError(`/api/show ${model} : HTTP ${r.status}`, { status: r.status });
    const j = await r.json(), info = j.model_info ?? {};
    const ctxKey = Object.keys(info).find((k) => k.endsWith('.context_length'));
    return {
      capabilities: Array.isArray(j.capabilities) ? j.capabilities : null, thinking: j.thinking ?? null, contextLength: ctxKey ? info[ctxKey] : null,
      details: j.details ?? {}, parameters: j.parameters ?? '', architecture: info['general.architecture'] ?? null, modifiedAt: j.modified_at ?? null,
    };
  }

  /** Flux NDJSON générique (téléchargement, création) : { status, total, completed, digest }. */
  async *#statusStream(path, body, signal) {
    let res;
    try {
      res = await this.fetch(`${this.base}${path}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ...body, stream: true }), signal });
    } catch (e) {
      throw new OllamaError(`Ollama injoignable sur ${this.base} — ${e.cause?.code ?? e.message}`);
    }
    if (!res.ok) throw new OllamaError(`Ollama ${path} HTTP ${res.status}: ${(await res.text().catch(() => '')).slice(0, 300)}`, { status: res.status });
    const reader = res.body.getReader(), dec = new TextDecoder();
    let buf = '';
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (!line) continue;
        const j = JSON.parse(line);
        if (j.error) throw new OllamaError(`Ollama : ${j.error}`);
        yield j;
      }
    }
  }

  /** Téléchargement d'un modèle (progression en octets). */
  pull(model, signal) {
    return this.#statusStream('/api/pull', { model }, signal);
  }

  /** Création d'un modèle dérivé (consignes système + paramètres) à partir d'un modèle installé. */
  create({ model, from, system, parameters }, signal) {
    return this.#statusStream('/api/create', { model, from, system, parameters }, signal);
  }

  /** Suppression d'un modèle installé. */
  async remove(model) {
    const r = await this.fetch(`${this.base}/api/delete`, { method: 'DELETE', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ model }), signal: AbortSignal.timeout(20_000) });
    if (!r.ok) throw new OllamaError(`suppression de ${model} : HTTP ${r.status} ${(await r.text().catch(() => '')).slice(0, 200)}`, { status: r.status });
    return true;
  }

  /** Modèles chargés en mémoire (taille, part en VRAM, expiration). */
  async ps() {
    const r = await this.fetch(`${this.base}/api/ps`, { signal: AbortSignal.timeout(3000) });
    if (!r.ok) throw new OllamaError(`HTTP ${r.status}`, { status: r.status });
    return (await r.json()).models ?? [];
  }

  /** Modèles installés avec leurs détails (taille, paramètres, quantification). */
  async tags() {
    const r = await this.fetch(`${this.base}/api/tags`, { signal: AbortSignal.timeout(5000) });
    if (!r.ok) throw new OllamaError(`HTTP ${r.status}`, { status: r.status });
    return (await r.json()).models ?? [];
  }

  async #post(path, body, signal) {
    let lastErr;
    for (let attempt = 0; attempt <= this.retries; attempt++) {
      const timeout = AbortSignal.timeout(this.timeoutMs);
      const sig = signal ? AbortSignal.any([signal, timeout]) : timeout;
      try {
        const r = await this.fetch(`${this.base}${path}`, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(body),
          signal: sig,
        });
        if (!r.ok) {
          const text = await r.text().catch(() => '');
          throw new OllamaError(`Ollama ${path} HTTP ${r.status}: ${text.slice(0, 300)}`, {
            status: r.status,
            retryable: r.status >= 500,
          });
        }
        return await r.json();
      } catch (e) {
        lastErr = e;
        const aborted = signal?.aborted;
        const retryable = !aborted && (e.retryable || e.name === 'TypeError' || e.name === 'TimeoutError');
        if (!retryable || attempt === this.retries) break;
        await sleep(500 * 3 ** attempt);
      }
    }
    if (lastErr?.name === 'TypeError') {
      throw new OllamaError(`Ollama injoignable sur ${this.base} (ollama serve lancé ?) — ${lastErr.cause?.code ?? lastErr.message}`);
    }
    throw lastErr;
  }
}

function statsOf(res) {
  const ns = (x) => (typeof x === 'number' ? x / 1e6 : null);
  const evalMs = ns(res?.eval_duration);
  return {
    model: res?.model,
    totalMs: ns(res?.total_duration),
    loadMs: ns(res?.load_duration),
    promptTokens: res?.prompt_eval_count ?? null,
    outputTokens: res?.eval_count ?? null,
    tokPerSec: evalMs ? (res.eval_count / evalMs) * 1000 : null,
  };
}

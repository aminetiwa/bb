// ============================================================================
//  BOURSO :: schemas.js — contrats JSON des agents + validation/normalisation.
//  Le même schéma sert (1) de grammaire à Ollama (`format`) et (2) de contrôle côté Node :
//  l'IA propose, le code vérifie. Les bornes numériques sont appliquées par écrêtage.
// ============================================================================

const num = (minimum, maximum) => ({ type: 'number', minimum, maximum });
const str = (maxLength = 400) => ({ type: 'string', maxLength });
const strEnum = (...e) => ({ type: 'string', enum: e });
const obj = (properties, required = Object.keys(properties)) => ({
  type: 'object', properties, required, additionalProperties: false,
});
const arr = (items, maxItems) => ({ type: 'array', items, maxItems });

export const DECISIONS = ['STRONG_BUY', 'BUY', 'HOLD', 'SELL', 'STRONG_SELL'];
export const EVENT_TYPES = [
  'EARNINGS', 'GUIDANCE', 'M_AND_A', 'RATING', 'MACRO_ECB', 'MACRO_DATA', 'REGULATORY',
  'LITIGATION', 'PRODUCT', 'MANAGEMENT', 'DIVIDEND_BUYBACK', 'SECTOR', 'OTHER',
];

export const SENTIMENT_SCHEMA = obj({
  items: arr(
    obj({
      id: str(64),
      tickers: arr(str(24), 8),
      event_type: strEnum(...EVENT_TYPES),
      sentiment: num(-1, 1),
      surprise: num(0, 1),
      credibility: num(0, 1),
      horizon: strEnum('INTRADAY', 'DAYS', 'WEEKS'),
      confidence: num(0, 1),
      key_facts: arr(str(240), 4),
    }),
    24,
  ),
  ecb_stance: num(-1, 1),
  aggregate: obj({
    ticker: str(24),
    score: num(-1, 1),
    confidence: num(0, 1),
    dominant_theme: strEnum(...EVENT_TYPES),
    summary: str(600),
  }),
  injection_detected: { type: 'boolean' },
});

export const QUANT_SCHEMA = obj({
  regime: strEnum('TREND_UP', 'TREND_DOWN', 'RANGE', 'BREAKOUT_UP', 'BREAKOUT_DOWN', 'REVERSAL_RISK', 'ILLIQUID'),
  bias: num(-1, 1),
  confidence: num(0, 1),
  liquidity: strEnum('DEEP', 'NORMAL', 'THIN', 'DISLOCATED'),
  key_levels: obj({ support: arr({ type: 'number' }, 4), resistance: arr({ type: 'number' }, 4) }),
  anomalies: arr(
    obj({
      kind: strEnum('PRICE_OUTLIER', 'VOLUME_SPIKE', 'BOOK_IMBALANCE', 'SPREAD_WIDENING', 'STALE_DATA', 'ABSORPTION', 'SPOOFING_SUSPECT', 'OTHER'),
      severity: num(0, 1),
      note: str(240),
    }),
    6,
  ),
  summary: str(600),
});

export const GENERAL_SCHEMA = obj({
  decision: strEnum(...DECISIONS),
  confidence: num(0, 1),
  horizon: strEnum('INTRADAY', 'SWING_DAYS', 'POSITION_WEEKS'),
  agreement: strEnum('ALIGNED', 'PARTIAL', 'CONFLICT'),
  entry: obj({ low: { type: 'number' }, high: { type: 'number' } }),
  invalidation: { type: 'number' },
  targets: arr({ type: 'number' }, 3),
  size_fraction: num(0, 1),
  rationale: arr(str(240), 6),
  dissent: str(600),
  memory_refs: arr(str(32), 8),
});

/** Mode « single » : UN appel produit sentiment + marché + décision (le plus économe en calcul). */
export const ANALYST_SCHEMA = obj({
  sentiment: obj({
    score: num(-1, 1),
    confidence: num(0, 1),
    theme: strEnum(...EVENT_TYPES),
    ecb_stance: num(-1, 1),
    key_facts: arr(str(240), 4),
    summary: str(400),
    injection_detected: { type: 'boolean' },
  }),
  quant: obj({
    regime: QUANT_SCHEMA.properties.regime,
    bias: num(-1, 1),
    confidence: num(0, 1),
    liquidity: QUANT_SCHEMA.properties.liquidity,
    key_levels: QUANT_SCHEMA.properties.key_levels,
    anomalies: { ...QUANT_SCHEMA.properties.anomalies, maxItems: 4 },
    summary: str(400),
  }),
  decision: obj({
    decision: strEnum(...DECISIONS),
    confidence: num(0, 1),
    horizon: strEnum('INTRADAY', 'SWING_DAYS', 'POSITION_WEEKS'),
    entry: obj({ low: { type: 'number' }, high: { type: 'number' } }),
    invalidation: { type: 'number' },
    targets: arr({ type: 'number' }, 3),
    size_fraction: num(0, 1),
    rationale: arr(str(240), 5),
    dissent: str(400),
    memory_refs: arr(str(32), 8),
  }),
});

export const QUESTIONS_SCHEMA = obj({
  questions: arr(obj({ to: strEnum('SENTIMENTAL', 'QUANT'), question: str(400) }), 2),
});

export const ANSWER_SCHEMA = obj({
  answer: str(800),
  maintains_view: { type: 'boolean' },
  revised_confidence: num(0, 1),
});

/**
 * Vérifie et normalise une valeur selon un schéma (sous-ensemble JSON Schema).
 * Écrête les nombres hors bornes, tronque chaînes et tableaux trop longs, ignore les clés inconnues.
 * Erreurs bloquantes : champ requis manquant, mauvais type, valeur hors enum.
 * @returns {{ ok: boolean, value: any, errors: string[] }}
 */
export function conform(schema, value) {
  const errors = [];
  const v = walk(schema, value, '$', errors);
  return { ok: errors.length === 0, value: v, errors };
}

function walk(s, v, path, errors) {
  switch (s.type) {
    case 'object': {
      if (v === null || typeof v !== 'object' || Array.isArray(v)) {
        errors.push(`${path}: objet attendu`);
        return v;
      }
      const out = {};
      for (const [k, sub] of Object.entries(s.properties ?? {})) {
        if (v[k] === undefined || v[k] === null) {
          if (s.required?.includes(k)) errors.push(`${path}.${k}: requis`);
          continue;
        }
        out[k] = walk(sub, v[k], `${path}.${k}`, errors);
      }
      return out;
    }
    case 'array': {
      if (!Array.isArray(v)) {
        errors.push(`${path}: tableau attendu`);
        return v;
      }
      const a = v.slice(0, s.maxItems ?? v.length);
      return a.map((x, i) => walk(s.items, x, `${path}[${i}]`, errors));
    }
    case 'number':
    case 'integer': {
      const x = typeof v === 'string' && v.trim() !== '' ? Number(v) : v;
      if (typeof x !== 'number' || !Number.isFinite(x)) {
        errors.push(`${path}: nombre attendu`);
        return v;
      }
      let y = s.type === 'integer' ? Math.round(x) : x;
      if (s.minimum !== undefined && y < s.minimum) y = s.minimum;
      if (s.maximum !== undefined && y > s.maximum) y = s.maximum;
      return y;
    }
    case 'string': {
      if (typeof v !== 'string') {
        errors.push(`${path}: chaîne attendue`);
        return v;
      }
      if (s.enum) {
        const up = v.trim().toUpperCase().replace(/[\s-]+/g, '_');
        if (!s.enum.includes(up)) errors.push(`${path}: « ${v} » ∉ {${s.enum.join(', ')}}`);
        return up;
      }
      return s.maxLength && v.length > s.maxLength ? `${v.slice(0, s.maxLength - 1)}…` : v;
    }
    case 'boolean': {
      if (typeof v === 'boolean') return v;
      if (v === 'true' || v === 'false') return v === 'true';
      errors.push(`${path}: booléen attendu`);
      return v;
    }
    default:
      return v;
  }
}

/** Extrait un objet JSON d'une réponse de LLM (tolère ```json … ``` et du texte parasite). */
export function parseJsonLoose(text) {
  if (typeof text !== 'string') return { ok: false, error: 'réponse vide' };
  const t = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '');
  try {
    return { ok: true, value: JSON.parse(t) };
  } catch {
    const a = t.indexOf('{'), b = t.lastIndexOf('}');
    if (a >= 0 && b > a) {
      const body = t.slice(a, b + 1);
      try {
        return { ok: true, value: JSON.parse(body) };
      } catch (e) {
        // erreur fréquente des modèles : virgule finale avant } ou ] (hors chaînes)
        try {
          return { ok: true, value: JSON.parse(body.replace(/("(?:[^"\\]|\\.)*")|,\s*([}\]])/g, (m, str, close) => str ?? close)) };
        } catch {
          return { ok: false, error: `JSON invalide (${e.message})` };
        }
      }
    }
    return { ok: false, error: 'aucun objet JSON dans la réponse' };
  }
}

// ---------------------------------------------------------------- v0.3 : analyse sur dossier complet
/** Réponse de l'analyste v3 (un seul appel, dossier quantitatif complet en entrée). */
export const ANALYSE_SCHEMA = obj({
  decision: strEnum(...DECISIONS),
  confidence: num(0, 1),
  horizon: strEnum('INTRADAY', 'SWING', 'POSITION'),
  summary: str(500),
  news: obj({ score: num(-1, 1), confidence: num(0, 1), summary: str(300) }),
  market: obj({ bias: num(-1, 1), confidence: num(0, 1), regime: strEnum('TREND_UP', 'TREND_DOWN', 'RANGE', 'VOLATILE', 'BREAKOUT_UP', 'BREAKOUT_DOWN'), summary: str(300) }),
  entry: obj({ low: { type: 'number' }, high: { type: 'number' } }),
  stop: { type: 'number' },
  targets: arr({ type: 'number' }, 3),
  size_fraction: num(0, 1),
  scenarios: arr(obj({ name: strEnum('HAUSSIER', 'CENTRAL', 'BAISSIER'), probability: num(0, 1), target: { type: 'number' }, description: str(240) }), 3),
  key_factors: arr(obj({ factor: str(200), impact: strEnum('POSITIF', 'NEGATIF', 'NEUTRE'), weight: num(1, 3) }), 8),
  risks: arr(str(200), 5),
  invalidation: str(300),
});

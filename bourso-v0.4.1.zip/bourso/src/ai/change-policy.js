// ============================================================================
//  BOURSO :: change-policy.js — « faut-il vraiment réanalyser ce favori ? »
//  Ne pas gaspiller le calcul : l'IA n'est appelée que si quelque chose a changé depuis la
//  dernière analyse du titre. Module pur (sans Node) : partagé par le serveur et l'interface.
// ============================================================================

export const DEFAULT_POLICY = Object.freeze({
  movePct: 0.5,               // variation du cours déclenchant une réanalyse (%)
  nisAlert: 9,                // anomalie de prix du filtre de Kalman (3 écarts-types)
  maxAgeMs: 30 * 60_000,      // réanalyse de fond au plus tard toutes les 30 min
  minGapMs: 2 * 60_000,       // jamais deux analyses d'un même titre à moins de 2 min
  onlyDuringSession: true,    // hors séance continue : aucune analyse
});

const SESSION_LABEL = {
  PRE_OPEN: 'pré-ouverture', OPENING_AUCTION: "fixing d'ouverture", CLOSING_AUCTION: 'fixing de clôture', CLOSED: 'marché fermé',
};

/**
 * @param {{ ts:number, price:number, newsIds?:string[], position?:string }|null} last  état lors de la dernière analyse
 * @param {{ ts:number, price:number, newsIds?:string[], position?:string, nisMax?:number, session?:string }} now
 * @param {object} [policy]
 * @returns {{ run:boolean, reason:string }}
 */
export function shouldAnalyze(last, now, policy = {}) {
  const p = { ...DEFAULT_POLICY, ...policy };
  if (p.onlyDuringSession && now.session && now.session !== 'CONTINUOUS') {
    return { run: false, reason: SESSION_LABEL[now.session] ?? now.session };
  }
  if (!last) return { run: true, reason: 'première analyse' };
  const age = now.ts - last.ts;
  if (age < p.minGapMs) return { run: false, reason: `analysé il y a ${Math.max(1, Math.round(age / 1000))} s` };
  const seen = new Set(last.newsIds ?? []);
  const fresh = (now.newsIds ?? []).filter((id) => !seen.has(id)).length;
  if (fresh) return { run: true, reason: `${fresh} nouvelle${fresh > 1 ? 's' : ''} actualité${fresh > 1 ? 's' : ''}` };
  const move = last.price > 0 ? Math.abs(now.price / last.price - 1) * 100 : 0;
  if (move >= p.movePct) return { run: true, reason: `cours ${move.toFixed(2).replace('.', ',')} % depuis la dernière analyse` };
  if (Number(now.nisMax) >= p.nisAlert) return { run: true, reason: 'mouvement de prix anormal' };
  if (now.position && last.position && now.position !== last.position) return { run: true, reason: 'sortie de la zone de valeur' };
  if (age >= p.maxAgeMs) return { run: true, reason: 'rafraîchissement périodique' };
  return { run: false, reason: 'rien de nouveau' };
}

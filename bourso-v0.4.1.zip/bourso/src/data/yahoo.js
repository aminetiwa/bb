// ============================================================================
//  BOURSO :: data/yahoo.js — Yahoo Finance (API publique non officielle, sans clé).
//
//  Seuls les points d'accès ouverts sont utilisés (aucun cookie, aucun « crumb », aucune page de
//  consentement) :
//   · v8/finance/chart/{sym}    historique (1 j sur 5 ans), intraday (1, 5, 15, 30, 60 min),
//                               cotation (méta : dernier cours, veille, plus haut/bas, volume),
//                               dividendes et divisions d'actions ;
//   · v8/finance/spark          cotations groupées (20 symboles par requête) ;
//   · v1/finance/search         recherche de valeurs dans le monde entier + titres d'actualités.
//  Données différées selon la place (≈ 15 min en Europe), usage personnel. Yahoo peut limiter le
//  débit ou changer ces points d'accès : le client réseau met alors la source en pause et Bourso
//  se rabat sur les autres sources ou sur le cache disque.
//
//  En-tête User-Agent : « Mozilla/5.0 » tout court, sans se faire passer pour un navigateur précis.
//  Depuis octobre 2026, Yahoo répond 429 aux requêtes qui annoncent un navigateur de bureau complet
//  (Chrome…) sans en avoir les cookies, alors que l'en-tête minimal passe. Bourso n'imite aucun
//  navigateur (ni en-têtes, ni empreinte TLS) et n'utilise ni cookie ni « crumb ».
// ============================================================================

export const YAHOO_HOST = 'https://query1.finance.yahoo.com';
export const YAHOO_UA = 'Mozilla/5.0';
const H = { 'user-agent': YAHOO_UA, accept: 'application/json,text/plain,*/*' };

const enc = (s) => encodeURIComponent(s);
const isNum = (x) => typeof x === 'number' && Number.isFinite(x);

/** Date locale (AAAA-MM-JJ) et minute du jour d'un instant, dans un fuseau donné. */
const fmt = new Map();
export function localParts(ms, tz) {
  if (!fmt.has(tz)) fmt.set(tz, new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }));
  const p = Object.fromEntries(fmt.get(tz).formatToParts(new Date(ms)).map((x) => [x.type, x.value]));
  return { ymd: `${p.year}-${p.month}-${p.day}`, min: Number(p.hour) * 60 + Number(p.minute) };
}

/** Lecture d'une réponse v8/chart : méta, barres sans trous (les barres vides sont retirées), événements. */
export function parseChart(json) {
  const err = json?.chart?.error;
  if (err) throw new Error(`Yahoo : ${err.description ?? err.code ?? 'erreur'}`);
  const r = json?.chart?.result?.[0];
  if (!r) throw new Error('Yahoo : réponse sans résultat');
  const m = r.meta ?? {};
  const q = r.indicators?.quote?.[0] ?? {}, adj = r.indicators?.adjclose?.[0]?.adjclose ?? null;
  const ts = r.timestamp ?? [];
  const bars = { t: [], open: [], high: [], low: [], close: [], volume: [], adjclose: [] };
  for (let i = 0; i < ts.length; i++) {
    const o = q.open?.[i], h = q.high?.[i], l = q.low?.[i], c = q.close?.[i];
    if (!isNum(c) || c <= 0) continue;
    const oo = isNum(o) && o > 0 ? o : c, hh = isNum(h) && h > 0 ? h : Math.max(oo, c), ll = isNum(l) && l > 0 ? l : Math.min(oo, c);
    bars.t.push(ts[i]);
    bars.open.push(oo);
    bars.high.push(Math.max(hh, oo, c));
    bars.low.push(Math.min(ll, oo, c));
    bars.close.push(c);
    bars.volume.push(isNum(q.volume?.[i]) ? q.volume[i] : 0);
    bars.adjclose.push(adj && isNum(adj[i]) ? adj[i] : c);
  }
  const ev = r.events ?? {};
  const dividends = Object.values(ev.dividends ?? {}).map((d) => ({ t: d.date, amount: d.amount })).filter((d) => isNum(d.amount)).sort((a, b) => a.t - b.t);
  const splits = Object.values(ev.splits ?? {}).map((s) => ({ t: s.date, ratio: s.numerator && s.denominator ? s.numerator / s.denominator : null, text: s.splitRatio })).sort((a, b) => a.t - b.t);
  const meta = {
    symbol: m.symbol, currency: m.currency ?? null, exchange: m.exchangeName ?? null, fullExchange: m.fullExchangeName ?? null, type: m.instrumentType ?? null,
    tz: m.exchangeTimezoneName ?? null, gmtoffset: m.gmtoffset ?? null, name: m.longName ?? m.shortName ?? null, shortName: m.shortName ?? null,
    price: isNum(m.regularMarketPrice) ? m.regularMarketPrice : null, time: isNum(m.regularMarketTime) ? m.regularMarketTime * 1000 : null,
    prevClose: isNum(m.chartPreviousClose) ? m.chartPreviousClose : isNum(m.previousClose) ? m.previousClose : null, previousClose: isNum(m.previousClose) ? m.previousClose : null,
    dayHigh: isNum(m.regularMarketDayHigh) ? m.regularMarketDayHigh : null, dayLow: isNum(m.regularMarketDayLow) ? m.regularMarketDayLow : null,
    dayVolume: isNum(m.regularMarketVolume) ? m.regularMarketVolume : null, high52: isNum(m.fiftyTwoWeekHigh) ? m.fiftyTwoWeekHigh : null, low52: isNum(m.fiftyTwoWeekLow) ? m.fiftyTwoWeekLow : null,
    granularity: m.dataGranularity ?? null, range: m.range ?? null, firstTrade: isNum(m.firstTradeDate) ? m.firstTradeDate * 1000 : null,
    regular: m.currentTradingPeriod?.regular ? { start: m.currentTradingPeriod.regular.start * 1000, end: m.currentTradingPeriod.regular.end * 1000 } : null,
  };
  return { meta, bars, dividends, splits };
}

/**
 * Lecture d'une réponse spark (deux formats connus) :
 *  - { spark: { result: [ { symbol, response: [ { meta, timestamp, indicators: { quote: [ { close } ] } } ] } ] } }
 *  - { "AAPL": { symbol, timestamp, close, chartPreviousClose, previousClose } }
 * @returns {Map<string, { price, prevClose, time, closes: number[], timestamps: number[], currency }>}
 */
export function parseSpark(json) {
  const out = new Map();
  const add = (sym, meta, ts, closes) => {
    if (!sym) return;
    const cl = (closes ?? []).filter(isNum);
    const price = isNum(meta?.regularMarketPrice) ? meta.regularMarketPrice : cl.at(-1) ?? null;
    if (!isNum(price)) return;
    const okTs = (ts ?? []).filter((_, i) => isNum(closes?.[i]));
    out.set(sym, {
      price, prevClose: isNum(meta?.chartPreviousClose) ? meta.chartPreviousClose : isNum(meta?.previousClose) ? meta.previousClose : null,
      time: isNum(meta?.regularMarketTime) ? meta.regularMarketTime * 1000 : okTs.length ? okTs.at(-1) * 1000 : null,
      closes: cl, timestamps: okTs, currency: meta?.currency ?? null,
      dayHigh: isNum(meta?.regularMarketDayHigh) ? meta.regularMarketDayHigh : cl.length ? Math.max(...cl) : null,
      dayLow: isNum(meta?.regularMarketDayLow) ? meta.regularMarketDayLow : cl.length ? Math.min(...cl) : null,
      dayVolume: isNum(meta?.regularMarketVolume) ? meta.regularMarketVolume : null,
    });
  };
  if (json?.spark?.result) {
    for (const r of json.spark.result) {
      const resp = r.response?.[0];
      add(r.symbol ?? resp?.meta?.symbol, resp?.meta, resp?.timestamp, resp?.indicators?.quote?.[0]?.close);
    }
    return out;
  }
  for (const [k, v] of Object.entries(json ?? {})) {
    if (!v || typeof v !== 'object') continue;
    add(v.symbol ?? k, { regularMarketPrice: v.regularMarketPrice, chartPreviousClose: v.chartPreviousClose, previousClose: v.previousClose, regularMarketTime: v.regularMarketTime, currency: v.currency }, v.timestamp, v.close);
  }
  return out;
}

/** Lecture d'une réponse de recherche : valeurs (actions, ETF, indices) et titres d'actualités. */
export function parseSearch(json) {
  const quotes = (json?.quotes ?? []).filter((q) => q.symbol && (q.isYahooFinance ?? true)).map((q) => ({
    symbol: q.symbol, name: q.longname ?? q.shortname ?? q.symbol, exchange: q.exchange ?? null, exchDisp: q.exchDisp ?? null,
    type: q.quoteType ?? null, typeDisp: q.typeDisp ?? null, sector: q.sectorDisp ?? q.sector ?? null, industry: q.industryDisp ?? q.industry ?? null,
  }));
  const news = (json?.news ?? []).filter((n) => n.title && n.link).map((n) => ({
    id: `y:${n.uuid ?? n.link}`, title: n.title, source: n.publisher ?? 'Yahoo Finance', url: n.link,
    ts: isNum(n.providerPublishTime) ? n.providerPublishTime * 1000 : Date.parse(n.providerPublishTime) || Date.now(), tickers: n.relatedTickers ?? [],
  }));
  return { quotes, news };
}

/** Fournisseur Yahoo : requêtes régulées par le client réseau commun (data/net.js). */
export class Yahoo {
  constructor(net, { host = YAHOO_HOST } = {}) {
    this.net = net;
    this.host = host;
    this.sparkPath = '/v8/finance/spark';
    this.sparkBroken = false;
  }

  chartUrl(sym, { range = '5y', interval = '1d', events = true, prepost = false } = {}) {
    return `${this.host}/v8/finance/chart/${enc(sym)}?range=${range}&interval=${interval}${events ? '&events=div%2Csplit' : ''}&includeAdjustedClose=true${prepost ? '&includePrePost=true' : ''}`;
  }

  /** Graphique brut (historique ou intraday). */
  async chart(sym, opts = {}, { priority = 1, ttlMs = 0 } = {}) {
    return parseChart(await this.net.get(this.chartUrl(sym, opts), { headers: H, priority, ttlMs, label: `Yahoo ${sym}` }));
  }

  /**
   * Cotations groupées (20 symboles au plus par requête). Si spark est indisponible, renvoie null :
   * l'appelant passe alors par chart(), symbole par symbole.
   */
  async spark(symbols, { range = '1d', interval = '15m' } = {}, { priority = 1 } = {}) {
    if (this.sparkBroken) return null;
    const url = `${this.host}${this.sparkPath}?symbols=${symbols.map(enc).join(',')}&range=${range}&interval=${interval}`;
    try {
      return parseSpark(await this.net.get(url, { headers: H, priority, label: 'Yahoo spark' }));
    } catch (e) {
      if (e.status === 404 && this.sparkPath.startsWith('/v8')) {
        this.sparkPath = '/v7/finance/spark';
        return this.spark(symbols, { range, interval }, { priority });
      }
      if (e.status === 401 || e.status === 404) {
        this.sparkBroken = true; // point d'accès fermé : on n'insiste pas
        return null;
      }
      throw e;
    }
  }

  /** Recherche mondiale (valeurs et actualités). */
  async search(q, { quotes = 10, news = 8, lang = 'fr-FR', region = 'FR' } = {}, { priority = 2, ttlMs = 10 * 60_000 } = {}) {
    const url = `${this.host}/v1/finance/search?q=${enc(q)}&quotesCount=${quotes}&newsCount=${news}&lang=${lang}&region=${region}&enableFuzzyQuery=false`;
    return parseSearch(await this.net.get(url, { headers: H, priority, ttlMs, label: 'Yahoo recherche' }));
  }
}

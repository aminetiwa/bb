// ============================================================================
//  BOURSO :: data/keyed.js — sources gratuites À CLÉ (facultatives, à renseigner dans Réglages).
//
//   · Finnhub (60 requêtes/min) : fondamentaux (PER, BPA, ROE, marge, croissance, capitalisation),
//     consensus des analystes, prochaine publication, actualités par société ;
//   · Financial Modeling Prep (≈ 250 requêtes/jour) : profil et ratios (capitalisation, PER, rendement) ;
//   · Twelve Data (8/min, 800/jour) : historique quotidien de secours (si Yahoo ne répond pas) —
//     l'offre gratuite ne couvre que les actions américaines ;
//   · Stooq (clé obtenue sur leur site, captcha résolu par TOI dans ton navigateur) : historique de secours.
//  La couverture de l'offre gratuite varie selon les places : une source qui ne couvre pas une
//  valeur est simplement ignorée pour elle. Les clés restent sur ta machine (data/state.json).
// ============================================================================
import { BOURSO_UA } from './net.js';

const ymd = (t) => new Date(t).toISOString().slice(0, 10);
const num = (x) => (typeof x === 'number' && Number.isFinite(x) ? x : typeof x === 'string' && x.trim() !== '' && Number.isFinite(Number(x)) ? Number(x) : null);
const H = { 'user-agent': BOURSO_UA, accept: 'application/json' };

/** CSV Stooq / Twelve Data → barres quotidiennes triées. */
export function parseDailyCsv(text) {
  const lines = String(text).trim().split(/\r?\n/);
  if (lines.length < 2 || !/^date/i.test(lines[0])) throw new Error(/apikey/i.test(text) ? 'clé API requise ou invalide' : `réponse inattendue (« ${lines[0].slice(0, 60)} »)`);
  const cols = lines[0].toLowerCase().split(/[,;]/);
  const ix = (k) => cols.findIndex((c) => c.trim() === k);
  const [d, o, h, l, c, v] = ['date', 'open', 'high', 'low', 'close', 'volume'].map(ix);
  const out = { dates: [], open: [], high: [], low: [], close: [], volume: [] };
  for (const line of lines.slice(1)) {
    const p = line.split(/[,;]/), cl = num(p[c]);
    if (!p[d] || !(cl > 0)) continue;
    out.dates.push(p[d].trim().slice(0, 10));
    out.open.push(num(p[o]) ?? cl);
    out.high.push(num(p[h]) ?? cl);
    out.low.push(num(p[l]) ?? cl);
    out.close.push(cl);
    out.volume.push(v >= 0 ? num(p[v]) ?? 0 : 0);
  }
  return out;
}

export class KeyedSources {
  constructor({ net, keys = {}, log = () => {} }) {
    this.net = net;
    this.keys = { ...keys };
    this.log = log;
    // budgets de l'offre gratuite
    net.setLimit('finnhub.io', { concurrency: 1, minIntervalMs: 1100 });
    net.setLimit('financialmodelingprep.com', { concurrency: 1, minIntervalMs: 1500, dailyBudget: 240 });
    net.setLimit('api.twelvedata.com', { concurrency: 1, minIntervalMs: 8000, dailyBudget: 780 });
    net.setLimit('stooq.com', { concurrency: 1, minIntervalMs: 2500, dailyBudget: 400 });
    this.noCover = new Map(); // source → ensemble des symboles non couverts (on n'insiste pas)
  }

  setKeys(k) {
    this.keys = { ...this.keys, ...k };
  }

  has(name) {
    return Boolean(this.keys[name]);
  }

  #skip(src, sym) {
    return this.noCover.get(src)?.has(sym);
  }

  #nocover(src, sym) {
    if (!this.noCover.has(src)) this.noCover.set(src, new Set());
    this.noCover.get(src).add(sym);
  }

  // ---------------------------------------------------------------- Finnhub
  async #fh(path) {
    return this.net.get(`https://finnhub.io/api/v1${path}${path.includes('?') ? '&' : '?'}token=${encodeURIComponent(this.keys.finnhub)}`, { headers: H, label: 'Finnhub', ttlMs: 30 * 60_000 });
  }

  /** Fondamentaux Finnhub (null si la valeur n'est pas couverte par l'offre gratuite). */
  async finnhubFundamentals(sym) {
    if (!this.has('finnhub') || this.#skip('finnhub', sym)) return null;
    const enc = encodeURIComponent(sym);
    try {
      const [m, p] = await Promise.all([this.#fh(`/stock/metric?symbol=${enc}&metric=all`), this.#fh(`/stock/profile2?symbol=${enc}`)]);
      const mt = m?.metric ?? {};
      if (!Object.keys(mt).length && !p?.name) { this.#nocover('finnhub', sym); return null; }
      const out = {
        source: 'Finnhub', per: num(mt.peTTM) ?? num(mt.peBasicExclExtraTTM), bpa: num(mt.epsTTM) ?? num(mt.epsBasicExclExtraItemsTTM),
        roePct: num(mt.roeTTM), margeNettePct: num(mt.netProfitMarginTTM), croissanceCaPct: num(mt.revenueGrowthTTMYoy), prixSurValeurComptable: num(mt.pbQuarterly) ?? num(mt.pbAnnual),
        rendementDividendePct: num(mt.dividendYieldIndicatedAnnual), beta: num(mt.beta), capitalisationM: num(p?.marketCapitalization) ?? num(mt.marketCapitalization),
        nombreActionsM: num(p?.shareOutstanding), devise: p?.currency ?? null, secteurSource: p?.finnhubIndustry ?? null, detteNetteSurFondsPropres: num(mt['totalDebt/totalEquityQuarterly']),
      };
      try {
        const rec = await this.#fh(`/stock/recommendation?symbol=${enc}`);
        const r = Array.isArray(rec) ? rec[0] : null;
        if (r) out.consensus = { achat: (r.strongBuy ?? 0) + (r.buy ?? 0), neutre: r.hold ?? 0, vente: (r.sell ?? 0) + (r.strongSell ?? 0), periode: r.period };
      } catch { /* consensus indisponible */ }
      try {
        const cal = await this.#fh(`/calendar/earnings?symbol=${enc}&from=${ymd(Date.now())}&to=${ymd(Date.now() + 120 * 86_400_000)}`);
        const next = (cal?.earningsCalendar ?? []).map((e) => e.date).filter(Boolean).sort()[0];
        if (next) out.prochainePublication = next;
      } catch { /* calendrier indisponible */ }
      return out;
    } catch (e) {
      if (e.status === 403 || e.status === 401) this.#nocover('finnhub', sym);
      throw e;
    }
  }

  /** Actualités Finnhub de la société (7 derniers jours). */
  async finnhubNews(sym) {
    if (!this.has('finnhub') || this.#skip('finnhub-news', sym)) return [];
    const to = ymd(Date.now()), from = ymd(Date.now() - 7 * 86_400_000);
    try {
      const list = await this.#fh(`/company-news?symbol=${encodeURIComponent(sym)}&from=${from}&to=${to}`);
      if (!Array.isArray(list)) return [];
      return list.slice(0, 30).filter((n) => n.headline).map((n) => ({ title: n.headline, url: n.url, ts: n.datetime ? n.datetime * 1000 : null, source: n.source ?? 'Finnhub', summary: n.summary ?? null }));
    } catch (e) {
      if (e.status === 403) this.#nocover('finnhub-news', sym);
      return [];
    }
  }

  // ---------------------------------------------------------------- FMP
  async fmpFundamentals(sym) {
    if (!this.has('fmp') || this.#skip('fmp', sym)) return null;
    const k = encodeURIComponent(this.keys.fmp), s = encodeURIComponent(sym);
    try {
      const [prof, ratios] = await Promise.all([
        this.net.get(`https://financialmodelingprep.com/stable/profile?symbol=${s}&apikey=${k}`, { headers: H, label: 'FMP', ttlMs: 6 * 3600_000 }),
        this.net.get(`https://financialmodelingprep.com/stable/ratios-ttm?symbol=${s}&apikey=${k}`, { headers: H, label: 'FMP', ttlMs: 6 * 3600_000 }).catch(() => null),
      ]);
      const p = Array.isArray(prof) ? prof[0] : null, r = Array.isArray(ratios) ? ratios[0] : null;
      if (!p) { this.#nocover('fmp', sym); return null; }
      return {
        source: 'Financial Modeling Prep', capitalisationM: num(p.marketCap) ? p.marketCap / 1e6 : null, beta: num(p.beta), devise: p.currency ?? null,
        per: num(r?.priceToEarningsRatioTTM) ?? num(r?.peRatioTTM), rendementDividendePct: num(r?.dividendYieldTTM) !== null ? num(r.dividendYieldTTM) * 100 : null,
        margeNettePct: num(r?.netProfitMarginTTM) !== null ? num(r.netProfitMarginTTM) * 100 : null, prixSurValeurComptable: num(r?.priceToBookRatioTTM),
        secteurSource: p.sector ?? null, industrie: p.industry ?? null, description: typeof p.description === 'string' ? p.description.slice(0, 600) : null,
      };
    } catch (e) {
      if (e.status === 402 || e.status === 403) this.#nocover('fmp', sym);
      throw e;
    }
  }

  // ---------------------------------------------------------------- historiques de secours
  async twelveDaily(meta) {
    if (!this.has('twelvedata') || this.#skip('twelvedata', meta.sym)) return null;
    const code = String(meta.code).trim().replace(/\s+/g, ' ');
    const url = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(code)}&mic_code=${meta.mic}&interval=1day&outputsize=1300&format=CSV&delimiter=,&apikey=${encodeURIComponent(this.keys.twelvedata)}`;
    try {
      const csv = await this.net.get(url, { type: 'text', headers: H, label: 'Twelve Data', priority: 0 });
      if (/"status"\s*:\s*"error"/.test(csv)) { this.#nocover('twelvedata', meta.sym); return null; }
      const d = parseDailyCsv(csv.replace(/^datetime/i, 'date'));
      // Twelve Data renvoie le plus récent d'abord
      if (d.dates.length > 1 && d.dates[0] > d.dates.at(-1)) for (const k of Object.keys(d)) d[k].reverse();
      return { ...d, source: 'Twelve Data' };
    } catch (e) {
      if (e.status === 400 || e.status === 403 || e.status === 404) this.#nocover('twelvedata', meta.sym);
      throw e;
    }
  }

  async stooqDaily(stooqSym) {
    if (!this.has('stooq') || !stooqSym || this.#skip('stooq', stooqSym)) return null;
    const csv = await this.net.get(`https://stooq.com/q/d/l/?s=${encodeURIComponent(stooqSym)}&i=d&apikey=${encodeURIComponent(this.keys.stooq)}`, { type: 'text', headers: { 'user-agent': BOURSO_UA }, label: 'Stooq', priority: 0 });
    try {
      return { ...parseDailyCsv(csv), source: 'Stooq' };
    } catch (e) {
      if (/aucune|no data/i.test(csv)) this.#nocover('stooq', stooqSym);
      throw e;
    }
  }

  info() {
    return Object.fromEntries(['finnhub', 'fmp', 'twelvedata', 'stooq'].map((k) => [k, { configured: this.has(k), notCovered: this.noCover.get(k)?.size ?? 0 }]));
  }
}

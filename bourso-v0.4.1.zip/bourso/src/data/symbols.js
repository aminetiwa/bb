// ============================================================================
//  BOURSO :: data/symbols.js — correspondance entre les symboles de Bourso (CODE:MIC) et ceux des
//  sources de données (Yahoo Finance, Stooq, Finnhub, Twelve Data), indices de référence par place,
//  et places reconnues dans les résultats de recherche de Yahoo.
// ============================================================================
import { EXCHANGES } from '../market/exchanges.js';

/** Suffixe Yahoo par place. */
export const YAHOO_SUFFIX = {
  XPAR: '.PA', XETR: '.DE', XAMS: '.AS', XBRU: '.BR', XMIL: '.MI', XMAD: '.MC', XLIS: '.LS', XDUB: '.IR', XSWX: '.SW', XLON: '.L',
  XSTO: '.ST', XCSE: '.CO', XHEL: '.HE', XOSL: '.OL', XWBO: '.VI', XWAR: '.WA', XATH: '.AT', XNYS: '', XNAS: '', XTSE: '.TO',
  XTKS: '.T', XHKG: '.HK', XSHG: '.SS', XKRX: '.KS', XTAI: '.TW', XNSE: '.NS', XASX: '.AX', XSES: '.SI', BVMF: '.SA', XMEX: '.MX', XJSE: '.JO',
};

/** Symbole Yahoo d'une valeur de l'univers (« BP. » → BP.L, « NOVO B » → NOVO-B.CO, « 700 » → 0700.HK…). */
export function yahooSymbol(meta) {
  if (meta.yahoo) return meta.yahoo;
  const mic = meta.mic;
  let c = String(meta.code).trim().replace(/\.$/, '');
  if (mic === 'XHKG') c = c.padStart(4, '0');
  if (mic === 'XSHG') return `${c}${/^[03]/.test(c) ? '.SZ' : '.SS'}`; // Shenzhen (0…, 3…) ou Shanghai (6…)
  c = c.replace(/\s+/g, '-').replace(/\./g, '-');
  return `${c}${YAHOO_SUFFIX[mic] ?? ''}`;
}

/** Symbole Stooq (historique quotidien, clé requise depuis 2026) : places couvertes seulement. */
export function stooqSymbol(meta) {
  const map = { XNYS: '.us', XNAS: '.us', XETR: '.de', XLON: '.uk', XTKS: '.jp', XHKG: '.hk' };
  const suf = map[meta.mic];
  if (!suf) return null;
  let c = String(meta.code).trim().replace(/\.$/, '').toLowerCase();
  if (meta.mic === 'XNYS' || meta.mic === 'XNAS') c = c.replace(/\./g, '-');
  return `${c.replace(/\s+/g, '-')}${suf}`;
}

/** Symbole Finnhub / Twelve Data : mêmes suffixes que Yahoo pour la plupart des places. */
export const finnhubSymbol = (meta) => yahooSymbol(meta);

/** Places Yahoo (champ `exchange` des résultats de recherche) → MIC de Bourso. */
export const YAHOO_EXCHANGE = {
  PAR: 'XPAR', ENX: 'XPAR', GER: 'XETR', FRA: 'XETR', ETR: 'XETR', DUS: 'XETR', BER: 'XETR', MUN: 'XETR', STU: 'XETR', HAM: 'XETR',
  AMS: 'XAMS', BRU: 'XBRU', MIL: 'XMIL', MCE: 'XMAD', LIS: 'XLIS', ISE: 'XDUB', EBS: 'XSWX', VTX: 'XSWX', LSE: 'XLON', IOB: 'XLON',
  STO: 'XSTO', CPH: 'XCSE', HEL: 'XHEL', OSL: 'XOSL', VIE: 'XWBO', WSE: 'XWAR', ATH: 'XATH',
  NMS: 'XNAS', NGM: 'XNAS', NCM: 'XNAS', NAS: 'XNAS', NYQ: 'XNYS', NYS: 'XNYS', ASE: 'XNYS', PCX: 'XNYS', BTS: 'XNYS', NYE: 'XNYS',
  TOR: 'XTSE', VAN: 'XTSE', JPX: 'XTKS', TYO: 'XTKS', OSA: 'XTKS', HKG: 'XHKG', SHH: 'XSHG', SHZ: 'XSHG', KSC: 'XKRX', KOE: 'XKRX',
  TAI: 'XTAI', TWO: 'XTAI', NSI: 'XNSE', BSE: 'XNSE', ASX: 'XASX', SES: 'XSES', SAO: 'BVMF', MEX: 'XMEX', JNB: 'XJSE',
};

/** Suffixe Yahoo → MIC (pour un symbole saisi à la main, ex. « RHM.DE »). */
export function micOfYahoo(sym, exchange) {
  if (exchange && YAHOO_EXCHANGE[exchange]) return YAHOO_EXCHANGE[exchange];
  const m = /\.([A-Z]{1,3})$/.exec(String(sym).toUpperCase());
  if (!m) return 'XNYS';
  const suf = `.${m[1]}`;
  if (suf === '.SZ') return 'XSHG';
  if (suf === '.KQ') return 'XKRX';
  if (suf === '.F' || suf === '.DU' || suf === '.MU' || suf === '.SG' || suf === '.HM' || suf === '.BE') return 'XETR';
  if (suf === '.TWO') return 'XTAI';
  if (suf === '.V' || suf === '.CN' || suf === '.NE') return 'XTSE';
  if (suf === '.BO') return 'XNSE';
  return Object.entries(YAHOO_SUFFIX).find(([, s]) => s === suf)?.[0] ?? null;
}

/** Code Bourso d'un symbole Yahoo (on retire le suffixe de place ; « BRK-B » reste « BRK-B »). */
export function codeOfYahoo(sym, mic) {
  let c = String(sym).toUpperCase();
  const suf = YAHOO_SUFFIX[mic];
  if (suf && c.endsWith(suf)) c = c.slice(0, -suf.length);
  else c = c.replace(/\.[A-Z]{1,3}$/, '');
  if (mic === 'XHKG') c = String(Number(c));
  return c;
}

/**
 * Indice de référence de chaque place (symbole Yahoo, avec des solutions de repli) et paniers
 * Europe / Monde. `proxy` : ce n'est pas l'indice lui-même mais un fonds qui le réplique.
 */
export const INDEX_SYMBOLS = {
  XPAR: { name: 'CAC 40', y: ['^FCHI'] }, XETR: { name: 'DAX', y: ['^GDAXI'] }, XAMS: { name: 'AEX', y: ['^AEX'] }, XBRU: { name: 'BEL 20', y: ['^BFX'] },
  XMIL: { name: 'FTSE MIB', y: ['FTSEMIB.MI'] }, XMAD: { name: 'IBEX 35', y: ['^IBEX'] }, XLIS: { name: 'PSI', y: ['PSI20.LS', '^PSI20'] },
  XDUB: { name: 'ISEQ', y: ['^ISEQ'] }, XSWX: { name: 'SMI', y: ['^SSMI'] }, XLON: { name: 'FTSE 100', y: ['^FTSE'] }, XSTO: { name: 'OMX Stockholm 30', y: ['^OMX'] },
  XCSE: { name: 'OMX Copenhague 25', y: ['^OMXC25'] }, XHEL: { name: 'OMX Helsinki 25', y: ['^OMXH25'] }, XOSL: { name: 'OBX', y: ['OBX.OL', '^OSEAX'] },
  XWBO: { name: 'ATX', y: ['^ATX'] }, XWAR: { name: 'WIG20', y: ['WIG20.WA'] }, XATH: { name: 'Athex Composite', y: ['GD.AT'] },
  XNYS: { name: 'S&P 500', y: ['^GSPC'] }, XNAS: { name: 'Nasdaq 100', y: ['^NDX'] }, XTSE: { name: 'S&P/TSX Composite', y: ['^GSPTSE'] },
  XTKS: { name: 'Nikkei 225', y: ['^N225'] }, XHKG: { name: 'Hang Seng', y: ['^HSI'] }, XSHG: { name: 'CSI 300', y: ['000300.SS'] }, XKRX: { name: 'KOSPI', y: ['^KS11'] },
  XTAI: { name: 'TAIEX', y: ['^TWII'] }, XNSE: { name: 'Nifty 50', y: ['^NSEI'] }, XASX: { name: 'S&P/ASX 200', y: ['^AXJO'] }, XSES: { name: 'STI', y: ['^STI'] },
  BVMF: { name: 'Ibovespa', y: ['^BVSP'] }, XMEX: { name: 'S&P/BMV IPC', y: ['^MXX'] }, XJSE: { name: 'JSE Top 40', y: ['^J200.JO', 'STX40.JO'] },
  EUROPE: { name: 'STOXX Europe 600', y: ['^STOXX', '^STOXX50E'], ref: 'XPAR' },
  MONDE: { name: 'MSCI World (fonds URTH)', y: ['URTH', 'ACWI'], ref: 'XNYS', proxy: true },
};

/** Paires de change suivies (unités pour 1 euro) : symbole Yahoo EURXXX=X. */
export const FX_CODES = ['USD', 'GBP', 'CHF', 'SEK', 'DKK', 'NOK', 'PLN', 'CAD', 'JPY', 'HKD', 'CNY', 'KRW', 'TWD', 'INR', 'AUD', 'SGD', 'BRL', 'MXN', 'ZAR'];
export const yahooFx = (ccy) => `EUR${ccy}=X`;

/** Devise de cotation Yahoo → devise Bourso (GBp = pence → GBX, ZAc = cents → ZAC). */
export function ccyOfYahoo(c) {
  if (!c) return null;
  if (c === 'GBp' || c === 'GBX') return 'GBX';
  if (c === 'ZAc' || c === 'ZAC') return 'ZAC';
  if (c === 'ILA') return 'ILS';
  return c.toUpperCase();
}

export const exchangeOf = (mic) => EXCHANGES[mic];

// ============================================================================
//  BOURSO :: data/news-real.js — actualités RÉELLES (titres, source, date, lien).
//
//  Sources gratuites, sans clé :
//   · Google Actualités (flux RSS de recherche) : par valeur (nom de la société), en français pour
//     l'Europe, en anglais ailleurs ; et la rubrique Économie ;
//   · Yahoo Finance (recherche : titres liés à la valeur) ;
//   · GDELT (base mondiale d'articles, toutes langues) : par valeur, au plus 1 requête / 5 s ;
//   · flux RSS de presse configurables (Les Echos, BCE, Investing, MarketWatch…).
//  Chaque titre est rattaché à une valeur (recherche par nom), ou classé « marché », « région »
//  ou « monde » (BCE, Fed, inflation…). Tonalité estimée par le lexique financier (FR + EN).
//  Les titres sont des DONNÉES NON FIABLES : l'IA les reçoit comme telles (anti-injection).
// ============================================================================
import { EventEmitter } from 'node:events';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { dirname } from 'node:path';
import { BOURSO_UA } from './net.js';
import { scoreText } from '../core/quant/sentiment.js';

export const DEFAULT_FEEDS = [
  { name: 'Les Echos — Finance & Marchés', url: 'https://services.lesechos.fr/rss/les-echos-finance-marches.xml', lang: 'fr' },
  { name: 'Les Echos — Entreprises', url: 'https://services.lesechos.fr/rss/les-echos-entreprises.xml', lang: 'fr' },
  { name: 'Les Echos — Économie', url: 'https://services.lesechos.fr/rss/les-echos-economie.xml', lang: 'fr' },
  { name: 'Google Actualités — Économie', url: 'https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=fr&gl=FR&ceid=FR:fr', lang: 'fr' },
  { name: 'Google Actualités — Bourse', url: 'https://news.google.com/rss/search?q=bourse%20OR%20%22CAC%2040%22%20OR%20Euronext%20when%3A1d&hl=fr&gl=FR&ceid=FR:fr', lang: 'fr' },
  { name: 'BCE — communiqués', url: 'https://www.ecb.europa.eu/rss/press.xml', lang: 'en' },
  { name: 'Investing.com France', url: 'https://fr.investing.com/rss/news.rss', lang: 'fr' },
  { name: 'MarketWatch — à la une', url: 'https://feeds.content.dowjones.io/public/rss/mw_topstories', lang: 'en' },
  { name: 'CNBC — marchés', url: 'https://www.cnbc.com/id/100003114/device/rss/rss.html', lang: 'en' },
];

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', laquo: '«', raquo: '»', rsquo: '’', lsquo: '‘', rdquo: '”', ldquo: '“', hellip: '…', eacute: 'é', egrave: 'è', agrave: 'à', ccedil: 'ç', euro: '€', ndash: '–', mdash: '—' };
export const decodeEntities = (s) => String(s ?? '').replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
  if (e[0] === '#') {
    const n = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : Number(e.slice(1));
    return Number.isFinite(n) && n > 0 && n < 0x110000 ? String.fromCodePoint(n) : m;
  }
  return ENT[e.toLowerCase()] ?? m;
});
const stripTags = (s) => String(s ?? '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/<[^>]+>/g, ' ');
// caractères de contrôle et séparateurs invisibles (écrits en échappements : U+2028 casse une regex littérale)
const CONTROL_CHARS = new RegExp('[\\u0000-\\u001f\\u007f\\u200b-\\u200f\\u2028\\u2029]', 'g');
/** Texte propre : CDATA, balises, entités, caractères de contrôle, espaces. */
export const clean = (s, max = 300) => {
  const t = decodeEntities(stripTags(decodeEntities(stripTags(s)))).replace(CONTROL_CHARS, ' ').replace(/\s+/g, ' ').trim();
  return t.length > max ? `${t.slice(0, max - 1)}…` : t;
};
const tag = (block, name) => {
  const m = new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, 'i').exec(block);
  return m ? m[1] : null;
};
const attr = (block, name, a) => new RegExp(`<${name}\\s[^>]*${a}=["']([^"']+)["']`, 'i').exec(block)?.[1] ?? null;

/** Lit un flux RSS 2.0 ou Atom. @returns {{ title, url, ts, source, summary }[]} */
export function parseFeed(xml) {
  const items = [];
  const blocks = [...String(xml).matchAll(/<item[\s>][\s\S]*?<\/item>/gi)].map((m) => m[0]);
  const atom = !blocks.length;
  const list = atom ? [...String(xml).matchAll(/<entry[\s>][\s\S]*?<\/entry>/gi)].map((m) => m[0]) : blocks;
  for (const b of list) {
    const title = clean(tag(b, 'title'), 240);
    if (!title) continue;
    const url = clean(atom ? attr(b, 'link', 'href') ?? tag(b, 'id') : tag(b, 'link') ?? tag(b, 'guid'), 600) || null;
    const when = tag(b, 'pubDate') ?? tag(b, 'updated') ?? tag(b, 'published') ?? tag(b, 'dc:date');
    const ts = when ? Date.parse(clean(when, 80)) : NaN;
    const source = clean(tag(b, 'source'), 80) || null;
    items.push({ title, url, ts: Number.isFinite(ts) ? ts : null, source, summary: clean(tag(b, 'description') ?? tag(b, 'summary') ?? '', 400) || null });
  }
  return items;
}

/** Google Actualités : « Titre - Éditeur » → titre et éditeur séparés. */
export function splitGoogleTitle(it) {
  const m = /^(.*\S)\s+[-–—]\s+([^-–—]{2,60})$/.exec(it.title);
  return m ? { ...it, title: m[1], source: it.source ?? m[2] } : it;
}

/** GDELT DOC 2.0 (mode artlist, JSON). */
export function parseGdelt(j) {
  return (j?.articles ?? []).filter((a) => a.title && a.url).map((a) => {
    const d = /^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z$/.exec(a.seendate ?? '');
    return { title: clean(a.title, 240), url: a.url, ts: d ? Date.UTC(+d[1], +d[2] - 1, +d[3], +d[4], +d[5], +d[6]) : null, source: a.domain ?? 'GDELT', lang: a.language ?? null };
  });
}

const norm = (s) => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const NAME_NOISE = /\b(sa|se|ag|nv|n\.v\.|plc|ltd|inc|corp|corporation|group|groupe|holding|holdings|co|company|asa|ab|oyj|spa|s\.p\.a\.)\b\.?/gi;

// noms de sociétés qui sont aussi des mots courants ou des sigles (BCE = Banque centrale européenne…)
const AMBIGUOUS = new Set(['bce', 'ses', 'sage', 'man', 'next', 'target', 'block', 'match', 'visa', 'fox', 'snap', 'unite', 'bic', 'kone', 'ing', 'abc', 'via', 'gap', 'arm', 'well']);

const MACRO = [
  [/\b(bce|ecb|lagarde|zone euro|eurozone|euro area|cac ?40|sbf ?120|bourse de paris|euronext|dax|stoxx|euro ?stoxx|ftse|aex|ibex|bourses? europ[ée]ennes?|european (stocks|shares|markets))\b/i, 'région', 'Europe'],
  [/\b(fed|powell|wall street|nasdaq|s&p ?500|dow jones|etats-unis|états-unis|treasury|us economy)\b/i, 'région', 'Amérique du Nord'],
  [/\b(chine|china|japon|japan|boj|nikkei|hang seng|yuan|asie|asia)\b/i, 'région', 'Asie-Pacifique'],
  [/\b(inflation|pib|gdp|chômage|chomage|unemployment|taux d'intérêt|interest rates?|pétrole|petrole|brent|opep|opec|récession|recession|tarifs douaniers|tariffs?|géopolitique|geopolit)/i, 'monde', null],
];

/** Adresse d'article conservée seulement si http(s) (un flux ne doit pas pouvoir injecter autre chose). */
export function httpUrl(u) {
  if (!u) return null;
  try {
    const x = new URL(String(u).trim());
    return x.protocol === 'https:' || x.protocol === 'http:' ? x.href : null;
  } catch { return null; }
}

/**
 * Fil d'actualités réelles, même interface que l'actualité simulée : items (du plus ancien au plus
 * récent), forSym(sym, limit), événement 'news' pour chaque nouveau titre.
 */
export class RealNews extends EventEmitter {
  constructor({ net, yahoo, market, file = null, log = () => {}, feeds = DEFAULT_FEEDS }) {
    super();
    Object.assign(this, { net, yahoo, market, file, log, feeds });
    this.items = [];
    this.keys = new Set();
    this.seq = 0;
    this.lastSym = new Map(); // valeur → dernière recherche
    this.lastGdelt = new Map();
    this.stats = { general: null, bySource: {}, errors: {} };
    this.ready = false;
  }

  async load() {
    if (this.file) {
      try {
        const j = JSON.parse(await readFile(this.file, 'utf8'));
        for (const it of j.items ?? []) this.#push(it, false);
        this.seq = j.seq ?? this.items.length;
      } catch { /* premier lancement */ }
    }
    this.ready = true;
  }

  #saveSoon() {
    if (!this.file || this.saveT) return;
    this.saveT = setTimeout(async () => {
      this.saveT = null;
      await mkdir(dirname(this.file), { recursive: true }).catch(() => {});
      await writeFile(this.file, JSON.stringify({ seq: this.seq, items: this.items.slice(-1500) })).catch(() => {});
    }, 5000);
    this.saveT.unref?.();
  }

  /** Clé de dédoublonnage : titre normalisé (un même titre repris par plusieurs sources = un seul). */
  #key(title) {
    return norm(title).replace(/[^a-z0-9]+/g, ' ').trim().slice(0, 120);
  }

  #push(it, emit = true) {
    const k = this.#key(it.title);
    if (!k || this.keys.has(k)) {
      // déjà connu : on complète éventuellement le rattachement à une valeur
      if (k && it.sym) {
        const old = this.items.find((x) => x.key === k);
        if (old && !old.sym) { old.sym = it.sym; old.scope = 'valeur'; }
      }
      return null;
    }
    this.keys.add(k);
    const item = { ...it, key: k, id: it.id ?? `r${++this.seq}` };
    // insertion triée par date (les flux n'arrivent pas dans l'ordre)
    let i = this.items.length;
    while (i > 0 && (this.items[i - 1].ts ?? 0) > (item.ts ?? 0)) i--;
    this.items.splice(i, 0, item);
    if (this.items.length > 2000) {
      const old = this.items.shift();
      this.keys.delete(old.key);
    }
    if (emit) this.emit('news', item);
    return item;
  }

  /** Index des noms de sociétés (expressions régulières précompilées ; alias ambigus écartés). */
  #buildIndex() {
    const insts = this.market?.instruments ?? [];
    const esc = (t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const entries = [], firstCount = new Map();
    for (const x of insts) {
      const raw = x.meta.name;
      const n = norm(raw).replace(NAME_NOISE, ' ').replace(/[^a-z0-9&' -]+/g, ' ').replace(/\s+/g, ' ').trim();
      const acronym = /^[A-Z0-9&]{3}$/.test(raw.trim());
      if ((n.length >= 4 || (acronym && n.length === 3)) && !AMBIGUOUS.has(n)) entries.push({ s: n, sym: x.meta.sym });
      const first = n.split(' ')[0];
      if (first !== n && first.length >= 5 && !['banco', 'banca', 'banque', 'credit', 'societe', 'deutsche', 'royal', 'compagnie', 'general', 'national', 'international'].includes(first)) {
        firstCount.set(first, (firstCount.get(first) ?? 0) + 1);
        entries.push({ s: first, sym: x.meta.sym, alias: true });
      }
    }
    this.index = entries.filter((e) => !e.alias || firstCount.get(e.s) === 1).map((e) => ({ ...e, re: new RegExp(`(^|[^a-z0-9])${esc(e.s)}([^a-z0-9]|$)`) }));
    this.indexSize = insts.length;
  }

  /** Rattache un titre : valeur citée (nom), sinon région / monde / marché. */
  classify(title, hint = null) {
    if (!this.index || this.indexSize !== (this.market?.instruments?.length ?? 0)) this.#buildIndex();
    const t = norm(title);
    if (hint) {
      // résultat d'une recherche sur la société : on la garde… sauf un titre purement macro qui ne la cite pas
      if (this.index.some((e) => e.sym === hint && e.re.test(t))) return { scope: 'valeur', sym: hint };
      for (const [re, scope, region] of MACRO) if (re.test(title)) return { scope, region };
      return { scope: 'valeur', sym: hint };
    }
    let best = null;
    for (const e of this.index) if (e.re.test(t) && (!best || e.s.length > best.s.length)) best = e;
    if (best) return { scope: 'valeur', sym: best.sym };
    for (const [re, scope, region] of MACRO) if (re.test(title)) return { scope, region };
    return { scope: 'marché' };
  }

  ingest(list, { provider, sym = null, lang = null } = {}) {
    let added = 0;
    const now = Date.now();
    for (const raw of list) {
      if (!raw.title) continue;
      const ts = raw.ts && raw.ts <= now + 3600_000 ? raw.ts : now;
      if (now - ts > 14 * 86_400_000) continue; // plus de deux semaines : sans intérêt pour la décision
      const c = this.classify(raw.title, sym);
      const lex = scoreText(raw.title);
      const it = this.#push({
        title: raw.title, url: httpUrl(raw.url), ts, source: raw.source ?? provider, provider, lang: raw.lang ?? lang, summary: raw.summary ?? null,
        scope: c.scope, sym: c.sym ?? null, region: c.region ?? (c.sym ? this.market?.get(c.sym)?.meta.region : null) ?? null,
        score: Number(lex.score.toFixed(2)), scoreConfidence: Number(lex.confidence.toFixed(2)), real: true,
      }, this.ready);
      if (it) added++;
    }
    if (added) this.#saveSoon();
    this.stats.bySource[provider] = { at: now, added, total: (this.stats.bySource[provider]?.total ?? 0) + added };
    return added;
  }

  #err(provider, e) {
    this.stats.errors[provider] = { at: Date.now(), message: e.message };
  }

  /** Flux généraux (presse, BCE, Google Économie). */
  async refreshGeneral() {
    let n = 0;
    for (const f of this.feeds) {
      if (f.enabled === false) continue;
      try {
        const xml = await this.net.get(f.url, { type: 'text', headers: { 'user-agent': BOURSO_UA, accept: 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*' }, priority: 0, label: f.name });
        let items = parseFeed(xml);
        if (/news\.google\./.test(f.url)) items = items.map(splitGoogleTitle);
        n += this.ingest(items.map((x) => ({ ...x, source: x.source ?? f.name })), { provider: f.name, lang: f.lang });
      } catch (e) {
        this.#err(f.name, e);
      }
    }
    this.stats.general = { at: Date.now(), added: n };
    return n;
  }

  /** Actualités d'une valeur : Google Actualités + Yahoo (+ GDELT au plus une fois par heure). */
  async refreshSymbol(sym, { gdelt = true, force = false } = {}) {
    const x = this.market?.get(sym);
    if (!x) return 0;
    const last = this.lastSym.get(sym) ?? 0;
    if (!force && Date.now() - last < 15 * 60_000) return 0;
    this.lastSym.set(sym, Date.now());
    const m = x.meta, eu = m.region === 'Europe';
    const name = m.name.replace(NAME_NOISE, '').replace(/\s+/g, ' ').trim();
    let n = 0;
    const gq = eu ? `"${name}" (bourse OR action OR résultats OR cours) when:7d` : `"${name}" (stock OR shares OR earnings) when:7d`;
    const gurl = `https://news.google.com/rss/search?q=${encodeURIComponent(gq)}&${eu ? 'hl=fr&gl=FR&ceid=FR:fr' : 'hl=en-US&gl=US&ceid=US:en'}`;
    try {
      const xml = await this.net.get(gurl, { type: 'text', headers: { 'user-agent': BOURSO_UA }, priority: 1, label: 'Google Actualités' });
      n += this.ingest(parseFeed(xml).map(splitGoogleTitle), { provider: 'Google Actualités', sym, lang: eu ? 'fr' : 'en' });
    } catch (e) { this.#err('Google Actualités', e); }
    if (this.yahoo) {
      try {
        const r = await this.yahoo.search(m.yahoo ?? m.code, { quotes: 1, news: 10 });
        n += this.ingest(r.news, { provider: 'Yahoo Finance', sym, lang: 'en' });
      } catch (e) { this.#err('Yahoo Finance', e); }
    }
    if (gdelt && Date.now() - (this.lastGdelt.get(sym) ?? 0) > 3600_000) {
      this.lastGdelt.set(sym, Date.now());
      const q = `"${name}"${eu ? ' sourcelang:french' : ' sourcelang:english'}`;
      const url = `https://api.gdeltproject.org/api/v2/doc/doc?query=${encodeURIComponent(q)}&mode=artlist&format=json&maxrecords=25&sort=datedesc&timespan=7d`;
      try {
        n += this.ingest(parseGdelt(await this.net.get(url, { headers: { 'user-agent': BOURSO_UA }, priority: 0, label: 'GDELT' })), { provider: 'GDELT', sym });
      } catch (e) { this.#err('GDELT', e); }
    }
    return n;
  }

  /** Actualités concernant une valeur : directes, sa région, le monde (même logique que la simulation). */
  forSym(sym, limit = 30) {
    const m = this.market?.get(sym)?.meta;
    if (!m) return [];
    return this.items.filter((n) => n.sym === sym || (n.scope === 'région' && n.region === m.region) || n.scope === 'monde').slice(-limit);
  }

  info() {
    return { items: this.items.length, general: this.stats.general, sources: this.stats.bySource, errors: this.stats.errors, feeds: this.feeds.map((f) => ({ name: f.name, url: f.url, lang: f.lang ?? null, enabled: f.enabled !== false })) };
  }
}

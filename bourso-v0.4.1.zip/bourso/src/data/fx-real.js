// ============================================================================
//  BOURSO :: data/fx-real.js — taux de change RÉELS pour valoriser le portefeuille en euros.
//
//  Sources, dans l'ordre :
//   1. Banque centrale européenne : taux de référence officiels (publiés vers 16 h, jours ouvrés),
//      eurofxref-daily.xml — gratuit, sans clé ;
//   2. Frankfurter (miroir JSON des taux de la BCE) si le site de la BCE ne répond pas ;
//   3. Yahoo Finance (paires EURXXX=X) pour un taux plus frais en séance, et pour les devises que la
//      BCE ne publie pas (dollar de Taïwan).
//  Tant qu'aucune source n'a répondu : derniers taux enregistrés sur le disque, sinon taux
//  indicatifs (signalés comme tels).
// ============================================================================
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { BOURSO_UA } from './net.js';
import { FX_CODES, yahooFx } from './symbols.js';

const INDICATIVE = { USD: 1.1, GBP: 0.85, CHF: 0.94, SEK: 11.3, DKK: 7.46, NOK: 11.6, PLN: 4.3, CAD: 1.5, JPY: 160, HKD: 8.6, CNY: 7.9,
  KRW: 1500, TWD: 35, INR: 92, AUD: 1.65, SGD: 1.46, BRL: 6, MXN: 20, ZAR: 20 };

export const ECB_DAILY = 'https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml';
export const FRANKFURTER = 'https://api.frankfurter.dev/v1/latest';

/** XML de la BCE → { date, rates } (unités de devise pour 1 euro). */
export function parseEcbXml(xml) {
  const date = /<Cube\s+time=['"](\d{4}-\d{2}-\d{2})['"]/.exec(xml)?.[1] ?? null;
  const rates = {};
  for (const m of xml.matchAll(/<Cube\s+currency=['"]([A-Z]{3})['"]\s+rate=['"]([\d.]+)['"]\s*\/?>/g)) rates[m[1]] = Number(m[2]);
  if (!date || !Object.keys(rates).length) throw new Error('BCE : format de réponse inattendu');
  return { date, rates };
}

/** JSON Frankfurter → { date, rates }. */
export function parseFrankfurter(j) {
  if (!j?.rates || !j.date) throw new Error('Frankfurter : format de réponse inattendu');
  return { date: j.date, rates: { ...j.rates } };
}

export class RealFx {
  constructor({ net, yahoo, file = null, log = () => {} }) {
    Object.assign(this, { net, yahoo, file, log });
    this.rates = { ...INDICATIVE };
    this.open = { ...INDICATIVE };
    this.source = 'indicatif';
    this.date = null;
    this.at = 0;
    this.live = {};
  }

  async load() {
    if (!this.file) return;
    try {
      const j = JSON.parse(await readFile(this.file, 'utf8'));
      Object.assign(this.rates, j.rates);
      Object.assign(this.open, j.open ?? j.rates);
      this.source = `${j.source} (enregistré)`;
      this.date = j.date;
      this.at = j.at;
    } catch { /* premier lancement */ }
  }

  async #save() {
    if (!this.file) return;
    await mkdir(dirname(this.file), { recursive: true }).catch(() => {});
    await writeFile(this.file, JSON.stringify({ rates: this.rates, open: this.open, source: this.source, date: this.date, at: this.at })).catch(() => {});
  }

  /** Taux officiels du jour (BCE, sinon Frankfurter). */
  async refreshOfficial() {
    let r = null, src = null;
    try {
      r = parseEcbXml(await this.net.get(ECB_DAILY, { type: 'text', headers: { 'user-agent': BOURSO_UA }, label: 'BCE (taux de change)' }));
      src = 'BCE';
    } catch (e) {
      this.log(`taux BCE indisponibles (${e.message}) → Frankfurter`);
      try {
        r = parseFrankfurter(await this.net.get(FRANKFURTER, { headers: { 'user-agent': BOURSO_UA }, label: 'Frankfurter (taux BCE)' }));
        src = 'BCE via Frankfurter';
      } catch (e2) {
        this.log(`taux de change officiels indisponibles : ${e2.message}`);
        return false;
      }
    }
    for (const [k, v] of Object.entries(r.rates)) {
      if (!FX_CODES.includes(k)) continue;
      if (this.date !== r.date) this.open[k] = this.rates[k] ?? v; // nouveau jour : la veille sert de référence
      if (!this.live[k]) this.rates[k] = v;
    }
    this.official = { date: r.date, rates: r.rates, source: src };
    this.source = src;
    this.date = r.date;
    this.at = Date.now();
    await this.#save();
    return true;
  }

  /** Taux en séance (Yahoo EURXXX=X) : plus frais que la BCE, et le TWD que la BCE ne publie pas. */
  async refreshLive() {
    if (!this.yahoo) return false;
    const syms = FX_CODES.map(yahooFx);
    const m = await this.yahoo.spark(syms, { range: '1d', interval: '1h' }).catch((e) => { this.log(`change Yahoo : ${e.message}`); return null; });
    if (!m) return false;
    let n = 0;
    for (const ccy of FX_CODES) {
      const x = m.get(yahooFx(ccy));
      if (!x || !(x.price > 0)) continue;
      // garde-fou : un taux de séance à plus de 10 % du taux officiel du jour est une donnée aberrante
      const ref = this.official?.rates?.[ccy];
      if (ref && Math.abs(x.price / ref - 1) > 0.1) continue;
      this.rates[ccy] = x.price;
      if (x.prevClose > 0) this.open[ccy] = x.prevClose;
      this.live[ccy] = Date.now();
      n++;
    }
    if (n) {
      this.source = this.official ? `${this.official.source} + Yahoo (séance)` : 'Yahoo (séance)';
      this.at = Date.now();
      await this.#save();
    }
    return n > 0;
  }

  tick() { /* les taux réels ne bougent qu'aux rafraîchissements */ }

  /** Valeur en euros d'1 unité de cotation (GBX, ZAC : centièmes). */
  toEur(ccy) {
    if (ccy === 'EUR') return 1;
    if (ccy === 'GBX') return 1 / this.rates.GBP / 100;
    if (ccy === 'ZAC') return 1 / this.rates.ZAR / 100;
    return 1 / (this.rates[ccy] ?? 1);
  }

  list() {
    return FX_CODES.map((k) => ({ pair: `EUR/${k}`, rate: this.rates[k], chgPct: this.open[k] ? (this.rates[k] / this.open[k] - 1) * 100 : 0, source: this.live[k] ? 'Yahoo' : this.source.startsWith('indicatif') ? 'indicatif' : 'BCE' }));
  }

  info() {
    return { source: this.source, date: this.date, at: this.at || null, live: Object.keys(this.live).length };
  }
}

export const FX_FILE = (dir) => join(dir, 'fx.json');

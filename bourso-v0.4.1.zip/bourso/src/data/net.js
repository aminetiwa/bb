// ============================================================================
//  BOURSO :: data/net.js — client HTTP « poli » pour les sources de données gratuites.
//
//  Chaque site a son propre régulateur : nombre de requêtes simultanées, intervalle minimal entre
//  deux requêtes, budget quotidien éventuel (offres gratuites à clé). Un refus « trop de
//  requêtes » (429) ou un blocage (403) ouvre un COUPE-CIRCUIT : le site n'est plus sollicité
//  pendant 1, 2, 5, 15 puis 30 minutes (en respectant Retry-After s'il est donné). Les requêtes
//  qui attendaient leur tour sont alors annulées sur-le-champ (aucune n'est envoyée pendant la
//  pause), et une même pause n'est comptée qu'une fois. Une requête identique déjà en cours est
//  partagée au lieu d'être envoyée deux fois. Les erreurs réseau et 5xx sont réessayées deux fois.
//  Cache mémoire avec durée de vie par requête. Rien n'est contourné : pas de captcha, pas de page
//  de consentement, pas de connexion, pas d'imitation de navigateur.
//  Statistiques par site pour la page Système (requêtes, erreurs, latence, état).
// ============================================================================

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const SECRET_PARAM = /^(token|apikey|api_key|key|access_key|access_token)$/i;

/** Masque les clés d'API de l'adresse dans un message (une réponse d'erreur peut les répéter). */
export function redact(text, url) {
  let t = String(text ?? '');
  try {
    for (const [k, v] of new URL(url).searchParams) if (SECRET_PARAM.test(k) && v.length >= 4) t = t.split(v).join('•••');
  } catch { /* adresse invalide : rien à masquer */ }
  return t;
}
const BACKOFF = [60_000, 120_000, 300_000, 900_000, 1_800_000];

export const BOURSO_UA = 'Bourso/0.4.1 (outil boursier personnel, usage local)';
const hhmm = (t) => new Date(t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

export class NetError extends Error {
  constructor(message, { status = 0, host = '', retryable = false, blocked = false, url = '', pausedUntil = null } = {}) {
    super(message);
    this.name = 'NetError';
    Object.assign(this, { status, host, retryable, blocked, url, pausedUntil });
  }
}

/** Régulateur d'un site : file d'attente, débit, budget, coupe-circuit, statistiques. */
class Gate {
  constructor(host, { concurrency = 1, minIntervalMs = 500, dailyBudget = 0 } = {}) {
    Object.assign(this, { host, concurrency, minIntervalMs, dailyBudget });
    this.active = 0;
    this.queue = [];
    this.last = 0;
    this.openUntil = 0;
    this.trips = 0;
    this.day = new Date().toISOString().slice(0, 10);
    this.used = 0;
    this.stats = { requests: 0, ok: 0, errors: 0, blocked: 0, cached: 0, bytes: 0, msTotal: 0, lastOk: 0, lastError: null, lastErrorAt: 0, lastStatus: 0 };
  }

  get state() {
    if (Date.now() < this.openUntil) return 'coupé';
    if (this.dailyBudget && this.used >= this.dailyBudget) return 'budget épuisé';
    return this.stats.errors > this.stats.ok && this.stats.requests > 3 ? 'instable' : 'ok';
  }

  pausedError() {
    return new NetError(`${this.host} : en pause jusqu'à ${hhmm(this.openUntil)} (requêtes refusées par le site)`, { host: this.host, blocked: true, pausedUntil: this.openUntil });
  }

  /** Rejette tout de suite si le coupe-circuit est ouvert ou le budget du jour épuisé. */
  check() {
    const today = new Date().toISOString().slice(0, 10);
    if (today !== this.day) { this.day = today; this.used = 0; }
    if (Date.now() < this.openUntil) throw this.pausedError();
    if (this.dailyBudget && this.used >= this.dailyBudget) throw new NetError(`${this.host} : budget quotidien de ${this.dailyBudget} requêtes atteint (offre gratuite)`, { host: this.host, blocked: true });
  }

  /** Attend son tour. Le coupe-circuit est revérifié APRÈS l'attente : pendant une pause, rien ne part. */
  async acquire(priority = 1) {
    this.check();
    if (this.active >= this.concurrency) {
      await new Promise((resolve, reject) => {
        this.queue.push({ resolve, reject, priority });
        this.queue.sort((a, b) => b.priority - a.priority);
      });
    }
    this.active++;
    try {
      this.check();
      const wait = this.last + this.minIntervalMs - Date.now();
      if (wait > 0) await sleep(wait);
      this.check(); // une pause a pu commencer pendant l'espacement
    } catch (e) {
      this.release();
      throw e;
    }
    this.last = Date.now();
    this.used++;
  }

  release() {
    this.active--;
    if (this.active < this.concurrency) this.queue.shift()?.resolve();
  }

  /**
   * Coupe-circuit : 1, 2, 5, 15, 30 min (ou Retry-After). Les requêtes en file sont annulées tout de
   * suite ; un refus reçu pendant une pause déjà ouverte (requête partie juste avant) ne l'allonge pas.
   * @returns {{ ms:number, already:boolean }}
   */
  trip(retryAfterMs = 0) {
    const now = Date.now();
    this.stats.blocked++;
    if (now < this.openUntil) return { ms: this.openUntil - now, already: true };
    const ms = Math.max(retryAfterMs, BACKOFF[Math.min(this.trips, BACKOFF.length - 1)]);
    this.trips++;
    this.openUntil = now + ms;
    const waiting = this.queue.splice(0);
    for (const w of waiting) w.reject(this.pausedError());
    return { ms, already: false };
  }

  info() {
    const s = this.stats;
    return {
      host: this.host, state: this.state, pausedUntil: Date.now() < this.openUntil ? this.openUntil : null, queue: this.queue.length, active: this.active,
      budget: this.dailyBudget ? { used: this.used, max: this.dailyBudget } : null, minIntervalMs: this.minIntervalMs,
      ...s, avgMs: s.ok ? Math.round(s.msTotal / s.ok) : null,
    };
  }
}

/**
 * Client HTTP partagé par toutes les sources.
 * @param {{ fetchImpl?: Function, limits?: Record<string, object>, log?: Function, timeoutMs?: number }} o
 *   limits : réglages par site, ex. { 'query1.finance.yahoo.com': { concurrency: 2, minIntervalMs: 300 } }
 */
export class Net {
  constructor({ fetchImpl = globalThis.fetch, limits = {}, log = () => {}, timeoutMs = 20_000, rewrite = null } = {}) {
    this.fetch = fetchImpl;
    this.limits = limits;
    this.log = log;
    this.timeoutMs = timeoutMs;
    this.rewrite = rewrite; // tests : redirige les URL vers un faux serveur
    this.gates = new Map();
    this.cache = new Map();
    this.cacheMax = 3000;
    this.inflight = new Map(); // requête identique déjà en cours → même promesse
  }

  /** Fin de la pause d'un site (ms), ou 0 s'il n'est pas en pause. */
  pausedUntil(host) {
    const g = this.gates.get(host);
    return g && Date.now() < g.openUntil ? g.openUntil : 0;
  }

  gate(host) {
    if (!this.gates.has(host)) {
      const l = this.limits[host] ?? Object.entries(this.limits).find(([k]) => k.startsWith('*.') && host.endsWith(k.slice(1)))?.[1] ?? this.limits['*'] ?? {};
      this.gates.set(host, new Gate(host, l));
    }
    return this.gates.get(host);
  }

  setLimit(host, l) {
    this.limits[host] = l;
    const g = this.gates.get(host);
    if (g) Object.assign(g, l);
  }

  /**
   * Requête GET régulée.
   * @param {string} url
   * @param {{ type?: 'json'|'text', ttlMs?: number, headers?: object, priority?: number, timeoutMs?: number, retries?: number, label?: string }} o
   */
  async get(url, o = {}) {
    const key = `${o.type ?? 'json'}:${url}`;
    if (o.ttlMs) {
      const c = this.cache.get(key);
      if (c && c.until > Date.now()) {
        this.gate(new URL(url).host).stats.cached++;
        return c.value;
      }
    }
    // même requête déjà en route : on la partage (pas de doublon envoyé au site)
    const running = this.inflight.get(key);
    if (running) return running;
    const p = this.#get(url, key, o).finally(() => this.inflight.delete(key));
    this.inflight.set(key, p);
    return p;
  }

  async #get(url, key, { type = 'json', ttlMs = 0, headers = {}, priority = 1, timeoutMs = this.timeoutMs, retries = 2, label = '' } = {}) {
    const host = new URL(url).host, g = this.gate(host);
    let lastErr = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
      await g.acquire(priority);
      const t0 = Date.now();
      let res;
      try {
        g.stats.requests++;
        const target = this.rewrite ? this.rewrite(url) : url;
        res = await this.fetch(target, { headers: { 'accept-language': 'fr-FR,fr;q=0.9,en;q=0.8', ...headers }, redirect: 'follow', signal: AbortSignal.timeout(timeoutMs) });
        const ms = Date.now() - t0;
        if (res.status === 429 || res.status === 403 || res.status === 999) {
          const ra = Number(res.headers.get('retry-after'));
          const t = g.trip(Number.isFinite(ra) && ra > 0 ? ra * 1000 : 0);
          const msg = `${host} refuse les requêtes (HTTP ${res.status}${res.status === 429 ? ' : trop de requêtes' : ''}) → pause jusqu'à ${hhmm(g.openUntil)}`;
          g.stats.errors++;
          g.stats.lastStatus = res.status;
          if (!t.already) {
            // une seule ligne par pause (les requêtes parties juste avant ne répètent rien)
            g.stats.lastError = msg;
            g.stats.lastErrorAt = Date.now();
            this.log(`${msg} : plus rien ne lui est envoyé d'ici là, reprise automatique`);
          }
          await res.body?.cancel?.().catch(() => {});
          throw new NetError(msg, { status: res.status, host, blocked: true, url, pausedUntil: g.openUntil });
        }
        // page de consentement, de connexion ou de vérification anti-robot : on s'arrête là (rien n'est contourné)
        const finalUrl = res.url || target;
        if (finalUrl !== target && /consent\.|guce\.|\/consent|captcha|\/challenge|sorry\/index/i.test(new URL(finalUrl).host + new URL(finalUrl).pathname)) {
          await res.body?.cancel?.().catch(() => {});
          g.stats.errors++;
          g.stats.lastError = `${host} : page de consentement ou de vérification (non contournée)`;
          g.stats.lastErrorAt = Date.now();
          throw new NetError(g.stats.lastError, { status: res.status, host, url });
        }
        if (!res.ok) {
          const body = await res.text().catch(() => '');
          const retryable = res.status >= 500;
          const msg = redact(`${label || host} : HTTP ${res.status}${body ? ` — ${body.replace(/\s+/g, ' ').slice(0, 160)}` : ''}`, url);
          g.stats.errors++;
          g.stats.lastError = msg;
          g.stats.lastErrorAt = Date.now();
          g.stats.lastStatus = res.status;
          throw new NetError(msg, { status: res.status, host, retryable, url });
        }
        const text = await res.text();
        g.stats.ok++;
        g.stats.bytes += text.length;
        g.stats.msTotal += ms;
        g.stats.lastOk = Date.now();
        g.stats.lastStatus = res.status;
        g.trips = Math.max(0, g.trips - 1);
        let value = text;
        if (type === 'json') {
          try { value = JSON.parse(text); } catch {
            throw new NetError(redact(`${label || host} : réponse illisible (JSON attendu, reçu « ${text.replace(/\s+/g, ' ').slice(0, 80)} »)`, url), { status: res.status, host, url });
          }
        }
        if (ttlMs) {
          if (this.cache.size >= this.cacheMax) this.cache.delete(this.cache.keys().next().value);
          this.cache.set(key, { value, until: Date.now() + ttlMs });
        }
        return value;
      } catch (e) {
        lastErr = e instanceof NetError ? e : new NetError(redact(`${label || host} : ${e.name === 'TimeoutError' ? `pas de réponse en ${Math.round(timeoutMs / 1000)} s` : e.cause?.code ?? e.message}`, url), { host, retryable: true, url });
        if (!(e instanceof NetError)) {
          g.stats.errors++;
          g.stats.lastError = lastErr.message;
          g.stats.lastErrorAt = Date.now();
        }
        if (!lastErr.retryable || attempt === retries) throw lastErr;
        await sleep(800 * 3 ** attempt);
      } finally {
        g.release();
      }
    }
    throw lastErr;
  }

  info() {
    return [...this.gates.values()].map((g) => g.info()).sort((a, b) => b.requests - a.requests);
  }
}

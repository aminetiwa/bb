// ============================================================================
//  BOURSO :: data/ttf.js — taxe sur les transactions financières (TTF, 0,4 % à l'achat).
//
//  La TTF s'applique aux acquisitions d'actions de sociétés dont le siège est en France et dont
//  la capitalisation boursière dépassait 1 milliard d'euros au 1er décembre de l'année
//  précédente. L'administration publie chaque année la liste officielle : c'est elle qui fait foi,
//  pas une capitalisation estimée. Liste 2026 : BOFiP BOI-ANNX-000467-20251217 (17 décembre 2025),
//  121 sociétés. Chaque ISIN ci-dessous a été vérifié par son chiffre de contrôle.
//  À mettre à jour chaque mois de décembre (liste de l'année suivante).
// ============================================================================

export const TTF_YEAR = 2026;
export const TTF_SOURCE = 'liste officielle 2026 (BOFiP BOI-ANNX-000467-20251217 : capitalisation > 1 Md€ au 1er décembre 2025)';

export const TTF_ISINS = new Set([
  'FR0000031023', 'FR0000031577', 'FR0000031775', 'FR0000033219', 'FR0000035081', 'FR0000039091',
  'FR0000039299', 'FR0000044448', 'FR0000045072', 'FR0000050049', 'FR0000050353', 'FR0000050809',
  'FR0000051807', 'FR0000052292', 'FR0000053225', 'FR0000053324', 'FR0000053837', 'FR0000054900',
  'FR0000060303', 'FR0000062234', 'FR0000062671', 'FR0000064271', 'FR0000064578', 'FR0000064784',
  'FR0000071946', 'FR0000073272', 'FR0000073298', 'FR0000076952', 'FR0000077919', 'FR0000120073',
  'FR0000120172', 'FR0000120271', 'FR0000120321', 'FR0000120404', 'FR0000120503', 'FR0000120578',
  'FR0000120628', 'FR0000120644', 'FR0000120693', 'FR0000120859', 'FR0000120966', 'FR0000121014',
  'FR0000121121', 'FR0000121147', 'FR0000121204', 'FR0000121220', 'FR0000121329', 'FR0000121485',
  'FR0000121667', 'FR0000121709', 'FR0000121964', 'FR0000121972', 'FR0000124141', 'FR0000124570',
  'FR0000125007', 'FR0000125338', 'FR0000125486', 'FR0000127771', 'FR0000130213', 'FR0000130395',
  'FR0000130403', 'FR0000130452', 'FR0000130577', 'FR0000130809', 'FR0000131104', 'FR0000131757',
  'FR0000131906', 'FR0000133308', 'FR0004024222', 'FR0004050250', 'FR0004125920', 'FR0004188670',
  'FR0005691656', 'FR0006174348', 'FR0010040865', 'FR0010208488', 'FR0010220475', 'FR0010221234',
  'FR0010241638', 'FR0010259150', 'FR0010282822', 'FR0010307819', 'FR0010313833', 'FR0010340141',
  'FR0010386334', 'FR0010411983', 'FR0010451203', 'FR0010481960', 'FR0010533075', 'FR0010667147',
  'FR0010828137', 'FR0010908533', 'FR0010929125', 'FR0011040500', 'FR0011726835', 'FR0012333284',
  'FR0012435121', 'FR0012757854', 'FR0013154002', 'FR0013176526', 'FR0013230612', 'FR0013258662',
  'FR0013269123', 'FR0013280286', 'FR0013326246', 'FR0013357621', 'FR0013447729', 'FR0013451333',
  'FR0013506730', 'FR0014003TT8', 'FR0014004L86', 'FR0014005AL0', 'FR0014005HJ9', 'FR001400AJ45',
  'FR001400J770', 'FR001400NLM4', 'FR001400PFU4', 'FR001400Q9V2', 'FR001400SF56', 'FR001400SU99',
  'FR001400SUB7',
]);

/**
 * La TTF s'applique-t-elle à un achat de ce titre ?
 * @param {string|null} isin
 * @param {number|null} capEur capitalisation connue (sert seulement pour une année sans liste intégrée)
 * @param {number} at date de l'achat (ms)
 * @returns {{ eligible:boolean, reason:string }}
 */
export function ttfStatus(isin, capEur = null, at = Date.now()) {
  if (!isin) return { eligible: false, reason: 'ISIN inconnu' };
  if (!isin.startsWith('FR')) return { eligible: false, reason: 'société non française' };
  const year = new Date(at).getUTCFullYear();
  if (year === TTF_YEAR) return TTF_ISINS.has(isin) ? { eligible: true, reason: `liste TTF ${TTF_YEAR}` } : { eligible: false, reason: `hors liste TTF ${TTF_YEAR}` };
  // année sans liste intégrée : capitalisation si elle est connue, sinon la dernière liste (à vérifier)
  if (Number.isFinite(capEur)) return { eligible: capEur > 1e9, reason: capEur > 1e9 ? 'capitalisation > 1 Md€' : 'capitalisation < 1 Md€' };
  return { eligible: TTF_ISINS.has(isin), reason: `liste TTF ${TTF_YEAR} (à vérifier pour ${year})` };
}

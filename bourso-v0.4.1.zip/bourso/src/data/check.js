// ============================================================================
//  BOURSO :: data/check.js — vérification des sources de données depuis TA machine.
//
//  Une requête légère par source (cours, historique, intraday, cotations groupées, recherche,
//  change BCE / Frankfurter, actualités Google / GDELT / flux RSS, et les sources à clé si elles
//  sont renseignées). Chaque résultat dit ce qui marche, en combien de temps, et sinon POURQUOI
//  avec une piste concrète. Utilisé par « npm run data:check » et par Réglages → Données.
//  Les règles de politesse du client réseau s'appliquent (débit par site, coupe-circuit) :
//  rien n'est contourné.
// ============================================================================
import { Net, BOURSO_UA } from './net.js';
import { Yahoo } from './yahoo.js';
import { ECB_DAILY, FRANKFURTER, parseEcbXml, parseFrankfurter } from './fx-real.js';
import { DEFAULT_FEEDS, parseFeed, splitGoogleTitle, parseGdelt } from './news-real.js';
import { parseDailyCsv } from './keyed.js';

/**
 * Réglages de débit par site (les mêmes que ceux du marché réel). Yahoo : une requête à la fois,
 * au plus une par seconde — l'ordonnanceur en demande bien moins en temps normal.
 */
export const NET_LIMITS = {
  'query1.finance.yahoo.com': { concurrency: 1, minIntervalMs: 1000 }, 'query2.finance.yahoo.com': { concurrency: 1, minIntervalMs: 1000 },
  'news.google.com': { concurrency: 1, minIntervalMs: 2000 }, 'api.gdeltproject.org': { concurrency: 1, minIntervalMs: 5500 },
  'www.ecb.europa.eu': { concurrency: 1, minIntervalMs: 1500 }, 'api.frankfurter.dev': { concurrency: 1, minIntervalMs: 1500 },
  '*': { concurrency: 1, minIntervalMs: 1200 },
};

const fmtPx = (v) => (Number.isFinite(v) ? v.toLocaleString('fr-FR', { maximumFractionDigits: 4 }) : '—');
const when = (ms) => (ms ? new Date(ms).toLocaleString('fr-FR', { timeZone: 'Europe/Paris', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—');

/** Piste de résolution, en français, selon l'erreur. */
export function hintFor(e, { source = '' } = {}) {
  const m = String(e?.message ?? e ?? ''), st = e?.status ?? 0, yahoo = /yahoo/i.test(source);
  // requête annulée parce que le site est déjà en pause : même cause que le premier refus
  if (e?.blocked && !st && /en pause jusqu/.test(m)) return 'Même cause que le premier refus : rien n\'est envoyé à ce site pendant la pause.';
  if (st === 429 || /trop de requêtes/.test(m)) return yahoo
    ? 'Yahoo refuse les requêtes venant de ton adresse IP pour l\'instant (souvent après une rafale d\'appels, ou depuis un VPN / un serveur). Bourso met Yahoo en pause puis réessaie seul ; relance ce test dans 10 à 30 min. Garde l\'intensité « normale » ou « économe ».'
    : 'Le site limite le nombre de requêtes : attends quelques minutes (Bourso fait une pause automatique).';
  if (st === 401) return yahoo
    ? 'Yahoo demande une authentification (cookie) pour ce point d\'accès depuis ta connexion : Bourso ne contourne pas cette protection. Les clés gratuites Twelve Data et Finnhub ne couvrent que les actions américaines ; une clé Stooq peut servir de secours pour certaines places.'
    : 'Clé refusée : vérifie-la dans Réglages → Données (copie complète, sans espace).';
  if (st === 402 || st === 403 || /refuse les requêtes/.test(m)) return 'Accès refusé par le site (protection anti-robot, offre gratuite qui ne couvre pas cette donnée, ou clé invalide).';
  if (/consentement|vérification/.test(m)) return 'Page de consentement ou de vérification : Bourso ne la contourne pas. La source est simplement ignorée.';
  if (/ENOTFOUND|EAI_AGAIN/.test(m)) return 'Nom de domaine introuvable : pas d\'accès Internet, DNS en panne, ou site bloqué par un filtre (pare-feu, contrôle parental).';
  if (/UND_ERR_CONNECT_TIMEOUT|ETIMEDOUT/.test(m)) return /gdelt/i.test(source)
    ? 'Le serveur de GDELT ne répond pas (il est souvent saturé) : non essentiel, les autres sources d\'actualités suffisent. Il sera réessayé plus tard.'
    : 'Le site ne répond pas (délai de connexion dépassé) : site saturé, ou bloqué sur ton réseau. Réessaie plus tard.';
  if (/ECONNREFUSED|ECONNRESET|EHOSTUNREACH|ENETUNREACH|UND_ERR|fetch failed/.test(m)) return 'Connexion impossible : vérifie l\'accès Internet, un proxy ou un pare-feu.';
  if (/pas de réponse en/.test(m)) return 'Le site ne répond pas à temps : connexion lente ou site saturé. Réessaie plus tard.';
  if (/CERT|certificate|self.signed/i.test(m)) return 'Problème de certificat TLS : un proxy d\'entreprise ou un antivirus intercepte peut-être les connexions HTTPS.';
  if (/en pause jusqu/.test(m)) return 'Le coupe-circuit de Bourso a mis ce site en pause après des refus : il sera réessayé automatiquement.';
  if (/budget quotidien/.test(m)) return 'Budget quotidien de l\'offre gratuite atteint : il se renouvelle demain.';
  if (/apikey|clé API requise/i.test(m)) return 'Clé requise ou invalide pour cette source.';
  if (/HTTP 404/.test(m)) return 'Adresse introuvable : la source a peut-être changé d\'adresse.';
  return '';
}

/**
 * Lance les vérifications. @returns {Promise<{ at:number, results:object[], summary:object }>}
 * @param {{ net?: Net, fetchImpl?: Function, rewrite?: Function, keys?: object, feeds?: object[], symbols?: string[], onResult?: Function, timeoutMs?: number }} o
 */
export async function checkSources({ net = null, fetchImpl, rewrite = null, keys = {}, feeds = DEFAULT_FEEDS, symbols = ['MC.PA', 'SAP.DE', 'AAPL'], onResult = () => {}, timeoutMs = 15_000 } = {}) {
  const n = net ?? new Net({ fetchImpl, rewrite, limits: { ...NET_LIMITS }, timeoutMs });
  const yahoo = new Yahoo(n), results = [];
  const run = async (group, name, essential, fn) => {
    const t0 = Date.now();
    let r;
    try {
      const detail = await fn();
      r = { group, name, essential, ok: true, ms: Date.now() - t0, detail };
    } catch (e) {
      // « Yahoo MC.PA : ENOTFOUND » → « ENOTFOUND » (la source est déjà nommée)
      const m = String(e.message ?? e), i = m.indexOf(' : '), short = i > 0 && i < 70 && !m.slice(0, i).includes('(') ? m.slice(i + 3) : m;
      r = { group, name, essential, ok: false, ms: Date.now() - t0, error: short, status: e.status ?? null, hint: hintFor(e, { source: name }) };
    }
    results.push(r);
    onResult(r);
    return r;
  };
  const get = (url, o = {}) => n.get(url, { retries: 0, timeoutMs, priority: 3, ...o });
  const enabledFeeds = (feeds ?? []).filter((f) => f.enabled !== false && !/news\.google\./.test(f.url));

  // les sites sont interrogés en parallèle (chacun à son rythme, comme en fonctionnement normal)
  const yahooChecks = (async () => {
    for (const s of symbols) {
      await run('Cours et historiques', `Yahoo — historique ${s}`, true, async () => {
        const r = await yahoo.chart(s, { range: '1mo', interval: '1d', events: false }, { priority: 3 });
        if (!r.meta?.price && !r.bars.close.length) throw new Error('réponse sans cours');
        return `${fmtPx(r.meta?.price ?? r.bars.close.at(-1))} ${r.meta?.currency ?? ''} · cours du ${when(r.meta?.time)} · ${r.bars.close.length} séances sur un mois`;
      });
    }
    await run('Cours et historiques', `Yahoo — bougies 1 min ${symbols[0]}`, false, async () => {
      const r = await yahoo.chart(symbols[0], { range: '1d', interval: '1m', events: false }, { priority: 3 });
      return `${r.bars.close.length} bougies d'une minute (séance du jour ou dernière séance)`;
    });
    await run('Cours et historiques', 'Yahoo — cotations groupées (spark)', false, async () => {
      const m = await yahoo.spark(symbols, { range: '1d', interval: '15m' }, { priority: 3 });
      if (!m) throw new Error('point d\'accès fermé (les cours passeront par les historiques, valeur par valeur — plus lent mais fonctionnel)');
      return `${m.size} / ${symbols.length} cotations en une requête (${yahoo.sparkPath})`;
    });
    await run('Recherche', 'Yahoo — recherche mondiale', false, async () => {
      const r = await yahoo.search('LVMH', { quotes: 5, news: 3 }, { priority: 3, ttlMs: 0 });
      if (!r.quotes.length) throw new Error('aucun résultat');
      return `${r.quotes.length} valeur(s) (${r.quotes.slice(0, 3).map((q) => q.symbol).join(', ')}) · ${r.news.length} actualité(s)`;
    });
  })();

  const fxChecks = (async () => {
    await run('Change', 'BCE — taux de référence', true, async () => {
      const r = parseEcbXml(await get(ECB_DAILY, { type: 'text', headers: { 'user-agent': BOURSO_UA }, label: 'BCE' }));
      return `${Object.keys(r.rates).length} devises · taux du ${r.date} · 1 € = ${fmtPx(r.rates.USD)} USD`;
    });
    await run('Change', 'Frankfurter (secours BCE)', false, async () => {
      const r = parseFrankfurter(await get(FRANKFURTER, { headers: { 'user-agent': BOURSO_UA }, label: 'Frankfurter' }));
      return `${Object.keys(r.rates).length} devises · taux du ${r.date}`;
    });
  })();

  const googleChecks = run('Actualités', 'Google Actualités (recherche)', false, async () => {
    const xml = await get('https://news.google.com/rss/search?q=%22LVMH%22%20when%3A7d&hl=fr&gl=FR&ceid=FR:fr', { type: 'text', headers: { 'user-agent': BOURSO_UA }, label: 'Google Actualités' });
    const items = parseFeed(xml).map(splitGoogleTitle);
    if (!items.length) throw new Error('flux vide');
    return `${items.length} titre(s) · dernier : « ${items[0].title.slice(0, 70)} »`;
  });

  const gdeltCheck = run('Actualités', 'GDELT (presse mondiale)', false, async () => {
    const url = `https://api.gdeltproject.org/api/v2/doc/doc?query=${encodeURIComponent('"TotalEnergies" sourcelang:french')}&mode=artlist&format=json&maxrecords=10&sort=datedesc&timespan=7d`;
    const items = parseGdelt(await get(url, { headers: { 'user-agent': BOURSO_UA }, label: 'GDELT' }));
    return `${items.length} article(s) sur 7 jours`;
  });

  const feedChecks = Promise.all(enabledFeeds.map((f) => run('Actualités', `Flux — ${f.name}`, false, async () => {
    const items = parseFeed(await get(f.url, { type: 'text', headers: { 'user-agent': BOURSO_UA, accept: 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*' }, label: f.name }));
    if (!items.length) throw new Error('flux vide ou format inconnu');
    return `${items.length} titre(s)`;
  })));

  const keyChecks = (async () => {
    const enc = encodeURIComponent, H = { 'user-agent': BOURSO_UA, accept: 'application/json' };
    if (keys.finnhub) await run('Sources à clé', 'Finnhub', false, async () => {
      const q = await get(`https://finnhub.io/api/v1/quote?symbol=AAPL&token=${enc(keys.finnhub)}`, { headers: H, label: 'Finnhub' });
      if (!Number.isFinite(q?.c) || q.c <= 0) throw new Error('réponse sans cours (clé refusée ?)');
      return `clé acceptée · AAPL ${fmtPx(q.c)} USD`;
    });
    if (keys.fmp) await run('Sources à clé', 'Financial Modeling Prep', false, async () => {
      const p = await get(`https://financialmodelingprep.com/stable/profile?symbol=AAPL&apikey=${enc(keys.fmp)}`, { headers: H, label: 'FMP' });
      if (!Array.isArray(p) || !p[0]) throw new Error(typeof p?.['Error Message'] === 'string' ? p['Error Message'].slice(0, 120) : 'réponse vide (clé refusée ?)');
      return `clé acceptée · ${p[0].companyName ?? 'AAPL'}`;
    });
    if (keys.twelvedata) await run('Sources à clé', 'Twelve Data', false, async () => {
      const r = await get(`https://api.twelvedata.com/time_series?symbol=AAPL&interval=1day&outputsize=5&apikey=${enc(keys.twelvedata)}`, { headers: H, label: 'Twelve Data' });
      if (r?.status === 'error') throw new Error(String(r.message ?? 'erreur').slice(0, 140));
      return `clé acceptée · ${r?.values?.length ?? 0} séances reçues`;
    });
    if (keys.stooq) await run('Sources à clé', 'Stooq', false, async () => {
      const d = parseDailyCsv(await get(`https://stooq.com/q/d/l/?s=aapl.us&i=d&apikey=${enc(keys.stooq)}`, { type: 'text', headers: { 'user-agent': BOURSO_UA }, label: 'Stooq' }));
      return `clé acceptée · ${d.dates.length} séances`;
    });
  })();

  await Promise.all([yahooChecks, fxChecks, googleChecks, gdeltCheck, feedChecks, keyChecks]);
  const ok = results.filter((r) => r.ok).length;
  const histOk = results.some((r) => r.ok && /historique/.test(r.name));
  const yahooRefused = results.some((r) => !r.ok && /Yahoo/.test(r.name) && r.status === 429);
  const pausedUntil = n.pausedUntil('query1.finance.yahoo.com');
  const fxOk = results.some((r) => r.ok && r.group === 'Change');
  const newsOk = results.some((r) => r.ok && r.group === 'Actualités');
  return {
    at: Date.now(), results,
    summary: {
      ok, total: results.length, essentialOk: histOk, quotes: histOk, fx: fxOk, news: newsOk, yahooRefused, yahooPausedUntil: pausedUntil || null,
      verdict: histOk
        ? `Les données réelles fonctionnent depuis cette machine (${ok}/${results.length} sources joignables).`
        : yahooRefused
          ? `Yahoo Finance refuse pour l'instant les requêtes de ta connexion (HTTP 429). Ce n'est pas une panne de Bourso : la limite vient de Yahoo. Bourso le laisse tranquille${pausedUntil ? ` jusqu'à ${new Date(pausedUntil).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}` : ''} puis réessaie seul ; en attendant, il affiche les derniers cours enregistrés. Relance ce test dans 10 à 30 min.`
          : 'Les cours réels ne sont PAS joignables depuis cette machine : Bourso affichera les derniers cours enregistrés. Voir les pistes ci-dessus.',
    },
  };
}

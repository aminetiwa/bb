#!/usr/bin/env node
// ============================================================================
//  BOURSO :: scripts/run.js — superviseur du serveur.
//
//   npm start      → lance le serveur (http://localhost:3000) et le surveille
//   npm run dev    → idem + redémarrage automatique quand un fichier de src/ change
//
//  Le serveur tourne dans un processus enfant. S'il s'arrête brutalement (plantage de code natif :
//  module C++, pilote… — dans ce cas Node n'affiche AUCUN message), le superviseur :
//    1. dit clairement ce qui s'est passé (signal, dernière opération native en cours) ;
//    2. écrit un rapport dans data/logs/plantage-AAAA-MM-JJ….txt (à joindre pour un diagnostic) ;
//    3. relance le serveur ; au 2ᵉ plantage rapproché sur du code C++, il relance sans module C++.
//  Le GPU, lui, est déjà isolé dans son propre processus (src/compute/gpu-proxy.js).
// ============================================================================
import { fork } from 'node:child_process';
import { watch, mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const MAIN = join(ROOT, 'src', 'server', 'main.js');
const DATA = process.env.BOURSO_DATA ?? join(ROOT, 'data');
const WATCH = process.argv.includes('--watch');
const SIGNALS = {
  SIGSEGV: 'accès mémoire invalide dans du code natif', SIGABRT: 'arrêt forcé par du code natif', SIGBUS: 'erreur de bus mémoire',
  SIGILL: 'instruction processeur non supportée (module compilé pour une autre machine ?)', SIGKILL: 'tué par le système (mémoire insuffisante ?)',
  SIGFPE: 'erreur arithmétique dans du code natif',
};
const say = (...a) => console.log(`[${new Date().toLocaleTimeString('fr-FR')}] [superviseur]`, ...a);

let child = null, lastOp = null, recent = [], reload = false, stopping = false, startedAt = 0;
const extraEnv = {};

function start() {
  lastOp = null;
  startedAt = Date.now();
  child = fork(MAIN, process.argv.slice(2).filter((a) => a !== '--watch'), {
    stdio: ['inherit', 'inherit', 'inherit', 'ipc'], execArgv: [], env: { ...process.env, ...extraEnv, BOURSO_SUPERVISED: '1' },
  });
  child.on('message', (m) => {
    if (m?.t === 'op') lastOp = m.op ? { op: m.op, at: Date.now() } : null;
  });
  child.on('exit', (code, signal) => {
    child = null;
    if (stopping) process.exit(0);
    if (reload) {
      reload = false;
      start();
      return;
    }
    if (!signal && code === 0) process.exit(0); // arrêt normal demandé
    if (!signal && code === 2) process.exit(2); // échec de démarrage (port occupé…) : déjà expliqué
    crashed(code, signal);
  });
}

function crashed(code, signal) {
  const now = Date.now(), up = Math.round((now - startedAt) / 1000);
  recent = recent.filter((t) => now - t < 5 * 60_000);
  recent.push(now);
  const why = signal ? `signal ${signal}${SIGNALS[signal] ? ` — ${SIGNALS[signal]}` : ''}` : `code de sortie ${code}`;
  const op = lastOp ? `${lastOp.op} (commencée ${Math.round((now - lastOp.at) / 100) / 10} s avant)` : 'aucune opération native en cours connue';
  const lines = [
    '',
    '══════════════════════════════════════════════════════════════════════',
    `  Le serveur Bourso s'est arrêté brutalement après ${up} s : ${why}.`,
    `  Opération native en cours : ${op}.`,
  ];
  let action = 'relance automatique dans 2 s';
  const nativeSuspect = Boolean(lastOp) && /C\+\+/.test(lastOp.op);
  if (nativeSuspect && recent.length >= 2 && extraEnv.BOURSO_NO_NATIVE !== '1') {
    extraEnv.BOURSO_NO_NATIVE = '1';
    action = 'relance SANS le module C++ (calculs CPU sur les workers JavaScript, mêmes résultats, plus lent)';
  }
  if (recent.length >= 5) action = 'trop de plantages en 5 minutes : arrêt';
  lines.push(`  → ${action}.`);
  let report = null;
  try {
    mkdirSync(join(DATA, 'logs'), { recursive: true });
    report = join(DATA, 'logs', `plantage-${new Date().toISOString().replace(/[:.]/g, '-')}.txt`);
    writeFileSync(report, [
      `Bourso — plantage du serveur`, `date : ${new Date().toISOString()}`, `durée de fonctionnement : ${up} s`, `cause : ${why}`,
      `opération native en cours : ${op}`, `Node ${process.version} · ${process.platform} ${process.arch}`,
      `variables : BOURSO_GPU=${process.env.BOURSO_GPU ?? ''} BOURSO_NO_NATIVE=${extraEnv.BOURSO_NO_NATIVE ?? process.env.BOURSO_NO_NATIVE ?? ''}`,
      `action : ${action}`, '',
    ].join('\n'));
    lines.push(`  Rapport : ${report}`);
  } catch { /* dossier non inscriptible : tant pis pour le rapport */ }
  lines.push('══════════════════════════════════════════════════════════════════════', '');
  console.error(lines.join('\n'));
  if (recent.length >= 5) process.exit(1);
  setTimeout(start, 2000);
}

function shutdown(sig) {
  if (stopping) return;
  stopping = true;
  if (!child) process.exit(0);
  // on transmet toujours le signal (Ctrl+C l'a peut-être déjà envoyé à l'enfant : l'arrêt est idempotent)
  try { child.kill(sig); } catch { /* déjà arrêté */ }
  setTimeout(() => { child?.kill('SIGKILL'); process.exit(0); }, 6000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

if (WATCH) {
  // seuls les fichiers du serveur imposent un redémarrage (web/ est relu à chaque requête)
  let t = null;
  watch(join(ROOT, 'src'), { recursive: true }, (ev, file) => {
    if (!file || !/\.(js|mjs|json)$/.test(file)) return;
    clearTimeout(t);
    t = setTimeout(() => {
      say(`modifié : src/${file} → redémarrage`);
      if (child) {
        reload = true;
        child.kill('SIGTERM');
      } else start();
    }, 250);
  });
  say('mode développement : redémarrage automatique quand src/ change (web/ est relu à chaque requête)');
}

start();

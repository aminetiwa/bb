#!/usr/bin/env node
// ============================================================================
//  BOURSO :: scripts/start-demo.js — démonstration complète SANS Ollama : lance un faux serveur
//  Ollama (réponses simulées, clairement étiquetées) puis Bourso branché dessus.
//  Pour la vraie IA : `ollama serve` + `npm run ollama:setup` puis `npm start`.
// ============================================================================
import { startMockOllama } from '../src/ai/mock-ollama-server.js';

const port = Number(process.env.MOCK_OLLAMA_PORT ?? 11435);
await startMockOllama({ port, tokenDelayMs: 10 });
process.env.OLLAMA_HOST = `127.0.0.1:${port}`;
console.log(`faux Ollama (simulation) sur 127.0.0.1:${port}`);
const { startServer } = await import('../src/server/main.js');
const s = await startServer({ market: process.env.BOURSO_MARKET ?? 'demo' });
process.on('SIGINT', async () => { await s.close(); process.exit(0); });

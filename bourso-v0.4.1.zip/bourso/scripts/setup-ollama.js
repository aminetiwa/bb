#!/usr/bin/env node
// ============================================================================
//  BOURSO :: setup-ollama.js — prépare l'unique modèle de l'IA (Linux / macOS / Windows).
//
//   npm run ollama:setup                                   qwen3:30b (défaut) → modèle « bourso »
//   BOURSO_MODEL=mistral-small3.2:24b npm run ollama:setup autre base (~20-32B)
//   BOURSO_MODEL_NAME=bourso-mistral …                     autre nom pour le modèle créé
//
//  Tout cela se fait aussi depuis l'interface : page Réglages (télécharger, tester, créer, choisir).
// ============================================================================
import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const MODELFILE = join(here, '..', 'src', 'ai', 'modelfiles', 'Bourso.Modelfile');
const NAME = process.env.BOURSO_MODEL_NAME ?? 'bourso';
const shell = process.platform === 'win32';
const run = (args) => spawnSync('ollama', args, { stdio: 'inherit', shell });

if (spawnSync('ollama', ['--version'], { stdio: 'ignore', shell }).status !== 0) {
  console.error('Ollama introuvable. Installe-le depuis https://ollama.com/download puis relance « npm run ollama:setup ».');
  process.exit(1);
}

let src = readFileSync(MODELFILE, 'utf8');
const original = src.match(/^FROM\s+(\S+)/m)[1];
const base = process.env.BOURSO_MODEL ?? original;
if (base !== original) src = src.replace(/^FROM\s+\S+/m, `FROM ${base}`);

const tmp = mkdtempSync(join(tmpdir(), 'bourso-modelfile-'));
try {
  console.log(`\n▶ ollama pull ${base}`);
  if (run(['pull', base]).status !== 0) throw new Error(`échec du téléchargement de ${base}`);
  const path = join(tmp, 'Bourso.Modelfile');
  writeFileSync(path, src);
  console.log(`\n▶ ollama create ${NAME}  (FROM ${base})`);
  if (run(['create', NAME, '-f', path]).status !== 0) throw new Error(`échec de création de ${NAME}`);
  console.log(`
✔ Modèle prêt : ${NAME} ← ${base}

Réglages conseillés pour « ollama serve » (un seul GPU), par ex. dans
« sudo systemctl edit ollama » (section [Service], lignes Environment=…) :
  OLLAMA_NUM_PARALLEL=1          une requête à la fois (les favoris passent dans l'ordre, l'agent en priorité)
  OLLAMA_FLASH_ATTENTION=1
  OLLAMA_KV_CACHE_TYPE=q8_0      cache de contexte compressé : moins de VRAM pour 32 k jetons

Lancer Bourso : npm start  →  http://localhost:3000  (Réglages : choix du modèle, contexte, maintien en mémoire)
Sans GPU ni Ollama : npm run demo (faux serveur Ollama, réponses simulées et étiquetées)`);
} catch (e) {
  console.error(`✖ ${e.message}`);
  process.exitCode = 1;
} finally {
  rmSync(tmp, { recursive: true, force: true });
}

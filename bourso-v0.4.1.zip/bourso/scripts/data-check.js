#!/usr/bin/env node
// ============================================================================
//  BOURSO :: scripts/data-check.js — « npm run data:check »
//  Vérifie, depuis TA machine, que chaque source de données réelles répond : cours et
//  historiques (Yahoo), change (BCE, Frankfurter), actualités (Google, GDELT, flux RSS) et les
//  sources à clé renseignées dans Réglages. Affiche ce qui marche et, sinon, une piste.
//  Code de sortie 0 si les cours réels sont joignables, 1 sinon.
//
//  Options : --sym MC.PA,SAP.DE,AAPL   symboles Yahoo à essayer
//            --data <dossier>          dossier des réglages (par défaut ./data)
// ============================================================================
import { readFile } from 'node:fs/promises';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkSources } from '../src/data/check.js';
import { DEFAULT_FEEDS } from '../src/data/news-real.js';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const arg = (k) => { const i = process.argv.indexOf(k); return i > 0 ? process.argv[i + 1] : null; };
const symbols = (arg('--sym') ?? 'MC.PA,SAP.DE,AAPL').split(',').map((s) => s.trim()).filter(Boolean);
const dataDir = resolve(arg('--data') ?? process.env.BOURSO_DATA ?? join(ROOT, 'data'));
const tty = process.stdout.isTTY;
const c = (code, s) => (tty ? `\x1b[${code}m${s}\x1b[0m` : s);

let keys = {}, feeds = DEFAULT_FEEDS;
try {
  const st = JSON.parse(await readFile(join(dataDir, 'state.json'), 'utf8'));
  keys = st.settings?.data?.keys ?? {};
  if (st.settings?.data?.feeds?.length) feeds = st.settings.data.feeds;
} catch { /* pas encore de réglages : sources sans clé seulement */ }

const nKeys = Object.values(keys).filter(Boolean).length;
console.log(c('1', 'Bourso — vérification des sources de données réelles'));
console.log(c('2', `${new Date().toLocaleString('fr-FR')} · valeurs essayées : ${symbols.join(', ')} · ${nKeys ? `${nKeys} clé(s) renseignée(s)` : 'aucune clé (facultatives)'}`));
console.log(c('2', 'Une requête par source, au rythme normal de Bourso (≈ 20 à 40 s)…\n'));

const r = await checkSources({
  keys, feeds, symbols,
  onResult: (x) => {
    const mark = x.ok ? c('32', '✔') : c(x.essential ? '31' : '33', '✘');
    const ms = c('2', `${x.ms} ms`);
    console.log(`${mark} ${c('2', `[${x.group}]`)} ${x.name} — ${x.ok ? x.detail : c(x.essential ? '31' : '33', x.error)} ${ms}`);
    if (!x.ok && x.hint) console.log(`    ${c('36', '→')} ${x.hint}`);
  },
});

const s = r.summary;
console.log(`\n${s.essentialOk ? c('32;1', '✔') : c('31;1', '✘')} ${s.verdict}`);
console.log(`  cours et historiques : ${s.quotes ? 'oui' : 'non'} · change : ${s.fx ? 'oui' : 'non (taux enregistrés ou indicatifs)'} · actualités : ${s.news ? 'oui' : 'non'}`);
if (!nKeys) console.log(c('2', '  Facultatif : une clé gratuite Finnhub ou FMP ajoute PER, BPA, consensus… (Réglages → Données).'));
console.log(c('2', '  Cours différés (≈ 15 min en Europe) ; Yahoo Finance est un accès public non officiel, pour un usage personnel.'));
process.exit(s.essentialOk ? 0 : 1);

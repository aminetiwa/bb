import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  backend, KalmanFilter, VolumeProfile, KalmanFilterJS, VolumeProfileJS, kalmanParamsFor, findVolumeNodes,
} from '../src/core/math/index.js';

// Générateur reproductible (mulberry32 + Box-Muller)
function rng(seed) {
  let a = seed >>> 0;
  const u = () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const n = () => Math.sqrt(-2 * Math.log(u() + 1e-300)) * Math.cos(2 * Math.PI * u());
  return { u, n };
}

function synthTicks(n, seed = 1) {
  const r = rng(seed);
  const t = new Float64Array(n), px = new Float64Array(n), vol = new Float64Array(n), side = new Float64Array(n);
  let ts = 1.7e15, p = 612.4;
  for (let i = 0; i < n; i++) {
    ts += 50 + Math.floor(r.u() * 2000);               // 50 µs → 2 ms entre ticks
    if (r.u() < 0.001) ts += 40e6;                      // trous de 40 s (enchères)
    p += r.n() * 0.03;
    const q = Math.round(p / 0.1) * 0.1;                // sur la grille du tick
    t[i] = ts; px[i] = r.u() < 0.0005 ? q * 1.08 : q;   // quelques prints aberrants
    vol[i] = 1 + Math.floor(r.u() * 500);
    side[i] = r.u() < 0.5 ? 1 : -1;
  }
  return { t, px, vol, side };
}

test(`backend chargé : ${backend}`, () => {
  assert.ok(['native', 'js'].includes(backend));
});

test('Kalman : natif et JS identiques bit à bit (200k ticks, trous, outliers)', () => {
  const { t, px } = synthTicks(200_000, 3);
  const params = kalmanParamsFor({ price: 612.4, tickSize: 0.1, annualVol: 0.3 });
  const a = new KalmanFilter(params), b = new KalmanFilterJS(params);
  const la = new Float64Array(t.length), sa = new Float64Array(t.length), na = new Float64Array(t.length);
  const lb = new Float64Array(t.length), sb = new Float64Array(t.length), nb = new Float64Array(t.length);
  a.run(t, px, la, sa, na);
  b.run(t, px, lb, sb, nb);
  for (let i = 0; i < t.length; i++) {
    if (la[i] !== lb[i] || sa[i] !== sb[i] || na[i] !== nb[i]) {
      assert.fail(`divergence à i=${i}: ${la[i]} vs ${lb[i]} / ${sa[i]} vs ${sb[i]}`);
    }
  }
  assert.deepEqual(a.state(), b.state());
});

test('Kalman : zero-copy sur vues de SharedArrayBuffer', () => {
  const n = 4096;
  const sab = new SharedArrayBuffer(n * 8 * 3);
  const t = new Float64Array(sab, 0, n), px = new Float64Array(sab, n * 8, n), out = new Float64Array(sab, 2 * n * 8, n);
  for (let i = 0; i < n; i++) { t[i] = 1e15 + i * 1000; px[i] = 100 + 0.02 * Math.sin(i / 400); }
  const kf = new KalmanFilter(kalmanParamsFor({ price: 100, tickSize: 0.01 }));
  assert.equal(kf.run(t.subarray(10, 2010), px.subarray(10, 2010), out.subarray(10, 2010)), 2000);
  assert.ok(Math.abs(out[2009] - px[2009]) < 0.05);
  assert.equal(out[9], 0);                                   // rien écrit hors de la vue
});

test('Kalman : suit une tendance bruitée et estime la pente', () => {
  const r = rng(9);
  const kf = new KalmanFilter({ ...kalmanParamsFor({ price: 100, tickSize: 0.01 }), r: 4e-4 });
  const o = new Float64Array(5);
  let truth = 100, t = 0;
  for (let i = 0; i < 20000; i++) { t += 1e5; truth += 0.001; kf.stepInto(t, truth + r.n() * 0.02, o); }
  assert.ok(Math.abs(o[0] - truth) < 0.02, `niveau ${o[0]} vs ${truth}`);
  assert.ok(Math.abs(o[1] - 0.01) < 0.003, `pente ${o[1]}`);
});

test('Volume Profile : POC / Value Area (CBOT pas 2 et pas 1)', () => {
  const px = Float64Array.from([100.0, 100.1, 100.2, 100.3, 100.4]);
  const vol = Float64Array.from([10, 30, 50, 20, 5]);
  for (const VP of [VolumeProfile, VolumeProfileJS]) {
    const v2 = new VP({ tickSize: 0.1, vaStep: 2 });
    v2.addTrades(px, vol);
    assert.deepEqual([v2.stats().val, v2.stats().poc, v2.stats().vah], [100.0, 100.2, 100.2]);
    const v1 = new VP({ tickSize: 0.1, vaStep: 1 });
    v1.addTrades(px, vol);
    assert.deepEqual([v1.stats().val, v1.stats().vah], [100.1, 100.3]);
  }
});

test('Volume Profile : natif et JS identiques (500k trades, delta, barres)', () => {
  const { px, vol, side } = synthTicks(500_000, 5);
  const a = new VolumeProfile({ tickSize: 0.1, ticksPerRow: 2 }), b = new VolumeProfileJS({ tickSize: 0.1, ticksPerRow: 2 });
  a.addTrades(px, vol, side); b.addTrades(px, vol, side);
  for (let i = 0; i < 1000; i++) { a.addBar(600 + i * 0.05, 599 + i * 0.05, 1000); b.addBar(600 + i * 0.05, 599 + i * 0.05, 1000); }
  assert.deepEqual(a.stats(), b.stats());
  const sa = a.snapshot(), sb = b.snapshot();
  assert.equal(sa.rows, sb.rows);
  assert.equal(sa.lowPrice, sb.lowPrice);
  assert.deepEqual(Array.from(sa.total), Array.from(sb.total));
  assert.deepEqual(Array.from(sa.buy), Array.from(sb.buy));
  const st = a.stats();
  assert.ok(st.valueAreaVolume >= 0.7 * st.totalVolume);
});

test('Volume Profile : binning exact malgré le flottant (712.35 / 0.05)', () => {
  for (const VP of [VolumeProfile, VolumeProfileJS]) {
    const vp = new VP({ tickSize: 0.05 });
    vp.addTrade(712.35, 1);
    assert.equal(vp.snapshot().firstRow, 14247);
    assert.equal(vp.stats().poc, 712.35);
  }
});

test('findVolumeNodes : HVN bimodal et LVN entre les deux', () => {
  const total = new Float64Array(100);
  for (let i = 0; i < 100; i++) total[i] = 100 * Math.exp(-((i - 25) ** 2) / 30) + 80 * Math.exp(-((i - 70) ** 2) / 40) + 1;
  const { hvn, lvn } = findVolumeNodes(total);
  assert.deepEqual(hvn, [25, 70]);
  assert.equal(lvn.length, 1);
  assert.ok(lvn[0] > 40 && lvn[0] < 55, `LVN ${lvn[0]}`);
});

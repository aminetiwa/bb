// Validation des noyaux GPU (WGSL) contre la référence CPU double précision.
//  1) Dawn dans Node (le vrai chemin du serveur), dans un processus à part avec ramasse-miettes
//     forcé entre chaque calcul : régression du plantage « instance Dawn récupérée par le GC ».
//     Carte réelle si le pilote Vulkan est là ; sinon Vulkan logiciel (SwiftShader de Chromium).
//  2) Sinon, si Playwright est installé : mêmes noyaux dans le WebGPU de Chromium.
//  3) Processus GPU isolé : un plantage du « pilote » ne fait pas tomber les calculs (repli CPU).
import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile, readdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { extname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));
let nodeValidated = false;

const PAGE = `<!doctype html><meta charset="utf-8"><title>gpu</title><script type="module">
import { GpuEngine } from '/src/compute/gpu.js';
import { simulateMC, histRange, checkpointSteps } from '/src/core/quant/montecarlo.js';
import { backtest, STRATEGIES, paramGrid } from '/src/core/quant/backtest.js';
import { WorldSim } from '/src/market/sim.js';
import { UNIVERSE } from '/src/market/universe.js';
import { validateGpu } from '/test/fixtures/gpu-validate.js';
window.run = async () => {
  const adapter = await navigator.gpu.requestAdapter();
  const gpu = await GpuEngine.fromAdapter(adapter);
  return validateGpu(gpu, { simulateMC, histRange, checkpointSteps, backtest, STRATEGIES, paramGrid, WorldSim, UNIVERSE });
};
window.ready = true;
</script>`;

async function serve() {
  const MIME = { '.js': 'text/javascript', '.html': 'text/html' };
  const srv = createServer(async (req, res) => {
    const path = decodeURIComponent(new URL(req.url, 'http://x').pathname);
    if (path === '/') return res.writeHead(200, { 'content-type': 'text/html' }).end(PAGE);
    try {
      const file = join(ROOT, path);
      if (!file.startsWith(ROOT) || !(path.startsWith('/src/') || path.startsWith('/test/fixtures/'))) throw new Error('interdit');
      res.writeHead(200, { 'content-type': MIME[extname(file)] ?? 'text/plain' }).end(await readFile(file));
    } catch { res.writeHead(404).end(); }
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  return srv;
}

function checkResults(out) {
  for (const m of out.mc) {
    // mêmes flux aléatoires : les issues de barrière doivent coïncider à quelques trajectoires près (float32)
    const tol = Math.max(3, m.paths * 0.002);
    assert.ok(Math.abs(m.gpu[0] - m.cpu[0]) <= tol, `${m.model} objectif GPU ${m.gpu[0]} / CPU ${m.cpu[0]}`);
    assert.ok(Math.abs(m.gpu[1] - m.cpu[1]) <= tol, `${m.model} stop GPU ${m.gpu[1]} / CPU ${m.cpu[1]}`);
    assert.ok(Math.abs(m.gpu[2] - m.cpu[2]) <= tol, `${m.model} hausse GPU ${m.gpu[2]} / CPU ${m.cpu[2]}`);
    assert.ok(m.l1 <= m.paths * 0.02, `${m.model} histogrammes : écart L1 ${m.l1}`);
  }
  for (const s of out.sweep) assert.ok(s.same >= s.n * 0.95, `${s.id} : ${s.same}/${s.n} combinaisons identiques (écart Sharpe max ${s.maxS})`);
}

/** Pilote Vulkan logiciel fourni avec le Chromium de Playwright (s'il est installé). */
async function swiftShaderIcd() {
  const roots = [process.env.PLAYWRIGHT_BROWSERS_PATH, '/opt/pw-browsers', join(process.env.HOME ?? '', '.cache', 'ms-playwright')].filter(Boolean);
  for (const r of roots) {
    let dirs = [];
    try { dirs = await readdir(r); } catch { continue; }
    for (const d of dirs.filter((x) => x.startsWith('chromium')).sort().reverse()) {
      for (const sub of ['chrome-linux64', 'chrome-linux']) {
        const icd = join(r, d, sub, 'vk_swiftshader_icd.json');
        if (existsSync(icd)) return icd;
      }
    }
  }
  return null;
}

function nodeCheck(env) {
  const r = spawnSync(process.execPath, ['--expose-gc', join(ROOT, 'test', 'fixtures', 'gpu-node-check.mjs')], { env: { ...process.env, ...env }, encoding: 'utf8', timeout: 300_000 });
  if (r.signal || r.status !== 0) return { crashed: true, why: r.signal ?? `code ${r.status}`, stderr: (r.stderr ?? '').slice(-2000) };
  try { return JSON.parse(r.stdout); } catch { return { ok: false, reason: `sortie illisible : ${(r.stdout ?? '').slice(0, 200)}` }; }
}

test('Dawn dans Node ≡ référence CPU, et l’instance survit au ramasse-miettes', async (t) => {
  try { await import('webgpu'); } catch { t.skip('module « webgpu » (Dawn) non installé'); return; }
  let r = nodeCheck({});
  if (!r.crashed && !r.ok && process.platform === 'linux' && !process.env.VK_ICD_FILENAMES) {
    const icd = await swiftShaderIcd();
    if (icd) {
      t.diagnostic(`pas de carte Vulkan utilisable : essai avec le Vulkan logiciel ${icd}`);
      r = nodeCheck({ VK_ICD_FILENAMES: icd });
    }
  }
  assert.ok(!r.crashed, `Dawn a planté dans Node (${r.why}) :\n${r.stderr}`);
  if (!r.ok) { t.skip(`pas d'adaptateur WebGPU dans Node : ${r.reason}`); return; }
  t.diagnostic(`Dawn dans Node : ${r.info.vendor} ${r.info.description}${r.info.software ? ' (logiciel)' : ''}`);
  checkResults(r.out);
  nodeValidated = true;
});

test('GPU (WGSL) dans Chromium ≡ référence CPU (si Dawn n’est pas utilisable dans Node)', async (t) => {
  if (nodeValidated) { t.skip('déjà validé avec Dawn dans Node'); return; }
  let chromium;
  try {
    chromium = createRequire(import.meta.url)('playwright').chromium;
  } catch {
    t.skip('ni Dawn dans Node ni Playwright : test GPU ignoré');
    return;
  }
  const srv = await serve();
  const browser = await chromium.launch({ args: ['--enable-unsafe-webgpu', '--enable-features=Vulkan', '--use-vulkan=swiftshader', '--use-webgpu-adapter=swiftshader', '--disable-vulkan-surface'] });
  try {
    const page = await browser.newPage();
    const logs = [];
    page.on('pageerror', (e) => logs.push(String(e)));
    await page.goto(`http://127.0.0.1:${srv.address().port}/`);
    await page.waitForFunction(() => window.ready === true, null, { timeout: 30_000 });
    const out = await page.evaluate(() => window.run());
    assert.equal(logs.length, 0, logs.join('\n'));
    checkResults(out);
  } finally {
    await browser.close();
    srv.close();
  }
});

test('GPU isolé : un plantage du processus GPU ne fait pas tomber les calculs (repli CPU)', async () => {
  const { ComputeService } = await import('../src/compute/service.js');
  process.env.FAKE_GPU_CRASH_AT = '2';
  const logs = [];
  const c = await ComputeService.create({ gpuHost: pathToFileURL(join(ROOT, 'test', 'fixtures', 'fake-gpu-host.js')), log: (m) => logs.push(m) });
  try {
    assert.equal(c.info().gpu.ok, true, 'faux GPU démarré');
    assert.equal(c.info().gpu.isolated, true);
    const model = { model: 'garch', mu: 0, omega: 1e-6, alpha: 0.05, beta: 0.93, h0: 1e-4 };
    const a = await c.monteCarlo(model, { s0: 100, steps: 10, up: 105, down: 95, paths: 20_000, mode: 'gpu', seed: 1 });
    assert.equal(a.split[0].backend, 'gpu');
    // 2ᵉ calcul : le « pilote » plante → la même tranche est refaite sur le CPU, le résultat est complet
    const b = await c.monteCarlo(model, { s0: 100, steps: 10, up: 105, down: 95, paths: 20_000, mode: 'gpu', seed: 1 });
    assert.match(b.split[0].backend, /repli GPU/);
    assert.equal(b.summary.paths, 20_000);
    assert.ok(b.summary.pTarget.p > 0 && b.summary.pStop.p > 0, 'probabilités calculées sur le CPU');
    const g = c.info().gpu;
    assert.equal(g.ok, false);
    assert.equal(g.crashes, 1);
    assert.match(g.reason, /SIGSEGV/);
    assert.ok(logs.some((m) => /repli sur le CPU/.test(m)));
  } finally {
    await c.close();
    delete process.env.FAKE_GPU_CRASH_AT;
  }
});

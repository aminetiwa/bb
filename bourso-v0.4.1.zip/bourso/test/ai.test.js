// IA : garde-fous, politique de réanalyse, schémas JSON, cerveau simulé (repli sans Ollama).
import test from 'node:test';
import assert from 'node:assert/strict';
import { applyGuardrails } from '../src/ai/guardrails.js';
import { shouldAnalyze } from '../src/ai/change-policy.js';
import { ANALYSE_SCHEMA, conform, parseJsonLoose } from '../src/ai/schemas.js';
import { mockAnalysis, mockAgentTurn } from '../src/ai/mock-brain.js';
import { WorldSim } from '../src/market/sim.js';
import { UNIVERSE } from '../src/market/universe.js';
import { buildDossier, dossierText } from '../src/core/quant/dossier.js';

const plan = (o = {}) => ({ decision: 'BUY', confidence: 0.7, entry: { low: 99.5, high: 100.5 }, invalidation: 97, targets: [104, 108], size_fraction: 0.5, rationale: ['x'], dissent: '', memory_refs: [], ...o });
const features = { price: 100, tick_size: 0.01, spread_ticks: 1, age_ms: 0, session: 'CONTINUOUS', levels: [97, 104, 108], atr: 2, volume_profile: {} };
const bull = { aggregate: { score: 0.5, confidence: 0.7 }, injection_detected: false }, bear = { aggregate: { score: -0.6, confidence: 0.8 }, injection_detected: false };
const qBull = { bias: 0.5, confidence: 0.7, regime: 'TREND_UP', liquidity: 'NORMAL' }, qBear = { bias: -0.6, confidence: 0.8, regime: 'TREND_DOWN', liquidity: 'NORMAL' };

test('garde-fous : plan cohérent accepté, contradictions et stops mal placés neutralisés', () => {
  const ok = applyGuardrails(plan(), { sentiment: bull, quant: qBull, features });
  assert.equal(ok.decision.decision, 'BUY');
  // décision contraire aux deux lectures (actualités ET marché baissiers) → attente
  const contra = applyGuardrails(plan(), { sentiment: bear, quant: qBear, features });
  assert.equal(contra.decision.decision, 'HOLD');
  // achat avec un stop AU-DESSUS du cours : jamais exécutable tel quel
  const bad = applyGuardrails(plan({ invalidation: 103 }), { sentiment: bull, quant: qBull, features });
  assert.ok(bad.decision.decision === 'HOLD' || bad.decision.invalidation < 100, 'stop sous le cours pour un achat');
  // données périmées → attente
  const stale = applyGuardrails(plan(), { sentiment: bull, quant: qBull, features: { ...features, age_ms: 10 * 60_000 } });
  assert.equal(stale.decision.decision, 'HOLD');
  // décision absente → attente, jamais d'exception
  assert.equal(applyGuardrails(null, { features }).decision.decision, 'HOLD');
});

test('garde-fous : stop proportionné à la volatilité (ni dans le bruit, ni trop loin)', () => {
  const f = { ...features, atr: 3, levels: [99.8, 96.5, 93, 110] }; // ATR 3 % : un stop à 0,2 % serait touché par le bruit
  const tight = applyGuardrails(plan({ invalidation: 99.8 }), { sentiment: bull, quant: qBull, features: f });
  if (tight.decision.decision !== 'HOLD') assert.ok(100 - tight.decision.invalidation >= 1.5 - 1e-9, `stop ${tight.decision.invalidation} à ≥ 0,5 ATR`);
  // une valeur agitée a droit à un stop au-delà de 3 % s'il reste sous 2,5 ATR
  const wide = applyGuardrails(plan({ invalidation: 95.5, targets: [109, 115] }), { sentiment: bull, quant: qBull, features: f });
  assert.equal(wide.decision.invalidation, 95.5);
});

test('garde-fous : un STRONG exige accord, confiance et liquidité', () => {
  const weak = applyGuardrails(plan({ decision: 'STRONG_BUY', confidence: 0.6 }), { sentiment: bull, quant: qBull, features });
  assert.equal(weak.decision.decision, 'BUY', 'confiance insuffisante → rétrogradé');
  const illiquid = applyGuardrails(plan({ decision: 'STRONG_BUY', confidence: 0.9 }), { sentiment: bull, quant: { ...qBull, liquidity: 'THIN' }, features });
  assert.notEqual(illiquid.decision.decision, 'STRONG_BUY');
});

test('politique de réanalyse : on n’appelle le modèle que s’il y a du nouveau', () => {
  const t = 1_800_000_000_000;
  assert.equal(shouldAnalyze(null, { ts: t, price: 100 }).run, true);
  assert.equal(shouldAnalyze({ ts: t, price: 100 }, { ts: t + 30_000, price: 110 }).run, false, 'jamais deux fois en moins de 2 min');
  assert.equal(shouldAnalyze({ ts: t, price: 100 }, { ts: t + 600_000, price: 100.1 }).run, false, 'rien de nouveau');
  assert.equal(shouldAnalyze({ ts: t, price: 100 }, { ts: t + 600_000, price: 101 }).run, true, 'cours qui bouge');
  assert.equal(shouldAnalyze({ ts: t, price: 100, newsIds: ['a'] }, { ts: t + 600_000, price: 100, newsIds: ['a', 'b'] }).run, true, 'actualité nouvelle');
  assert.equal(shouldAnalyze({ ts: t, price: 100 }, { ts: t + 3 * 3600_000, price: 100 }).run, true, 'rafraîchissement périodique');
});

test('JSON du modèle : lecture tolérante et conformité au schéma', () => {
  const p = parseJsonLoose('Voici :\n```json\n{"a": 1, "b": [1,2,], "c": "x, ]"}\n```');
  assert.equal(p.ok, true);
  assert.equal(p.value.a, 1);
  assert.deepEqual(p.value.b, [1, 2]);
  assert.equal(p.value.c, 'x, ]', 'les chaînes ne sont pas modifiées');
  assert.equal(parseJsonLoose('pas de json').ok, false);
  const bad = conform(ANALYSE_SCHEMA, { decision: 'ACHETER' });
  assert.equal(bad.ok, false);
});

test('cerveau simulé : analyse conforme au schéma à partir d’un vrai dossier, agent qui appelle des outils', () => {
  const sub = UNIVERSE.filter((x) => x.mic === 'XPAR').slice(0, 6);
  const sim = new WorldSim({ universe: sub, dailyDays: 400, intraDays: 2, secDays: 1 });
  const sym = sub[0].sym, d = sim.daily(sym), q = sim.quote(sym), x = sim.get(sym);
  const D = buildDossier({
    meta: { ...x.meta, exchangeName: x.ex.name }, now: { session: 'CONTINUOUS', time: '10:00:00', date: x.clk.today }, quote: q,
    daily: { open: d.open, high: d.high, low: d.low, close: d.close, volume: d.volume }, dailyDates: d.dates, news: [], fundamentals: x.fund,
  });
  const text = dossierText(D);
  assert.ok(text.includes('## FAITS SAILLANTS') && text.includes('## ANALOGUES'));
  const a = mockAnalysis(text);
  const c = conform(ANALYSE_SCHEMA, a);
  assert.equal(c.ok, true, c.errors?.join(' ; '));
  const tools = ['rechercher_valeur', 'cotation', 'analyse_technique'].map((name) => ({ type: 'function', function: { name, parameters: {} } }));
  const turn = mockAgentTurn([{ role: 'system', content: `VALEUR AFFICHÉE : ${x.meta.name} (${sym})` }, { role: 'user', content: 'Analyse technique de cette valeur ?' }], tools);
  assert.ok(turn.tool_calls?.length > 0, 'appelle au moins un outil');
});

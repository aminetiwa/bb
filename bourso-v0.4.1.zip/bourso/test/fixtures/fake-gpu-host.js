// Faux processus GPU pour les tests : se déclare prêt, répond au 1er calcul par un résultat vide
// valide, puis « plante » (SIGSEGV) au calcul suivant — comme un pilote défaillant.
const send = (m) => { try { process.send?.(m); } catch { /* parent parti */ } };
process.on('disconnect', () => process.exit(0));
let n = 0;
send({ t: 'ready', info: { vendor: 'test', architecture: 'faux', device: 'faux', description: 'GPU de test', fallback: false, software: false, limits: {} }, pid: process.pid });
process.on('message', (m) => {
  if (m?.t === 'exit') process.exit(0);
  if (m?.t !== 'job') return;
  if (++n >= Number(process.env.FAKE_GPU_CRASH_AT ?? 2)) process.kill(process.pid, 'SIGSEGV');
  const s = m.spec, bins = s.bins ?? 2048, paths = (s.pathTo ?? 0) - (s.pathFrom ?? 0);
  // résultat neutre : toutes les trajectoires dans la classe centrale
  const hist = new Uint32Array(bins); hist[bins >> 1] = paths;
  send({ t: 'done', id: m.id, ok: true, result: { backend: 'gpu', hist, cpHist: new Uint32Array((s.checkpoints ?? []).length * bins), sum: 0, sum2: 0, minSum: 0, upCount: 0, hitUp: 0, hitDown: 0, paths, ms: 1, bins } });
});

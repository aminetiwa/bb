// Validation des noyaux GPU contre la référence CPU double précision — logique commune au
// navigateur (Chromium/Playwright) et à Node (Dawn). Les dépendances sont injectées pour que le
// même code tourne avec des chemins d'import différents. `between()` est appelé entre deux calculs
// (dans Node : ramasse-miettes forcé, pour vérifier que l'instance Dawn survit).
export async function validateGpu(gpu, { simulateMC, histRange, checkpointSteps, backtest, STRATEGIES, paramGrid, WorldSim, UNIVERSE }, between = async () => {}) {
  const out = { info: gpu.info, mc: [], sweep: [] };
  for (const model of ['garch', 'bootstrap']) {
    const spec = { model, s0: 100, steps: 200, paths: 6000, seed: 9, mu: 0.0002, omega: 2e-6, alpha: 0.07, beta: 0.91, h0: 1e-4, uncondVar: 1e-4, up: 108, down: 94, bins: 2048,
      returns: Float64Array.from({ length: 500 }, (_, i) => 0.01 * Math.sin(i * 1.3) + 0.002 * Math.cos(i * 7.1)), block: 8 };
    const range = histRange(spec), cps = checkpointSteps(spec.steps);
    const ref = simulateMC({ ...spec, range, checkpoints: cps });
    await between();
    const g = await gpu.monteCarlo({ ...spec, rangeLo: range.lo, rangeHi: range.hi, checkpoints: cps, pathFrom: 0, pathTo: spec.paths });
    let l1 = 0;
    for (let i = 0; i < 2048; i++) l1 += Math.abs(g.hist[i] - ref.hist[i]);
    out.mc.push({ model, gpu: [g.hitUp, g.hitDown, g.upCount, g.sum], cpu: [ref.hitUp, ref.hitDown, ref.upCount, ref.sum], l1, paths: spec.paths });
  }
  const sim = new WorldSim({ universe: UNIVERSE.filter((x) => x.sym === 'SAP:XETR'), dailyDays: 800 });
  const d = sim.daily('SAP:XETR');
  const codes = { ema_cross: 0, sma_cross: 1, rsi_revert: 2, boll_revert: 3, donchian_break: 4, macd_cross: 5 };
  for (const [id, code] of Object.entries(codes)) {
    const grid = paramGrid(STRATEGIES[id]).slice(0, 60), keys = Object.keys(STRATEGIES[id].grid), P = keys.length;
    const params = new Float64Array(grid.length * P);
    grid.forEach((g, i) => keys.forEach((k, j) => { params[i * P + j] = g[k]; }));
    await between();
    const r = await gpu.sweep({ open: d.open, high: d.high, low: d.low, close: d.close, strategy: code, params, K: grid.length, P, costBps: 5 });
    let same = 0, maxS = 0;
    grid.forEach((p, i) => {
      const m = backtest(d, id, p, { costBps: 5 }).metrics;
      const ds = Math.abs(r.metrics[i * 10 + 2] - m.sharpe), dt = Math.abs(r.metrics[i * 10 + 5] - m.trades);
      if (dt === 0 && ds < 2e-3) same++;
      maxS = Math.max(maxS, ds);
    });
    out.sweep.push({ id, n: grid.length, same, maxS });
  }
  return out;
}

import { workerData, parentPort } from 'node:worker_threads';
import { SoARing } from '../../src/core/shm/soa-ring.js';

const ring = SoARing.from(workerData.ring);
let i = 0;
while (i < workerData.count) {
  const slot = ring.claim();
  if (slot < 0) continue;            // plein : on réessaie (backpressure active)
  ring.col.seq[slot] = i;
  ring.col.val[slot] = i * 0.5;
  ring.commit();
  i++;
}
parentPort.postMessage('done');

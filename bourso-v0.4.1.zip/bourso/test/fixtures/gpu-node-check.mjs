// Lancé par test/gpu.test.js dans un processus à part (node --expose-gc) : Dawn dans Node,
// validation complète avec ramasse-miettes forcé entre chaque calcul. Écrit un JSON sur stdout.
import { GpuEngine } from '../../src/compute/gpu.js';
import { simulateMC, histRange, checkpointSteps } from '../../src/core/quant/montecarlo.js';
import { backtest, STRATEGIES, paramGrid } from '../../src/core/quant/backtest.js';
import { WorldSim } from '../../src/market/sim.js';
import { UNIVERSE } from '../../src/market/universe.js';
import { validateGpu } from './gpu-validate.js';

const { engine, reason } = await GpuEngine.create();
if (!engine) {
  process.stdout.write(JSON.stringify({ ok: false, reason }));
  process.exit(0);
}
const between = async () => {
  globalThis.gc?.();
  await new Promise((r) => setTimeout(r, 5));
  globalThis.gc?.();
};
const out = await validateGpu(engine, { simulateMC, histRange, checkpointSteps, backtest, STRATEGIES, paramGrid, WorldSim, UNIVERSE }, between);
engine.destroy();
process.stdout.write(JSON.stringify({ ok: true, info: engine.info, out }));
process.exit(0);

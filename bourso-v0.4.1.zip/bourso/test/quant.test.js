// Tests de précision du moteur quantitatif (src/core/quant).
import test from 'node:test';
import assert from 'node:assert/strict';
import * as N from '../src/core/quant/numeric.js';
import * as I from '../src/core/quant/indicators.js';
import * as V from '../src/core/quant/volatility.js';
import * as S from '../src/core/quant/stats.js';
import { fitHmm, fitHmmAuto } from '../src/core/quant/hmm.js';
import { dominantCycles, cycleAnalysis } from '../src/core/quant/fft.js';
import { historicalAnalogs } from '../src/core/quant/analogs.js';
import { simulate, backtest, walkForward, STRATEGIES, paramGrid } from '../src/core/quant/backtest.js';
import { simulateMC, summarizeMC, mergeMC, exactQuantiles, histQuantile } from '../src/core/quant/montecarlo.js';
import { technicalRating } from '../src/core/quant/signals.js';
import { buildDossier, dossierText } from '../src/core/quant/dossier.js';
import { marketProfile } from '../src/core/quant/tpo.js';
import { scoreText } from '../src/core/quant/sentiment.js';

const close = (a, b, tol, msg) => assert.ok(Math.abs(a - b) <= tol, `${msg ?? ''} ${a} ≠ ${b} (tolérance ${tol})`);

/** Série OHLCV synthétique (marche aléatoire log-normale, tick 0,01). */
function series(n, seed = 7, s0 = 100, vol = 0.015) {
  const r = new N.Rng(seed), o = new Float64Array(n), h = new Float64Array(n), l = new Float64Array(n), c = new Float64Array(n), v = new Float64Array(n);
  let p = s0;
  for (let i = 0; i < n; i++) {
    const op = p * Math.exp(r.normal() * vol * 0.2);
    p = op * Math.exp(r.normal() * vol);
    o[i] = N.roundTick(op, 0.01); c[i] = N.roundTick(p, 0.01);
    h[i] = N.roundTick(Math.max(o[i], c[i]) * (1 + Math.abs(r.normal()) * vol * 0.4), 0.01);
    l[i] = N.roundTick(Math.min(o[i], c[i]) * (1 - Math.abs(r.normal()) * vol * 0.4), 0.01);
    v[i] = Math.round(1000 + r.next() * 9000);
  }
  return { open: o, high: h, low: l, close: c, volume: v };
}

/**
 * Φ(x) de RÉFÉRENCE en arithmétique entière exacte (virgule fixe 10^-110 avec BigInt) :
 * Φ(x) = 1/2 + φ(x)·Σ x^(2k+1)/(1·3·5…(2k+1)), φ(x) = e^(−x²/2)/√(2π). x : décimal exact (chaîne).
 */
function phiRef(xs) {
  const SC = 10n ** 110n;
  const [ip, fp = ''] = xs.replace('-', '').split('.');
  const neg = xs.startsWith('-'), den = 10n ** BigInt(fp.length), num = BigInt(ip + fp) * (neg ? -1n : 1n);
  // e^(x²/2) par Taylor (termes positifs), puis inversion
  const aN = num * num, aD = 2n * den * den;
  let term = SC, ea = SC;
  for (let k = 1n; term > 0n; k++) { term = (term * aN) / (aD * k); ea += term; }
  const emA = (SC * SC) / ea;
  // √(2π) par Newton en virgule fixe
  const PIDIGITS = 31415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679821480865132823n;
  const PI = (PIDIGITS * SC) / 10n ** BigInt(PIDIGITS.toString().length - 1);
  const twoPi = 2n * PI;
  let s = SC * 2n;
  for (let i = 0; i < 200; i++) s = (s + (twoPi * SC) / s) / 2n;
  // série de Marsaglia
  let t = (num * SC) / den, sum = t;
  for (let k = 1n; t !== 0n; k++) { t = (t * num * num) / (den * den * (2n * k + 1n)); sum += t; }
  const phi = (emA * SC) / s;
  const val = SC / 2n + (phi * sum) / SC;
  const shift = val.toString().length - 20; // 20 chiffres significatifs exacts
  return Number(val / 10n ** BigInt(shift)) * 10 ** (shift - 110);
}

test('loi normale : Φ et Φ⁻¹ en pleine précision (référence exacte à 100 chiffres)', () => {
  for (const xs of ['1.96', '0.5', '-0.25', '-1.5', '-2', '-3', '-4.5', '-6', '-8', '-10']) {
    const ref = phiRef(xs), got = N.normCdf(Number(xs));
    assert.ok(Math.abs(got / ref - 1) < 2e-15, `Φ(${xs}) = ${got}, référence ${ref}, erreur relative ${Math.abs(got / ref - 1)}`);
  }
  close(N.normInv(0.975), 1.959963984540054, 1e-14);
  for (const p of [1e-12, 1e-6, 0.01, 0.3, 0.5, 0.77, 0.999]) assert.ok(Math.abs(N.normCdf(N.normInv(p)) / p - 1) < 1e-13, `aller-retour p=${p}`);
});

test('sommes compensées : Neumaier exact là où la somme naïve échoue', () => {
  const x = [1e16, 1, -1e16];
  assert.equal(x.reduce((a, b) => a + b, 0), 0);
  assert.equal(N.sum(x), 1);
  const acc = new N.Neumaier();
  for (let i = 0; i < 1e6; i++) acc.add(0.1);
  close(acc.value, 1e5, 1e-9);
});

test('arrondi exact au pas de cotation', () => {
  assert.equal(N.roundTick(0.15000000000000002, 0.05), 0.15);
  assert.equal(N.roundTick(712.3499999, 0.05), 712.35);
  assert.equal(N.decimalsOf(0.005), 3);
});

test('moyennes glissantes O(1) identiques au calcul naïf sur 100 000 bougies', () => {
  const d = series(100_000), c = d.close;
  const naiveSma = (n, i) => { let s = 0; for (let j = i - n + 1; j <= i; j++) s += c[j]; return s / n; };
  const naiveWma = (n, i) => { let s = 0; for (let k = 0; k < n; k++) s += (k + 1) * c[i - n + 1 + k]; return s / ((n * (n + 1)) / 2); };
  const sma = I.sma(c, 50), wma = I.wma(c, 30), std = I.rollingStd(c, 20);
  for (const i of [49, 1000, 4095, 4096, 50_000, 99_999]) {
    close(sma[i], naiveSma(50, i), 1e-10, `SMA[${i}]`);
    if (i >= 29) close(wma[i], naiveWma(30, i), 1e-10, `WMA[${i}]`);
    if (i >= 19) {
      const m = naiveSma(20, i);
      let v = 0;
      for (let j = i - 19; j <= i; j++) v += (c[j] - m) ** 2;
      close(std[i], Math.sqrt(v / 20), 1e-10, `σ[${i}]`);
    }
  }
  assert.ok(Number.isNaN(sma[48]));
});

test('VWAP exact (arithmétique rationnelle BigInt) sur des ticks entiers', () => {
  const r = new N.Rng(3), n = 20_000, p = new Float64Array(n), v = new Float64Array(n);
  let num = 0n, den = 0n;
  for (let i = 0; i < n; i++) {
    const ticks = 600_000 + r.int(20_000), q = 1 + r.int(5000);
    p[i] = ticks / 1000; v[i] = q;
    num += BigInt(ticks) * BigInt(q); den += BigInt(q);
  }
  const vw = I.vwap(p, p, p, v).mid[n - 1];
  const exact = Number(num * 10n ** 12n / den) / 1e15; // ticks → prix (÷1000), 12 décimales exactes
  assert.ok(Math.abs(vw / exact - 1) < 1e-14, `VWAP ${vw} vs exact ${exact}`);
});

test('RSI de Wilder, MACD, Bollinger, ATR : cohérence des définitions', () => {
  const d = series(600), c = d.close;
  const r = I.rsi(c, 14);
  assert.ok(r.slice(14).every((x) => x >= 0 && x <= 100));
  const up = new Float64Array(40).map((_, i) => 100 + i);
  assert.equal(I.rsi(up, 14)[30], 100);
  const m = I.macd(c), e12 = I.ema(c, 12), e26 = I.ema(c, 26);
  close(m.line[500], e12[500] - e26[500], 1e-12);
  const b = I.bollinger(c, 20, 2);
  close(b.up[300] - b.mid[300], 2 * b.sd[300], 1e-12);
  const a = I.atr(d.high, d.low, c, 14);
  assert.ok(a[100] > 0 && a[100] < 10);
  const st = I.stoch(d.high, d.low, c);
  assert.ok(st.k.slice(20).every((x) => x >= 0 && x <= 100));
  const ax = I.adx(d.high, d.low, c);
  assert.ok(ax.adx[200] >= 0 && ax.adx[200] <= 100);
  const ps = I.psar(d.high, d.low);
  assert.ok(Number.isFinite(ps.sar[300]));
  const ich = I.ichimoku(d.high, d.low, c);
  close(ich.spanA[200], ich.spanAraw[174], 0);
});

test('ZigZag : sommets et creux alternés', () => {
  const d = series(2000, 11);
  const z = I.zigzag(d.high, d.low, { pct: 0.04 });
  assert.ok(z.swings.length > 10);
  for (let k = 1; k < z.swings.length; k++) assert.notEqual(z.swings[k].type, z.swings[k - 1].type);
});

test('statistiques : AR(1), Hurst, ratio de variance, ADF, moments', () => {
  const r = new N.Rng(5), n = 6000, iid = new Float64Array(n), ar = new Float64Array(n), rw = new Float64Array(n);
  let x = 0, w = 0;
  for (let i = 0; i < n; i++) {
    iid[i] = r.normal();
    x = 0.6 * x + r.normal(); ar[i] = x;
    w += r.normal(); rw[i] = w;
  }
  close(S.autocorr(ar, 1), 0.6, 0.04, 'autocorrélation AR(1)');
  close(S.hurst(iid), 0.5, 0.08, 'Hurst bruit blanc');
  close(S.varianceRatio(iid, 5).vr, 1, 0.08, 'VR bruit blanc');
  assert.ok(S.adf(ar).stationary, 'AR(1) stationnaire');
  assert.ok(!S.adf(rw).stationary, 'marche aléatoire non stationnaire');
  const mo = S.moments(iid);
  // erreurs standard à n = 6000 : asymétrie 0,032 ; kurtosis 0,063 → tolérance ≈ 4,5 ET
  close(mo.mean, 0, 0.05); close(mo.sd, 1, 0.05); close(mo.skew, 0, 0.15); close(mo.kurt, 0, 0.3);
  close(S.halfLife(ar), Math.LN2 / -Math.log(0.6), 0.5, 'demi-vie OU');
  const dd = S.drawdowns(Float64Array.of(100, 120, 90, 110, 130, 104));
  close(dd.maxDD, -0.25, 1e-12);
  close(dd.current, -0.2, 1e-12);
});

test('GARCH(1,1) : paramètres retrouvés par maximum de vraisemblance', () => {
  const r = new N.Rng(9), n = 8000, x = new Float64Array(n);
  const omega = 2e-6, alpha = 0.08, beta = 0.9;
  let h = omega / (1 - alpha - beta);
  for (let i = 0; i < n; i++) {
    const e = Math.sqrt(h) * r.normal();
    x[i] = e;
    h = omega + alpha * e * e + beta * h;
  }
  const fit = V.garch11(x);
  close(fit.alpha, alpha, 0.03, 'α'); close(fit.beta, beta, 0.04, 'β');
  assert.ok(fit.persistence < 1);
});

test('volatilité : estimateurs cohérents sur une marche log-normale', () => {
  const d = series(3000, 21, 100, 0.01);
  const cc = V.closeToClose(d.close, 2000, 252), pk = V.parkinson(d.high, d.low, 2000, 252), yz = V.yangZhang(d.open, d.high, d.low, d.close, 2000, 252);
  assert.ok(cc > 0.1 && cc < 0.3, `close-to-close ${cc}`);
  assert.ok(pk > 0 && yz > 0);
});

test('HMM gaussien : deux régimes retrouvés', () => {
  const r = new N.Rng(2), x = [];
  let st = 0;
  for (let i = 0; i < 3000; i++) {
    if (r.next() < 0.01) st = 1 - st;
    x.push(st ? 0.002 + 0.005 * r.normal() : -0.001 + 0.02 * r.normal());
  }
  const m = fitHmm(x, { K: 2, restarts: 4 });
  const calm = m.sd[0] < m.sd[1] ? 0 : 1;
  close(m.sd[calm], 0.005, 0.0015, 'σ régime calme');
  close(m.sd[1 - calm], 0.02, 0.004, 'σ régime agité');
  assert.ok(m.A[0][0] > 0.95 && m.A[1][1] > 0.95, 'persistance des régimes');
  const pSum = m.filtered.reduce((a, b) => a + b, 0);
  close(pSum, 1, 1e-9);
});

test('FFT : cycle de 37 bougies retrouvé dans le bruit', () => {
  const r = new N.Rng(4), n = 740, c = new Float64Array(n);
  for (let i = 0; i < n; i++) c[i] = 100 * Math.exp(0.03 * Math.sin((2 * Math.PI * i) / 37) + 0.0004 * i + 0.004 * r.normal());
  const cyc = dominantCycles(c, { minPeriod: 8, maxPeriod: 200 });
  close(cyc[0].period, 37, 0.8, 'période dominante');
});

test('HMM régularisé : pas d’« état » bâti sur quelques jours extrêmes ; BIC comparé au modèle à 1 état', () => {
  const r = new N.Rng(7), x = [];
  for (let i = 0; i < 1000; i++) x.push(0.0003 + 0.015 * r.normal() + (i % 63 === 0 ? 0.06 * r.normal() : 0)); // bruit + ~16 « publications »
  const m = fitHmm(x, { K: 3, restarts: 6 });
  for (const s of m.states) assert.ok(!(s.occupancyPosterior < 0.02 && Math.abs(s.mu) > 0.02), `état dégénéré ${s.label} μ=${s.mu}`);
  const auto = fitHmmAuto(x, { Ks: [2, 3], restarts: 4 });
  assert.equal(auto.selection[0].K, 1);
  assert.equal(auto.regimesSupported, false, 'une loi unique (avec sauts) ne doit pas passer pour des régimes');
  // de vrais régimes, eux, sont reconnus
  const y = [];
  let st = 0;
  for (let i = 0; i < 2000; i++) { if (r.next() < 0.01) st = 1 - st; y.push(st ? 0.001 + 0.006 * r.normal() : -0.001 + 0.022 * r.normal()); }
  assert.equal(fitHmmAuto(y, { Ks: [2, 3], restarts: 4 }).regimesSupported, true);
});

test('FFT : marche aléatoire sans cycle significatif, sinusoïde nettement significative', () => {
  let fp = 0;
  for (let k = 0; k < 20; k++) {
    const r = new N.Rng(100 + k), c = new Float64Array(512);
    let lp = Math.log(100);
    for (let i = 0; i < 512; i++) { lp += 0.015 * r.normal(); c[i] = Math.exp(lp); }
    if (cycleAnalysis(c, { minPeriod: 5, maxPeriod: 170, top: 6 }).cycles.some((cy) => cy.significant)) fp++;
  }
  assert.ok(fp <= 3, `faux positifs au seuil global : ${fp} / 20`);
  const r = new N.Rng(5), c = new Float64Array(512);
  for (let i = 0; i < 512; i++) c[i] = 100 * Math.exp(0.05 * Math.sin((2 * Math.PI * i) / 40) + 0.004 * r.normal());
  const a = cycleAnalysis(c, { minPeriod: 5, maxPeriod: 170 });
  close(a.cycles[0].period, 40, 0.8);
  assert.ok(a.cycles[0].significant && a.cycles[0].share > 0.5);
});

test('analogues historiques : aucune fuite du futur, test calibré sur une marche aléatoire', () => {
  let sig = 0, n = 0;
  for (let k = 0; k < 30; k++) {
    const r = new N.Rng(500 + k), N0 = 1200, close_ = new Float64Array(N0), vol = new Float64Array(N0);
    let lp = Math.log(50);
    for (let i = 0; i < N0; i++) { lp += 0.0002 + 0.017 * r.normal(); close_[i] = Math.exp(lp); vol[i] = 1e5 * Math.exp(0.3 * r.normal()); }
    const a = historicalAnalogs({ close: close_, volume: vol }, { k: 30, horizons: [5, 20] });
    assert.ok(a, 'analogues trouvés');
    for (const nb of a.nearest) assert.ok(nb.t + 20 <= N0 - 1 - 20, 'horizon terminé 20 séances avant aujourd’hui');
    for (const h of a.horizons) { n++; if (h.significant) sig++; }
  }
  assert.ok(sig / n <= 0.12, `trop de « signaux » sur du pur hasard : ${sig} / ${n}`);
});

test('backtest : exécution à l’ouverture suivante (aucune anticipation possible)', () => {
  const d = { open: Float64Array.of(100, 110, 120, 90, 95), high: Float64Array.of(101, 111, 121, 91, 96), low: Float64Array.of(99, 109, 119, 89, 94),
    close: Float64Array.of(100, 112, 118, 92, 96), volume: new Float64Array(5).fill(1) };
  const pos = Int8Array.of(1, 1, 0, 0, 0);
  const { ret, trades } = simulate(d, pos, { costBps: 0 });
  close(ret[1], Math.log(112 / 110), 1e-15, 'entrée à l’ouverture de la bougie 1');
  close(ret[2], Math.log(118 / 112), 1e-15);
  close(ret[3], Math.log(90 / 118), 1e-15, 'sortie à l’ouverture de la bougie 3 (gap de nuit encaissé)');
  assert.equal(ret[4], 0);
  assert.equal(trades.length, 1);
  close(trades[0].ret, Math.log(90 / 110), 1e-14);
  // une décision prise à la clôture de t (ici : « la bougie t a monté ») ne doit JAMAIS encaisser le
  // rendement de la bougie t elle-même. Sur une marche aléatoire, le gain attendu est alors ≈ 0 ;
  // un moteur qui l'appliquerait à la même bougie gagnerait Σ max(r, 0) ≈ +18.
  const s = series(3000, 12), same = new Int8Array(3000);
  for (let t = 1; t < 3000; t++) same[t] = s.close[t] > s.close[t - 1] ? 1 : 0;
  const res = simulate(s, same, { costBps: 0 });
  let gain = 0;
  for (const x of res.ret) gain += x;
  assert.ok(Math.abs(gain) < 3, `aucune anticipation : gain ${gain}`);
});

test('backtest & walk-forward : stratégies et grille', () => {
  const d = series(1500, 31);
  assert.ok(paramGrid(STRATEGIES.ema_cross).every((p) => p.fast < p.slow));
  const b = backtest(d, 'ema_cross', { fast: 10, slow: 50 });
  assert.ok(Number.isFinite(b.metrics.sharpe) && b.metrics.trades > 0);
  const wf = walkForward(d, 'rsi_revert', { folds: 3 });
  assert.equal(wf.chosen.length, 3);
  assert.ok(Number.isFinite(wf.oos.sharpe));
});

test('Monte Carlo : franchissement de barrières exact grâce au pont brownien', () => {
  // mouvement brownien sans dérive : P(toucher +u avant −d) = d / (u + d), exactement
  const s0 = 100, u = 0.05, dlt = 0.03, sd = 0.02;
  const spec = { model: 'garch', mu: 0, omega: sd * sd, alpha: 0, beta: 0, h0: sd * sd, uncondVar: sd * sd, s0, steps: 400, paths: 60_000, seed: 77,
    up: s0 * Math.exp(u), down: s0 * Math.exp(-dlt) };
  const res = summarizeMC(simulateMC(spec), s0);
  const exact = dlt / (u + dlt);
  assert.ok(Math.abs(res.pTarget.p - exact) < 4 * res.pTarget.se, `P(objectif) ${res.pTarget.p} vs ${exact} ± ${res.pTarget.se}`);
  assert.ok(res.pNone.p < 1e-3);
  // découpage multi-cœurs : même résultat exact que d'un seul tenant
  const a = simulateMC({ ...spec, paths: 4000, pathFrom: 0, pathTo: 1500 }), b = simulateMC({ ...spec, paths: 4000, pathFrom: 1500, pathTo: 4000 });
  const whole = simulateMC({ ...spec, paths: 4000 }), merged = mergeMC([a, b]);
  assert.equal(merged.hitUp, whole.hitUp);
  assert.deepEqual(Array.from(merged.hist), Array.from(whole.hist));
});

test('Monte Carlo : quantiles de l’histogramme vs quantiles exacts', () => {
  const sd = 0.01, spec = { model: 'garch', mu: 0.0002, omega: 2e-6, alpha: 0.06, beta: 0.92, h0: sd * sd, uncondVar: 2e-6 / 0.02, s0: 50, steps: 50, paths: 40_000, seed: 5, keepFinals: true, bins: 4096 };
  const r = simulateMC(spec), ex = exactQuantiles(r.finals);
  for (const q of [0.05, 0.5, 0.95]) close(histQuantile(r.hist, r.range, q), ex[q], (r.range.hi - r.range.lo) / r.bins, `q${q}`);
});

test('résumé technique et dossier complet', () => {
  const d = series(1300, 41, 80, 0.012);
  const t = technicalRating(d);
  assert.ok(t.rating >= -1 && t.rating <= 1);
  assert.equal(t.details.length, 26);
  const sb = 510, intra = series(sb * 6, 43, d.close[1299], 0.0008);
  const dos = buildDossier({
    meta: { sym: 'TST:XPAR', code: 'TST', name: 'Test SA', tick: 0.01, currency: 'EUR', sector: 'Industrie', exchangeName: 'Euronext Paris', country: 'FR' },
    quote: { last: intra.close.at(-1), prev: d.close.at(-1), open: intra.open[sb * 5], high: 90, low: 70, volume: 120000, bid: intra.close.at(-1) - 0.01, ask: intra.close.at(-1) },
    daily: d, intraday: intra, sessionBars: sb, todayFrom: sb * 5,
    book: { bids: [[79.9, 500], [79.89, 400]], asks: [[80, 300], [80.01, 300]] }, flow: { buyVol: 60000, sellVol: 40000 },
    news: [{ title: 'Test SA relève ses prévisions annuelles', minutesAgo: 30 }],
  });
  assert.ok(dos.faits.length > 3);
  assert.ok(dos.sections.regime && dos.sections.technique.quotidien);
  assert.ok(dos.scores.global >= -1 && dos.scores.global <= 1);
  const txt = dossierText(dos);
  assert.ok(txt.includes('FAITS SAILLANTS') && txt.length > 2000);
});

test('Market Profile (TPO) et tonalité des actualités', () => {
  const d = series(510, 51, 50, 0.0015);
  const tpo = marketProfile({ high: d.high, low: d.low, periodBars: 30, tick: 0.01 });
  assert.ok(tpo.val <= tpo.poc && tpo.poc <= tpo.vah);
  assert.ok(scoreText('Le groupe relève fortement ses prévisions').score > 0.3);
  assert.ok(scoreText('Avertissement sur résultats : pertes et dette en hausse').score < 0);
  assert.ok(scoreText("L'entreprise ne relève pas ses objectifs").score < 0);
});

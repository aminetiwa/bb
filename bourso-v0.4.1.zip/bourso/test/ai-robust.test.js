// IA robuste : schéma envoyé à Ollama, lecture tolérante des réponses, JSON coupé, anti-boucle,
// choix automatique du modèle, explication des erreurs d'Ollama — puis, de bout en bout avec un faux
// Ollama, des modèles volontairement défaillants (brouillon, boucle, radotage, muet, droits refusés).
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { ANALYSE_SCHEMA, SENTIMENT_SCHEMA, QUANT_SCHEMA, GENERAL_SCHEMA, ANALYST_SCHEMA, QUESTIONS_SCHEMA, ANSWER_SCHEMA } from '../src/ai/schemas.js';
import { toOllamaFormat } from '../src/ai/ollama-client.js';
import { salvage, closeJson, readJson, parseNumber, matchEnum, patchSchema, applyPatch } from '../src/ai/repair.js';
import { detectLoop, LoopGuard, callKey } from '../src/ai/loop-guard.js';
import { explainOllamaError } from '../src/ai/ollama-diag.js';
import { bestChatModel } from '../src/ai/analysis.js';
import { mockAnalysis } from '../src/ai/mock-brain.js';
import { startMockOllama } from '../src/ai/mock-ollama-server.js';
import { startServer } from '../src/server/main.js';

const ROOT = new URL('..', import.meta.url);

/** Tous les objets d'un schéma : chaque champ requis doit être décrit dans `properties`. */
function requiredDescribed(s, path = '$', out = []) {
  if (!s || typeof s !== 'object') return out;
  if (s.type === 'object') {
    for (const r of s.required ?? []) if (!s.properties?.[r]) out.push(`${path}.${r}`);
    for (const [k, sub] of Object.entries(s.properties ?? {})) requiredDescribed(sub, `${path}.${k}`, out);
  }
  if (s.type === 'array') requiredDescribed(s.items, `${path}[]`, out);
  return out;
}

test('schéma envoyé à Ollama : les NOMS de champs sont gardés (régression « description »)', () => {
  for (const [name, sch] of Object.entries({ ANALYSE_SCHEMA, SENTIMENT_SCHEMA, QUANT_SCHEMA, GENERAL_SCHEMA, ANALYST_SCHEMA, QUESTIONS_SCHEMA, ANSWER_SCHEMA })) {
    const f = toOllamaFormat(sch);
    assert.deepEqual(requiredDescribed(f), [], `${name} : champ requis absent de la grammaire`);
    assert.ok(!JSON.stringify(f).includes('"maxLength"'), `${name} : mots-clés de bornes retirés`);
  }
  const sc = toOllamaFormat(ANALYSE_SCHEMA).properties.scenarios.items.properties;
  assert.deepEqual(Object.keys(sc), ['name', 'probability', 'target', 'description']);
});

test('lecture tolérante : réponse sans descriptions, puis réponse « à la main » d’un modèle sans grammaire', () => {
  const a = mockAnalysis('global: 0.1\ndernier: 55.88\natr14: 1.2');
  const noDesc = { ...a, scenarios: a.scenarios.map(({ description, ...x }) => x) };
  const r = salvage(ANALYSE_SCHEMA, noDesc, { essential: ['decision'] });
  assert.equal(r.ok, true, 'la décision reste exploitable');
  assert.deepEqual(r.missing, ['scenarios[0].description', 'scenarios[1].description', 'scenarios[2].description']);
  // clés françaises, enveloppe, pourcentages, virgules décimales, énumérations en clair, liste en texte
  const sloppy = { analyse: { Recommandation: 'Conserver / attendre', Confiance: '62 %', horizon: 'court terme', résumé: 'Le titre hésite.',
    actualités: { score: '0,2', confidence: 40, summary: 'neutre' }, stoploss: '52,5 €', objectifs: '58,1 et 60,5',
    scénarios: { HAUSSIER: { proba: '30%', objectif: '58,10 €', desc: 'Rebond.' }, CENTRAL: { proba: 50, objectif: 55.9, texte: 'Range' }, Bearish: { probabilite: 0.2, cible: '53,2' } },
    facteurs_clés: [{ description: 'RSI 48', effet: 'neutral', poids: 2 }], risques: 'Résultats ; BCE ; Pétrole' } };
  const s = salvage(ANALYSE_SCHEMA, sloppy, { essential: ['decision'] });
  assert.equal(s.ok, true);
  assert.equal(s.value.decision, 'HOLD');
  assert.equal(s.value.confidence, 0.62);
  assert.equal(s.value.horizon, 'SWING');
  assert.equal(s.value.news.score, 0.2);
  assert.equal(s.value.news.confidence, 0.4);
  assert.equal(s.value.stop, 52.5);
  assert.deepEqual(s.value.targets, [58.1, 60.5]);
  assert.deepEqual(s.value.scenarios.map((x) => [x.name, x.probability, x.target]), [['HAUSSIER', 0.3, 58.1], ['CENTRAL', 0.5, 55.9], ['BAISSIER', 0.2, 53.2]]);
  assert.equal(s.value.scenarios[0].description, 'Rebond.');
  assert.deepEqual(s.value.risks, ['Résultats', 'BCE', 'Pétrole']);
  assert.equal(s.value.key_factors[0].impact, 'NEUTRE');
  assert.ok(s.missing.includes('scenarios[2].description') && s.missing.includes('market'));
  assert.ok(s.notes.some((n) => /enveloppée/.test(n)) && s.notes.some((n) => /renommées/.test(n)));
  // décision vraiment illisible : erreur bloquante, mais le reste est gardé pour l'affichage
  const bad = salvage(ANALYSE_SCHEMA, { decision: 'peut-être', summary: 'x' }, { essential: ['decision'] });
  assert.equal(bad.ok, false);
  assert.equal(bad.value.summary, 'x');
  assert.match(bad.errors[0], /non reconnue/);
});

test('nombres et énumérations écrits librement', () => {
  assert.deepEqual(parseNumber('1 234,5'), { value: 1234.5, percent: false });
  assert.deepEqual(parseNumber('1,234.5'), { value: 1234.5, percent: false });
  assert.deepEqual(parseNumber('−2,5 %'), { value: -2.5, percent: true });
  assert.equal(parseNumber('60 62').value, 60, 'deux nombres ne fusionnent pas');
  assert.equal(parseNumber('abc'), null);
  const D = ['STRONG_BUY', 'BUY', 'HOLD', 'SELL', 'STRONG_SELL'];
  assert.equal(matchEnum('Achat fort', D), 'STRONG_BUY');
  assert.equal(matchEnum('acheter', D), 'BUY');
  assert.equal(matchEnum('Vendre', D), 'SELL');
  assert.equal(matchEnum('neutre', D), 'HOLD');
  assert.equal(matchEnum('bof', D), null);
});

test('JSON coupé (limite de jetons, anti-boucle) : la partie complète est gardée', () => {
  const cut = '{"decision": "BUY", "confidence": 0.7, "scenarios": [{"name": "HAUSSIER", "probability": 0.4, "target": 60.1, "description": "Poursuite vers la résis';
  const c = closeJson(cut);
  assert.equal(c.truncated, true);
  const v = JSON.parse(c.text);
  assert.equal(v.decision, 'BUY');
  assert.match(v.scenarios[0].description, /^Poursuite vers la résis…$/);
  assert.deepEqual(JSON.parse(closeJson('{"decision": "BUY", "conf').text), { decision: 'BUY' }, 'clé coupée retirée');
  assert.deepEqual(JSON.parse(closeJson('{"a": [1, 2, {"b": tr').text), { a: [1, 2, {}] }, 'littéral coupé retiré');
  assert.deepEqual(JSON.parse(closeJson('{"x": 12').text), {}, 'nombre peut-être coupé retiré');
  const r = readJson(`Voici : ${cut}`);
  assert.equal(r.ok, true);
  assert.equal(r.closed, true);
});

test('complément ciblé : schéma des seuls champs manquants, puis fusion', () => {
  const { schema, keys } = patchSchema(ANALYSE_SCHEMA, ['scenarios[0].description', 'news', 'nope.x']);
  assert.deepEqual(Object.keys(schema.properties), ['scenarios_0_description', 'news']);
  assert.deepEqual(requiredDescribed(toOllamaFormat(schema)), []);
  const target = { scenarios: [{ name: 'HAUSSIER' }] };
  const filled = applyPatch(target, { scenarios_0_description: 'Rebond vers 58.', news: { score: 0, confidence: 0.2, summary: 'calme' } }, keys);
  assert.deepEqual(filled, ['scenarios[0].description', 'news']);
  assert.equal(target.scenarios[0].description, 'Rebond vers 58.');
});

test('anti-boucle : aucune fausse alerte sur des textes normaux, boucles détectées et coupées après la 1re occurrence', () => {
  const feed = (text, opts = {}, kind = 'content') => {
    const g = new LoopGuard(opts);
    for (let i = 0; i < text.length; i += 7) {
      const h = g.push(kind, text.slice(i, i + 7));
      if (h) return h;
    }
    return null;
  };
  const a = mockAnalysis('global: 0.4\ndernier: 55.88\natr14: 1.2');
  const json = JSON.stringify({ ...a, key_factors: Array.from({ length: 8 }, (_, i) => ({ factor: `Facteur ${i} : RSI ${40 + i}`, impact: 'NEUTRE', weight: 2 })) }, null, 2);
  assert.equal(feed(json, { json: true }), null, 'JSON d’analyse');
  assert.equal(feed(readFileSync(new URL('README.md', ROOT), 'utf8')), null, 'README');
  assert.equal(feed(readFileSync(new URL('src/ai/prompts.js', ROOT), 'utf8')), null, 'consignes');
  const intro = 'Je regarde le RSI qui est à 48, la tendance est neutre. ';
  const para = 'Attendons, je dois revérifier le calcul du stop : le cours est de 55,88 et l\'ATR de 1,2, donc le stop serait 55,28. ';
  const t = intro + para.repeat(6);
  const h = feed(t, {}, 'thinking');
  assert.ok(h && h.type === 'loop', 'paragraphe répété');
  assert.ok(t.slice(0, h.keep).startsWith(intro) && h.keep <= intro.length + para.length + 2, 'coupé après la première occurrence');
  const varied = Array.from({ length: 10 }, (_, i) => `Attendons, je dois revérifier le calcul du stop : le cours est de 55,${80 + i} et l'ATR de 1,2${i}, donc le stop serait plus bas. `).join('');
  assert.ok(feed(intro + varied, {}, 'thinking'), 'phrase répétée avec des chiffres qui changent');
  assert.ok(feed(`{"decision": "HOLD", ${' \n'.repeat(200)}`, { json: true }), 'retours à la ligne en rafale (défaut du mode JSON)');
  assert.ok(feed(`{"summary": "${'le titre est en range '.repeat(30)}`, { json: true }), 'chaîne JSON qui radote');
  assert.equal(feed('x'.repeat(5000).replace(/x/g, () => String.fromCharCode(97 + Math.floor(Math.random() * 26))), {}), null, 'texte aléatoire');
  const long = new LoopGuard({ maxThinkChars: 1000 });
  let hit = null;
  for (let i = 0; i < 300 && !hit; i++) hit = long.push('thinking', `pensée ${i} différente ${i * 7}. `);
  assert.equal(hit?.type, 'long', 'budget de réflexion');
  assert.equal(detectLoop('court'), null);
  assert.equal(callKey('cotation', { symbole: 'MC:XPAR ' }), callKey('cotation', '{"symbole":"mc:xpar"}'), 'appels identiques reconnus');
  assert.notEqual(callKey('cotation', { symbole: 'MC:XPAR' }), callKey('cotation', { symbole: 'SAP:XETR' }));
});

test('modèle automatique : le meilleur modèle installé (cas réel d’une machine avec 9 modèles)', () => {
  const m = (name, params, caps = ['completion', 'tools']) => ({ name, params, capabilities: caps });
  const installed = [m('qwen3.8-27b:latest', '27.4B'), m('qwen3.6-35B-moe:latest', '35.1B'), m('gemma4-31b-q8:latest', '31.2B', ['completion', 'vision']), m('qwen3-coder-local:latest', '30.5B'),
    m('gemma4:12b', '12.2B'), m('qwen2.5:14b', '14.8B'), m('gemma4:e4b', '4B'), m('gemma4:26b', '26B'), m('gemma3:4b', '4.3B', ['completion', 'vision']), m('bge-m3:latest', '566.70M', ['embedding'])];
  const best = bestChatModel(installed);
  assert.ok(['qwen3.6-35B-moe:latest', 'qwen3.8-27b:latest', 'gemma4:26b'].includes(best.name), `choisi : ${best.name}`);
  assert.notEqual(best.name, 'qwen3-coder-local:latest', 'pas le modèle spécialisé code');
  assert.equal(bestChatModel([...installed, m('bourso:latest', '35.1B')]).name, 'bourso:latest', '« bourso » s’il existe');
  assert.equal(bestChatModel([m('bge-m3', '566M', ['embedding'])]), null);
});

test('erreur Ollama « chtimes … operation not permitted » : explication, commandes, modèle de base utilisable', async () => {
  const msg = 'Ollama /api/create HTTP 500: {"error":"chtimes /home/amine/.ollama/models/blobs/sha256-aeda25e6: operation not permitted"}';
  const h = await explainOllamaError(msg, { host: 'http://127.0.0.1:11434', op: 'create', from: 'gemma4:26b' });
  assert.match(h.title, /droit/);
  assert.ok(h.lines.some((l) => /FACULTATIF/.test(l)));
  assert.ok(h.commands.some((c) => /chown -R .* \/home\/amine\/\.ollama\/models/.test(c.code)), 'commande chown sur le dossier des modèles');
  assert.equal(h.useBase, 'gemma4:26b');
  assert.match((await explainOllamaError('no space left on device')).title, /Disque plein/);
  assert.equal(await explainOllamaError('erreur inconnue'), null);
});

// ---------------------------------------------------------------- de bout en bout, faux Ollama
let mock, srv, base, dir;
const J = { 'content-type': 'application/json' };
const get = async (p) => { const r = await fetch(`${base}${p}`); return { status: r.status, body: await r.json() }; };
const send = async (method, p, data) => { const r = await fetch(`${base}${p}`, { method, headers: J, body: data === undefined ? undefined : JSON.stringify(data) }); return { status: r.status, body: await r.json() }; };
const until = async (fn, ms = 60_000, step = 150) => {
  const end = Date.now() + ms;
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() > end) throw new Error('délai dépassé');
    await new Promise((r) => setTimeout(r, step));
  }
};
const useModel = (model, extra = {}) => send('PUT', '/api/settings', { ai: { model, ...extra } });
const analyze = async (sym, opts = {}) => {
  const r = await send('POST', '/api/ai/analyze', { sym, ...opts });
  assert.equal(r.status, 200);
  return until(async () => { const s = await get(`/api/ai/signal/${r.body.id}`); return s.status === 200 ? s.body : null; });
};

before(async () => {
  dir = mkdtempSync(join(tmpdir(), 'bourso-robust-'));
  mock = await startMockOllama({ port: 0, tokenDelayMs: 0, quirks: true });
  srv = await startServer({ port: 0, dataDir: dir, ollamaHost: `127.0.0.1:${mock.address().port}`, gpu: 'off', autoAnalysis: false, quiet: true, market: 'demo' });
  base = `http://127.0.0.1:${srv.port}`;
});

after(async () => {
  await srv?.close();
  await new Promise((r) => mock?.close(r));
  rmSync(dir, { recursive: true, force: true });
});

test('analyse avec un modèle qui suit la grammaire : scénarios complets (descriptions comprises)', async () => {
  await useModel('qwen3:30b');
  const sig = await analyze('MC:XPAR');
  assert.equal(sig.simulated, false);
  assert.equal(sig.scenarios.length, 3);
  assert.ok(sig.scenarios.every((s) => s.description.length > 5), 'descriptions présentes');
  assert.ok(!sig.guardrails.some((g) => /illisible|inexploitable/.test(g)));
  assert.equal(sig.parsing.calls, 0, 'aucun appel supplémentaire');
});

test('analyse avec un modèle « brouillon » (sans grammaire) : tout est récupéré, les manques sont redemandés', async () => {
  await useModel('brouillon:test');
  const sig = await analyze('SAP:XETR');
  assert.ok(sig.llmDecision, `décision lue (${sig.guardrails.join(' | ')})`);
  assert.equal(sig.scenarios.length, 3);
  assert.ok(sig.scenarios.every((s) => s.description), 'descriptions obtenues par l’appel court');
  assert.ok(sig.parsing.completed.some((p) => /^scenarios\[\d\]\.description$/.test(p)));
  assert.ok(sig.parsing.notes.some((n) => /renommées/.test(n)));
  assert.ok(sig.keyFactors.length > 0 && sig.risks.length > 0 && sig.news);
  assert.ok(sig.raw.includes('complément'), 'réponse brute + complément conservés');
});

test('anti-boucle : réflexion en boucle → coupée puis relance sans réflexion ; réponse qui radote → partie utile gardée', async () => {
  await useModel('boucle:test');
  const a = await analyze('ASML:XAMS', { think: true });
  assert.ok(a.antiLoop.length >= 1 && /Réflexion/.test(a.antiLoop[0]), a.antiLoop.join(' | '));
  assert.ok(a.llmDecision, 'décision obtenue après la relance');
  await useModel('radote:test');
  const b = await analyze('TTE:XPAR');
  assert.ok(b.antiLoop.some((x) => /Réponse/.test(x)), b.antiLoop.join(' | '));
  assert.ok(b.llmDecision, 'la décision écrite avant la boucle est gardée');
  assert.ok(b.parsing.completed.length > 0, 'les champs perdus dans la boucle sont redemandés');
  const st = (await get('/api/ai/status')).body;
  assert.ok(st.queue.stats.loops >= 2);
});

test('anti-boucle : modèle muet → chien de garde, erreur claire, pas de doublon dans la file', async () => {
  await useModel('muet:test', { loop: { firstTokenSec: 1.5, stallSec: 2, maxMinutes: 1, maxThinkTokens: 6000 } });
  const r1 = await send('POST', '/api/ai/analyze', { sym: 'AAPL:XNAS' });
  const r2 = await send('POST', '/api/ai/analyze', { sym: 'AAPL:XNAS' });
  // la 1re demande peut déjà être en cours ; une 2e demande identique en attente n'est pas dupliquée
  const r3 = await send('POST', '/api/ai/analyze', { sym: 'AAPL:XNAS' });
  assert.ok(r2.body.duplicate || r3.body.duplicate, 'doublon reconnu');
  const before0 = (await get('/api/ai/status')).body.queue.stats.errors;
  await until(async () => (await get('/api/ai/status')).body.queue.stats.errors > before0 || null, 30_000);
  assert.equal((await get(`/api/ai/signal/${r1.body.id}`)).status, 404, 'aucun faux signal');
  await until(async () => { const q = (await get('/api/ai/status')).body.queue; return !q.running && !q.manual.length; }, 30_000);
  await useModel('qwen3:30b', { loop: { firstTokenSec: 240, stallSec: 120, maxMinutes: 10, maxThinkTokens: 6000 } });
});

test('création de « bourso » refusée par Ollama (droits) : aide transmise, modèle de base proposé', async () => {
  const events = [];
  const ws = new globalThis.WebSocket(`ws://127.0.0.1:${srv.port}/ws`);
  ws.onmessage = (m) => { const e = JSON.parse(m.data); if (e.t === 'ollama') events.push(e); };
  await new Promise((r) => { ws.onopen = r; });
  const c = await send('POST', '/api/ollama/create', { from: 'perm:test', name: 'bourso-perm' });
  assert.equal(c.status, 200);
  const done = await until(() => events.find((e) => e.done) ?? null, 15_000);
  ws.close();
  assert.equal(done.ok, false);
  assert.match(done.status, /operation not permitted/);
  assert.match(done.help.title, /droit/);
  assert.equal(done.help.useBase, 'perm:test');
});

test('agent : appels d’outils identiques en boucle → non relancés, réponse finale forcée', async () => {
  await send('PUT', '/api/settings', { agent: { model: 'radote:test' } });
  const c = await send('POST', '/api/agent/conversations', { sym: 'MC:XPAR' });
  const id = c.body.id;
  await send('POST', `/api/agent/conversations/${id}/messages`, { text: 'Cotation de LVMH ?' });
  const conv = await until(async () => { const x = (await get(`/api/agent/conversations/${id}`)).body; return !x.busy && x.messages.at(-1)?.role === 'assistant' && !x.messages.at(-1).tool_calls ? x : null; }, 30_000);
  const real = conv.messages.filter((m) => m.role === 'tool' && !m.duplicate);
  const dups = conv.messages.filter((m) => m.role === 'tool' && m.duplicate);
  assert.equal(real.length, 1, 'l’outil n’a tourné qu’une fois');
  assert.ok(dups.length >= 2, 'les répétitions ont été renvoyées au résultat déjà obtenu');
  const last = conv.messages.at(-1);
  assert.ok(last.content.length > 10 && !last.error, 'réponse finale rédigée');
  assert.ok(last.antiLoop?.some((x) => /identique/.test(x)));
  await send('PUT', '/api/settings', { agent: { model: null } });
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Worker } from 'node:worker_threads';
import { SoARing, ControlBlock } from '../src/core/shm/soa-ring.js';

test('SoARing : capacité puissance de 2 obligatoire', () => {
  assert.throws(() => SoARing.create(1000, ['a']), RangeError);
});

test('SoARing : plein → claim() = -1 et compteur dropped', () => {
  const r = SoARing.create(4, ['x']);
  for (let i = 0; i < 4; i++) { const s = r.claim(); r.col.x[s] = i; r.commit(); }
  assert.equal(r.claim(), -1);
  assert.equal(r.dropped, 1);
  const seen = [];
  r.consume(10, (s, n) => { for (let i = 0; i < n; i++) seen.push(r.col.x[s + i]); });
  assert.deepEqual(seen, [0, 1, 2, 3]);
  assert.notEqual(r.claim(), -1);
});

test('SoARing : 2 000 000 éléments entre threads, ordre et intégrité, rebouclages', async () => {
  const COUNT = 2_000_000;
  const ring = SoARing.create(1024, ['seq', 'val']);   // petit anneau → ~2000 rebouclages
  const w = new Worker(new URL('./fixtures/ring-producer.worker.js', import.meta.url), {
    workerData: { ring: ring.descriptor(), count: COUNT },
  });
  let expect = 0, bad = 0, wraps = 0;
  const deadline = Date.now() + 30_000;
  while (expect < COUNT && Date.now() < deadline) {
    const n = ring.consume(512, (s, k) => {
      if (s === 0) wraps++;
      for (let i = 0; i < k; i++) {
        if (ring.col.seq[s + i] !== expect || ring.col.val[s + i] !== expect * 0.5) bad++;
        expect++;
      }
    });
    if (n === 0) ring.wait(5);
  }
  await new Promise((r) => w.once('message', r));
  await w.terminate();
  assert.equal(bad, 0);
  assert.equal(expect, COUNT);
  assert.ok(wraps > 1000, `rebouclages=${wraps}`);
});

test('ControlBlock : sleep() se réveille sur ring(), aucun réveil perdu', () => {
  const c = ControlBlock.create();
  const seen = c.seq();
  c.ring();
  assert.equal(c.sleep(seen, 1000), 'not-equal');   // a sonné entre-temps : retour immédiat
  assert.equal(c.sleep(c.seq(), 10), 'timed-out');
});

// Serveur complet de bout en bout : faux Ollama + Bourso (GPU coupé), données dans un dossier
// temporaire. Vérifie la sécurité HTTP, les API principales, le choix du modèle Ollama, une
// analyse IA complète (dossier → modèle → garde-fous → signal) et l'agent avec appels d'outils.
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { request } from 'node:http';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { startMockOllama } from '../src/ai/mock-ollama-server.js';
import { startServer } from '../src/server/main.js';

let mock, srv, base, dir;
const J = { 'content-type': 'application/json' };
const get = async (p) => {
  const r = await fetch(`${base}${p}`);
  const body = r.headers.get('content-type')?.includes('json') ? await r.json() : await r.arrayBuffer();
  return { status: r.status, body };
};
const send = async (method, p, data) => {
  const r = await fetch(`${base}${p}`, { method, headers: J, body: data === undefined ? undefined : JSON.stringify(data) });
  return { status: r.status, body: await r.json() };
};
const until = async (fn, ms = 60_000, step = 200) => {
  const end = Date.now() + ms;
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() > end) throw new Error('délai dépassé');
    await new Promise((r) => setTimeout(r, step));
  }
};
/** Requête brute (pour forger les en-têtes Host / Origin interdits à fetch). */
const raw = (method, path, headers, body = '') => new Promise((ok, ko) => {
  const req = request({ host: '127.0.0.1', port: srv.port, method, path, headers: { ...headers, 'content-length': Buffer.byteLength(body) } }, (res) => {
    let s = '';
    res.on('data', (c) => { s += c; });
    res.on('end', () => ok({ status: res.statusCode, body: s }));
  });
  req.on('error', ko);
  req.end(body);
});

before(async () => {
  dir = mkdtempSync(join(tmpdir(), 'bourso-test-'));
  mock = await startMockOllama({ port: 0, tokenDelayMs: 0 });
  srv = await startServer({ port: 0, dataDir: dir, ollamaHost: `127.0.0.1:${mock.address().port}`, gpu: 'off', autoAnalysis: false, quiet: true, market: 'demo' });
  base = `http://127.0.0.1:${srv.port}`;
});

after(async () => {
  await srv?.close();
  await new Promise((r) => mock?.close(r));
  rmSync(dir, { recursive: true, force: true });
});

test('sécurité : hôte étranger (DNS rebinding), origine étrangère, corps non JSON', async () => {
  const h = await raw('GET', '/api/health', { host: 'evil.example' });
  assert.equal(h.status, 421);
  const o = await raw('POST', '/api/favorites', { host: `127.0.0.1:${srv.port}`, origin: 'http://evil.example', 'content-type': 'application/json' }, '{"sym":"MC:XPAR"}');
  assert.equal(o.status, 403);
  const t = await raw('POST', '/api/favorites', { host: `127.0.0.1:${srv.port}`, 'content-type': 'text/plain' }, '{"sym":"MC:XPAR"}');
  assert.equal(t.status, 415);
  const ok = await get('/api/health');
  assert.equal(ok.status, 200);
  assert.equal(ok.body.ok, true);
});

test('marché : méta, cotations, historique binaire, recherche, corrélations alignées par date', async () => {
  const meta = await get('/api/meta');
  assert.equal(meta.status, 200);
  assert.ok(meta.body.strategies.every((s) => s.short), 'noms courts des stratégies');
  const q = await get('/api/quote/MC:XPAR');
  assert.equal(q.status, 200);
  assert.ok(q.body.quote.last > 0 && q.body.quote.bid < q.body.quote.ask, 'fourchette achat < vente');
  assert.equal(q.body.meta.isin, 'FR0000121014');
  const h = await get('/api/history?sym=MC:XPAR&tf=1D');
  assert.equal(h.status, 200);
  assert.ok(h.body.byteLength > 1000);
  const s = await get('/api/search?q=lvmh');
  assert.equal(s.body[0].sym, 'MC:XPAR');
  // Paris et New York n'ont pas les mêmes fériés : sans alignement par date, la corrélation s'effondre vers 0
  const c = await send('POST', '/api/lab/correlation', { syms: ['MC:XPAR', 'AAPL:XNAS'], window: 252 });
  assert.equal(c.status, 200);
  assert.ok(c.body.days >= 240 && c.body.days <= 252, `séances communes ${c.body.days}`);
  assert.ok(c.body.matrix[0][1] > 0.1, `corrélation Europe/États-Unis ${c.body.matrix[0][1]}`);
  // performance depuis le 1er janvier : le screener (dates partielles) et le dossier (historique complet) concordent
  // (le screener se calcule en tâche de fond sur les workers : on attend que la ligne soit complète)
  const row = await until(async () => (await get('/api/screener')).body.rows?.find((x) => x.sym === 'MC:XPAR' && x.ytd !== undefined && x.ytd !== null), 60_000, 500);
  const dos = (await get('/api/ai/dossier?sym=MC:XPAR')).body;
  const ytd = (dos.dossier ?? dos).sections.performances.debutAnnee;
  assert.ok(Math.abs(row.ytd - ytd) < 1, `depuis le 1er janvier : screener ${row.ytd} % vs dossier ${ytd} %`);
});

test('labo : régimes (BIC, comparaison à 1 état), cycles (bruit rouge), analogues historiques', async () => {
  const hm = await send('POST', '/api/lab/hmm', { sym: 'MC:XPAR', K: 0, window: 800, restarts: 3 });
  assert.equal(hm.status, 200);
  assert.ok(hm.body.auto && hm.body.selection[0].K === 1, 'le modèle à un état sert de référence');
  assert.equal(typeof hm.body.regimesSupported, 'boolean');
  assert.equal(hm.body.states.length, hm.body.K);
  const cy = await send('POST', '/api/lab/cycles', { sym: 'MC:XPAR', window: 512 });
  assert.equal(cy.status, 200);
  assert.ok(cy.body.thresholds.global > cy.body.thresholds.local, 'seuil global plus strict que le seuil ponctuel');
  assert.ok(cy.body.spectrum.period.length > 50);
  const an = await send('POST', '/api/lab/analogs', { sym: 'MC:XPAR' });
  assert.equal(an.status, 200);
  assert.ok(an.body.horizons.length === 2 && an.body.nearest.length > 0);
  // aucune fuite du futur : chaque analogue a son horizon complet terminé au moins 20 séances avant la dernière
  const h = (await get('/api/history?sym=MC:XPAR&tf=1D&format=json')).body;
  const lastDate = h.dates?.at(-1) ?? h.header?.dates?.at(-1);
  if (lastDate) for (const nb of an.body.nearest) assert.ok(nb.date < lastDate, 'analogue dans le passé');
});

test('Ollama : modèles détaillés, test de vitesse, téléchargement suivi, choix du modèle dans les réglages', async () => {
  const m = await get('/api/ollama/models');
  assert.equal(m.status, 200);
  const list = m.body.models ?? m.body;
  const names = list.map((x) => x.name);
  assert.ok(names.includes('qwen3:30b') && names.includes('gpt-oss:20b'));
  const gemma = list.find((x) => x.name.startsWith('gemma3'));
  assert.ok(!gemma.capabilities.includes('tools'), 'gemma3 sans appels d’outils');
  const t = await send('POST', '/api/ollama/test', { model: 'qwen3:30b' });
  assert.equal(t.status, 200);
  assert.ok(t.body.tokPerSec === null || t.body.tokPerSec > 0);
  const p = await send('POST', '/api/ollama/pull', { model: 'mistral-small3.2:24b' });
  assert.equal(p.status, 200);
  await until(async () => ((await get('/api/ollama/models')).body.models ?? []).some((x) => x.name === 'mistral-small3.2:24b'), 30_000);
  // choix du modèle de l'agent dans les réglages
  const cur = (await get('/api/settings')).body;
  const put = await send('PUT', '/api/settings', { ...cur, agent: { ...cur.agent, model: 'gpt-oss:20b' } });
  assert.equal(put.status, 200);
  const st = (await get('/api/ai/status')).body;
  assert.equal(st.modelStatus.agent.used, 'gpt-oss:20b');
  assert.equal(st.modelStatus.agent.installed, true);
});

test('analyse IA complète : dossier → modèle → garde-fous → signal, puis mémoire', async () => {
  const r = await send('POST', '/api/ai/analyze', { sym: 'SAP:XETR' });
  assert.equal(r.status, 200);
  const sig = await until(async () => (await get('/api/ai/signals?sym=SAP:XETR')).body[0]);
  assert.ok(['STRONG_BUY', 'BUY', 'HOLD', 'SELL', 'STRONG_SELL'].includes(sig.decision));
  assert.ok(sig.confidence >= 0 && sig.confidence <= 1);
  if (sig.decision !== 'HOLD') {
    const dir = sig.decision.includes('BUY') ? 1 : -1;
    assert.ok(dir * (sig.price - sig.stop) > 0, 'stop du bon côté');
    assert.ok(sig.targets.every((x) => dir * (x - sig.price) > 0), 'objectifs du bon côté');
  }
  assert.ok(sig.mc && sig.mc.paths > 0, 'Monte Carlo joint au signal');
  // la mémoire de l'IA apparaît dans le dossier suivant
  const d = (await get('/api/ai/dossier?sym=SAP:XETR')).body;
  const sections = (d.dossier ?? d).sections;
  assert.equal(sections.memoire.analysesPrecedentes[0].decision, sig.decision);
  assert.ok(sections.analogues && sections.regime && sections.cycles);
});

test('agent Bourso Pro : discussion, appels d’outils, réponse en flux', async () => {
  const c = await send('POST', '/api/agent/conversations', { sym: 'MC:XPAR' });
  assert.equal(c.status, 200);
  const id = c.body.id;
  const m = await send('POST', `/api/agent/conversations/${id}/messages`, { text: 'Donne-moi la cotation et l’analyse technique de LVMH' });
  assert.equal(m.status, 200);
  const conv = await until(async () => {
    const x = (await get(`/api/agent/conversations/${id}`)).body;
    return !x.busy && x.messages.some((mm) => mm.role === 'assistant' && mm.content) ? x : null;
  }, 60_000);
  const toolMsgs = conv.messages.filter((mm) => mm.role === 'tool' || mm.tool_calls?.length);
  assert.ok(toolMsgs.length > 0, 'au moins un appel d’outil');
  const last = conv.messages.filter((mm) => mm.role === 'assistant').at(-1);
  assert.ok(last.content.length > 20);
  // outil direct
  const tool = await send('POST', '/api/agent/tool/calcul_position', { capital: 10000, risque_pct: 1, entree: 100, stop: 95 });
  assert.equal(tool.status, 200);
  assert.equal(tool.body.ok, true);
  assert.equal(tool.body.result.quantite, 20, '1 % de 10 000 € / 5 € de risque par action = 20 titres');
  await send('DELETE', `/api/agent/conversations/${id}`);
});

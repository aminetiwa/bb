// Tests du marché mondial simulé : univers, places, calendriers, cohérence des historiques.
import test from 'node:test';
import assert from 'node:assert/strict';
import { UNIVERSE, REJECTED_IDS, isValidIsin, bySym } from '../src/market/universe.js';
import { EXCHANGES, REGIONS, easter, holidays, isTradingDay, sessionSecondOf, localTimeOf, tickFor } from '../src/market/exchanges.js';
import { WorldSim } from '../src/market/sim.js';

const ymd = (t) => new Date(t).toISOString().slice(0, 10);

test('univers : identifiants contrôlés, symboles uniques, Europe en tête', () => {
  assert.ok(UNIVERSE.length > 600);
  assert.equal(new Set(UNIVERSE.map((x) => x.sym)).size, UNIVERSE.length);
  assert.ok(UNIVERSE.filter((x) => x.isin).every((x) => isValidIsin(x.isin)));
  assert.deepEqual(REJECTED_IDS, ['KR7012450002'], 'seul identifiant douteux écarté (laissé vide, pas inventé)');
  assert.equal(bySym.get('AAPL:XNAS').isin, 'US0378331005', 'ISIN reconstruit depuis le CUSIP');
  assert.equal(REGIONS[0], 'Europe');
  const eu = UNIVERSE.filter((x) => x.region === 'Europe').length;
  assert.ok(eu > UNIVERSE.length / 2, 'majorité européenne');
  assert.ok(UNIVERSE.every((x) => x.tick > 0 && x.price > 0));
  assert.equal(tickFor('mifid', 612), 0.1);
  assert.equal(tickFor('tokyo', 2700), 0.5);
});

test('calendriers : Pâques, fériés US / Londres / Euronext', () => {
  assert.equal(ymd(easter(2024)), '2024-03-31');
  assert.equal(ymd(easter(2025)), '2025-04-20');
  assert.equal(ymd(easter(2026)), '2026-04-05');
  const us = holidays('us', 2026);
  for (const d of ['2026-01-01', '2026-01-19', '2026-02-16', '2026-04-03', '2026-05-25', '2026-06-19', '2026-07-03', '2026-09-07', '2026-11-26', '2026-12-25']) assert.ok(us.has(d), `US ${d}`);
  const uk = holidays('lse', 2026);
  for (const d of ['2026-04-03', '2026-04-06', '2026-05-04', '2026-05-25', '2026-08-31', '2026-12-25', '2026-12-28']) assert.ok(uk.has(d), `Londres ${d}`);
  assert.ok(!isTradingDay(EXCHANGES.XPAR, Date.parse('2026-05-01T12:00:00Z')), '1er mai fermé à Paris');
  assert.ok(isTradingDay(EXCHANGES.XNYS, Date.parse('2026-05-01T12:00:00Z')), '1er mai ouvert à New York');
});

test('séance : secondes ↔ heure locale avec pause déjeuner (Tokyo)', () => {
  const tk = EXCHANGES.XTKS;
  assert.equal(tk.sessionMin, 330);
  assert.equal(localTimeOf(tk, 0), '09:00:00');
  assert.equal(localTimeOf(tk, 150 * 60, false), '12:30', 'après la pause');
  assert.equal(sessionSecondOf(tk, 12 * 60 + 10), 150 * 60, 'pendant la pause : seconde figée');
  assert.equal(sessionSecondOf(tk, 13 * 60), 180 * 60);
  assert.equal(EXCHANGES.XPAR.sessionSec, 30_600);
});

const sub = UNIVERSE.filter((x) => ['MC:XPAR', 'SAP:XETR', 'ASML:XAMS', 'AAPL:XNAS', '7203:XTKS', 'TTE:XPAR', 'BNP:XPAR'].includes(x.sym));

test('simulateur : quotidien → minutes → secondes parfaitement emboîtés', () => {
  const sim = new WorldSim({ universe: sub, dailyDays: 300, intraDays: 6, secDays: 2 });
  for (const sym of ['MC:XPAR', '7203:XTKS']) {
    const d = sim.daily(sym), m = sim.minutes(sym, 6), M = m.sessionBars;
    for (let j = 0; j < 6; j++) {
      const di = d.close.length - 6 + j, b = j * M;
      let H = -Infinity, L = Infinity, V = 0;
      for (let k = b; k < b + M; k++) { H = Math.max(H, m.high[k]); L = Math.min(L, m.low[k]); V += m.volume[k]; }
      assert.deepEqual([m.open[b], H, L, m.close[b + M - 1], V], [d.open[di], d.high[di], d.low[di], d.close[di], d.volume[di]], `${sym} séance ${m.dates[j]}`);
    }
    const s = sim.seconds(sym, 2), S = s.sessionBars;
    for (const mk of [0, 77, M - 1]) {
      const sb = S + mk * 60, mb = (6 - 2 + 1) * M + mk;
      let H = -Infinity, L = Infinity, V = 0;
      for (let k = sb; k < sb + 60; k++) { H = Math.max(H, s.high[k]); L = Math.min(L, s.low[k]); V += s.volume[k]; }
      assert.deepEqual([s.open[sb], H, L, s.close[sb + 59], V], [m.open[mb], m.high[mb], m.low[mb], m.close[mb], m.volume[mb]], `${sym} minute ${mk}`);
    }
  }
  // déterminisme : même graine → mêmes historiques
  const sim2 = new WorldSim({ universe: sub, dailyDays: 300, intraDays: 6, secDays: 2 });
  assert.deepEqual(Array.from(sim2.daily('SAP:XETR').close.slice(-50)), Array.from(sim.daily('SAP:XETR').close.slice(-50)));
});

test('simulateur : temps réel, minute close, fin de séance et nouvelle journée', () => {
  const sim = new WorldSim({ universe: sub, dailyDays: 300 });
  const clk = sim.clocks.XPAR, x = sim.get('MC:XPAR');
  const n0 = x.daily.n, day0 = clk.today, m0 = x.mN;
  clk.sec = Math.ceil(clk.sec / 60) * 60 - 1;
  for (let i = 0; i < 20; i++) sim.step();
  assert.equal(x.mN, m0 + 1, 'une minute close');
  clk.sec = clk.ex.sessionSec - 1;
  const lastBefore = x.last;
  for (let i = 0; i < 20; i++) sim.step(); // dernière seconde : des échanges peuvent encore avoir lieu
  assert.equal(x.daily.n, n0 + 1, 'séance ajoutée au quotidien');
  const closeD = x.daily.close[n0];
  assert.ok(Math.abs(closeD - lastBefore) <= 0.01 * lastBefore, 'clôture proche du dernier cours connu');
  assert.notEqual(clk.today, day0);
  assert.equal(x.prev, closeD, 'la veille = la clôture enregistrée');
  assert.equal(x.mN, 0);
  assert.equal(sim.daily('MC:XPAR').dates.at(-1), day0);
  // la séance terminée reste disponible en minutes, telle qu'elle a été vécue
  const m = sim.minutes('MC:XPAR', 1);
  assert.equal(m.dates[0], day0);
  assert.equal(m.close[m.sessionBars - 1], closeD);
});

test('simulateur : actualité → dérive et volume ; carnet et bande', () => {
  const sim = new WorldSim({ universe: sub, dailyDays: 300 });
  const x = sim.get('BNP:XPAR'), f0 = x.F;
  sim.applyNews({ scope: 'valeur', sym: 'BNP:XPAR', score: 1 });
  assert.ok(x.drift > 0 && x.burst > 1);
  for (let i = 0; i < 400; i++) sim.step();
  assert.ok(x.F > f0 - 0.01);
  const b = sim.book('BNP:XPAR', 10);
  assert.equal(b.bids.length, 10);
  assert.ok(b.bids[0][0] < b.asks[0][0], 'meilleur achat < meilleure vente');
  for (let k = 1; k < 10; k++) assert.ok(b.bids[k][0] < b.bids[k - 1][0] && b.asks[k][0] > b.asks[k - 1][0]);
  const t = sim.tape('BNP:XPAR', 20);
  assert.ok(t.length > 0 && t.every((tr) => tr.px > 0 && tr.qty > 0));
  const q = sim.quote('BNP:XPAR');
  assert.ok(q.low <= q.last && q.last <= q.high);
  assert.ok(sim.indices().some((i) => i.key === 'EUROPE'));
});

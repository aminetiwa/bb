# Bourso 0.4.1 — plateforme boursière locale : données réelles, calcul natif GPU/CPU, IA Ollama

Bourso est un site de bourse qui tourne **sur ta machine**, dans l'esprit des portails classiques
(Zone Bourse, l'ancien TradingView). Il suit 678 actions sur 31 places du monde, avec l'Europe en
premier (390 valeurs), et **n'importe quelle autre action du monde s'ajoute d'un clic** depuis la
recherche. Les **cours, historiques, actualités et taux de change sont réels**, tirés de sources
publiques gratuites. Tu y trouves des graphiques WebGL professionnels avec 39 indicateurs et 43
outils de tracé, des actualités, un portefeuille fictif et un labo quantitatif.

Le serveur Node pilote trois moteurs de calcul :

- le **GPU en natif**, via Dawn/Vulkan sous Ubuntu ;
- un **module C++ multi-cœurs** ;
- des **workers** JavaScript.

**Une seule IA locale (~30B, via Ollama)** analyse tes favoris dans l'ordre. Tu choisis le modèle
dans **Réglages**. L'agent **Bourso Pro** répond à tes questions en appelant les outils de calcul.

![Accueil](docs/capture-accueil.jpg)

> **Données réelles, ordres fictifs.** Les cours sont **différés** (≈ 15 min en Europe) et viennent
> d'accès publics gratuits (Yahoo Finance, BCE, Google Actualités, GDELT, presse). Le portefeuille et
> les ordres restent **fictifs** : rien n'est transmis à un courtier. Le bandeau bleu le rappelle sur
> chaque page. Le mode **démonstration** (marché simulé, hors connexion) reste disponible dans
> Réglages. Les captures ci-dessous viennent de ce mode démonstration.

| | |
|---|---|
| ![Graphique](docs/capture-graphique.jpg) | ![Marchés](docs/capture-marches.jpg) |
| ![Analyse IA](docs/capture-analyse-ia.jpg) | ![Agent Bourso Pro](docs/capture-agent-pro.jpg) |
| ![Réglages : choix du modèle](docs/capture-reglages.jpg) | ![Labo : Monte Carlo](docs/capture-labo-monte-carlo.jpg) |
| ![Labo : analogues historiques](docs/capture-labo-analogues.jpg) | |

---

## 1. Installation (Ubuntu)

```bash
# Node.js 22 ou plus récent + outils de compilation (pour le module C++)
sudo apt install -y build-essential python3 curl
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt install -y nodejs

# Pilote Vulkan de la carte graphique (calcul GPU natif)
#   NVIDIA : pilote propriétaire (ex. sudo ubuntu-drivers install)
#   AMD / Intel : sudo apt install -y mesa-vulkan-drivers
sudo apt install -y vulkan-tools && vulkaninfo --summary   # la carte doit apparaître

# Bourso
cd bourso
npm install        # compile le module C++ et installe Dawn (WebGPU natif)
npm start          # → ouvre http://localhost:3000
```

| Commande | Rôle |
|---|---|
| `npm start` | lance le serveur sous **superviseur** (voir ci-dessous) |
| `npm run dev` | idem, et redémarre tout seul quand un fichier de `src/` change (`web/` est relu à chaque requête) |
| `npm run server` | le serveur seul, sans superviseur (débogage) |
| `npm run demo` | sans GPU ni Ollama ni Internet : faux serveur Ollama (réponses simulées et étiquetées) + marché simulé |
| `npm run data:check` | vérifie depuis ta machine que chaque source de données répond, avec une piste en cas d'échec |

`npm install` a des replis automatiques :

- **Sans compilateur C++**, les calculs passent sur les workers JavaScript. Les résultats sont les
  mêmes, en plus lent.
- **Sans GPU utilisable**, tout est calculé sur le CPU. La page **Système** dit précisément ce qui
  est actif et pourquoi.

**Robustesse face au code natif.** Le pilote graphique, Dawn et le module C++ sont du code natif :
s'il plante, Node s'arrête sans aucun message. Bourso s'en protège de deux façons :

- **Le GPU tourne dans son propre processus.** S'il plante, le serveur continue : la part GPU du
  calcul en cours est refaite sur le CPU, le GPU est relancé (deux fois au plus), et la page Système
  affiche la cause et le calcul qui tournait.
- **Le superviseur** (`npm start`, `npm run dev`) relance le serveur s'il s'arrête brutalement. Il
  affiche le signal reçu et l'opération native en cours, et écrit un rapport dans
  `data/logs/plantage-….txt`. Si c'est le module C++ qui plante deux fois, il relance sans lui.

## 2. L'IA : un seul modèle, que tu choisis dans Réglages

```bash
curl -fsSL https://ollama.com/install.sh | sh     # installe et démarre le service Ollama
```

Ouvre ensuite **Réglages → Modèle d'IA (Ollama)**. Cette page te permet de :

- **télécharger** un modèle conseillé ou n'importe quel nom de la bibliothèque Ollama, avec une
  barre de progression et un bouton d'annulation ;
- **tester** sa vitesse (jetons/s) et voir ses capacités : outils, réflexion, images, contexte
  maximal, mémoire GPU occupée ;
- **choisir le modèle des analyses et celui de l'agent**. Par défaut le choix est **automatique** :
  le meilleur modèle installé (taille 20-40B d'abord, modèles « code » écartés). Le même modèle pour
  les deux est recommandé : deux modèles, c'est deux fois la mémoire ou des rechargements ;
- **créer le modèle « bourso »** (facultatif) : une copie du modèle de base avec des consignes et
  paramètres par défaut. Bourso envoie de toute façon ses consignes et ses réglages à chaque appel,
  donc utiliser directement le modèle de base donne le même résultat ;
- régler la réflexion (oui/non ou niveau), le contexte (32 768 jetons par défaut), la longueur
  maximale, le maintien en mémoire, l'horizon et la taille du Monte Carlo, l'analyse automatique ;
- pointer vers un **autre ordinateur** du réseau qui sert le modèle (adresse du serveur Ollama).

En ligne de commande, l'équivalent est `npm run ollama:setup`. Il télécharge `qwen3:30b` et crée
`bourso`. Pour partir d'une autre base : `BOURSO_MODEL=qwen3.5:35b npm run ollama:setup`.

**Si la création échoue avec `chtimes …/blobs/sha256-…: operation not permitted`.** Ce n'est pas
une erreur de Bourso. Le serveur Ollama n'a pas le droit de modifier les fichiers de ses propres
modèles : ils appartiennent à un autre utilisateur que celui qui fait tourner le serveur. Cela arrive
par exemple quand les modèles ont été téléchargés avec `ollama serve` lancé sous ton compte, puis que
le service système a relancé Ollama sous l'utilisateur `ollama`. La page Réglages lit le
propriétaire du fichier et l'utilisateur du serveur, puis affiche la commande exacte. En général,
l'une de ces deux solutions suffit :

```bash
# 1) rendre les modèles à l'utilisateur du service
sudo systemctl stop ollama && sudo chown -R ollama:ollama /home/TOI/.ollama/models && sudo systemctl start ollama
# 2) ou faire tourner le service sous ton compte : sudo systemctl edit ollama
#    [Service]
#    User=TOI
#    Group=TOI
```

Tu peux aussi ignorer « bourso » et choisir directement le modèle de base : le résultat est le même.

| Modèle (octobre 2026) | Taille | Carte conseillée | Pourquoi |
|---|---|---|---|
| `qwen3:30b` (défaut) | 19 Go | 24 Go (ou 12-16 Go + RAM) | MoE ≈ 3B actifs : rapide ; outils + réflexion ; bon français |
| `qwen3.5:35b` | 22 Go | 24 Go | MoE ≈ 3B actifs ; outils, réflexion, images, contexte 256k |
| `qwen3.8:27b` | 18 Go | 24 Go | le plus récent (août 2026), dense, images, 256k ; Ollama à jour requis |
| `qwen3.5:27b` | 17 Go | 20-24 Go | dense ; outils, réflexion, images |
| `gpt-oss:20b` | 14 Go | 16 Go | raisonnement à niveaux (faible / moyen / élevé) |
| `mistral-small3.2:24b` | 15 Go | 16-24 Go | excellent en français, appels d'outils fiables |

Réglages conseillés du service Ollama, avec `sudo systemctl edit ollama` puis des lignes
`Environment=` dans la section `[Service]` :

- `OLLAMA_NUM_PARALLEL=1` : une requête à la fois ;
- `OLLAMA_FLASH_ATTENTION=1` ;
- `OLLAMA_KV_CACHE_TYPE=q8_0` : un cache de contexte compressé, donc moins de VRAM pour 32 k jetons.

### Ce que fait l'IA, et ce qu'elle ne fait pas

1. **Le moteur calcule tout** avant d'appeler le modèle. Il produit un dossier d'environ 3 000
   jetons :
   - faits saillants classés et scores déterministes ;
   - tendance et momentum sur deux échelles, volatilité (ATR, GARCH, Yang-Zhang), volumes et flux ;
   - VWAP, profil de volume, Market Profile, niveaux, pivots ;
   - statistiques (Hurst, ADF, ratio de variance), régime de Markov, cycles FFT ;
   - risque (VaR, ES, drawdown), figures et chandeliers ;
   - backtests **hors échantillon** (walk-forward), **Monte Carlo GPU/CPU** sur un GARCH ajusté ;
   - **analogues historiques**, actualités, fondamentaux, position ;
   - la **mémoire** de ses analyses précédentes.
2. **Le modèle raisonne** sur ces chiffres. Il répond en JSON strict : décision, confiance, plan,
   3 scénarios, facteurs clés, risques. Tu vois sa réponse s'écrire en direct.
   - **Lecture tolérante.** Si un modèle ne suit pas le format à la lettre, Bourso récupère tout ce
     qui est exploitable. Il reconnaît les clés renommées, les pourcentages, les nombres à la
     française, les valeurs en clair (« Acheter ») et les réponses coupées. Il ne redemande au modèle,
     par un appel court, que les champs manquants. La page Analyse IA indique ce qui a été corrigé.
   - **Anti-boucle.** La génération est surveillée au fil de l'eau : phrase ou paragraphe répété,
     réflexion trop longue, rafale de retours à la ligne, modèle muet, durée maximale. En cas de
     boucle, Bourso coupe et garde la partie utile, ou relance une fois sans réflexion avec une
     pénalité de répétition. Côté agent, un appel d'outil identique n'est jamais relancé et le
     nombre d'appels est plafonné. Une valeur qui échoue est mise en pause de plus en plus longue
     (1, 2, 4… minutes), et toute la boucle des favoris aussi si les échecs s'enchaînent.
3. **Des garde-fous en code** contrôlent le plan :
   - stop du bon côté, et à au moins 0,5 ATR (sinon le bruit quotidien suffit à le toucher) ;
   - gain/risque minimal ;
   - pas de « STRONG » si actualités et marché se contredisent ;
   - confiance minimale ;
   - données fraîches.
4. **Chaque décision est suivie** jusqu'à son objectif, son stop ou son expiration. La page
   **Analyse IA** affiche le **taux de réussite réel par niveau de confiance**.
5. **Mémoire.** Avant chaque analyse, l'IA reçoit plusieurs éléments :
   - ses 5 dernières analyses de la valeur et leur issue réelle ;
   - sa fiabilité mesurée, pour calibrer sa confiance ;
   - les **situations passées les plus proches** (k plus proches voisins sur 8 variables d'état) et
     ce qui a suivi.
6. **Économie.** Les favoris passent un par un, dans l'ordre. Un favori n'est réanalysé que s'il y
   a du nouveau : mouvement de cours, actualité ou âge. Les demandes manuelles passent devant, et
   l'agent passe devant tout.

**Aucune IA ne prédit le marché à 100 %.** Bourso ne le prétend pas. Les calculs sont exacts, mais
la fiabilité des décisions est **mesurée**, pas promise.

## 3. Pages

| Page | Contenu |
|---|---|
| **Accueil** | Indices (niveaux réels différés), favoris avec décision IA, plus fortes hausses et baisses Europe, volumes inhabituels, valeurs les plus échangées, places ouvertes, devises, actualités, portefeuille |
| **Marchés** | Tableau triable de toutes les valeurs, screener, carte thermique, secteurs, places, corrélations, devises ; export CSV |
| **Graphique** | Graphique WebGL2 multi-panneaux. Unités de 1 min au mois (1 s en démonstration) ; 39 indicateurs ; 43 outils de tracé (Fibonacci, Gann, fourchettes d'Andrews/Schiff, harmoniques, Elliott…) avec aimant OHLC ; profil de volume. Onglets : synthèse technique, statistiques, dossier de l'IA, Market Profile (TPO), saisonnalité, performances, fondamentaux (dividendes réels ; PER, consensus avec une clé), historique. Heure et source du cours affichées |
| **Favoris** | Liste ordonnée (glisser-déposer) analysée par l'IA dans cet ordre, règle de réanalyse, compteurs |
| **Analyse IA** | Analyse de n'importe quelle valeur. Console en direct (calculs → dossier → modèle → garde-fous), décision détaillée, historique, fiabilité mesurée |
| **Agent Pro** | Discussion avec « Bourso Pro ». 15 outils de calcul (cotation, technique, dossier complet, Monte Carlo, backtests, screener, corrélations, portefeuille, taille de position…). Il ne passe jamais d'ordre |
| **Actualités** | Titres réels (presse, Google Actualités, GDELT) rattachés à une valeur, une région ou au marché, avec lien vers l'article, tonalité estimée et réaction du cours |
| **Portefeuille & ordres** | Négociation **fictive** sur les cours réels : au marché, à cours limité, stop, stop limite ; validité jour ou à révocation. Exécution seulement pendant la séance de la place. Frais exacts, TTF d'après la liste officielle. Risque : volatilité, VaR, ES, bêta, diversification, contributions, corrélations. Comptes réel et démonstration séparés |
| **Labo quant** | Toutes ces études tournent sur la valeur de ton choix : Monte Carlo (GARCH, Student-t, bootstrap) dosé GPU+CPU avec contrôle croisé ; balayage massif de stratégies ; walk-forward ; régimes de Markov ; cycles FFT ; **analogues historiques** ; statistiques ; corrélations ; test de charge |
| **Outils** | Taille de position, gain/risque, Black-Scholes et volatilité implicite, Kelly, pivots, Fibonacci, frais et TTF, volatilité, intérêts composés, devises, dividende, seuil de rentabilité |
| **Système** | Cœurs CPU, mémoire, GPU, moteurs actifs, débits mesurés, niveau de calcul (éco → « fondre les serveurs »), état d'Ollama, **état de chaque source de données** (requêtes, refus, pauses, budgets, erreurs) |
| **Réglages** | Données de marché (réelles ou démonstration, intensité, clés gratuites, flux d'actualités, test des sources), modèle d'IA (voir § 2), génération, analyse automatique, calcul, négociation, affichage, exports |
| **Aide** | Raccourcis, fonctionnement, glossaire, installation |

**Raccourcis :**

- `F1` ou `F2` : ordre d'achat ou de vente ;
- `/` ou `Ctrl+K` : recherche ;
- `Alt+F` : Fibonacci ; `Alt+T` : tendance ; `Alt+G` : Gann ; `Alt+P` : fourchette ; `Alt+X` :
  harmonique ; `Alt+E` : Elliott ;
- `Ctrl+Z` : annuler.

La liste complète est dans la page Aide.

## 4. Le calcul : GPU natif, C++ multi-cœurs, workers

- **GPU natif côté Node** : Dawn (paquet `webgpu`) sur Vulkan, dans un **processus isolé**, avec des noyaux WGSL pour le Monte
  Carlo et le balayage de stratégies. Les résultats GPU (float32) sont **recontrôlés en double
  précision** par le CPU (contrôle croisé GPU/CPU sur les mêmes trajectoires).
- **CPU natif** : module C++17 (N-API) sur tous les cœurs (`std::thread`), en double précision.
- **Workers** JavaScript : dossier IA, backtests, régimes, cycles, analogues, corrélations. Les
  séries sont partagées par SharedArrayBuffer.
- **Dosage mesuré** : le travail est réparti au prorata des débits mesurés, pour que GPU et CPU
  finissent ensemble. Il y a quatre niveaux : éco, équilibré, maximum et « fondre les serveurs »
  (20 millions de trajectoires, tous les cœurs). Un test de charge est inclus.

## 5. Précision : ce qui est exact, ce qui est statistique

**Exact** (testé contre des références) :

- loi normale à 10⁻¹⁵ ;
- sommes compensées (Neumaier) ;
- VWAP en arithmétique rationnelle ;
- arrondi au pas de cotation ;
- moyennes glissantes identiques au calcul naïf ;
- franchissement de barrières du Monte Carlo par pont brownien ;
- natif et JS identiques bit à bit ;
- frais et TTF au centime.

**Statistique, et donc testé honnêtement :**

- **Régimes de Markov** : EM régularisé, pour qu'un « état » ne puisse pas se résumer à quelques
  jours extrêmes. Les régimes sont toujours comparés au modèle à un seul état (BIC) et doivent
  durer au moins 5 séances. Sinon, ils sont déclarés **non significatifs**, et l'IA les ignore.
- **Cycles FFT** : chaque pic est comparé à un bruit rouge AR(1), avec correction des tests
  multiples (Šidák). La plupart des « cycles » boursiers ne passent pas ce test, et Bourso le dit.
- **Analogues historiques** : aucune fuite du futur. Les fenêtres des analogues ne se recouvrent
  pas, et le test z est corrigé du recouvrement. Il est calibré sur des marches aléatoires : environ
  5 % de faux signaux, comme attendu.
- **Stratégies** : seuls comptent les résultats **hors échantillon** (walk-forward). La référence
  achat-conservation est prise sur la même période.
- **Corrélations entre places** : elles sont calculées sur les séances **communes**. Les fériés
  diffèrent d'une place à l'autre, et sans alignement les séries se décalent.

## 6. Les données : réelles par défaut, démonstration au choix

### Sources (gratuites, sans inscription)

| Donnée | Source | Fraîcheur | Remarques |
|---|---|---|---|
| Cours, plus haut / bas, volume | Yahoo Finance (cotations groupées, sinon valeur par valeur) | **différé** : ≈ 15 min en Europe, selon la place ailleurs | rafraîchi toutes les 3 min (90 s pour tes favoris, la valeur affichée et tes positions) en intensité « normale » |
| Historique quotidien | Yahoo Finance | 5 ans de séances, dividendes | mis en cache sur disque, complété chaque jour, rechargé en entier chaque mois |
| Bougies intraday | Yahoo Finance | 1 min sur 5 séances, 5/15/30 min sur un mois, 1 h sur six mois | complétées sans trou (minute sans échange = bougie plate sans volume) |
| Indices | Yahoo Finance | différé | CAC 40, DAX, STOXX Europe 600, S&P 500… ; « MSCI World » approché par un fonds indiciel coté |
| Change | Banque centrale européenne (taux de référence, ≈ 16 h), Frankfurter en secours, affiné en séance | quotidien + séance | sert à valoriser le portefeuille en euros |
| Actualités | flux RSS de presse, Google Actualités, Yahoo, GDELT | quelques minutes | titres seulement, lien vers l'article ; rattachés à une valeur, une région ou au marché |
| TTF (0,4 %) | liste officielle BOFiP des sociétés concernées en 2026 (121 sociétés) | annuelle | intégrée au code, à mettre à jour chaque décembre |

### Sources à clé (facultatives, gratuites)

À renseigner dans **Réglages → Données de marché**. Les clés restent sur ta machine
(`data/state.json`) et ne sont **jamais renvoyées en clair** par le serveur, même à l'interface.

| Source | Ce qu'elle apporte | Offre gratuite |
|---|---|---|
| Finnhub | PER, BPA, ROE, marges, capitalisation, consensus des analystes, prochaine publication, actualités par société | 60 requêtes/min ; couverture surtout américaine |
| Financial Modeling Prep | profil, capitalisation, PER, rendement, marges | ≈ 250 requêtes/jour |
| Twelve Data | historiques quotidiens de secours | 8 requêtes/min, 800/jour ; **actions américaines seulement** en offre gratuite |
| Stooq | historiques de secours | la clé s'obtient sur leur page de téléchargement CSV, après un captcha que **tu** résous dans ton navigateur |

Sans clé, la fiche « Fondamentaux » montre ce que les sources ouvertes donnent vraiment : dividendes
versés, rendement sur 12 mois, extrêmes sur 52 semaines. Le reste affiche « — », pas une valeur
inventée. Pour classer les valeurs par taille (tableaux, carte du marché, « plus grosses
capitalisations »), Bourso utilise alors les **capitaux moyens échangés par jour sur 20 séances**,
une mesure réelle.

### Bourso est poli avec les sources

- Débit limité **par site** (requêtes simultanées, intervalle minimal, budget quotidien des offres
  gratuites), cache mémoire et disque (`data/cache`).
- **Coupe-circuit** : une réponse « trop de requêtes » (429) ou un refus (403) met le site en pause
  1, 2, 5, 15 puis 30 min (ou la durée demandée par le site). Bourso continue avec ses derniers
  cours enregistrés.
- **Rien n'est contourné** : pas de captcha résolu automatiquement, pas de page de consentement
  validée, pas de connexion, pas de paywall. Une source qui l'exige est simplement ignorée.
- Yahoo Finance est un accès public **non officiel**, prévu pour un usage personnel : il peut
  ralentir ou refuser des requêtes (surtout depuis un serveur, un VPN ou après beaucoup d'appels).
  Bourso n'automatise pas le jeton de session (« crumb ») que Yahoo réserve à ses propres pages, et
  n'imite aucun navigateur : il s'annonce avec l'en-tête minimal `Mozilla/5.0` (depuis octobre 2026,
  Yahoo refuse en 429 les requêtes qui se font passer pour un Chrome complet sans en être un).
- Si Yahoo refuse (HTTP 429), **plus rien ne lui est envoyé** jusqu'à la fin de la pause (les
  requêtes en attente sont annulées, pas envoyées) ; la barre d'état affiche « Yahoo en pause
  jusqu'à … » et Bourso reprend seul. Les analyses de l'IA attendent les données au lieu d'échouer.
- L'**intensité** (économe / normale / soutenue) règle la fréquence des rafraîchissements. En
  « normale », Bourso fait environ 15 requêtes par minute à Yahoo une fois les historiques en cache
  (le double le premier jour, le temps de charger 5 ans de séances pour chaque valeur, une valeur
  toutes les 4 s : les favoris d'abord, puis l'Europe).

### Ce que les sources gratuites ne donnent pas

- **Pas de carnet d'ordres, pas de bande des transactions, pas de bougies à la seconde** : il
  faudrait un flux de niveau 2 payant. Ces panneaux sont remplacés par un encadré « Données de cette
  valeur » (source, heure du cours, historique) ; l'unité « seconde » est retirée du graphique.
- La **fourchette** n'est pas publiée : la négociation fictive utilise le dernier cours ± 0,05 % (au
  moins un pas de cotation), et le dit.
- Un ordre fictif n'est exécuté **que pendant la séance de la place**, sur un cours du jour. Hors
  séance, il attend l'ouverture ; un ordre « jour » expire à la fin de sa séance.

### Vérifier depuis ta machine

```bash
npm run data:check            # une requête par source ; ✔ / ✘ avec une piste en cas d'échec
npm run data:check -- --sym MC.PA,AIR.PA,ASML.AS
```

Le même test se lance dans **Réglages → Données de marché**, et la page **Système** montre en
direct l'état de chaque site (requêtes, réussites, refus, pauses, latence, dernière erreur).

### Mode démonstration

Réglages → Données de marché → « Démonstration », ou `BOURSO_MARKET=demo npm start`. Le marché est
alors simulé sur le serveur, hors connexion :

- les 678 actions avec 5 ans de quotidien générés par un modèle à facteurs (corrélations
  réalistes, GARCH, publications de résultats, écarts d'ouverture) ;
- minutes et secondes emboîtées dans les bougies quotidiennes, **carnet d'ordres et bande des
  transactions** simulés ;
- fondamentaux et actualités **simulés**, étiquetés comme tels.

Le portefeuille de démonstration est **séparé** de celui des données réelles, et les décisions de
l'IA aussi : la fiabilité mesurée ne mélange jamais les deux.

## 7. Variables d'environnement

| Variable | Défaut | Rôle |
|---|---|---|
| `BOURSO_PORT` | `3000` | port du serveur |
| `BOURSO_HOST` | `127.0.0.1` | adresse d'écoute (laisser en local) |
| `BOURSO_DATA` | `./data` | réglages, favoris, portefeuilles, signaux, discussions, cache des données (`data/cache`) |
| `BOURSO_MARKET` | réglage enregistré (`real`) | `real` (données réelles) ou `demo` (marché simulé) pour forcer le mode au démarrage |
| `BOURSO_GPU` | `auto` | `off` pour couper le GPU |
| `BOURSO_GPU_INPROCESS` | — | `1` : GPU dans le processus du serveur (débogage seulement) |
| `BOURSO_NO_NATIVE` | — | `1` pour ignorer le module C++ |
| `OLLAMA_HOST` | `127.0.0.1:11434` | serveur Ollama (modifiable aussi dans Réglages) |
| `BOURSO_MODEL_NAME` | `bourso` | modèle utilisé par défaut |
| `BOURSO_MODEL` | `qwen3:30b` | base de `npm run ollama:setup` |

## 8. Tests

```bash
npm test             # 84 tests : maths exactes, quant, marché, IA (garde-fous, JSON, mémoire, lecture tolérante, anti-boucle),
                     # serveur complet avec faux Ollama (sécurité, API, choix du modèle, analyse, agent),
                     # données réelles contre un « faux internet » qui imite exactement Yahoo, la BCE,
                     # Frankfurter, Google Actualités, GDELT et la presse (séance ouverte simulée, 429,
                     # repli, ordres fictifs, bascule réel ↔ démonstration, clés masquées, TTF officielle)
npm run data:check   # les vraies sources, depuis ta machine
npm run test:native  # noyau C++ (Kalman, profil de volume) + micro-bancs
npm run test:gpu     # noyaux WGSL comparés au CPU double précision avec Dawn dans Node (ta carte, sinon Vulkan
                     # logiciel), ramasse-miettes forcé ; plantage simulé du processus GPU → repli CPU
```

## 9. Sécurité

- Le serveur n'écoute qu'en local. Il **refuse** :
  - les en-têtes `Host` étrangers (protection contre le DNS rebinding) ;
  - les écritures venant d'une autre origine ;
  - les corps qui ne sont pas en JSON.
- Aucun ordre ne quitte la machine, et l'agent ne passe jamais d'ordre.
- Les documents (actualités) sont traités comme des **données non fiables** : le modèle ne suit
  aucune instruction qu'ils contiennent, et ils lui sont transmis entre balises de document.
- Les clés d'API ne sortent jamais en clair des réponses du serveur, et sont masquées dans les
  messages d'erreur. Les liens d'articles ne sont suivis que s'ils sont en `http(s)`. Les flux
  ajoutés à la main sont contrôlés (adresse `http(s)` seulement).

## 10. Arborescence

```
bourso/
├── package.json · binding.gyp · README.md
├── docs/                    captures d'écran, notes techniques
├── native/                  C++17 : montecarlo.hpp, backtest.hpp, kalman.hpp, volume_profile.hpp, addon N-API, tests
├── scripts/                 run.js (superviseur : relance + rapport de plantage), setup-ollama.js (modèle « bourso »),
│                            start-demo.js (faux Ollama + Bourso), data-check.js (test des sources)
├── src/
│   ├── server/              main.js, http.js (API REST), ws.js (temps réel), state.js, market-service.js,
│   │                        portfolio.js (ordres, frais, risque), alerts.js, system.js
│   ├── market/              exchanges.js (places, calendriers), universe.js (678 actions), real.js (marché RÉEL : cotations,
│   │                        historiques, intraday, indices, change, actualités), sim.js, gen.js, fx.js, news-sim.js (démonstration)
│   ├── data/                net.js (client poli : débit par site, coupe-circuit, cache), yahoo.js, fx-real.js (BCE),
│   │                        news-real.js (RSS, Google, GDELT), keyed.js (Finnhub, FMP, Twelve Data, Stooq),
│   │                        symbols.js (correspondances de symboles), check.js (test des sources), ttf.js (liste officielle)
│   ├── compute/             service.js (dosage GPU/CPU/workers, repli CPU), gpu.js + kernels.js (Dawn/WGSL),
│   │                        gpu-host.js + gpu-proxy.js (GPU dans un processus isolé), native.js, pool.js, quant.worker.js
│   ├── core/quant/          indicateurs, volatilité, statistiques, hmm, fft, analogues, figures, signaux, backtest,
│   │                        Monte Carlo, TPO, tonalité, dossier IA (code partagé serveur / navigateur)
│   ├── core/math/ · shm/    Kalman, profil de volume, anneau mémoire partagée
│   └── ai/                  analysis.js (dossier → Ollama → garde-fous → signal, mémoire, fiabilité), agent.js + tools.js,
│                            ollama-client.js, prompts.js, schemas.js, guardrails.js, change-policy.js, modelfiles/, faux Ollama
├── web/                     index.html, css/, js/ (app, pages/*, chart/* moteur WebGL et tracés, widgets/*, core/*)
└── test/                    84 tests node:test (dont fixtures/fake-internet.js) + tests natifs
```

---

*Bourso n'est pas un conseil en investissement. Les cours sont différés et peuvent contenir des
erreurs de la source ; en mode démonstration, les données sont simulées. Les performances passées,
réelles ou simulées, ne préjugent pas des performances futures.*
